# VaqtBlok 0.1.0

Android uchun lokal vaqtga asoslangan ilova bloklagichining birinchi test buildi.

## 0.1.0 da mavjud

- Bosh ekranning yuqorisidagi `+` orqali blok yaratish.
- Qurilmada ishga tushiriladigan ilovalar ro‘yxati: ikonka, nom, checkbox.
- Bir blokka bir nechta ilova tanlash.
- Boshlanish va tugash vaqti.
- Hafta kunlarini tanlash.
- Tun orqali o‘tadigan jadval (`22:00 -> 07:00`)ni to‘g‘ri hisoblash.
- Bir nechta mustaqil blok profillari.
- Android Accessibility Service orqali bloklangan ilova oynasini aniqlash va blok ekranini chiqarish.
- 6–12 xonali administrator PIN.
- PIN salt + PBKDF2-HMAC-SHA256 hash ko‘rinishida saqlanadi; ochiq PIN saqlanmaydi. Credential checksum bilan tekshiriladi va primary/backup nusxada saqlanadi.
- PIN himoyalangan blokni o‘chirish, to‘xtatish yoki tahrirlash PIN talab qiladi.
- Blok ekranida to‘g‘ri PIN kiritilsa, ayni blok sessiyasi tugaguncha shu ilovaga bypass beriladi va ilova qayta ochiladi.
- PIN holati yo‘qolgan/buzilgan bo‘lsa `fail-open`: foydalanuvchi ochilmaydigan blok ichida qolmaydi.
- To‘g‘ri PIN bilan bypass barcha ayni paytdagi ustma-ust faol bloklarga bitta sinxron yozuvda beriladi; keyin target ilova ochiladi.
- Blok vaqti boshlanganda target ilova allaqachon ochiq bo‘lsa, Accessibility xizmati har yangi daqiqa chegarasida jadvalni qayta tekshiradi.
- Vaqt logikasi va PIN kriptografiyasi uchun unit testlar.

## Birinchi ishga tushirish

1. APKni o‘rnating va VaqtBlokni oching.
2. `Ruxsatni ochish` tugmasini bosing.
3. Android Accessibility sozlamalarida `VaqtBlok bloklash xizmati`ni yoqing.
4. Ilovaga qayting, `+` bosing, ilovalarni belgilang, vaqt va kunlarni tanlang.
5. PIN himoyasini yoqsangiz, birinchi saqlashda administrator PIN yaratiladi.

## GitHub Actions

`.github/workflows/main.yml` quyidagilarni bajaradi:

- JDK 17
- Android SDK API 37 + Build Tools 36.0.0
- Gradle 9.5.0
- `testDebugUnitTest`
- `lintDebug`
- `assembleDebug`
- `app-debug.apk`ni `VaqtBlok-0.1.0-debug` artifact sifatida yuklaydi.

Workflow maxsus Gradle wrapper JARga bog‘lanmagan: `gradle/actions/setup-gradle@v6` aniq Gradle 9.5.0 ni o‘rnatadi. CI Android SDK o‘rnatilishini 3 martagacha retry qiladi, toolchainni builddan oldin tekshiradi va APK mavjudligini builddan keyin tasdiqlaydi.

## Muhim Android cheklovi

0.1.0 — oddiy consumer rejim. Dastur ichidagi blokni o‘chirish/to‘xtatish PIN bilan himoyalangan, lekin Android Settings orqali VaqtBlokni uninstall/force-stop qilishni oddiy ilova 100% taqiqlay olmaydi. Buning haqiqiy tizim-darajasidagi varianti keyingi `Strict / Device Owner` rejimiga tegishli.

## Failsafe qoidalari

- VaqtBlok o‘zini bloklash uchun ro‘yxatda ko‘rsatmaydi.
- Launcher, Settings, System UI, Permission Controller, Package Installer va default telefon ilovasi tanlashdan chiqarilgan.
- PIN-himoyalangan profil PIN mavjud bo‘lmasa blokni qo‘llamaydi.
- To‘g‘ri PIN verifikatsiyasi bitta markaziy `PinManager` orqali bajariladi.
- Bypass SharedPreferences xotirasiga sinxron ko‘rinadi, shuning uchun Accessibility xizmati target ilova qayta ochilishidan oldin bypassni ko‘radi.
