# Memora 0.9.38 — Harmony UI

An Android e-journal and Topilmalar app (Kotlin / Jetpack Compose / Room).

- `versionName`: **0.9.38**
- `versionCode`: **59**
- Android application ID and debug signing key: unchanged from 0.9.37.
- Room database schema: **8**, unchanged.

## Approved UI changes

See [`docs/RELEASE_0.9.38.md`](docs/RELEASE_0.9.38.md) for U-01–U-06 details and validation boundaries. This version modernizes navigation, note grouping, overlays and language/theme/security settings without migrating the database.

## GitHub / phones

Read [`GITHUB_YUKLASH_YORIQNOMA.md`](GITHUB_YUKLASH_YORIQNOMA.md). The supplied `.github/workflows/android-build.yml` supports both extracted sources and a single `Memora_0.9.38_GitHub.zip` stored in the repository root. The standalone YAML supplied alongside the ZIP is identical.

## Build from extracted sources

`./gradlew :app:testDebugUnitTest :app:lintDebug :app:assembleDebug :app:assembleDebugAndroidTest`

For Android emulator migration checks run `:app:connectedDebugAndroidTest` after provisioning an emulator. Backend is separately tested via `cd backend && npm test`.

**Status:** Static regressions and backend tests pass locally; the full Android APK has not been compiled in this environment. Do not infer build success until GitHub Actions reports success.
