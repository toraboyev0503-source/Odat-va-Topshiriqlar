#!/usr/bin/env python3
"""Memora 0.9.48 offline source-contract regression (not an Android runtime test)."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
J = ROOT / 'app/src/main/java/com/memora/app'
checks = []

def read(path):
    p = ROOT / path
    assert p.exists(), f'Missing: {path}'
    return p.read_text(encoding='utf-8')

def assert_case(title, condition):
    checks.append((title,bool(condition)))

build = read('app/build.gradle.kts')
assert_case('Version 0.9.48', 'versionName = "0.9.48"' in build)
assert_case('VersionCode 69', 'versionCode = 69' in build)
assert_case('Application ID preserved', 'applicationId = "com.memora.app"' in build)
assert_case('Debug signing preserved', 'memora-test-debug.jks' in build)

entities = read('app/src/main/java/com/memora/app/data/local/Entities.kt')
database = read('app/src/main/java/com/memora/app/data/local/AppDatabase.kt')
daos = read('app/src/main/java/com/memora/app/data/local/Daos.kt')
for title, value in [
    ('New album entity', 'data class MemoryAlbumPhotoEntity'),
    ('New memory entity', 'data class MemoryRecallEventEntity'),
]:
    assert_case(title, value in entities and entities.count(value)==1)
assert_case('Room schema 10', 'version = 10' in database)
assert_case('8 to 9 migration', 'Migration(8, 9)' in database)
assert_case('Historical migrations intact', all(f'MIGRATION_{i}_{i+1}' in database for i in range(1,9)))
for table in ['memory_album_photos','memory_recall_events']:
    assert_case('New table '+table, f'CREATE TABLE IF NOT EXISTS `{table}`' in database)
    assert_case('DAO accesses '+table, table in daos)
assert_case('Old photos retained', 'TimeTracePhotoEntity::class' in database)
assert_case('Old Topilmalar retained for migration', 'TopilmaSourceEntity::class' in database)

app = read('app/src/main/java/com/memora/app/ui/MemoraApp.kt')
bar = read('app/src/main/java/com/memora/app/ui/components/MemoraBottomBar.kt')
assert_case('Calendar root tab', 'RootTab.CALENDAR' in app and 'Routes.CALENDAR_ROOT' in app)
assert_case('Calendar in bottom bar', 'onCalendar' in bar and 'CalendarMonth' in bar)
assert_case('New album screen used', 'MemoryAlbumScreen(' in app)
assert_case('Memory settings screen used', 'MemorySettingsScreen(' in app)
assert_case('Legacy Topilmalar route not mounted', 'composable(Routes.TOPILMALAR)' not in app)
assert_case('New data in home', 'onMemoryDismiss' in app and 'onMemoryLater' in app)
assert_case('Notification deep-link note', 'pendingMemoryNote' in app)
assert_case('Notification deep-link camera', 'pendingOpenAlbumCamera' in app)

album = read('app/src/main/java/com/memora/app/ui/screens/MemoryAlbumScreen.kt')
for word in ['ORIGINAL','WARM','VINTAGE','INSTANT','MONO']:
    assert_case('Album filter '+word, word in album)
assert_case('Uses CameraX', 'ProcessCameraProvider' in album and 'ImageCapture' in album)
assert_case('20 word caption', 'words(input) <= 20' in album)
assert_case('Cursive saved caption', 'FontFamily.Cursive' in album)
assert_case('Book pager', 'HorizontalPager' in album and 'rotationY' in album)
assert_case('Photo numbering', 'padStart(3' in album)
assert_case('Original photo kept reversible', 'albumFilter(effect)' in album)

rules=read('app/src/main/java/com/memora/app/memories/MemoryRecallPlanner.kt')
assert_case('Minimum seven days', 'minimumAgeDays: Long = 7' in rules)
assert_case('Old-first weighted selection', 'listOf(0,0,0,0,0,1,1,1,2,2)' in rules)
assert_case('Memoized daily selection seed', 'day.toEpochDay()' in rules)
assert_case('Original hour', 'local.hour, local.minute' in rules)
assert_case('Album min 135/180 gaps', 'count == 5) 135' in rules and 'count == 3) 180' in rules)

scheduler=read('app/src/main/java/com/memora/app/memories/MemoryScheduler.kt')
notification=read('app/src/main/java/com/memora/app/memories/MemoryNotificationReceiver.kt')
assert_case('Daily scheduling', 'NEXT_DAY' in scheduler)
assert_case('Best effort exact alarm', 'canScheduleExactAlarms()' in scheduler)
assert_case('30 day recall history', 'minusDays(30)' in scheduler)
assert_case('Two independent channels', 'NotificationChannels.MEMORIES' in notification and 'NotificationChannels.ALBUM' in notification)
for action in ['DISMISS_MEMORY','SNOOZE_MEMORY','DISMISS_ALBUM','SNOOZE_ALBUM']:
    assert_case('Notification action '+action, action in notification)
assert_case('Notes open directly', 'EXTRA_OPEN_NOTE' in notification)
assert_case('Camera opens directly', 'EXTRA_OPEN_ALBUM_CAMERA' in notification)
assert_case('Photo notification stops after saved photo', 'allMemoryAlbum()' in notification)
assert_case('All language localized action labels', 'MemoryText.get(language' in notification)

backups=read('app/src/main/java/com/memora/app/export/ExportManager.kt')
assert_case('New backup schema 7', 'put("schemaVersion", 7)' in backups)
assert_case('Album backed up', 'put("memoryAlbumPhotos"' in backups)
assert_case('Album zip content', 'memoryAlbumStorage.resolve(photo.relativePath)' in backups)
assert_case('Album restored', 'importPhoto(tmp)' in backups)
assert_case('Room backup in transaction', 'repository.withImportTransaction' in backups)
assert_case('Old Topilma backup preserved', 'TopilmalarBackupCodec.toJson' in backups)

editor=read('app/src/main/java/com/memora/app/ui/screens/EditorScreen.kt')
assert_case('Editor floating back', 'FloatingNoteChrome(' in editor and 'onBack = ::leaveEditor' in editor)
assert_case('Editor initial padding scrolls with content', 'stableNoteStatusInset() + 66.dp' in editor)

prefs=read('app/src/main/java/com/memora/app/prefs/UserPreferences.kt')
for k in ['memoryEnabled', 'memoryDailyCount', 'albumReminderEnabled','albumReminderDailyCount','albumReminderRandom','albumReminderHour','albumReminderMinute']:
    assert_case('User preference '+k, k in prefs)

translations=read('app/src/main/java/com/memora/app/memories/MemoryText.kt')
for language in ['UZ','EN','RU','TR','FR','DE','ES','PT_BR','ID','HI','AR','JA','KO']:
    assert_case('Notification locale '+language, f'AppLanguage.{language} to listOf(' in translations)

# F-01..F-08: Full Canvas visual behavior contracts.
chrome = read('app/src/main/java/com/memora/app/ui/components/FullCanvasNoteChrome.kt')
policy = read('app/src/main/java/com/memora/app/ui/NoteChromeScrollPolicy.kt')
reader = read('app/src/main/java/com/memora/app/ui/screens/ReaderScreen.kt')
app = read('app/src/main/java/com/memora/app/ui/MemoraApp.kt')
assert_case('F-01 host viewport itself has NO global safeDrawing', 'Box(Modifier.fillMaxSize()) {' in app and 'Box(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing))' not in app)
assert_case('F-01 per-route inset preserved outside document', 'if (fullCanvas) Modifier else Modifier.windowInsetsPadding(WindowInsets.safeDrawing)' in app)
assert_case('F-01 Reader is full canvas', 'MemoraNavigationPage(isRootTab = false, reserveBottomSpace = false, fullCanvas = true)' in app and app.count('fullCanvas = true') == 2)
assert_case('F-02 reader physical top scroll viewport', 'state = readerScroll' in reader and 'itemsIndexed(blocks' in reader and 'stableNoteStatusInset() + 66.dp' in reader)
assert_case('F-02 editor physical top scroll viewport', '.verticalScroll(editorScrollState)' in editor and 'stableNoteStatusInset() + 66.dp' in editor)
assert_case('F-03 no Reader TopAppBar', 'MemoraTopBar(' not in reader)
assert_case('F-03 no fixed 52dp editor header', 'Spacer(Modifier.height(52.dp))' not in editor)
assert_case('F-04 shared floating note chrome', all(word in chrome for word in ['FloatingNoteChrome(', 'FloatingNoteControl(', 'statusBarsIgnoringVisibility', 'CircleShape', 'shadowElevation = 2.dp']))
assert_case('F-04 floating pencil in Reader', 'icon = Icons.Rounded.Edit' in reader)
assert_case('F-04 Done saves/exits Editor', 'icon = Icons.Rounded.Done' in editor and 'onClick = ::leaveEditor' in editor)
assert_case('F-05 small scroll directional policy', 'NoteChromeScrollPolicy(thresholdPx)' in chrome and 'SCROLL_THRESHOLD_DP = 16' in chrome)
assert_case('F-05 170ms show, 140ms hide', 'CHROME_SHOW_MS = 170' in chrome and 'CHROME_HIDE_MS = 140' in chrome)
assert_case('F-05 tap without consuming event', 'PointerEventPass.Initial' in chrome and 'currentPointer.position - start' in chrome and '.consume(' not in chrome)
assert_case('F-05 editing and reading both observe taps', '.showNoteChromeOnTap {' in reader and '.showNoteChromeOnTap {' in editor)
assert_case('F-05 editor controls observe scroll state', 'rememberNoteChromeVisibility(editorScrollState)' in editor)
assert_case('F-06 revised: no fixed Reader top bar', 'MemoraTopBar(' not in reader and 'ReaderPaperSegment(' in reader)
assert_case('F-06 revised: same document card for both editor types', 'NotePaper {' in editor and 'blockContent(\n                Modifier.fillMaxWidth().weight(1f)' in editor)
assert_case('F-07 reader/editor position hand-off', 'readerFraction' in reader and 'readerFraction' in editor and '.readerFraction' in reader and '.readerFraction' in editor)
assert_case('F-07 keyboard/IME protection', '.imePadding().navigationBarsPadding()' in editor)
assert_case('F-08 48dp control and theme colors', 'ACTION_DIAMETER_DP = 48' in chrome and 'MaterialTheme.colorScheme.surface' in chrome)
assert_case('F-08 rooted navigation bar respects inset', '.windowInsetsPadding(WindowInsets.navigationBars)' in app)
assert_case('F-08 Quiet Navigation remains', 'QuietNavigationPolicy.DETAIL_DURATION_MS' in app)
assert_case('F-08 Room schema stays at 9', 'version = 10' in database)
assert_case('F-08 debug signing identity unchanged', 'getByName("debug")' in build and 'memora-test-debug.jks' in build)

# F-09..F-15: full-page paper, footer dates and dynamic system bar.
paper = read('app/src/main/java/com/memora/app/ui/components/NotePaper.kt')
bar_effect = read('app/src/main/java/com/memora/app/ui/components/NoteStatusBarEffect.kt')
bar_policy = read('app/src/main/java/com/memora/app/ui/NoteStatusBarPolicy.kt')
bar_test = read('app/src/test/java/com/memora/app/ui/NoteStatusBarPolicyTest.kt')
assert_case('F-09 actual system bar toggled', 'controller.hide(WindowInsetsCompat.Type.statusBars())' in bar_effect and 'controller.show(WindowInsetsCompat.Type.statusBars())' in bar_effect)
assert_case('F-09 status bar restored on disposal', 'onDispose { controller.show(WindowInsetsCompat.Type.statusBars()) }' in bar_effect)
assert_case('F-09 status bar scroll hysteresis', 'scrollPx >= hideAtPx' in bar_policy and 'scrollPx <= restoreAtPx' in bar_policy)
assert_case('F-09 status bar scroll unit tests', 'smallReverseScrollDoesNotCauseStatusBarFlicker' in bar_test)
assert_case('F-09 stable top inset when hidden', 'ViewCompat.getRootWindowInsets(view)' in bar_effect and 'stableNoteStatusInset()' in chrome)
assert_case('F-09 status effect in reader and editor', 'NoteStatusBarEffect(readerScroll)' in reader and 'NoteStatusBarEffect(editorScrollState)' in editor)
assert_case('F-10 passive save labels removed', 'savingStatusText(' not in editor and 'savedStatusText(' not in editor and 'Saqlanmoqda' not in editor)
assert_case('F-10 save errors still visible', 'showSaveFailure()' in editor and 'MemoraFeedbackHost(' in editor)
assert_case('F-11 shared document surface', 'fun NotePaper(' in paper and 'Surface(' in paper and 'Column(' in paper)
assert_case('F-11 Reader document in paper', 'ReaderPaperSegment(' in reader and 'itemsIndexed(blocks' in reader)
assert_case('F-11 Editor document in paper', 'NotePaper {' in editor and 'blocks.forEachIndexed' in editor)
assert_case('F-11 no nested scrolling paper', '.verticalScroll(' not in paper)
assert_case('P-01 39sp Reader title', 'fontSize = 39.sp, lineHeight = 48.sp' in reader)
assert_case('P-01 39sp Editor title', 'fontSize = 39.sp, lineHeight = 48.sp' in editor)
assert_case('F-13 shared date footer', 'fun NoteDatesFooter(' in paper)
assert_case('F-13 Reader dates moved below hashtags', reader.index('NoteDatesFooter(') > reader.index('HashtagChips('))
assert_case('F-13 Editor dates moved below hashtags', editor.index('NoteDatesFooter(') > editor.index('HashtagChips('))
assert_case('F-13 no upper date chips in Reader', 'ReaderMetaChip(' not in reader)
assert_case('F-13 edited date suppressed for unchanged note', 'updatedAt > createdAt + 1000L' in editor and 'updatedAt > note.createdAt + 1000L' in reader)
assert_case('F-14 controls use stable inset', 'padding(top = stableNoteStatusInset())' in chrome)
assert_case('F-14 floating controls remain separate', 'FloatingNoteChrome(' in reader and 'FloatingNoteChrome(' in editor)
assert_case('F-15 title animation removed to avoid layout jitter', 'animateContentSize()' not in editor)
assert_case('F-15 keyboard-aware viewport kept', '.imePadding().navigationBarsPadding()' in editor)
assert_case('F-15 editor position persistence preserved', 'persistEditorPosition()' in editor)
assert_case('F-15 Room schema not modified', 'version = 10' in database)


# P-01 .. P-09 code-contract checks. These are static, not proof of APK compilation.
reader = read('app/src/main/java/com/memora/app/ui/screens/ReaderScreen.kt')
editor = read('app/src/main/java/com/memora/app/ui/screens/EditorScreen.kt')
share = read('app/src/main/java/com/memora/app/share/ReaderShareManager.kt')
renderer = read('app/src/main/java/com/memora/app/share/PaperShareRenderer.kt')
selector = read('app/src/main/java/com/memora/app/ui/components/ReaderSelectionParagraph.kt')
block = read('app/src/main/java/com/memora/app/data/model/NoteBlocks.kt')
policy = read('app/src/main/java/com/memora/app/data/model/NoteHighlightPolicy.kt')
rich = read('app/src/main/java/com/memora/app/ui/components/RichTextEditor.kt')
repo = read('app/src/main/java/com/memora/app/data/repository/MemoraRepository.kt')
dao = read('app/src/main/java/com/memora/app/data/local/Daos.kt')
for title, condition in [
    ('P-01 Reader title at 39sp', 'fontSize = 39.sp, lineHeight = 48.sp' in reader),
    ('P-01 Editor title at 39sp', 'fontSize = 39.sp, lineHeight = 48.sp' in editor),
    ('P-02 Shared Paper renderer', 'PaperShareRenderer(context)' in share),
    ('P-02 Paper content including image and audio', 'is NoteBlock.Image' in renderer and 'is NoteBlock.Audio' in renderer),
    ('P-03 Multi-page PNG', 'fun render(note:' in renderer and 'nextPage()' in renderer),
    ('P-03 PDF export', 'fun sharePdf(' in share and 'PdfDocument()' in share),
    ('P-03 HTML shares title, spans and dates', '<h1>' in share and 'BackgroundColorSpan' in renderer and 'class=' in share and 'dates' in share),
    ('P-03 Preview surface', 'actionLabels.preview' in reader),
    ('P-04 No top delete menu', 'Icons.Rounded.MoreVert' not in reader and 'DropdownMenuItem(' not in reader),
    ('P-04 Bottom delete retained', 'ReaderAction(' in reader and 'Icons.Rounded.DeleteOutline' in reader),
    ('P-05 Readonly selectable text', 'BasicTextField(' in selector and 'readOnly = true' in selector),
    ('P-05 Native clipboard', 'clipboard.setText(AnnotatedString(selected))' in selector),
    ('P-06 Color policy', all(x in policy for x in ['YELLOW','GREEN','ROSE'])),
    ('P-06 Persistent inline JSON', 'put(\"highlight\", it)' in block and 'optString(\"highlight\")' in block),
    ('P-06 Editor preserving spans', 'highlightComposeColor(span.highlight)' in rich),
    ('P-06 Optimistic database update', 'changeStyleSpans' in dao and 'current.blocksJson' in repo),
    ('P-07 Selected text sharing', 'shareSelectionImage(' in share and 'shareSelection(' in share),
    ('H-08 no search state', 'searchOpen' not in reader and 'searchQuery' not in reader),
    ('H-09 no search icon', 'Icons.Rounded.Search' not in reader),
    ('P-09 13 locales', selector.count('AppLanguage.') >= 13),
    ('P-09 Existing Room 9 retained', 'version = 10' in database),
    ('P-09 Backup uses blocksJson', 'put(\"blocksJson\", n.blocksJson)' in backups),
]: assert_case(title, condition)

# H-01..H-09 + selection-sized cards (0.9.44): static source contracts.
selector = read('app/src/main/java/com/memora/app/ui/components/ReaderSelectionParagraph.kt')
renderer = read('app/src/main/java/com/memora/app/share/PaperShareRenderer.kt')
manager = read('app/src/main/java/com/memora/app/share/ReaderShareManager.kt')
policy = read('app/src/main/java/com/memora/app/data/model/NoteHighlightPolicy.kt')
size_policy = read('app/src/main/java/com/memora/app/share/SelectionPaperDimensions.kt')
marker_tests = read('app/src/test/java/com/memora/app/data/model/NoteHighlightPolicyTest.kt')
size_tests = read('app/src/test/java/com/memora/app/share/SelectionPaperDimensionsTest.kt')
for label, condition in [
    ('H-01 native selection menu replaced by local Memora toolbar', 'LocalTextToolbar provides memoraToolbar' in selector and 'object : TextToolbar' in selector),
    ('H-01 native handles retained', 'BasicTextField(' in selector and 'readOnly = true' in selector),
    ('H-02 only three normal selection actions', 'MemoraSelectionItem(labels.copy)' in selector and 'MemoraSelectionItem(labels.image)' in selector and 'Text(labels.marker' in selector),
    ('H-03 default marker one-tap, chooser long-tap', 'onClick = { applyMarker(defaultColor) }' in selector and 'onLongClick = { colorPickerOpen = true }' in selector),
    ('H-04 persistent default marker', 'getSharedPreferences("memora_reader_marker"' in selector and 'putString("default_color", shade)' in selector),
    ('H-05 tapping colored region selects whole run', 'NoteHighlightPolicy.runAt(block, offset)' in selector and 'TextRange(run.start, run.end)' in selector),
    ('H-05 marker run recognizes contiguous shade', 'while (right < block.text.length && colorAt(right) == color)' in policy),
    ('H-06 one-tap X remove and three recolors', 'MemoraSelectionItem("✕") { applyMarker(null) }' in selector and 'MarkerColorCircle(shade, activeRun.color == shade' in selector),
    ('H-07 authentic actual app icon in full PNG footer', 'context.applicationInfo.loadIcon(context.packageManager)' in renderer and 'drawSignature(canvas, 1430f, number)' in renderer),
    ('H-08 reader no search icon', 'Icons.Rounded.Search' not in reader),
    ('H-09 no search panel', 'searchOpen' not in reader and 'searchQuery' not in reader),
    ('selection height from actual StaticLayout', 'val layout = makeLayout(part, textPaint, 1.28f)' in renderer and 'heightForText(layout.height)' in renderer),
    ('short cards do not use full-page height', 'Bitmap.createBitmap(width, pageHeight' in renderer and 'pageHeight' in renderer),
    ('long selections paginate', 'while (remaining.isNotEmpty())' in renderer and 'getLineEnd' in renderer),
    ('selection preview exposes Save and Share', 'selectionImageSave.launch' in reader and 'shareSelectionFiles(selectedImageFiles' in reader),
    ('multiselection saved as ZIP', 'selectionZipSave.launch' in reader and 'ZipOutputStream' in reader),
    ('renderer and preview both use selection renderer', 'renderer.renderSelection(selection)' in manager and 'shareManager.renderSelectionImages(selected)' in reader),
    ('room retained', 'version = 10' in database),
    ('highlight run unit tests added', 'tappingHighlightFindsWholeRun' in marker_tests and 'deletingMarkerMakesItPlainText' in marker_tests),
    ('card height unit tests added', 'threeLinesMakeCompactCard' in size_tests and 'heightTracksMeasuredLayout' in size_tests),
    ('minimum selection height policy sane', 'TEXT_TOP = 98' in size_policy and 'FOOTER_SPACE = 158' in size_policy),
]: assert_case(label, condition)



# 0.9.48: Android native context menu regression. The legacy toolbar alone is not sufficient
# for Compose Foundation 1.9+; ensure the modern provider is replaced as well.
selector = read('app/src/main/java/com/memora/app/ui/components/ReaderSelectionParagraph.kt')
assert_case('Fix: modern Compose toolbar provider intercepted', 'LocalTextContextMenuToolbarProvider provides suppressPlatformMenu' in selector)
assert_case('Fix: modern Compose dropdown provider intercepted', 'LocalTextContextMenuDropdownProvider provides suppressPlatformMenu' in selector)
assert_case('Fix: modern provider awaits cancellation, no native Android popup', 'override suspend fun showTextContextMenu(dataProvider: TextContextMenuDataProvider)' in selector and 'awaitCancellation()' in selector)
assert_case('Fix: legacy TextToolbar also intercepted', 'LocalTextToolbar provides memoraToolbar' in selector)
assert_case('Fix: custom menu is derived from selection, not native showMenu', 'val selectionBarRect = if (selectionEnd > selectionStart)' in selector and 'selectionBarRect ?: nativeMenuRect' in selector)
assert_case('Fix: user requested 3 buttons retained', 'MemoraSelectionItem(labels.copy)' in selector and 'MemoraSelectionItem(labels.image)' in selector and 'Text(labels.marker' in selector)
assert_case('Fix: active highlight quick edit retained', 'MemoraSelectionItem("✕")' in selector and 'MarkerColorCircle(shade, activeRun.color == shade' in selector)
assert_case('Fix: drag handles selection retained', 'BasicTextField(' in selector and 'readOnly = true' in selector and 'TextRange(run.start, run.end)' in selector)

# O-01 to O-09: Performance Foundation must stay compatible with editor and data safety.
summaries = read('app/src/main/java/com/memora/app/data/local/NoteSummary.kt')
search_query = read('app/src/main/java/com/memora/app/data/repository/NoteSearchQuery.kt')
benchmark = read('tools/benchmark_0946.py')
image_cache = read('app/src/main/java/com/memora/app/media/DisplayBitmapCache.kt')
media_blocks = read('app/src/main/java/com/memora/app/ui/components/MediaBlocks.kt')
read_tests = read('app/src/test/java/com/memora/app/data/model/NoteFastEditTest.kt')
search_tests = read('app/src/test/java/com/memora/app/data/repository/NoteSearchQueryTest.kt')
for title, ok in [
    ('O-01 global full note Flow removed', 'val allNotes by repository.observeAllNotes()' not in app),
    ('O-01 summary projection excludes heavy text', 'substr(plainText, 1, 360)' in daos and 'contentHtml' not in daos.split('fun observeSummaries()')[0].split('SELECT id, type, title')[-1]),
    ('O-01 only current note fully loaded in home', 'currentMemoryNoteFlow' in app),
    ('O-01 Calendar observes summaries only', 'repository.observeNoteSummaries()' in app),
    ('O-01 list summary cannot be saved', 'fun asCardEntity()' in summaries and 'contentHtml = ""' in summaries),
    ('O-02 Room PagingSource with bound filters', 'fun pageSummaries(query: SupportSQLiteQuery): PagingSource<Int, NoteSummary>' in daos),
    ('O-02 Paging3 integration', 'paging-compose:3.4.2' in build and 'room-paging:2.8.4' in build),
    ('O-02 Paging3 lazy UI', 'collectAsLazyPagingItems()' in read('app/src/main/java/com/memora/app/ui/screens/NotesHubScreen.kt')),
    ('O-03 Reader virtual blocks', 'itemsIndexed(blocks, key = { _, block -> block.id })' in reader and 'ReaderPaperSegment' in reader),
    ('O-03 reader retains selection/highlights', 'ReaderSelectionParagraph(' in reader and 'setNoteHighlight(' in reader),
    ('O-03 preserves reader scroll and editor hand-off', 'rememberLazyListState()' in reader and 'readerFraction' in reader),
    ('O-04 snapshot built only after 900ms', editor.index('delay(900)') < editor.index('val snapshot = snapshotNow()', editor.index('delay(900)'))),
    ('O-04 stats delayed work', 'produceState(initialValue = "", key1 = blocks)' in editor),
    ('O-04 fast text edits', 'Fast path for ordinary IME input' in block and 'updated[target] = original.copy' in block),
    ('O-05 FTS4 content index', 'CREATE VIRTUAL TABLE IF NOT EXISTS notes_fts' in database),
    ('O-05 FTS migration 9->10 preserved', 'Migration(9, 10)' in database and 'MIGRATION_8_9' in database),
    ('O-05 FTS write triggers', all(t in database for t in ['notes_fts_insert','notes_fts_update','notes_fts_delete'])),
    ('O-05 fresh installs initialize FTS', 'MIGRATION_9_10.migrate(db)' in database),
    ('O-05 parameterized FTS', 'notes_fts MATCH ?' in search_query and 'args.toTypedArray()' in search_query),
    ('O-05 search test added', 'operatorsCannotEscapeQuotedFtsTerms' in search_tests),
    ('O-06 images decoded off main and cached', 'withContext(Dispatchers.IO)' in media_blocks and 'DisplayBitmapCache.get(fileKey)' in media_blocks),
    ('O-06 bounded image LRU', 'LruCache<String, Bitmap>(MAX_BYTES)' in image_cache),
    ('O-07 saving keeps mutex and recovery', 'saveMutex.withLock' in editor and 'recoveryStore.write(' in editor),
    ('O-07 export still off main', 'withContext(Dispatchers.IO)' in share),
    ('O-08 non-debuggable R8 release retained', 'isMinifyEnabled = true' in build and 'isDebuggable = false' in build),
    ('O-08 baseline rules present', read('app/src/main/baseline-prof.txt').startswith('HSPL')),
    ('O-09 synthetic sizes 140/1000/5000/10000', '[140,1000,5000,10000]' in benchmark),
    ('O-09 regression edit stress test', 'editsOnlyTargetParagraph' in read_tests),
    ('O-09 Room migration instrumentation', 'upgradeThreeToTenPreservesLegacyNoteAndIndexesSearch' in read('app/src/androidTest/java/com/memora/app/data/local/AppDatabaseMigrationTest.kt')),
    ('Safety: versionCode 67 and Room 10', 'versionCode = 69' in build and 'version = 10' in database),
]: assert_case(title, ok)

passed=sum(good for _,good in checks)
for title,good in checks:
    if not good: print('FAIL',title)
print(f'Memora 0.9.48 regression: {passed}/{len(checks)} passed')
if passed != len(checks):sys.exit(1)
