# Memora 0.9.48 — measured performance and safe first optimizations

This is stage 2 following diagnostic 0.9.47. **No schema migration, no note text/media transformations.**

Implemented changes:
- Move the Home count, album photo, nostalgia recall; album page; title editor/list; and reminder collectors *inside their respective destinations*, rather than invalidating root navigation.
- Parse the reader block JSON on `Dispatchers.Default`; cancellation discards superseded work. UI retains its existing `LazyColumn`, highlight and media components. The initial empty block list is transient while loading.
- Parse editor initialization/recovery JSON on `Dispatchers.Default`; all existing auto-save, cursor and recovery logic is unchanged.
- Retain 0.9.47 performanceProbe/JankStats/Macrobenchmark and tracing hooks.

Intentionally **not** changed without measured evidence: Room schema/media count triggers, notes data format, `onStop()` lock timestamp synchronous commit, editor live text-input update design, audio recorder, attachments storage, backup format, export, themes, subscription, navigation animation.

### Validation gate
- Check identical notes and media before/after update using a user backup.
- Install both Stage 1 probe and Stage 2 probe on same device; compare p50/p95 navigation, jank count, StartupTimingMetrics; stable 140-note test dataset.
- Test editor autosave/recovery/format spans, Reader highlight changes, camera, album, and share with actual device.
- Neither performance improvement nor absence of UI regressions is claimed before device tests.
