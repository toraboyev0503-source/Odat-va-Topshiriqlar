@echo off
chcp 65001 >nul
title So'z yodlash - ishga tushirish
cd /d "%~dp0"

where flutter >nul 2>nul
if errorlevel 1 (
  echo XATO: Flutter topilmadi.
  pause
  exit /b 1
)

call flutter pub get
if errorlevel 1 goto error
call flutter run
if errorlevel 1 goto error
exit /b 0

:error
echo.
echo Ishga tushirishda xatolik yuz berdi. Yuqoridagi xato matnini rasmga olib yuboring.
pause
exit /b 1

