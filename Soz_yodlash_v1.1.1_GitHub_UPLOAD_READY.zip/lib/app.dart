import 'dart:async';

import 'package:flutter/material.dart';

import 'screens/home_screen.dart';
import 'screens/lesson_detail_screen.dart';
import 'services/lesson_repository.dart';
import 'services/notification_service.dart';
import 'services/progress_database.dart';
import 'theme/app_theme.dart';

class SozYodlashApp extends StatefulWidget {
  const SozYodlashApp({
    super.key,
    required this.lessonRepository,
    required this.progressDatabase,
    required this.notificationService,
    this.initialNotificationPayload,
  });

  final LessonRepository lessonRepository;
  final ProgressDatabase progressDatabase;
  final NotificationService notificationService;
  final String? initialNotificationPayload;

  @override
  State<SozYodlashApp> createState() => _SozYodlashAppState();
}

class _SozYodlashAppState extends State<SozYodlashApp> {
  final GlobalKey<NavigatorState> _navigatorKey = GlobalKey<NavigatorState>();
  final GlobalKey<ScaffoldMessengerState> _messengerKey =
      GlobalKey<ScaffoldMessengerState>();
  StreamSubscription<String?>? _notificationTapSubscription;
  bool _openingNotificationTarget = false;

  @override
  void initState() {
    super.initState();
    _notificationTapSubscription = widget.notificationService.tapStream.listen(
      _handleNotificationPayload,
    );
    final initialPayload = widget.initialNotificationPayload;
    if (initialPayload != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _handleNotificationPayload(initialPayload);
      });
    }
  }

  @override
  void dispose() {
    _notificationTapSubscription?.cancel();
    super.dispose();
  }

  Future<void> _handleNotificationPayload(String? payload) async {
    if (payload != NotificationService.openLastCompletedLessonPayload ||
        _openingNotificationTarget) {
      return;
    }
    _openingNotificationTarget = true;
    try {
      final wordCountsByLevel = <String, Map<int, int>>{};
      for (final levelId in const ['A1', 'A2', 'B1', 'B2', 'C1', 'C2']) {
        if (widget.lessonRepository.isAvailable(levelId)) {
          wordCountsByLevel[levelId] = widget.lessonRepository.wordCountsFor(
            levelId,
          );
        }
      }

      final location = await widget.progressDatabase.resolveLastCompletedLesson(
        wordCountsByLevel: wordCountsByLevel,
      );
      if (!mounted) return;
      if (location == null) {
        _messengerKey.currentState?.showSnackBar(
          const SnackBar(
            content: Text(
              'Hali tugallangan dars yo‘q. Avval kamida bitta mashqni yakunlang.',
            ),
          ),
        );
        return;
      }

      final lesson = widget.lessonRepository.lesson(
        location.level,
        location.lessonNumber,
      );
      final navigator = _navigatorKey.currentState;
      if (navigator == null) return;
      await navigator.pushAndRemoveUntil<void>(
        MaterialPageRoute(
          builder: (_) => LessonDetailScreen(
            lesson: lesson,
            progressDatabase: widget.progressDatabase,
          ),
        ),
        (route) => route.isFirst,
      );
    } catch (_) {
      _messengerKey.currentState?.showSnackBar(
        const SnackBar(content: Text('Oxirgi bajarilgan darsni ochib bo‘lmadi.')),
      );
    } finally {
      _openingNotificationTarget = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      navigatorKey: _navigatorKey,
      scaffoldMessengerKey: _messengerKey,
      debugShowCheckedModeBanner: false,
      title: 'So‘z yodlash',
      theme: AppTheme.light(),
      home: HomeScreen(
        lessonRepository: widget.lessonRepository,
        progressDatabase: widget.progressDatabase,
        notificationService: widget.notificationService,
      ),
    );
  }
}
