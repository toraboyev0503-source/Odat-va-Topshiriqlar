import 'package:flutter/material.dart';

import 'app.dart';
import 'services/lesson_repository.dart';
import 'services/notification_service.dart';
import 'services/progress_database.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final lessonRepository = await LessonRepository.load();
  final progressDatabase = ProgressDatabase.instance;
  await progressDatabase.database;

  final notificationService = NotificationService.instance;
  String? initialNotificationPayload;
  try {
    initialNotificationPayload = await notificationService.initialize();
    final reminders = await progressDatabase.loadReminders();
    await notificationService.rescheduleEnabledReminders(reminders);
  } catch (_) {
    // Bildirishnoma tizimidagi muammo ilovaning asosiy dars funksiyalarini
    // ochilmay qolishiga sabab bo‘lmasligi kerak.
  }

  runApp(
    SozYodlashApp(
      lessonRepository: lessonRepository,
      progressDatabase: progressDatabase,
      notificationService: notificationService,
      initialNotificationPayload: initialNotificationPayload,
    ),
  );
}
