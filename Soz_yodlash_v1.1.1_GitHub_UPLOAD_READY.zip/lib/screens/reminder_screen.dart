import 'package:flutter/material.dart';

import '../models/reminder.dart';
import '../services/notification_service.dart';
import '../services/progress_database.dart';

class ReminderScreen extends StatefulWidget {
  const ReminderScreen({
    super.key,
    required this.progressDatabase,
    required this.notificationService,
  });

  final ProgressDatabase progressDatabase;
  final NotificationService notificationService;

  @override
  State<ReminderScreen> createState() => _ReminderScreenState();
}

class _ReminderScreenState extends State<ReminderScreen> {
  List<DailyReminder> _reminders = const [];
  bool _loading = true;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  Future<void> _reload() async {
    final reminders = await widget.progressDatabase.loadReminders();
    if (!mounted) return;
    setState(() {
      _reminders = reminders;
      _loading = false;
    });
  }

  Future<TimeOfDay?> _pickTime([DailyReminder? reminder]) {
    final now = TimeOfDay.now();
    return showTimePicker(
      context: context,
      initialTime: reminder == null
          ? now
          : TimeOfDay(hour: reminder.hour, minute: reminder.minute),
      helpText: reminder == null ? 'Eslatma vaqtini tanlang' : 'Vaqtni o‘zgartiring',
      cancelText: 'Bekor qilish',
      confirmText: 'Saqlash',
    );
  }

  Future<bool> _ensurePermission() async {
    final granted = await widget.notificationService.requestPermission();
    if (!granted && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Bildirishnoma ruxsati berilmadi. Telefon sozlamalaridan ruxsatni yoqing.',
          ),
        ),
      );
    }
    return granted;
  }

  Future<void> _addReminder() async {
    if (_busy) return;
    final time = await _pickTime();
    if (time == null || !mounted) return;
    if (!await _ensurePermission()) return;

    setState(() => _busy = true);
    try {
      final reminder = await widget.progressDatabase.createReminder(
        hour: time.hour,
        minute: time.minute,
      );
      await widget.notificationService.scheduleDaily(reminder);
      await _reload();
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Eslatmani saqlab bo‘lmadi.')),
      );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _editReminder(DailyReminder reminder) async {
    if (_busy) return;
    final time = await _pickTime(reminder);
    if (time == null || !mounted) return;

    setState(() => _busy = true);
    try {
      final updated = reminder.copyWith(hour: time.hour, minute: time.minute);
      await widget.progressDatabase.updateReminder(updated);
      if (updated.enabled) {
        if (!await _ensurePermission()) {
          final disabled = updated.copyWith(enabled: false);
          await widget.progressDatabase.updateReminder(disabled);
          await widget.notificationService.cancel(disabled.id);
        } else {
          await widget.notificationService.scheduleDaily(updated);
        }
      }
      await _reload();
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Eslatma vaqtini o‘zgartirib bo‘lmadi.')),
      );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _toggleReminder(DailyReminder reminder, bool enabled) async {
    if (_busy) return;
    if (enabled && !await _ensurePermission()) return;

    setState(() => _busy = true);
    try {
      final updated = reminder.copyWith(enabled: enabled);
      await widget.progressDatabase.updateReminder(updated);
      if (enabled) {
        await widget.notificationService.scheduleDaily(updated);
      } else {
        await widget.notificationService.cancel(updated.id);
      }
      await _reload();
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Eslatma holatini o‘zgartirib bo‘lmadi.')),
      );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _deleteReminder(DailyReminder reminder) async {
    if (_busy) return;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Eslatma o‘chirilsinmi?'),
        content: Text('${reminder.timeLabel} dagi kundalik eslatma o‘chiriladi.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Bekor qilish'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('O‘chirish'),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;

    setState(() => _busy = true);
    try {
      await widget.notificationService.cancel(reminder.id);
      await widget.progressDatabase.deleteReminder(reminder.id);
      await _reload();
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Eslatmani o‘chirib bo‘lmadi.')),
      );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Bildirishnomalar',
          style: TextStyle(fontWeight: FontWeight.w900),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _busy ? null : _addReminder,
        icon: const Icon(Icons.add_alarm_rounded),
        label: const Text('Eslatma qo‘shish'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.fromLTRB(14, 8, 14, 100),
              children: [
                Container(
                  padding: const EdgeInsets.all(15),
                  decoration: BoxDecoration(
                    color: const Color(0xFFEFF3FF),
                    borderRadius: BorderRadius.circular(17),
                    border: Border.all(color: const Color(0xFFD8E1FF)),
                  ),
                  child: const Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(Icons.notifications_active_outlined),
                      SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          'Har bir eslatma har kuni tanlangan vaqtda keladi. Ilova ichida eslatmalar soniga sun’iy cheklov qo‘yilmagan.',
                          style: TextStyle(height: 1.4),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 14),
                if (_reminders.isEmpty)
                  const _EmptyReminderCard()
                else
                  for (final reminder in _reminders) ...[
                    _ReminderCard(
                      reminder: reminder,
                      enabled: !_busy,
                      onTap: () => _editReminder(reminder),
                      onChanged: (value) => _toggleReminder(reminder, value),
                      onDelete: () => _deleteReminder(reminder),
                    ),
                    const SizedBox(height: 10),
                  ],
              ],
            ),
    );
  }
}

class _ReminderCard extends StatelessWidget {
  const _ReminderCard({
    required this.reminder,
    required this.enabled,
    required this.onTap,
    required this.onChanged,
    required this.onDelete,
  });

  final DailyReminder reminder;
  final bool enabled;
  final VoidCallback onTap;
  final ValueChanged<bool> onChanged;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(17),
      child: InkWell(
        onTap: enabled ? onTap : null,
        borderRadius: BorderRadius.circular(17),
        child: Container(
          padding: const EdgeInsets.fromLTRB(14, 10, 8, 10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(17),
            border: Border.all(color: const Color(0xFFE0E4EE)),
          ),
          child: Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: const Color(0xFFEDF1FF),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: const Icon(
                  Icons.alarm_rounded,
                  color: Color(0xFF3156D9),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      reminder.timeLabel,
                      style: const TextStyle(
                        fontSize: 21,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      reminder.enabled ? 'Har kuni' : 'O‘chirilgan',
                      style: const TextStyle(color: Color(0xFF747C8E)),
                    ),
                  ],
                ),
              ),
              Switch(
                value: reminder.enabled,
                onChanged: enabled ? onChanged : null,
              ),
              IconButton(
                tooltip: 'O‘chirish',
                onPressed: enabled ? onDelete : null,
                icon: const Icon(Icons.delete_outline_rounded),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _EmptyReminderCard extends StatelessWidget {
  const _EmptyReminderCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(17),
        border: Border.all(color: const Color(0xFFE0E4EE)),
      ),
      child: const Column(
        children: [
          Icon(Icons.notifications_none_rounded, size: 42),
          SizedBox(height: 10),
          Text(
            'Hozircha eslatma yo‘q',
            style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16),
          ),
          SizedBox(height: 5),
          Text(
            'Pastdagi “Eslatma qo‘shish” tugmasi orqali kerakli vaqtlarni kiriting.',
            textAlign: TextAlign.center,
            style: TextStyle(color: Color(0xFF747C8E), height: 1.4),
          ),
        ],
      ),
    );
  }
}
