import 'package:flutter/material.dart';

import '../models/lesson.dart';
import '../models/practice.dart';
import '../services/lesson_repository.dart';
import '../services/progress_database.dart';
import '../theme/app_theme.dart';
import 'lesson_detail_screen.dart';

class LessonListScreen extends StatefulWidget {
  const LessonListScreen({
    super.key,
    required this.levelId,
    required this.lessonRepository,
    required this.progressDatabase,
  });

  final String levelId;
  final LessonRepository lessonRepository;
  final ProgressDatabase progressDatabase;

  @override
  State<LessonListScreen> createState() => _LessonListScreenState();
}

class _LessonListScreenState extends State<LessonListScreen> {
  Map<int, LessonProgress> _progress = {};
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadProgress();
  }

  Future<void> _loadProgress() async {
    final result = await widget.progressDatabase.loadLevelProgress(
      level: widget.levelId,
      wordCountsByLesson: widget.lessonRepository.wordCountsFor(widget.levelId),
    );
    if (!mounted) return;
    setState(() {
      _progress = result;
      _loading = false;
    });
  }

  Future<void> _openLesson(Lesson lesson) async {
    await Navigator.of(context).push<void>(
      MaterialPageRoute(
        builder: (_) => LessonDetailScreen(
          lesson: lesson,
          progressDatabase: widget.progressDatabase,
        ),
      ),
    );
    await _loadProgress();
  }

  @override
  Widget build(BuildContext context) {
    final lessons = widget.lessonRepository.lessonsFor(widget.levelId);
    final completed = _progress.values
        .where((progress) => progress.hasCompletedExercise)
        .length;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          '${widget.levelId} darslari',
          style: const TextStyle(fontWeight: FontWeight.w900),
        ),
      ),
      body: RefreshIndicator(
        onRefresh: _loadProgress,
        child: ListView.separated(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(14, 8, 14, 28),
          itemCount: lessons.length + 1,
          separatorBuilder: (_, index) =>
              SizedBox(height: index == 0 ? 14 : 10),
          itemBuilder: (context, index) {
            if (index == 0) {
              return _LevelSummary(
                levelId: widget.levelId,
                completedLessons: completed,
                totalLessons: lessons.length,
                loading: _loading,
              );
            }
            final lesson = lessons[index - 1];
            return _LessonCard(
              lesson: lesson,
              progress: _progress[lesson.number] ?? const LessonProgress(),
              onTap: () => _openLesson(lesson),
            );
          },
        ),
      ),
    );
  }
}

class _LevelSummary extends StatelessWidget {
  const _LevelSummary({
    required this.levelId,
    required this.completedLessons,
    required this.totalLessons,
    required this.loading,
  });

  final String levelId;
  final int completedLessons;
  final int totalLessons;
  final bool loading;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF3156D9), Color(0xFF617CE4)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '$levelId • 60 ta dars',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  '$completedLessons/$totalLessons darsda kamida bitta mashq tugallangan',
                  style: TextStyle(
                    color: Colors.white.withAlpha(215),
                    height: 1.35,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          if (loading)
            const CircularProgressIndicator(color: Colors.white)
          else
            Text(
              '${(completedLessons / totalLessons * 100).round()}%',
              style: const TextStyle(
                color: Colors.white,
                fontSize: 25,
                fontWeight: FontWeight.w900,
              ),
            ),
        ],
      ),
    );
  }
}

class _LessonCard extends StatelessWidget {
  const _LessonCard({
    required this.lesson,
    required this.progress,
    required this.onTap,
  });

  final Lesson lesson;
  final LessonProgress progress;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final score = progress.score;
    final hasScore = progress.hasCompletedExercise;
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(17),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(17),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(17),
            border: Border.all(color: const Color(0xFFE0E4EE)),
          ),
          child: Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: lesson.isReview
                      ? const Color(0xFFFFF0D6)
                      : const Color(0xFFEDF1FF),
                  borderRadius: BorderRadius.circular(14),
                ),
                alignment: Alignment.center,
                child: Text(
                  '${lesson.number}',
                  style: TextStyle(
                    color: lesson.isReview
                        ? const Color(0xFF9C5C00)
                        : const Color(0xFF3156D9),
                    fontWeight: FontWeight.w900,
                    fontSize: 17,
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            '${lesson.number}-dars',
                            style: const TextStyle(
                              fontWeight: FontWeight.w900,
                              fontSize: 16,
                            ),
                          ),
                        ),
                        if (lesson.isReview)
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 3,
                            ),
                            decoration: BoxDecoration(
                              color: const Color(0xFFFFE7B8),
                              borderRadius: BorderRadius.circular(99),
                            ),
                            child: const Text(
                              'Takrorlash',
                              style: TextStyle(
                                color: Color(0xFF875000),
                                fontSize: 10.5,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: 3),
                    Text(
                      lesson.title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: Color(0xFF626B7D)),
                    ),
                    const SizedBox(height: 7),
                    Row(
                      children: [
                        Text(
                          '${lesson.words.length} ta so‘z',
                          style: const TextStyle(
                            color: Color(0xFF818899),
                            fontSize: 12,
                          ),
                        ),
                        if (progress.hasPartialExercise) ...[
                          const Text(
                            '  •  ',
                            style: TextStyle(color: Color(0xFFADB2BD)),
                          ),
                          const Text(
                            'Davom etmoqda',
                            style: TextStyle(
                              color: AppTheme.warning,
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    hasScore ? '${score!.round()}%' : '—',
                    style: TextStyle(
                      color: hasScore
                          ? AppTheme.success
                          : const Color(0xFF9CA2AF),
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    hasScore
                        ? '${progress.completedExercises} ta mashq'
                        : 'Boshlanmagan',
                    style: const TextStyle(
                      color: Color(0xFF8B92A1),
                      fontSize: 10.5,
                    ),
                  ),
                  const SizedBox(height: 3),
                  const Icon(
                    Icons.chevron_right_rounded,
                    color: Color(0xFFA0A6B3),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
