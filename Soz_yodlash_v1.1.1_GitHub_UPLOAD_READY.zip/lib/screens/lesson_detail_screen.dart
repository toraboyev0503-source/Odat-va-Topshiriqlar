import 'package:flutter/material.dart';

import '../models/lesson.dart';
import '../models/practice.dart';
import '../services/progress_database.dart';
import '../widgets/block_action_row.dart';
import '../widgets/exercise_block_card.dart';
import '../widgets/reading_text_card.dart';
import '../widgets/vocabulary_section.dart';

class LessonDetailScreen extends StatefulWidget {
  const LessonDetailScreen({
    super.key,
    required this.lesson,
    required this.progressDatabase,
  });

  final Lesson lesson;
  final ProgressDatabase progressDatabase;

  @override
  State<LessonDetailScreen> createState() => _LessonDetailScreenState();
}

class _LessonDetailScreenState extends State<LessonDetailScreen> {
  List<PracticeBlock> _blocks = [];
  bool _loading = true;
  bool _mutating = false;

  @override
  void initState() {
    super.initState();
    _reloadBlocks();
  }

  Future<void> _reloadBlocks() async {
    try {
      final result = await widget.progressDatabase.loadBlocks(
        level: widget.lesson.level,
        lessonNumber: widget.lesson.number,
        wordCount: widget.lesson.words.length,
      );
      if (!mounted) return;
      setState(() {
        _blocks = result;
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() => _loading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Mashqlarni yuklashda xatolik yuz berdi.'),
        ),
      );
    }
  }

  Future<void> _insertAfter(PracticeBlock block, PracticeBlockType type) async {
    if (_mutating) return;
    setState(() => _mutating = true);
    try {
      await widget.progressDatabase.insertBlock(
        level: widget.lesson.level,
        lessonNumber: widget.lesson.number,
        type: type,
        afterPosition: block.position,
      );
      await _reloadBlocks();
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Yangi blokni qo‘shib bo‘lmadi.')),
      );
    } finally {
      if (mounted) setState(() => _mutating = false);
    }
  }

  Future<void> _askToDelete(PracticeBlock block) async {
    if (_blocks.length <= 1 || _mutating) return;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Blok o‘chirilsinmi?'),
        content: const Text(
          'Ushbu blokdagi yozilgan javoblar va belgilar ham o‘chadi.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Bekor qilish'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('O‘chirish'),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;

    setState(() => _mutating = true);
    try {
      await widget.progressDatabase.deleteBlock(block);
      await _reloadBlocks();
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Blokni o‘chirib bo‘lmadi.')),
      );
    } finally {
      if (mounted) setState(() => _mutating = false);
    }
  }

  List<Widget> _practiceWidgets() {
    final widgets = <Widget>[];
    var exerciseNumber = 0;
    var textNumber = 0;

    for (final block in _blocks) {
      if (block.type == PracticeBlockType.exercise) {
        exerciseNumber += 1;
        widgets.add(
          ExerciseBlockCard(
            key: ValueKey(block.id),
            exerciseNumber: exerciseNumber,
            block: block,
            words: widget.lesson.words,
            onTranslationVisibilityChanged: (showTranslations) {
              return widget.progressDatabase.setTranslationVisibility(
                block.id,
                showTranslations,
              );
            },
            onAnswerChanged: (answer) {
              return widget.progressDatabase.saveAnswer(
                blockId: block.id,
                answer: answer,
              );
            },
            onScoreChanged: () {
              if (mounted) setState(() {});
            },
            onExerciseCompleted: () {
              return widget.progressDatabase.markLessonCompleted(
                level: widget.lesson.level,
                lessonNumber: widget.lesson.number,
              );
            },
            onDelete: _blocks.length > 1 ? () => _askToDelete(block) : null,
          ),
        );
      } else {
        textNumber += 1;
        widgets.add(
          ReadingTextCard(
            key: ValueKey(block.id),
            number: textNumber,
            text: widget.lesson.readingText,
            onDelete: _blocks.length > 1 ? () => _askToDelete(block) : null,
          ),
        );
      }

      widgets
        ..add(
          BlockActionRow(
            busy: _mutating,
            onAddExercise: () =>
                _insertAfter(block, PracticeBlockType.exercise),
            onAddText: () => _insertAfter(block, PracticeBlockType.readingText),
          ),
        )
        ..add(const SizedBox(height: 12));
    }

    return widgets;
  }

  @override
  Widget build(BuildContext context) {
    final bottomKeyboardInset = MediaQuery.viewInsetsOf(context).bottom;
    return Scaffold(
      resizeToAvoidBottomInset: true,
      appBar: AppBar(
        title: Text(
          '${widget.lesson.level} • ${widget.lesson.number}-dars',
          style: const TextStyle(fontWeight: FontWeight.w900),
        ),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
              padding: EdgeInsets.fromLTRB(14, 6, 14, bottomKeyboardInset + 30),
              children: [
                _LessonHeader(lesson: widget.lesson, blocks: _blocks),
                const SizedBox(height: 14),
                VocabularySection(
                  words: widget.lesson.words,
                  initiallyExpanded: true,
                ),
                const SizedBox(height: 18),
                ..._practiceWidgets(),
              ],
            ),
    );
  }
}

class _LessonHeader extends StatelessWidget {
  const _LessonHeader({required this.lesson, required this.blocks});

  final Lesson lesson;
  final List<PracticeBlock> blocks;

  @override
  Widget build(BuildContext context) {
    final completed = blocks
        .where(
          (block) =>
              block.type == PracticeBlockType.exercise && block.isComplete,
        )
        .toList(growable: false);
    final average = completed.isEmpty
        ? null
        : completed
                  .map((block) => block.score)
                  .reduce((left, right) => left + right) /
              completed.length;

    return Container(
      padding: const EdgeInsets.all(17),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF263E9B), Color(0xFF4D6BE0)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${lesson.number}-dars',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      lesson.title,
                      style: TextStyle(
                        color: Colors.white.withAlpha(220),
                        height: 1.35,
                      ),
                    ),
                  ],
                ),
              ),
              if (lesson.isReview)
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 9,
                    vertical: 5,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.white.withAlpha(35),
                    borderRadius: BorderRadius.circular(99),
                  ),
                  child: const Text(
                    'Takrorlash',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w800,
                      fontSize: 11,
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 15),
          Row(
            children: [
              _HeaderStat(
                icon: Icons.translate_rounded,
                value: '${lesson.words.length}',
                label: 'so‘z',
              ),
              const SizedBox(width: 9),
              _HeaderStat(
                icon: Icons.task_alt_rounded,
                value: '${completed.length}',
                label: 'mashq',
              ),
              const SizedBox(width: 9),
              _HeaderStat(
                icon: Icons.insights_rounded,
                value: average == null ? '—' : '${average.round()}%',
                label: 'natija',
                valueColor: average == null ? null : const Color(0xFFB8FFD8),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _HeaderStat extends StatelessWidget {
  const _HeaderStat({
    required this.icon,
    required this.value,
    required this.label,
    this.valueColor,
  });

  final IconData icon;
  final String value;
  final String label;
  final Color? valueColor;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
        decoration: BoxDecoration(
          color: Colors.white.withAlpha(25),
          borderRadius: BorderRadius.circular(13),
          border: Border.all(color: Colors.white.withAlpha(32)),
        ),
        child: Column(
          children: [
            Icon(icon, size: 18, color: Colors.white.withAlpha(225)),
            const SizedBox(height: 3),
            Text(
              value,
              style: TextStyle(
                color: valueColor ?? Colors.white,
                fontWeight: FontWeight.w900,
              ),
            ),
            Text(
              label,
              style: TextStyle(
                color: Colors.white.withAlpha(190),
                fontSize: 10.5,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
