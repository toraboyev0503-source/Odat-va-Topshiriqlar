import 'package:flutter/material.dart';

import '../models/practice.dart';
import '../services/lesson_repository.dart';
import '../services/notification_service.dart';
import '../services/progress_database.dart';
import '../widgets/progress_ring.dart';
import 'lesson_list_screen.dart';
import 'reminder_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({
    super.key,
    required this.lessonRepository,
    required this.progressDatabase,
    required this.notificationService,
  });

  final LessonRepository lessonRepository;
  final ProgressDatabase progressDatabase;
  final NotificationService notificationService;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  static const _levelIds = ['A1', 'A2', 'B1', 'B2', 'C1', 'C2'];
  static const _levelNames = {
    'A1': 'Boshlang‘ich',
    'A2': 'Asosiy',
    'B1': 'O‘rta',
    'B2': 'Yuqori o‘rta',
    'C1': 'Ilg‘or',
    'C2': 'Mukammal',
  };

  final Map<String, LevelProgress> _progress = {};
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadProgress();
  }

  Future<void> _loadProgress() async {
    final nextProgress = <String, LevelProgress>{};
    for (final levelId in _levelIds) {
      if (!widget.lessonRepository.isAvailable(levelId)) continue;
      final lessons = widget.lessonRepository.lessonsFor(levelId);
      final lessonProgress = await widget.progressDatabase.loadLevelProgress(
        level: levelId,
        wordCountsByLesson: widget.lessonRepository.wordCountsFor(levelId),
      );
      nextProgress[levelId] = LevelProgress.fromLessons(
        lessonProgress.values,
        totalLessons: lessons.length,
      );
    }
    if (!mounted) return;
    setState(() {
      _progress
        ..clear()
        ..addAll(nextProgress);
      _loading = false;
    });
  }

  Future<void> _openLevel(String levelId) async {
    if (!widget.lessonRepository.isAvailable(levelId)) return;
    await Navigator.of(context).push<void>(
      MaterialPageRoute(
        builder: (_) => LessonListScreen(
          levelId: levelId,
          lessonRepository: widget.lessonRepository,
          progressDatabase: widget.progressDatabase,
        ),
      ),
    );
    await _loadProgress();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'So‘z yodlash',
          style: TextStyle(fontWeight: FontWeight.w900),
        ),
      ),
      drawer: Drawer(
        child: SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Padding(
                padding: EdgeInsets.fromLTRB(20, 22, 20, 18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'So‘z yodlash',
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    SizedBox(height: 4),
                    Text(
                      'So‘zlarni muntazam takrorlash uchun yordamchi bo‘limlar',
                      style: TextStyle(color: Color(0xFF747C8E), height: 1.35),
                    ),
                  ],
                ),
              ),
              const Divider(height: 1),
              ListTile(
                leading: const Icon(Icons.notifications_active_outlined),
                title: const Text(
                  'Bildirishnomalar',
                  style: TextStyle(fontWeight: FontWeight.w800),
                ),
                subtitle: const Text('Kunlik eslatmalar'),
                trailing: const Icon(Icons.chevron_right_rounded),
                onTap: () {
                  Navigator.of(context).pop();
                  Navigator.of(context).push<void>(
                    MaterialPageRoute(
                      builder: (_) => ReminderScreen(
                        progressDatabase: widget.progressDatabase,
                        notificationService: widget.notificationService,
                      ),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
      body: RefreshIndicator(
        onRefresh: _loadProgress,
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
          children: [
            Text(
              'Darajangizni tanlang',
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.w900,
                color: const Color(0xFF18213A),
              ),
            ),
            const SizedBox(height: 6),
            const Text(
              'So‘zlarni ko‘ring, yozib mashq qiling va natijangizni kuzating.',
              style: TextStyle(color: Color(0xFF697185), height: 1.45),
            ),
            const SizedBox(height: 20),
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: _levelIds.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                childAspectRatio: 0.95,
              ),
              itemBuilder: (context, index) {
                final levelId = _levelIds[index];
                final available = widget.lessonRepository.isAvailable(levelId);
                return _LevelCard(
                  levelId: levelId,
                  name: _levelNames[levelId]!,
                  available: available,
                  loading: _loading && available,
                  progress: _progress[levelId],
                  onTap: () => _openLevel(levelId),
                );
              },
            ),
            const SizedBox(height: 18),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: const Color(0xFFEFF3FF),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFFD8E1FF)),
              ),
              child: const Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.offline_bolt_rounded, color: Color(0xFF3156D9)),
                  SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'Ilova internetsiz ishlaydi. Javoblar, mashqlar va natijalar telefonning o‘zida saqlanadi.',
                      style: TextStyle(height: 1.4, color: Color(0xFF3D4B72)),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _LevelCard extends StatelessWidget {
  const _LevelCard({
    required this.levelId,
    required this.name,
    required this.available,
    required this.loading,
    required this.progress,
    required this.onTap,
  });

  final String levelId;
  final String name;
  final bool available;
  final bool loading;
  final LevelProgress? progress;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final score = progress?.score;
    final completed = progress?.completedLessons ?? 0;

    return Material(
      color: available ? Colors.white : const Color(0xFFF0F1F5),
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        onTap: available ? onTap : null,
        borderRadius: BorderRadius.circular(20),
        child: Container(
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: available
                  ? const Color(0xFFDDE2EF)
                  : const Color(0xFFE2E3E8),
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 11,
                      vertical: 7,
                    ),
                    decoration: BoxDecoration(
                      color: available
                          ? colorScheme.primary.withAlpha(23)
                          : const Color(0xFFE3E4E9),
                      borderRadius: BorderRadius.circular(11),
                    ),
                    child: Text(
                      levelId,
                      style: TextStyle(
                        color: available
                            ? colorScheme.primary
                            : const Color(0xFF8D929F),
                        fontWeight: FontWeight.w900,
                        fontSize: 19,
                      ),
                    ),
                  ),
                  if (available)
                    if (loading)
                      const SizedBox.square(
                        dimension: 26,
                        child: CircularProgressIndicator(strokeWidth: 2.5),
                      )
                    else
                      ProgressRing(
                        value: (score ?? 0) / 100,
                        centerText: score == null ? '—' : '${score.round()}%',
                        size: 54,
                        strokeWidth: 5,
                      )
                  else
                    const Icon(
                      Icons.lock_outline_rounded,
                      color: Color(0xFF989DA9),
                    ),
                ],
              ),
              const Spacer(),
              Text(
                name,
                style: TextStyle(
                  fontWeight: FontWeight.w800,
                  fontSize: 16,
                  color: available
                      ? const Color(0xFF20283A)
                      : const Color(0xFF8B909C),
                ),
              ),
              const SizedBox(height: 5),
              Text(
                available ? '$completed/60 dars bajarilgan' : 'Tez orada',
                style: TextStyle(
                  color: available
                      ? const Color(0xFF6C7486)
                      : const Color(0xFF999EAA),
                  fontSize: 12.5,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
