import 'package:path/path.dart' as path;
import 'package:sqflite/sqflite.dart';

import '../models/practice.dart';
import '../models/reminder.dart';

class ProgressDatabase {
  ProgressDatabase._();

  static final ProgressDatabase instance = ProgressDatabase._();

  static const _databaseName = 'soz_yodlash_progress.db';
  static const _databaseVersion = 2;
  static const _blocksTable = 'practice_blocks';
  static const _answersTable = 'exercise_answers';
  static const _remindersTable = 'daily_reminders';
  static const _appStateTable = 'app_state';

  Database? _database;

  Future<Database> get database async {
    final existing = _database;
    if (existing != null) return existing;
    final opened = await _openDatabase();
    _database = opened;
    return opened;
  }

  Future<Database> _openDatabase() async {
    final databasesDirectory = await getDatabasesPath();
    final databasePath = path.join(databasesDirectory, _databaseName);

    return openDatabase(
      databasePath,
      version: _databaseVersion,
      onConfigure: (db) async {
        await db.execute('PRAGMA foreign_keys = ON');
      },
      onCreate: (db, version) async {
        await _createPracticeTables(db);
        await _createReminderAndStateTables(db);
      },
      onUpgrade: (db, oldVersion, newVersion) async {
        if (oldVersion < 2) {
          await _createReminderAndStateTables(db);
        }
      },
    );
  }

  Future<void> _createPracticeTables(DatabaseExecutor db) async {
    await db.execute('''
      CREATE TABLE $_blocksTable (
        id TEXT PRIMARY KEY,
        level TEXT NOT NULL,
        lesson_number INTEGER NOT NULL,
        block_type TEXT NOT NULL,
        position_index INTEGER NOT NULL,
        show_translations INTEGER NOT NULL DEFAULT 0,
        created_at INTEGER NOT NULL
      )
    ''');
    await db.execute('''
      CREATE INDEX idx_blocks_lesson
      ON $_blocksTable(level, lesson_number, position_index)
    ''');
    await db.execute('''
      CREATE TABLE $_answersTable (
        block_id TEXT NOT NULL,
        word_index INTEGER NOT NULL,
        answer_text TEXT NOT NULL DEFAULT '',
        result INTEGER NOT NULL DEFAULT 0,
        PRIMARY KEY(block_id, word_index),
        FOREIGN KEY(block_id) REFERENCES $_blocksTable(id) ON DELETE CASCADE
      )
    ''');
  }

  Future<void> _createReminderAndStateTables(DatabaseExecutor db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS $_remindersTable (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        hour INTEGER NOT NULL,
        minute INTEGER NOT NULL,
        enabled INTEGER NOT NULL DEFAULT 1,
        created_at INTEGER NOT NULL
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS $_appStateTable (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
      )
    ''');
  }

  Future<List<PracticeBlock>> loadBlocks({
    required String level,
    required int lessonNumber,
    required int wordCount,
  }) async {
    var rows = await _queryBlockRows(level, lessonNumber);
    if (rows.isEmpty) {
      await insertBlock(
        level: level,
        lessonNumber: lessonNumber,
        type: PracticeBlockType.exercise,
        afterPosition: -1,
      );
      rows = await _queryBlockRows(level, lessonNumber);
    }
    return _hydrateBlocks(rows, wordCount: wordCount);
  }

  Future<List<Map<String, Object?>>> _queryBlockRows(
    String level,
    int lessonNumber,
  ) async {
    final db = await database;
    return db.query(
      _blocksTable,
      where: 'level = ? AND lesson_number = ?',
      whereArgs: [level, lessonNumber],
      orderBy: 'position_index ASC',
    );
  }

  Future<List<PracticeBlock>> _hydrateBlocks(
    List<Map<String, Object?>> rows, {
    required int wordCount,
  }) async {
    final exerciseIds = rows
        .where((row) => row['block_type'] == 'exercise')
        .map((row) => row['id'] as String)
        .toList(growable: false);
    final answersByBlock = <String, Map<int, ExerciseAnswer>>{};

    if (exerciseIds.isNotEmpty) {
      final db = await database;
      final placeholders = List.filled(exerciseIds.length, '?').join(',');
      final answerRows = await db.query(
        _answersTable,
        where: 'block_id IN ($placeholders)',
        whereArgs: exerciseIds,
      );

      for (final row in answerRows) {
        final blockId = row['block_id'] as String;
        final wordIndex = row['word_index'] as int;
        answersByBlock.putIfAbsent(
          blockId,
          () => <int, ExerciseAnswer>{},
        )[wordIndex] = ExerciseAnswer(
          wordIndex: wordIndex,
          answerText: row['answer_text'] as String? ?? '',
          result: AnswerResult.fromDatabase(row['result'] as int? ?? 0),
        );
      }
    }

    return rows
        .map((row) {
          final id = row['id'] as String;
          final type = row['block_type'] == 'exercise'
              ? PracticeBlockType.exercise
              : PracticeBlockType.readingText;
          final answers = type == PracticeBlockType.exercise
              ? List.generate(
                  wordCount,
                  (index) =>
                      answersByBlock[id]?[index] ??
                      ExerciseAnswer(wordIndex: index),
                )
              : <ExerciseAnswer>[];

          return PracticeBlock(
            id: id,
            level: row['level'] as String,
            lessonNumber: row['lesson_number'] as int,
            type: type,
            position: row['position_index'] as int,
            showTranslations: (row['show_translations'] as int? ?? 0) == 1,
            answers: answers,
          );
        })
        .toList(growable: false);
  }

  Future<String> insertBlock({
    required String level,
    required int lessonNumber,
    required PracticeBlockType type,
    required int afterPosition,
  }) async {
    final db = await database;
    final now = DateTime.now().microsecondsSinceEpoch;
    final id = '${level}_${lessonNumber}_${type.name}_$now';
    final newPosition = afterPosition + 1;

    await db.transaction((transaction) async {
      await transaction.rawUpdate(
        '''
          UPDATE $_blocksTable
          SET position_index = position_index + 1
          WHERE level = ? AND lesson_number = ? AND position_index > ?
        ''',
        [level, lessonNumber, afterPosition],
      );
      await transaction.insert(_blocksTable, {
        'id': id,
        'level': level,
        'lesson_number': lessonNumber,
        'block_type': type == PracticeBlockType.exercise
            ? 'exercise'
            : 'reading_text',
        'position_index': newPosition,
        'show_translations': 0,
        'created_at': DateTime.now().millisecondsSinceEpoch,
      });
    });

    return id;
  }

  Future<void> deleteBlock(PracticeBlock block) async {
    final db = await database;
    await db.transaction((transaction) async {
      await transaction.delete(
        _blocksTable,
        where: 'id = ?',
        whereArgs: [block.id],
      );
      await transaction.rawUpdate(
        '''
          UPDATE $_blocksTable
          SET position_index = position_index - 1
          WHERE level = ? AND lesson_number = ? AND position_index > ?
        ''',
        [block.level, block.lessonNumber, block.position],
      );
    });
  }

  Future<void> setTranslationVisibility(
    String blockId,
    bool showTranslations,
  ) async {
    final db = await database;
    await db.update(
      _blocksTable,
      {'show_translations': showTranslations ? 1 : 0},
      where: 'id = ?',
      whereArgs: [blockId],
    );
  }

  Future<void> saveAnswer({
    required String blockId,
    required ExerciseAnswer answer,
  }) async {
    final db = await database;
    if (answer.answerText.trim().isEmpty &&
        answer.result == AnswerResult.unmarked) {
      await db.delete(
        _answersTable,
        where: 'block_id = ? AND word_index = ?',
        whereArgs: [blockId, answer.wordIndex],
      );
      return;
    }

    await db.insert(
      _answersTable,
      {
        'block_id': blockId,
        'word_index': answer.wordIndex,
        'answer_text': answer.answerText,
        'result': answer.result.databaseValue,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<Map<int, LessonProgress>> loadLevelProgress({
    required String level,
    required Map<int, int> wordCountsByLesson,
  }) async {
    final db = await database;
    final blockRows = await db.query(
      _blocksTable,
      columns: ['id', 'lesson_number'],
      where: 'level = ? AND block_type = ?',
      whereArgs: [level, 'exercise'],
    );

    final answerRows = await db.rawQuery(
      '''
      SELECT a.block_id, a.word_index, a.answer_text, a.result
      FROM $_answersTable a
      INNER JOIN $_blocksTable b ON b.id = a.block_id
      WHERE b.level = ? AND b.block_type = ?
    ''',
      [level, 'exercise'],
    );

    final answersByBlock = <String, Map<int, ExerciseAnswer>>{};
    for (final row in answerRows) {
      final blockId = row['block_id'] as String;
      final wordIndex = row['word_index'] as int;
      answersByBlock.putIfAbsent(
        blockId,
        () => <int, ExerciseAnswer>{},
      )[wordIndex] = ExerciseAnswer(
        wordIndex: wordIndex,
        answerText: row['answer_text'] as String? ?? '',
        result: AnswerResult.fromDatabase(row['result'] as int? ?? 0),
      );
    }

    final completedScores = <int, List<double>>{};
    final partialLessons = <int>{};

    for (final blockRow in blockRows) {
      final blockId = blockRow['id'] as String;
      final lessonNumber = blockRow['lesson_number'] as int;
      final wordCount = wordCountsByLesson[lessonNumber];
      if (wordCount == null || wordCount == 0) continue;
      final blockAnswers =
          answersByBlock[blockId] ?? const <int, ExerciseAnswer>{};

      var marked = 0;
      var correct = 0;
      var hasActivity = false;
      for (var index = 0; index < wordCount; index += 1) {
        final answer = blockAnswers[index];
        if (answer == null) continue;
        if (answer.answerText.trim().isNotEmpty ||
            answer.result != AnswerResult.unmarked) {
          hasActivity = true;
        }
        if (answer.result != AnswerResult.unmarked) marked += 1;
        if (answer.result == AnswerResult.correct) correct += 1;
      }

      if (marked == wordCount) {
        completedScores
            .putIfAbsent(lessonNumber, () => <double>[])
            .add(correct / wordCount * 100);
      } else if (hasActivity) {
        partialLessons.add(lessonNumber);
      }
    }

    final result = <int, LessonProgress>{};
    for (final lessonNumber in wordCountsByLesson.keys) {
      final scores = completedScores[lessonNumber] ?? const <double>[];
      final score = scores.isEmpty
          ? null
          : scores.reduce((left, right) => left + right) / scores.length;
      result[lessonNumber] = LessonProgress(
        completedExercises: scores.length,
        hasPartialExercise: partialLessons.contains(lessonNumber),
        score: score,
      );
    }
    return result;
  }

  Future<List<DailyReminder>> loadReminders() async {
    final db = await database;
    final rows = await db.query(
      _remindersTable,
      orderBy: 'hour ASC, minute ASC, id ASC',
    );
    return rows
        .map(
          (row) => DailyReminder(
            id: row['id'] as int,
            hour: row['hour'] as int,
            minute: row['minute'] as int,
            enabled: (row['enabled'] as int? ?? 1) == 1,
          ),
        )
        .toList(growable: false);
  }

  Future<DailyReminder> createReminder({
    required int hour,
    required int minute,
  }) async {
    final db = await database;
    final id = await db.insert(_remindersTable, {
      'hour': hour,
      'minute': minute,
      'enabled': 1,
      'created_at': DateTime.now().millisecondsSinceEpoch,
    });
    return DailyReminder(id: id, hour: hour, minute: minute, enabled: true);
  }

  Future<void> updateReminder(DailyReminder reminder) async {
    final db = await database;
    await db.update(
      _remindersTable,
      {
        'hour': reminder.hour,
        'minute': reminder.minute,
        'enabled': reminder.enabled ? 1 : 0,
      },
      where: 'id = ?',
      whereArgs: [reminder.id],
    );
  }

  Future<void> deleteReminder(int reminderId) async {
    final db = await database;
    await db.delete(
      _remindersTable,
      where: 'id = ?',
      whereArgs: [reminderId],
    );
  }

  Future<void> markLessonCompleted({
    required String level,
    required int lessonNumber,
  }) async {
    final db = await database;
    await db.transaction((transaction) async {
      await _putState(transaction, 'last_completed_level', level);
      await _putState(
        transaction,
        'last_completed_lesson',
        lessonNumber.toString(),
      );
      await _putState(
        transaction,
        'last_completed_at',
        DateTime.now().millisecondsSinceEpoch.toString(),
      );
    });
  }

  Future<void> _putState(
    DatabaseExecutor db,
    String key,
    String value,
  ) async {
    await db.insert(
      _appStateTable,
      {'key': key, 'value': value},
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<LessonLocation?> resolveLastCompletedLesson({
    required Map<String, Map<int, int>> wordCountsByLevel,
  }) async {
    final db = await database;
    final stateRows = await db.query(
      _appStateTable,
      where: 'key IN (?, ?)',
      whereArgs: ['last_completed_level', 'last_completed_lesson'],
    );
    final state = <String, String>{
      for (final row in stateRows)
        row['key'] as String: row['value'] as String,
    };
    final savedLevel = state['last_completed_level'];
    final savedLesson = int.tryParse(state['last_completed_lesson'] ?? '');
    if (savedLevel != null && savedLesson != null) {
      return LessonLocation(level: savedLevel, lessonNumber: savedLesson);
    }

    // v1 dan yangilangan foydalanuvchilarda oxirgi tugallash vaqti saqlanmagan.
    // Shuning uchun to‘liq belgilangan mashqlar orasidan eng keyin yaratilgan
    // blokni bir martalik fallback sifatida tanlaymiz.
    final rows = await db.rawQuery('''
      SELECT
        b.id,
        b.level,
        b.lesson_number,
        b.created_at,
        SUM(CASE WHEN a.result != 0 THEN 1 ELSE 0 END) AS marked_count
      FROM $_blocksTable b
      LEFT JOIN $_answersTable a ON a.block_id = b.id
      WHERE b.block_type = 'exercise'
      GROUP BY b.id, b.level, b.lesson_number, b.created_at
      ORDER BY b.created_at DESC
    ''');

    for (final row in rows) {
      final level = row['level'] as String;
      final lessonNumber = row['lesson_number'] as int;
      final expectedCount = wordCountsByLevel[level]?[lessonNumber];
      final markedCount = (row['marked_count'] as num?)?.toInt() ?? 0;
      if (expectedCount != null && expectedCount > 0 && markedCount == expectedCount) {
        await markLessonCompleted(level: level, lessonNumber: lessonNumber);
        return LessonLocation(level: level, lessonNumber: lessonNumber);
      }
    }

    return null;
  }
}
