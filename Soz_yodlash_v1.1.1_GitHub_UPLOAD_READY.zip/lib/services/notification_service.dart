import 'dart:async';

import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;

import '../models/reminder.dart';

class NotificationService {
  NotificationService._();

  static final NotificationService instance = NotificationService._();

  static const openLastCompletedLessonPayload = 'open_last_completed_lesson';
  static const _channelId = 'daily_word_reminders_v1';
  static const _channelName = 'Kunlik so‘z takrorlash';
  static const _channelDescription =
      'Inglizcha so‘zlarni takrorlash uchun kundalik eslatmalar';

  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();
  final StreamController<String?> _tapController =
      StreamController<String?>.broadcast();

  Stream<String?> get tapStream => _tapController.stream;

  Future<String?> initialize() async {
    tz.initializeTimeZones();
    await _configureLocalTimeZone();

    const androidSettings = AndroidInitializationSettings(
      '@mipmap/ic_launcher',
    );
    const settings = InitializationSettings(android: androidSettings);

    final launchDetails = await _plugin.getNotificationAppLaunchDetails();
    await _plugin.initialize(
      settings,
      onDidReceiveNotificationResponse: (response) {
        _tapController.add(response.payload);
      },
    );

    if (launchDetails?.didNotificationLaunchApp ?? false) {
      return launchDetails?.notificationResponse?.payload;
    }
    return null;
  }

  Future<void> _configureLocalTimeZone() async {
    try {
      final info = await FlutterTimezone.getLocalTimezone();
      tz.setLocalLocation(tz.getLocation(info.identifier));
    } catch (_) {
      // Ilovaning asosiy auditoriyasi O‘zbekiston. Platforma vaqt zonasini
      // aniqlash muvaffaqiyatsiz bo‘lsa, kundalik eslatma UTC bo‘lib ketmasligi
      // uchun xavfsiz lokal fallback ishlatiladi.
      tz.setLocalLocation(tz.getLocation('Asia/Tashkent'));
    }
  }

  Future<bool> requestPermission() async {
    final android = _plugin.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();
    final granted = await android?.requestNotificationsPermission();
    return granted ?? true;
  }

  Future<void> scheduleDaily(DailyReminder reminder) async {
    if (!reminder.enabled) {
      await cancel(reminder.id);
      return;
    }

    await cancel(reminder.id);
    final now = tz.TZDateTime.now(tz.local);
    var scheduled = tz.TZDateTime(
      tz.local,
      now.year,
      now.month,
      now.day,
      reminder.hour,
      reminder.minute,
    );
    if (!scheduled.isAfter(now)) {
      scheduled = scheduled.add(const Duration(days: 1));
    }

    const details = NotificationDetails(
      android: AndroidNotificationDetails(
        _channelId,
        _channelName,
        channelDescription: _channelDescription,
        importance: Importance.high,
        priority: Priority.high,
      ),
    );

    await _plugin.zonedSchedule(
      reminder.id,
      'So‘zlarni takrorlash vaqti',
      'Bugungi inglizcha so‘zlarni bir marta takrorlab chiqing.',
      scheduled,
      details,
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
      matchDateTimeComponents: DateTimeComponents.time,
      payload: openLastCompletedLessonPayload,
    );
  }

  Future<void> cancel(int reminderId) => _plugin.cancel(reminderId);

  Future<void> rescheduleEnabledReminders(
    Iterable<DailyReminder> reminders,
  ) async {
    for (final reminder in reminders) {
      if (reminder.enabled) {
        await scheduleDaily(reminder);
      }
    }
  }
}
