import 'dart:convert';

import 'package:flutter/services.dart';

import '../models/lesson.dart';

class LessonRepository {
  LessonRepository._(this._levels);

  final Map<String, LearningLevel> _levels;

  static Future<LessonRepository> load() async {
    final rawJson = await rootBundle.loadString('assets/data/lessons.json');
    final decoded = jsonDecode(rawJson) as Map<String, dynamic>;
    final rawLevels = decoded['levels'] as List<dynamic>;
    final levels = <String, LearningLevel>{};

    for (final rawLevel in rawLevels) {
      final level = LearningLevel.fromJson(rawLevel as Map<String, dynamic>);
      levels[level.id] = level;
    }

    return LessonRepository._(levels);
  }

  bool isAvailable(String levelId) => _levels.containsKey(levelId);

  LearningLevel level(String levelId) {
    final result = _levels[levelId];
    if (result == null) {
      throw StateError('$levelId darajasi uchun ma’lumot topilmadi.');
    }
    return result;
  }

  List<Lesson> lessonsFor(String levelId) => level(levelId).lessons;

  Lesson lesson(String levelId, int lessonNumber) {
    return level(
      levelId,
    ).lessons.firstWhere((lesson) => lesson.number == lessonNumber);
  }

  Map<int, int> wordCountsFor(String levelId) {
    return {
      for (final lesson in lessonsFor(levelId))
        lesson.number: lesson.words.length,
    };
  }
}
