class DailyReminder {
  const DailyReminder({
    required this.id,
    required this.hour,
    required this.minute,
    required this.enabled,
  });

  final int id;
  final int hour;
  final int minute;
  final bool enabled;

  String get timeLabel =>
      '${hour.toString().padLeft(2, '0')}:${minute.toString().padLeft(2, '0')}';

  DailyReminder copyWith({
    int? hour,
    int? minute,
    bool? enabled,
  }) {
    return DailyReminder(
      id: id,
      hour: hour ?? this.hour,
      minute: minute ?? this.minute,
      enabled: enabled ?? this.enabled,
    );
  }
}

class LessonLocation {
  const LessonLocation({required this.level, required this.lessonNumber});

  final String level;
  final int lessonNumber;
}
