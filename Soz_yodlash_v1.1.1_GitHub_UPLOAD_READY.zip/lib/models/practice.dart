enum PracticeBlockType { exercise, readingText }

enum AnswerResult {
  wrong(-1),
  unmarked(0),
  correct(1);

  const AnswerResult(this.databaseValue);

  final int databaseValue;

  AnswerResult get next {
    return switch (this) {
      AnswerResult.unmarked => AnswerResult.correct,
      AnswerResult.correct => AnswerResult.wrong,
      AnswerResult.wrong => AnswerResult.unmarked,
    };
  }

  static AnswerResult fromDatabase(int value) {
    return switch (value) {
      1 => AnswerResult.correct,
      -1 => AnswerResult.wrong,
      _ => AnswerResult.unmarked,
    };
  }
}

class ExerciseAnswer {
  ExerciseAnswer({
    required this.wordIndex,
    this.answerText = '',
    this.result = AnswerResult.unmarked,
  });

  final int wordIndex;
  String answerText;
  AnswerResult result;
}

class PracticeBlock {
  PracticeBlock({
    required this.id,
    required this.level,
    required this.lessonNumber,
    required this.type,
    required this.position,
    required this.showTranslations,
    required this.answers,
  });

  final String id;
  final String level;
  final int lessonNumber;
  final PracticeBlockType type;
  final int position;
  bool showTranslations;
  final List<ExerciseAnswer> answers;

  int get markedCount =>
      answers.where((answer) => answer.result != AnswerResult.unmarked).length;

  int get correctCount =>
      answers.where((answer) => answer.result == AnswerResult.correct).length;

  int get wrongCount =>
      answers.where((answer) => answer.result == AnswerResult.wrong).length;

  bool get isComplete => answers.isNotEmpty && markedCount == answers.length;

  bool get hasActivity => answers.any(
    (answer) =>
        answer.result != AnswerResult.unmarked ||
        answer.answerText.trim().isNotEmpty,
  );

  double get score {
    if (answers.isEmpty) return 0;
    return correctCount / answers.length * 100;
  }
}

class LessonProgress {
  const LessonProgress({
    this.completedExercises = 0,
    this.hasPartialExercise = false,
    this.score,
  });

  final int completedExercises;
  final bool hasPartialExercise;
  final double? score;

  bool get hasCompletedExercise => completedExercises > 0 && score != null;
}

class LevelProgress {
  const LevelProgress({
    required this.completedLessons,
    required this.totalLessons,
    required this.score,
  });

  final int completedLessons;
  final int totalLessons;
  final double? score;

  double get completionRatio {
    if (totalLessons == 0) return 0;
    return completedLessons / totalLessons;
  }

  factory LevelProgress.fromLessons(
    Iterable<LessonProgress> lessons, {
    required int totalLessons,
  }) {
    final completed = lessons
        .where((lesson) => lesson.hasCompletedExercise)
        .toList(growable: false);
    if (completed.isEmpty) {
      return LevelProgress(
        completedLessons: 0,
        totalLessons: totalLessons,
        score: null,
      );
    }
    final average =
        completed
            .map((lesson) => lesson.score!)
            .reduce((left, right) => left + right) /
        completed.length;
    return LevelProgress(
      completedLessons: completed.length,
      totalLessons: totalLessons,
      score: average,
    );
  }
}
