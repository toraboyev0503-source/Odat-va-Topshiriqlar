class WordPair {
  const WordPair({required this.english, required this.uzbek});

  final String english;
  final String uzbek;

  factory WordPair.fromJson(Map<String, dynamic> json) {
    return WordPair(
      english: json['english'] as String,
      uzbek: json['uzbek'] as String,
    );
  }
}

class Lesson {
  const Lesson({
    required this.level,
    required this.number,
    required this.title,
    required this.words,
    required this.readingText,
  });

  final String level;
  final int number;
  final String title;
  final List<WordPair> words;
  final String readingText;

  bool get isReview => number % 10 == 0;

  factory Lesson.fromJson(String level, Map<String, dynamic> json) {
    final rawWords = json['words'] as List<dynamic>;
    return Lesson(
      level: level,
      number: json['number'] as int,
      title: json['title'] as String,
      words: rawWords
          .map((word) => WordPair.fromJson(word as Map<String, dynamic>))
          .toList(growable: false),
      readingText: json['readingText'] as String,
    );
  }
}

class LearningLevel {
  const LearningLevel({required this.id, required this.lessons});

  final String id;
  final List<Lesson> lessons;

  factory LearningLevel.fromJson(Map<String, dynamic> json) {
    final id = json['id'] as String;
    final rawLessons = json['lessons'] as List<dynamic>;
    return LearningLevel(
      id: id,
      lessons: rawLessons
          .map((lesson) => Lesson.fromJson(id, lesson as Map<String, dynamic>))
          .toList(growable: false),
    );
  }
}
