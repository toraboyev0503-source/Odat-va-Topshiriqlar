import 'package:flutter/material.dart';

class BlockActionRow extends StatelessWidget {
  const BlockActionRow({
    super.key,
    required this.onAddExercise,
    required this.onAddText,
    required this.busy,
  });

  final VoidCallback onAddExercise;
  final VoidCallback onAddText;
  final bool busy;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 10, bottom: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          FilledButton.tonalIcon(
            onPressed: busy ? null : onAddExercise,
            icon: const Icon(Icons.add_rounded),
            label: const Text('Mashq'),
          ),
          const SizedBox(width: 12),
          FilledButton.tonalIcon(
            onPressed: busy ? null : onAddText,
            icon: const Text(
              'M',
              style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17),
            ),
            label: const Text('Matn'),
          ),
        ],
      ),
    );
  }
}
