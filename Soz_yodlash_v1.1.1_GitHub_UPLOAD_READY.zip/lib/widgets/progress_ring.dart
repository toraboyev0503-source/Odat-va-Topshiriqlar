import 'package:flutter/material.dart';

class ProgressRing extends StatelessWidget {
  const ProgressRing({
    super.key,
    required this.value,
    required this.centerText,
    this.size = 62,
    this.strokeWidth = 6,
    this.color,
  });

  final double value;
  final String centerText;
  final double size;
  final double strokeWidth;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final safeValue = value.clamp(0.0, 1.0).toDouble();
    final progressColor = color ?? Theme.of(context).colorScheme.primary;

    return SizedBox.square(
      dimension: size,
      child: Stack(
        alignment: Alignment.center,
        children: [
          SizedBox.square(
            dimension: size,
            child: CircularProgressIndicator(
              value: safeValue,
              strokeWidth: strokeWidth,
              strokeCap: StrokeCap.round,
              color: progressColor,
              backgroundColor: progressColor.withAlpha(32),
            ),
          ),
          Text(
            centerText,
            style: Theme.of(context).textTheme.labelLarge?.copyWith(
              fontWeight: FontWeight.w800,
              color: const Color(0xFF18213A),
            ),
          ),
        ],
      ),
    );
  }
}
