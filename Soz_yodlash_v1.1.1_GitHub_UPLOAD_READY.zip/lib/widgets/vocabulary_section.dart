import 'package:flutter/material.dart';

import '../models/lesson.dart';

class VocabularySection extends StatelessWidget {
  const VocabularySection({
    super.key,
    required this.words,
    required this.initiallyExpanded,
  });

  final List<WordPair> words;
  final bool initiallyExpanded;

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    return Card(
      margin: EdgeInsets.zero,
      elevation: 0,
      color: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(18),
        side: const BorderSide(color: Color(0xFFE1E5F0)),
      ),
      clipBehavior: Clip.antiAlias,
      child: ExpansionTile(
        initiallyExpanded: initiallyExpanded,
        maintainState: true,
        tilePadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        childrenPadding: EdgeInsets.zero,
        leading: Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            color: colorScheme.primary.withAlpha(25),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(Icons.menu_book_rounded, color: colorScheme.primary),
        ),
        title: const Text(
          'Dars lug‘ati',
          style: TextStyle(fontWeight: FontWeight.w800),
        ),
        subtitle: Text('${words.length} ta so‘z va tarjima'),
        children: [
          const _VocabularyHeader(),
          for (var index = 0; index < words.length; index += 1)
            _VocabularyRow(
              index: index,
              word: words[index],
              shaded: index.isOdd,
            ),
        ],
      ),
    );
  }
}

class _VocabularyHeader extends StatelessWidget {
  const _VocabularyHeader();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
      decoration: const BoxDecoration(
        color: Color(0xFFEEF1F8),
        border: Border(
          top: BorderSide(color: Color(0xFFDDE2ED)),
          bottom: BorderSide(color: Color(0xFFDDE2ED)),
        ),
      ),
      child: const Row(
        children: [
          SizedBox(
            width: 38,
            child: Text('№', style: TextStyle(fontWeight: FontWeight.w800)),
          ),
          Expanded(
            flex: 4,
            child: Text(
              'Inglizcha',
              style: TextStyle(fontWeight: FontWeight.w800),
            ),
          ),
          SizedBox(width: 8),
          Expanded(
            flex: 5,
            child: Text(
              'O‘zbekcha',
              style: TextStyle(fontWeight: FontWeight.w800),
            ),
          ),
        ],
      ),
    );
  }
}

class _VocabularyRow extends StatelessWidget {
  const _VocabularyRow({
    required this.index,
    required this.word,
    required this.shaded,
  });

  final int index;
  final WordPair word;
  final bool shaded;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: shaded ? const Color(0xFFF9FAFD) : Colors.white,
        border: const Border(bottom: BorderSide(color: Color(0xFFEBEEF5))),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 38,
            child: Text(
              '${index + 1}',
              style: const TextStyle(color: Color(0xFF6B7280)),
            ),
          ),
          Expanded(
            flex: 4,
            child: Text(
              word.english,
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            flex: 5,
            child: Text(
              word.uzbek,
              style: const TextStyle(color: Color(0xFF3F4758)),
            ),
          ),
        ],
      ),
    );
  }
}
