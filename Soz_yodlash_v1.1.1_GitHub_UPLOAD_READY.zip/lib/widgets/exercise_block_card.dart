import 'dart:async';

import 'package:flutter/material.dart';

import '../models/lesson.dart';
import '../models/practice.dart';
import '../theme/app_theme.dart';

class ExerciseBlockCard extends StatefulWidget {
  const ExerciseBlockCard({
    super.key,
    required this.exerciseNumber,
    required this.block,
    required this.words,
    required this.onTranslationVisibilityChanged,
    required this.onAnswerChanged,
    required this.onScoreChanged,
    required this.onExerciseCompleted,
    this.onDelete,
  });

  final int exerciseNumber;
  final PracticeBlock block;
  final List<WordPair> words;
  final Future<void> Function(bool showTranslations)
  onTranslationVisibilityChanged;
  final Future<void> Function(ExerciseAnswer answer) onAnswerChanged;
  final VoidCallback onScoreChanged;
  final Future<void> Function() onExerciseCompleted;
  final VoidCallback? onDelete;

  @override
  State<ExerciseBlockCard> createState() => _ExerciseBlockCardState();
}

class _ExerciseBlockCardState extends State<ExerciseBlockCard> {
  late List<TextEditingController> _controllers;

  @override
  void initState() {
    super.initState();
    _createControllers();
  }

  @override
  void didUpdateWidget(covariant ExerciseBlockCard oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.block.id != widget.block.id ||
        oldWidget.block.answers.length != widget.block.answers.length) {
      _disposeControllers();
      _createControllers();
    }
  }

  void _createControllers() {
    _controllers = widget.block.answers
        .map((answer) => TextEditingController(text: answer.answerText))
        .toList(growable: false);
  }

  void _disposeControllers() {
    for (final controller in _controllers) {
      controller.dispose();
    }
  }

  @override
  void dispose() {
    _disposeControllers();
    super.dispose();
  }

  void _toggleTranslations() {
    setState(() {
      widget.block.showTranslations = !widget.block.showTranslations;
    });
    unawaited(
      widget.onTranslationVisibilityChanged(widget.block.showTranslations),
    );
  }

  void _cycleResult(int index) {
    final wasComplete = widget.block.isComplete;
    final answer = widget.block.answers[index];
    setState(() {
      answer.result = answer.result.next;
    });
    final becameComplete = !wasComplete && widget.block.isComplete;
    widget.onScoreChanged();
    unawaited(_persistResult(answer, becameComplete));
  }

  Future<void> _persistResult(
    ExerciseAnswer answer,
    bool becameComplete,
  ) async {
    await widget.onAnswerChanged(answer);
    if (becameComplete) {
      await widget.onExerciseCompleted();
    }
  }

  void _updateAnswerText(int index, String value) {
    final answer = widget.block.answers[index];
    answer.answerText = value;
    unawaited(widget.onAnswerChanged(answer));
  }

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    return Card(
      margin: EdgeInsets.zero,
      elevation: 0,
      color: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(18),
        side: const BorderSide(color: Color(0xFFDDE2EE)),
      ),
      clipBehavior: Clip.antiAlias,
      child: ExpansionTile(
        initiallyExpanded: widget.exerciseNumber == 1,
        maintainState: true,
        tilePadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
        childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 16),
        leading: Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            color: colorScheme.primary.withAlpha(25),
            borderRadius: BorderRadius.circular(12),
          ),
          alignment: Alignment.center,
          child: Text(
            '${widget.exerciseNumber}',
            style: TextStyle(
              color: colorScheme.primary,
              fontSize: 17,
              fontWeight: FontWeight.w900,
            ),
          ),
        ),
        title: Text(
          '${widget.exerciseNumber}-mashq',
          style: const TextStyle(fontWeight: FontWeight.w800),
        ),
        subtitle: Text(_subtitle()),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (widget.onDelete != null)
              IconButton(
                onPressed: widget.onDelete,
                tooltip: 'Mashqni o‘chirish',
                icon: Icon(
                  Icons.delete_outline_rounded,
                  color: colorScheme.error,
                ),
              ),
            const Icon(Icons.expand_more_rounded),
          ],
        ),
        children: [
          _TranslationToggle(
            showTranslations: widget.block.showTranslations,
            onTap: _toggleTranslations,
          ),
          const SizedBox(height: 10),
          Text(
            'Har bir so‘zdagi bo‘sh belgini bosing: bo‘sh → ✓ → ✕.',
            style: Theme.of(
              context,
            ).textTheme.bodySmall?.copyWith(color: const Color(0xFF687083)),
          ),
          const SizedBox(height: 12),
          for (var index = 0; index < widget.words.length; index += 1) ...[
            _ExerciseWordRow(
              index: index,
              word: widget.words[index],
              showTranslation: widget.block.showTranslations,
              answer: widget.block.answers[index],
              controller: _controllers[index],
              isLast: index == widget.words.length - 1,
              onResultTap: () => _cycleResult(index),
              onAnswerChanged: (value) => _updateAnswerText(index, value),
            ),
            if (index != widget.words.length - 1) const SizedBox(height: 10),
          ],
          const SizedBox(height: 14),
          _ScorePanel(block: widget.block),
        ],
      ),
    );
  }

  String _subtitle() {
    if (widget.block.isComplete) {
      return '${widget.block.score.round()}% • ${widget.block.correctCount}/${widget.block.answers.length} to‘g‘ri';
    }
    if (widget.block.markedCount > 0) {
      return '${widget.block.markedCount}/${widget.block.answers.length} ta belgilandi';
    }
    return '${widget.block.answers.length} ta so‘z';
  }
}

class _TranslationToggle extends StatelessWidget {
  const _TranslationToggle({
    required this.showTranslations,
    required this.onTap,
  });

  final bool showTranslations;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final color = showTranslations ? AppTheme.success : AppTheme.danger;
    return Material(
      color: color.withAlpha(18),
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 11),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: color.withAlpha(90)),
          ),
          child: Row(
            children: [
              Container(
                width: 30,
                height: 30,
                decoration: BoxDecoration(color: color, shape: BoxShape.circle),
                alignment: Alignment.center,
                child: Icon(
                  showTranslations ? Icons.check_rounded : Icons.close_rounded,
                  color: Colors.white,
                  size: 20,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  showTranslations
                      ? 'O‘zbekcha tarjimalar ko‘rinadi'
                      : 'O‘zbekcha tarjimalar yashirilgan',
                  style: TextStyle(color: color, fontWeight: FontWeight.w800),
                ),
              ),
              Icon(Icons.touch_app_rounded, color: color, size: 20),
            ],
          ),
        ),
      ),
    );
  }
}

class _ExerciseWordRow extends StatelessWidget {
  const _ExerciseWordRow({
    required this.index,
    required this.word,
    required this.showTranslation,
    required this.answer,
    required this.controller,
    required this.isLast,
    required this.onResultTap,
    required this.onAnswerChanged,
  });

  final int index;
  final WordPair word;
  final bool showTranslation;
  final ExerciseAnswer answer;
  final TextEditingController controller;
  final bool isLast;
  final VoidCallback onResultTap;
  final ValueChanged<String> onAnswerChanged;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFF8F9FC),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE3E7F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 34,
                height: 34,
                decoration: const BoxDecoration(
                  color: Color(0xFFE8ECF7),
                  shape: BoxShape.circle,
                ),
                alignment: Alignment.center,
                child: Text(
                  '${index + 1}',
                  style: const TextStyle(
                    color: Color(0xFF46516A),
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      word.english,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                        color: Color(0xFF20283A),
                      ),
                    ),
                    const SizedBox(height: 4),
                    AnimatedSwitcher(
                      duration: const Duration(milliseconds: 180),
                      child: Text(
                        showTranslation ? word.uzbek : 'Tarjima yashirilgan',
                        key: ValueKey(showTranslation),
                        style: TextStyle(
                          color: showTranslation
                              ? const Color(0xFF555E71)
                              : const Color(0xFF9299A8),
                          fontStyle: showTranslation
                              ? FontStyle.normal
                              : FontStyle.italic,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              _ResultButton(result: answer.result, onTap: onResultTap),
            ],
          ),
          const SizedBox(height: 10),
          TextField(
            controller: controller,
            textInputAction: isLast
                ? TextInputAction.done
                : TextInputAction.next,
            autocorrect: false,
            enableSuggestions: false,
            decoration: const InputDecoration(
              labelText: 'Javobingiz',
              hintText: 'Tarjimasini eslab yozing',
              isDense: true,
            ),
            onChanged: onAnswerChanged,
            onSubmitted: (_) {
              if (isLast) {
                FocusScope.of(context).unfocus();
              } else {
                FocusScope.of(context).nextFocus();
              }
            },
            onTap: () {
              Future<void>.delayed(const Duration(milliseconds: 350), () {
                if (!context.mounted) return;
                Scrollable.ensureVisible(
                  context,
                  duration: const Duration(milliseconds: 240),
                  curve: Curves.easeOut,
                  alignment: 0.32,
                );
              });
            },
            onTapOutside: (_) => FocusScope.of(context).unfocus(),
          ),
        ],
      ),
    );
  }
}

class _ResultButton extends StatelessWidget {
  const _ResultButton({required this.result, required this.onTap});

  final AnswerResult result;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final (color, icon, label) = switch (result) {
      AnswerResult.correct => (
        AppTheme.success,
        Icons.check_rounded,
        'To‘g‘ri',
      ),
      AnswerResult.wrong => (AppTheme.danger, Icons.close_rounded, 'Noto‘g‘ri'),
      AnswerResult.unmarked => (
        const Color(0xFF8790A3),
        Icons.horizontal_rule_rounded,
        'Bo‘sh',
      ),
    };

    return Tooltip(
      message: label,
      child: Material(
        color: color.withAlpha(18),
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(12),
          child: Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: color.withAlpha(105)),
            ),
            alignment: Alignment.center,
            child: Icon(icon, color: color, size: 26),
          ),
        ),
      ),
    );
  }
}

class _ScorePanel extends StatelessWidget {
  const _ScorePanel({required this.block});

  final PracticeBlock block;

  @override
  Widget build(BuildContext context) {
    final complete = block.isComplete;
    final color = complete ? AppTheme.success : AppTheme.warning;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color.withAlpha(18),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withAlpha(80)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  complete ? 'Mashq natijasi' : 'Mashq davom etmoqda',
                  style: TextStyle(color: color, fontWeight: FontWeight.w800),
                ),
              ),
              Text(
                '${block.score.round()}%',
                style: TextStyle(
                  color: color,
                  fontWeight: FontWeight.w900,
                  fontSize: 20,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(999),
            child: LinearProgressIndicator(
              value: block.answers.isEmpty
                  ? 0
                  : block.correctCount / block.answers.length,
              minHeight: 8,
              color: color,
              backgroundColor: color.withAlpha(30),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            complete
                ? '${block.correctCount} ta to‘g‘ri • ${block.wrongCount} ta noto‘g‘ri'
                : '${block.markedCount}/${block.answers.length} ta belgilandi. Barcha so‘z belgilangach, natija dars statistikasiga qo‘shiladi.',
            style: const TextStyle(color: Color(0xFF5C6475), height: 1.35),
          ),
        ],
      ),
    );
  }
}
