import 'package:flutter_test/flutter_test.dart';
import 'package:soz_yodlash/models/practice.dart';

void main() {
  test('belgi bo‘sh, to‘g‘ri, noto‘g‘ri tartibida aylanadi', () {
    expect(AnswerResult.unmarked.next, AnswerResult.correct);
    expect(AnswerResult.correct.next, AnswerResult.wrong);
    expect(AnswerResult.wrong.next, AnswerResult.unmarked);
  });

  test('mashq foizi jami so‘zlar sonidan hisoblanadi', () {
    final answers = List.generate(
      10,
      (index) => ExerciseAnswer(
        wordIndex: index,
        result: index < 8 ? AnswerResult.correct : AnswerResult.wrong,
      ),
    );
    final block = PracticeBlock(
      id: 'test',
      level: 'A1',
      lessonNumber: 1,
      type: PracticeBlockType.exercise,
      position: 0,
      showTranslations: false,
      answers: answers,
    );

    expect(block.isComplete, isTrue);
    expect(block.correctCount, 8);
    expect(block.wrongCount, 2);
    expect(block.score, 80);
  });

  test('level natijasi bajarilgan darslar o‘rtachasidir', () {
    final progress = LevelProgress.fromLessons(const [
      LessonProgress(completedExercises: 2, score: 80),
      LessonProgress(completedExercises: 1, score: 60),
      LessonProgress(),
    ], totalLessons: 60);

    expect(progress.completedLessons, 2);
    expect(progress.score, 70);
    expect(progress.totalLessons, 60);
  });
}
