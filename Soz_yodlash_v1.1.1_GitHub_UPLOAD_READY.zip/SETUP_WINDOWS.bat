@echo off
chcp 65001 >nul
title So'z yodlash - dastlabki sozlash
cd /d "%~dp0"

where flutter >nul 2>nul
if errorlevel 1 (
  echo XATO: Flutter topilmadi.
  echo Flutter bin papkasini Windows PATH ga qo'shing va qayta urinib ko'ring.
  pause
  exit /b 1
)

echo 1/5 Android loyiha fayllari tayyorlanmoqda...
call flutter create --platforms=android --org uz.shuhrat --project-name soz_yodlash .
if errorlevel 1 goto error

echo 2/5 Android bildirishnoma sozlamalari qo'shilmoqda...
powershell -NoProfile -ExecutionPolicy Bypass -File "tools\configure_android.ps1"
if errorlevel 1 goto error

echo 3/5 Kerakli paketlar yuklanmoqda...
call flutter pub get
if errorlevel 1 goto error

echo 4/5 Testlar ishlatilmoqda...
call flutter test
if errorlevel 1 goto error

echo 5/5 Loyiha tekshirilmoqda...
call flutter analyze
if errorlevel 1 goto error

echo.
echo TAYYOR. Endi ushbu papkani Android Studio orqali oching.
echo Telefonni USB orqali ulang va yashil Run tugmasini bosing.
pause
exit /b 0

:error
echo.
echo Sozlash vaqtida xatolik yuz berdi. Yuqoridagi xato matnini rasmga olib yuboring.
pause
exit /b 1
