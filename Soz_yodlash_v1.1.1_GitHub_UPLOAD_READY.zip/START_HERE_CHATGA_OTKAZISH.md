# SO‘Z YODLASH — LOYIHANI BOSHQA CHATGA O‘TKAZISH HUJJATI

**Hujjat sanasi:** 2026-08-25  
**Joriy loyiha turi:** Flutter asosidagi Android ilova  
**Joriy versiya:** `1.1.0+2`  
**Loyiha papkasi:** `soz_yodlash_app`

> Ushbu hujjat yangi ChatGPT/Codex chatiga loyihaning maqsadi, amaldagi funksiyalari, ma’lumotlari, kod tuzilishi va ochiq muammolarini to‘liq tushuntirish uchun yozilgan. Hujjatni loyiha SOURCE ZIP fayli bilan birga yangi chatga yuklash kerak.

---

## 1. Yangi chatda ishlatish tartibi

Yangi chatga ushbu ZIP faylni yuklab, quyidagi xabarni yozing:

> Bu ZIP ichida “So‘z yodlash” Flutter Android ilovasining amaldagi source kodi va `START_HERE_CHATGA_OTKAZISH.md` boshqaruv hujjati bor. Avval hujjatni va mavjud kodni to‘liq o‘rgan. Mavjud ishlaydigan funksiyalarni saqla. Men kiritmoqchi bo‘lgan o‘zgarishlarni avval mendan so‘rab, aniq spetsifikatsiya qil. Men `START` yoki `Tasdiqlayman` demagunimcha yakuniy kodlashni boshlama. Tasdiqdan keyin o‘zgarishlarni mavjud Flutter loyihasiga kiriting, tekshiring va yangilangan to‘liq SOURCE ZIPni bering. Ilovani Kotlin loyihasiga aylantirmang, agar men alohida so‘ramasam.

Yangi chat loyiha haqida savol bersa, ushbu hujjatdagi ma’lumotlar asos bo‘ladi. Koddagi amaldagi holat esa texnik haqiqatning so‘nggi manbai hisoblanadi.

---

## 2. Ilovaning maqsadi

Ilova foydalanuvchiga ingliz tilidagi so‘zlarni daraja va darslar bo‘yicha yodlash, qayta yozib mashq qilish hamda natijasini foizlarda kuzatish imkonini beradi.

Asosiy tamoyillar:

- ilova internetsiz ishlaydi;
- barcha dars ma’lumotlari ilova ichida saqlanadi;
- foydalanuvchining javoblari va statistikasi telefonning lokal SQLite bazasida saqlanadi;
- bir darsda istalgancha mashq va matn bloki yaratish mumkin;
- javobning to‘g‘ri yoki noto‘g‘riligi hozircha foydalanuvchi tomonidan qo‘lda belgilanadi;
- natija mashq, dars va daraja kesimida hisoblanadi.

---

## 3. Asosiy navigatsiya

Ilova oqimi:

1. **Bosh sahifa — darajalar**
2. **Tanlangan daraja — 60 ta dars ro‘yxati**
3. **Tanlangan dars — lug‘at, mashqlar va matn bloklari**

### Bosh sahifadagi darajalar

Darajalar 2 ustunli kataklarda ko‘rsatiladi:

| Qator | Darajalar |
|---|---|
| 1 | A1 va A2 |
| 2 | B1 va B2 |
| 3 | C1 va C2 |

Amaldagi holat:

- **A1:** mavjud, 60 ta dars;
- **A2:** mavjud, 60 ta dars;
- **B1, B2, C1, C2:** hozircha ma’lumot yo‘q, kartalarda qulf va `Tez orada` yozuvi chiqadi.

Har bir mavjud daraja kartasida:

- daraja nomi;
- bajarilgan darslar soni (`x/60`);
- darajaning o‘rtacha natijasi ko‘rsatiladigan aylana mavjud.

---

## 4. Darslar ro‘yxati

A1 yoki A2 bosilganda 1-darsdan 60-darsgacha ro‘yxat ochiladi.

Har bir dars kartasida:

- dars raqami;
- dars mavzusi/sarlavhasi;
- darsdagi so‘zlar soni;
- mashq boshlangan bo‘lsa `Davom etmoqda` holati;
- tugallangan mashqlar soni;
- darsning o‘rtacha natijasi ko‘rsatiladi.

10, 20, 30, 40, 50 va 60-darslar **takrorlash darslari**. Ularning kartasida `Takrorlash` belgisi chiqadi. Ushbu darslarda o‘z blokidagi oldingi 9 ta dars so‘zlari jamlangan, mini-matn esa shu takrorlash darsining o‘ziga tegishli.

Daraja sahifasining tepasida kamida bitta tugallangan mashqi bor darslar soni ko‘rsatiladi.

---

## 5. Dars ichidagi ko‘rinish

Dars ochilganda sahifa quyidagi tartibda tuzilgan:

### 5.1. Dars sarlavhasi va qisqa statistika

- daraja va dars raqami;
- dars mavzusi;
- so‘zlar soni;
- tugallangan mashqlar soni;
- darsning o‘rtacha natijasi.

### 5.2. Dars lug‘ati

Ochiladigan/yopiladigan `Dars lug‘ati` kartasi mavjud. U dastlab ochiq turadi.

Jadval ustunlari:

| № | Inglizcha | O‘zbekcha |
|---|---|---|

Bu bo‘lim faqat ko‘rish uchun. Ma’lumotlar `assets/data/lessons.json` faylidan olinadi.

### 5.3. Mashq bloklari

Dars birinchi marta ochilganda **1-mashq avtomatik yaratiladi**.

Har bir mashqda:

- mashq raqami;
- o‘zbekcha tarjimalarni umumiy ko‘rsatish/yashirish tugmasi;
- har bir inglizcha so‘z;
- tarjima ko‘rinadigan yoki `Tarjima yashirilgan` holati;
- javob yozish maydoni;
- natijani belgilash tugmasi;
- mashq yakunidagi foiz paneli bor.

Tarjima tugmasi ikki holatda ishlaydi:

- yashil `✓` — o‘zbekcha tarjimalar ko‘rinadi;
- qizil `✕` — o‘zbekcha tarjimalar yashiriladi.

Har bir so‘zning natija tugmasi uch holatda aylanadi:

`bo‘sh → ✓ to‘g‘ri → ✕ noto‘g‘ri → bo‘sh`

Javob yozish maydoni bosilganda telefon klaviaturasi ochiladi. Sahifa klaviaturaga mos ko‘tariladi va tanlangan maydon berkilmasligi uchun scroll qilinadi.

**Muhim:** amaldagi versiyada yozilgan javob avtomatik tekshirilmaydi. `✓` yoki `✕` ni foydalanuvchi o‘zi qo‘yadi.

### 5.4. Matn bloklari

`M Matn` tugmasi bosilganda shu darsga tegishli mini-matn alohida karta sifatida qo‘shiladi.

Hozirgi versiyada har bir yangi `M` bloki shu darsning bir xil tayyor mini-matnini takror ko‘rsatadi. Ilova ichida yangi shaxsiy matn yozish funksiyasi mavjud emas.

### 5.5. Cheksiz bloklar

Har bir mashq yoki matn blokining tagida:

- `+ Mashq`;
- `M Matn`

tugmalari chiqadi. Bosilgan yangi blok aynan shu blokdan keyin joylashadi. Shu sabab mashq va matn bloklarini istalgan tartibda va istalgancha qo‘shish mumkin.

Ortiqcha blok o‘chirilishi mumkin. O‘chirishdan oldin tasdiqlash oynasi chiqadi va shu blokdagi javoblar ham o‘chishi haqida ogohlantiradi. Darsda faqat bitta blok qolgan bo‘lsa, uni o‘chirib bo‘lmaydi.

---

## 6. Statistika hisoblash qoidalari

### 6.1. Mashq natijasi

Formula:

`to‘g‘ri deb belgilangan so‘zlar / darsdagi jami so‘zlar × 100`

Misol: 10 ta so‘zdan 8 tasi `✓`, 2 tasi `✕` bo‘lsa — **80%**.

Mashq barcha so‘zlar `✓` yoki `✕` bilan belgilangandagina tugallangan hisoblanadi. Bo‘sh natija qolsa, mashq `Davom etmoqda` holatida turadi va darsning yakuniy o‘rtachasiga qo‘shilmaydi.

Javob maydoniga matn yozilishi o‘z-o‘zidan natijani o‘zgartirmaydi; natijani `✓/✕` belgilari belgilaydi.

### 6.2. Dars natijasi

Formula:

`shu darsdagi barcha tugallangan mashqlar foizlari yig‘indisi / tugallangan mashqlar soni`

Misol: 5 ta tugallangan mashq natijasi 80, 90, 70, 100 va 60 bo‘lsa:

`(80 + 90 + 70 + 100 + 60) / 5 = 80%`

Tugallanmagan mashqlar dars o‘rtachasiga kiritilmaydi.

### 6.3. Daraja natijasi

Daraja natijasi kamida bitta tugallangan mashqi bor darslarning o‘rtacha natijasidan hisoblanadi.

Hali boshlanmagan darslar daraja natijasini sun’iy pasaytirmaydi.

Daraja bo‘yicha ikki xil ko‘rsatkich bor:

- **o‘zlashtirish natijasi:** bajarilgan darslar foizlarining o‘rtachasi;
- **bajarilgan darslar:** kamida bitta tugallangan mashqi bor darslar soni (`x/60`).

---

## 7. Dars ma’lumotlari

Asosiy ma’lumot fayli:

`assets/data/lessons.json`

Uning ichida:

- A1 — 60 ta dars;
- A2 — 60 ta dars;
- jami 120 ta dars;
- har dars sarlavhasi;
- inglizcha–o‘zbekcha so‘z juftliklari;
- mini-matn mavjud.

Manba Excel fayllari:

- `source_data/A1_60_dars_sozlar_va_matnlar.xlsx`
- `source_data/A2_60_dars_sozlar_va_matnlar.xlsx`

JSON darsining soddalashtirilgan tuzilishi:

```json
{
  "number": 1,
  "title": "Dars mavzusi",
  "words": [
    {"english": "instruction", "uzbek": "ko‘rsatma"}
  ],
  "readingText": "Dars uchun inglizcha mini-matn"
}
```

Ma’lumotlarni yangilashda UTF-8, apostroflar va o‘zbek harflari saqlanishi shart. Dars raqamlari takrorlanmasligi, har darajada 1–60 tartibi buzilmasligi kerak.

---

## 8. Lokal saqlash tizimi

Paket: `sqflite`  
Baza nomi: `soz_yodlash_progress.db`  
Baza versiyasi: `1`

Asosiy jadvallar:

### `practice_blocks`

- blok ID;
- daraja;
- dars raqami;
- blok turi (`exercise` yoki `reading_text`);
- dars ichidagi tartib raqami;
- tarjima ko‘rinishi;
- yaratilgan vaqt.

### `exercise_answers`

- blok ID;
- so‘z indeksi;
- yozilgan javob;
- natija: `1 = to‘g‘ri`, `0 = bo‘sh`, `-1 = noto‘g‘ri`.

Blok o‘chirilganda unga tegishli javoblar `ON DELETE CASCADE` orqali o‘chadi.

Hozircha quyidagilar yo‘q:

- akkaunt va login;
- server yoki bulut sinxronizatsiyasi;
- backup/restore;
- qurilmalararo ma’lumot ko‘chirish.

Ilova o‘chirilsa, lokal statistika ham yo‘qolishi mumkin.

---

## 9. Texnologiyalar

- Flutter va Dart;
- Material 3 UI;
- Dart SDK talabi: `>=3.5.0 <4.0.0`;
- `sqflite: ^2.4.1`;
- `path: ^1.9.1`;
- ilova internetsiz ishlaydi.

Flutter package nomi: `soz_yodlash`  
Android loyihasi yaratish tashkiloti: `uz.shuhrat`  
Android ko‘rinadigan nomi: `So'z yodlash`

Loyihani boshqa texnologiyaga ko‘chirish shart emas. Yangi o‘zgarishlar mavjud Flutter arxitekturasi ichida qilinishi kerak, agar foydalanuvchi alohida boshqa qaror bermasa.

---

## 10. Muhim fayllar va vazifalari

| Fayl/papka | Vazifasi |
|---|---|
| `lib/main.dart` | Boshlang‘ich ma’lumot va bazani yuklaydi, ilovani ishga tushiradi |
| `lib/app.dart` | `MaterialApp`, tema va bosh sahifani ulaydi |
| `lib/models/lesson.dart` | Daraja, dars va so‘z modellari |
| `lib/models/practice.dart` | Mashq, javob holati va statistika modellari |
| `lib/services/lesson_repository.dart` | `lessons.json` ma’lumotini o‘qiydi |
| `lib/services/progress_database.dart` | SQLite yaratish, javob/blok/statistikani saqlash va o‘qish |
| `lib/screens/home_screen.dart` | A1–C2 bosh sahifasi va daraja natijalari |
| `lib/screens/lesson_list_screen.dart` | 60 ta dars ro‘yxati va dars natijalari |
| `lib/screens/lesson_detail_screen.dart` | Lug‘at, mashq va matn bloklarini boshqaradi |
| `lib/widgets/exercise_block_card.dart` | Mashqning barcha UI va javob belgilash mantig‘i |
| `lib/widgets/vocabulary_section.dart` | Inglizcha–o‘zbekcha lug‘at jadvali |
| `lib/widgets/reading_text_card.dart` | `M` mini-matn kartasi |
| `lib/widgets/block_action_row.dart` | `+ Mashq` va `M Matn` tugmalari |
| `lib/widgets/progress_ring.dart` | Daraja natijasi aylanasi |
| `lib/theme/app_theme.dart` | Rang va Material 3 tema |
| `assets/data/lessons.json` | Ilovada ishlatiladigan barcha A1/A2 darslari |
| `source_data/` | Darslarning dastlabki Excel manbalari |
| `test/progress_models_test.dart` | Belgilar aylanishi va statistika formulalari testlari |
| `SETUP_WINDOWS.bat` | Android platforma fayllarini yaratish va dastlabki sozlash |
| `RUN_ANDROID.bat` | `flutter pub get` va `flutter run` bajaradi |

---

## 11. Dizaynning amaldagi uslubi

- och kulrang fon;
- oq kartalar;
- asosiy ko‘k rang: `#3156D9`;
- yashil — to‘g‘ri/yakunlangan;
- qizil — noto‘g‘ri/yashirilgan;
- sariq — davom etayotgan holat;
- yumaloq burchakli Material 3 kartalar;
- dars va mashq sahifalarida ochiladigan bloklar;
- telefon ekraniga mos vertikal scroll.

Hozir faqat yorug‘ tema mavjud. Qorong‘i tema va ko‘p tilli UI yo‘q.

---

## 12. Hozircha mavjud bo‘lmagan funksiyalar

Yangi chat quyidagilarni amalda bor deb qabul qilmasin:

- B1, B2, C1, C2 dars ma’lumotlari;
- javobni avtomatik tekshirish;
- ovozli talaffuz va audio;
- interval takrorlash/spaced repetition;
- qidiruv va favoritlar;
- login, server, sinxronizatsiya va backup;
- foydalanuvchining ilova ichida o‘z darsi yoki matnini yaratishi;
- qorong‘i tema;
- maxsus tayyorlangan ilova ikonka va splash dizayni.

---

## 13. Oxirgi ishga tushirish holati va ochiq muammo

Loyiha Windows kompyuterda Android Studio orqali Honor telefoni (`LNA NX1`) bilan sinovdan o‘tkazilgan.

Jarayonda:

1. Flutter va Dart plaginlari o‘rnatilgan.
2. Telefon USB debugging orqali tanilgan.
3. NDK `28.2.13676358` dastlab chala yuklangan.
4. C diskda joy yetishmasligi aniqlangan (`Недостаточно места на диске`).
5. Joy bo‘shatilgan va buzilgan NDK papkasi o‘chirilib qayta yuklangan.
6. CMake `3.22.1` o‘rnatilgan.
7. Yakunda `Built build\app\outputs\flutter-apk\app-debug.apk` yozuvi chiqqan va APK telefonga o‘rnatilgan.

**Ochiq muammo:** telefonda standart Flutter logotipli oq splash ekran 5–10 daqiqadan ko‘p turib qolgan, bosh sahifa ochilmagan.

`lib/main.dart` hozir `runApp()`dan oldin quyidagilarni kutadi:

1. `LessonRepository.load()` — katta JSON assetni o‘qish;
2. `ProgressDatabase.instance.database` — SQLite bazasini ochish/yaratish.

Shuning uchun ushbu jarayonlardan biri to‘xtasa yoki xato bersa, foydalanuvchi faqat native Flutter splash ekranini ko‘radi; ilovaning o‘zida xatolik oynasi chiqmaydi. Bu splashda qolishning ehtimoliy sababi, lekin loglar bilan tasdiqlanishi kerak.

### Yangi chat birinchi navbatda qilishi kerak bo‘lgan ish

1. Source kodni ochish va `flutter pub get` bajarish.
2. `flutter analyze` va `flutter test` ishlatish.
3. Real qurilma yoki emulator logini tekshirib splashda qolishning aniq sababini aniqlash.
4. Ilova UI’ini `runApp()` orqali darhol ishga tushirib, boshlang‘ich yuklash uchun Flutter ichidagi loading/error ekrani yaratish tavsiya etiladi.
5. JSON va SQLite ochilishida xato bo‘lsa, foydalanuvchiga tushunarli xabar va qayta urinish tugmasi ko‘rsatish.
6. Tuzatishdan keyin sovuq ishga tushirish, qayta ochish va telefon qayta ishga tushganidan keyingi holatni tekshirish.

---

## 14. Ma’lum sozlash ehtiyot choralari

`SETUP_WINDOWS.bat` ichida `flutter create` ishlatiladi. Bu buyruq qayta bajarilsa, Flutter standart `test/widget_test.dart` faylini yana yaratishi mumkin. U standart `MyApp` klassini qidirib, ushbu loyihada analyzer xatosi chiqaradi.

Shuning uchun:

- Android platformasi allaqachon yaratilgan loyihada `SETUP_WINDOWS.bat`ni qayta-qayta ishlatmaslik;
- standart `test/widget_test.dart` paydo bo‘lsa, uni olib tashlash yoki amaldagi `SozYodlashApp`ga moslab yozish;
- `test/progress_models_test.dart`ni saqlash;
- foydalanuvchining lokal SQLite ma’lumotini ataylab o‘chirmaslik kerak.

---

## 15. O‘zgartirishlar paytida saqlanishi shart bo‘lgan qoidalar

Yangi funksiya alohida kelishilmagan bo‘lsa, quyidagilar buzilmasin:

1. A1 va A2 ning 60 tadan darsi va mini-matnlari saqlansin.
2. B1–C2 ma’lumotsiz bo‘lsa `Tez orada` holatida qolsin.
3. Mashq va matn bloklari cheksiz qo‘shilsin.
4. Bloklar aynan bosilgan blokdan keyin joylashsin.
5. Tarjimalarni mashq kesimida ko‘rsatish/yashirish ishlasin.
6. Har bir so‘zning javobi va `bo‘sh/✓/✕` holati lokal saqlansin.
7. Klaviatura javob maydonini berkitmasin.
8. Mashq, dars va daraja formulalari yuqoridagi qoidalarga mos qolsin.
9. Ilova internetsiz ishlashda davom etsin.
10. Mavjud foydalanuvchi statistikasi migratsiyasiz yo‘qolmasin.

SQLite sxemasi o‘zgartirilsa, baza versiyasini oshirish va xavfsiz migratsiya yozish shart.

---

## 16. Har bir yangi build uchun tekshiruv ro‘yxati

- [ ] `dart format` bajarildi.
- [ ] `flutter analyze` xatosiz yakunlandi.
- [ ] `flutter test` xatosiz yakunlandi.
- [ ] Ilova yangi o‘rnatilganda bosh sahifa ochildi.
- [ ] Ilova ikkinchi marta ochilganda splashda qolmadi.
- [ ] A1 va A2 da 60 tadan dars ko‘rindi.
- [ ] B1–C2 bloklangan holatda qoldi.
- [ ] Dars lug‘ati to‘liq ko‘rindi.
- [ ] Tarjima yashirish/ko‘rsatish ishladi.
- [ ] Javob yozildi va klaviatura maydonni berkitmadi.
- [ ] `bo‘sh → ✓ → ✕ → bo‘sh` aylanishi ishladi.
- [ ] Ilova yopib ochilganda javob va belgilar saqlandi.
- [ ] `+ Mashq` va `M Matn` bilan bir nechta blok qo‘shildi.
- [ ] Blok o‘chirildi va tartib buzilmadi.
- [ ] Mashq foizi to‘g‘ri chiqdi.
- [ ] Dars o‘rtachasi to‘g‘ri chiqdi.
- [ ] Daraja natijasi to‘g‘ri chiqdi.
- [ ] Internet o‘chiq holatda asosiy funksiyalar ishladi.

---

## 17. Yangi chatdan kutiladigan yakuniy topshirish

Foydalanuvchi o‘zgarishlarni tasdiqlagandan keyin yangi chat:

1. mavjud source kod ustida ishlashi;
2. oldingi funksiyalarni saqlashi;
3. o‘zgarishlarni test qilishi;
4. versiya raqamini mantiqan yangilashi;
5. yangilangan to‘liq Flutter SOURCE ZIP berishi;
6. nimalar o‘zgargani va telefonda qanday sinashni qisqa yozishi kerak.

APK yoki GitHub Actions workflow alohida so‘ralsa, source ZIP bilan birga qo‘shilishi mumkin.

---

## 18. Qisqa loyiha xulosasi

“So‘z yodlash” — A1 va A2 darajalaridagi 120 ta dars uchun inglizcha–o‘zbekcha lug‘at, mini-matn, cheksiz qo‘lda baholanadigan mashqlar va lokal statistika beruvchi oflayn Flutter Android ilovasi. Asosiy funksiyalar kodlangan. APK yig‘ilishi muvaffaqiyatli bo‘lgan, ammo real telefonda ilova standart Flutter splash ekranidan bosh sahifaga o‘tmay qolgan. Keyingi ishning birinchi vazifasi shu startup muammosini log orqali aniqlab, xavfsiz loading/error oqimi bilan tuzatishdir.



---

## 17. 2026-08-25 qo‘shilgan bildirishnoma funksiyalari

- Bosh sahifada chapdan ochiladigan Drawer menyu qo‘shildi.
- Drawer ichida `Bildirishnomalar` bo‘limi mavjud.
- Foydalanuvchi sun’iy ilova cheklovisiz bir nechta kundalik eslatma vaqtlarini qo‘shishi, vaqtini tahrirlashi, vaqtincha o‘chirishi/yoqishi va o‘chirib tashlashi mumkin.
- Eslatma matni inglizcha so‘zlarni takrorlashga undaydi va har kuni tanlangan vaqtda lokal bildirishnoma sifatida keladi.
- Android 13+ da bildirishnoma ruxsati eslatma qo‘shish/yoqish paytida so‘raladi.
- Bildirishnoma bosilganda ilova faqat bosh sahifani emas, oxirgi marta mashqi to‘liq yakunlangan darsning `LessonDetailScreen` oynasini ochadi.
- Oxirgi tugallangan dars `app_state` jadvalida saqlanadi. v1 foydalanuvchilari uchun eski tugallangan mashqlardan bir martalik fallback aniqlash mavjud.
- SQLite baza versiyasi `2`: yangi `daily_reminders` va `app_state` jadvallari qo‘shilgan. `v1 → v2` migratsiya eski mashq/javob/statistika ma’lumotlarini saqlaydi.
- Lokal notification paketlari: `flutter_local_notifications`, `flutter_timezone`, `timezone`.
- Android notification scheduling uchun `RECEIVE_BOOT_COMPLETED`, scheduled receiverlar, Java 17 va core-library desugaring `tools/configure_android.ps1` orqali sozlanadi.
- GitHub Actions: `.github/workflows/main.yml` test → analyze → debug APK build → artifact upload oqimini bajaradi.
