# So‘z yodlash

Ingliz tilidagi so‘zlarni darslar bo‘yicha yodlash va mashq qilish uchun internetsiz ishlaydigan Flutter ilovasi.

## Tayyor funksiyalar

- A1 va A2 darajalari, har birida 60 tadan dars.
- B1, B2, C1 va C2 darajalari asosiy oynada `Tez orada` holatida turadi.
- Har bir darsda inglizcha–o‘zbekcha lug‘at va mini-matn mavjud.
- Dars ochilganda 1-mashq avtomatik yaratiladi.
- O‘zbekcha tarjimalarni `✓/✕` tugmasi bilan ko‘rsatish yoki yashirish mumkin.
- Har bir so‘z uchun javob yozish maydoni va uch holatli belgi mavjud: `bo‘sh → ✓ → ✕`.
- `+ Mashq` va `M Matn` tugmalari orqali bloklarni istalgancha ko‘paytirish mumkin.
- Ortiqcha qo‘shilgan blokni o‘chirish mumkin.
- Mashq, dars va level natijalari avtomatik hisoblanadi.
- Barcha javoblar va statistika telefondagi SQLite bazasida saqlanadi.
- Chap menyudagi `Bildirishnomalar` bo‘limida istalgancha kundalik eslatma vaqti qo‘shish mumkin.
- Bildirishnoma bosilganda oxirgi marta mashqi tugallangan dars ichiga to‘g‘ridan-to‘g‘ri o‘tiladi.

## Windows va Android Studio’da birinchi marta ochish

1. ZIP faylni alohida papkaga to‘liq chiqaring.
2. `SETUP_WINDOWS.bat` faylini ikki marta bosing.
3. Qora oynada `TAYYOR` yozuvi chiqquncha kuting.
4. Android Studio’ni oching va **Open** tugmasini bosing.
5. ZIPdan chiqarilgan `soz_yodlash_app` papkasini tanlang.
6. Telefoningizda USB debugging yoqilgan holda uni USB orqali ulang.
7. Android Studio yuqorisidan telefoningizni tanlab, yashil **Run ▶** tugmasini bosing.

Keyingi safar Android Studio ichidagi **Run ▶** yoki `RUN_ANDROID.bat` orqali ishga tushirish mumkin.

## Muhim fayllar

- `lib/` — ilovaning Dart kodi.
- `assets/data/lessons.json` — ilova o‘qiydigan 120 ta dars ma’lumoti.
- `source_data/` — dastlabki A1 va A2 Excel fayllari.
- `test/` — statistika hisobini tekshiruvchi testlar.

## Natija hisoblash

- Mashq: `to‘g‘ri belgilar / jami so‘zlar × 100`.
- Mashq barcha so‘zlar `✓` yoki `✕` bilan belgilangach tugallangan hisoblanadi.
- Dars: shu darsdagi tugallangan mashqlar foizining o‘rtachasi.
- Level: kamida bitta tugallangan mashqi bor darslar natijasining o‘rtachasi.
- Hali boshlanmagan darslar level foizini sun’iy pasaytirmaydi.



## GitHub Actions

`.github/workflows/main.yml` GitHub Actions orqali test, analyze va debug APK build qiladi. APK `soz-yodlash-debug-apk` artifact sifatida chiqadi.

Bildirishnomalar uchun Android platform fayllari yaratilgach `tools/configure_android.ps1` manifest, Java 17 va desugaring sozlamalarini avtomatik qo‘shadi.
