$ErrorActionPreference = 'Stop'

$projectRoot = Split-Path -Parent $PSScriptRoot
$manifestPath = Join-Path $projectRoot 'android/app/src/main/AndroidManifest.xml'
$gradleKtsPath = Join-Path $projectRoot 'android/app/build.gradle.kts'
$gradleGroovyPath = Join-Path $projectRoot 'android/app/build.gradle'
$utf8WithoutBom = New-Object System.Text.UTF8Encoding($false)

if (Test-Path -LiteralPath $manifestPath) {
    $content = [System.IO.File]::ReadAllText($manifestPath)
    $content = $content.Replace(
        'android:label="soz_yodlash"',
        'android:label="So''z yodlash"'
    )

    if (-not $content.Contains('android.permission.RECEIVE_BOOT_COMPLETED')) {
        $content = $content.Replace(
            '<manifest xmlns:android="http://schemas.android.com/apk/res/android">',
            "<manifest xmlns:android=`"http://schemas.android.com/apk/res/android`">`n    <uses-permission android:name=`"android.permission.RECEIVE_BOOT_COMPLETED`"/>"
        )
    }

    if (-not $content.Contains('ScheduledNotificationReceiver')) {
        $receivers = @'
        <receiver
            android:exported="false"
            android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver" />
        <receiver
            android:exported="false"
            android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED"/>
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED"/>
                <action android:name="android.intent.action.QUICKBOOT_POWERON"/>
                <action android:name="com.htc.intent.action.QUICKBOOT_POWERON"/>
            </intent-filter>
        </receiver>
'@
        $content = $content.Replace('</application>', "$receivers    </application>")
    }

    [System.IO.File]::WriteAllText($manifestPath, $content, $utf8WithoutBom)
}

if (Test-Path -LiteralPath $gradleKtsPath) {
    $content = [System.IO.File]::ReadAllText($gradleKtsPath)
    $content = $content -replace 'compileSdk\s*=\s*flutter\.compileSdkVersion', 'compileSdk = 35'
    $content = $content.Replace('JavaVersion.VERSION_11', 'JavaVersion.VERSION_17')
    $content = $content.Replace('JavaVersion.VERSION_1_8', 'JavaVersion.VERSION_17')

    if (-not $content.Contains('isCoreLibraryDesugaringEnabled')) {
        $content = $content -replace 'compileOptions\s*\{', "compileOptions {`n        isCoreLibraryDesugaringEnabled = true"
    }
    if (-not $content.Contains('coreLibraryDesugaring(')) {
        $content += @'


dependencies {
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")
}
'@
    }
    [System.IO.File]::WriteAllText($gradleKtsPath, $content, $utf8WithoutBom)
}
elseif (Test-Path -LiteralPath $gradleGroovyPath) {
    $content = [System.IO.File]::ReadAllText($gradleGroovyPath)
    $content = $content -replace 'compileSdkVersion\s+flutter\.compileSdkVersion', 'compileSdkVersion 35'
    $content = $content -replace 'compileSdk\s+flutter\.compileSdkVersion', 'compileSdk 35'
    $content = $content.Replace('JavaVersion.VERSION_11', 'JavaVersion.VERSION_17')
    $content = $content.Replace('JavaVersion.VERSION_1_8', 'JavaVersion.VERSION_17')

    if (-not $content.Contains('coreLibraryDesugaringEnabled')) {
        $content = $content -replace 'compileOptions\s*\{', "compileOptions {`n        coreLibraryDesugaringEnabled true"
    }
    if (-not $content.Contains('coreLibraryDesugaring ')) {
        $content += @'


dependencies {
    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.4'
}
'@
    }
    [System.IO.File]::WriteAllText($gradleGroovyPath, $content, $utf8WithoutBom)
}
else {
    throw 'Android app Gradle fayli topilmadi.'
}
