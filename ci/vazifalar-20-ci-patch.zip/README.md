# Vazifalar 2.0 — 4-bosqich (jamlangan GitHub manba paketi)

**Paket tarkibi: 1+2+3+4-bosqich o‘zgarishlari.** Yagona `tools/apply_phase4.py` skripti `iSoron/uhabits` repozitoriysining **aynan** `2816b7c3d04b61277dab8765d17420f878241f09` commitidagi manba kodiga ilovaning barcha mavjud o‘zgarishlarini qo‘llaydi. Oldingi ZIP'larni ketma-ket qo‘llash shart emas.

**Bu 4-bosqichdagi manba paketi — APK emas.** GitHub'da `assembleRelease` ishga tushirilishi **5-bosqichga** qoldirilgan. 4-bosqichda Kotlin/Android kompilyatsiyasi va telefon sinovi o'tkazilmadi.

## 4-bosqich yangi imkoniyatlari

1. Yuqori o‘ngdagi **kalendar** tugmasida bugungi hali bajarilmagan kalendar vazifalari soni (`●n`) ko‘rsatiladi. Yuqori sana tugmasidagi avvalgi foizli **monitoring kalendari saqlanadi**.
2. **Oylik kalendar:** kunlarda vazifalar soni, bajarilmagan kunlarda `×`, o‘tmishda `?` qolgan kunlarda `!`, bugungi rejalarda ko‘k indikator. Pastda oylik jami, `✓`, `×`, `?`, umumiy foiz.
3. **Sana ichidagi vazifalar oynasi:** yangi vazifa yozish, tahrirlash, mavjud sananing blokiga biriktirish (`+`), bitta kun rejasini o‘chirish, oylik pinni yoqish/o‘chirish, boshqa kunga ko‘chirish, kelajak takrorlarini to‘xtatish.
4. **Kalendar vazifasi avtomatik pin bilan yaratiladi:** har oy bir xil sanada `?` holatli yangi nusxasi hosil bo‘ladi. Sana mavjud bo‘lmagan oyda (masalan, 31-fevral) avtomatik ko‘chirish o‘rniga shu oyning nusxasi yaratilmaydi.
5. **Biriktirish:** kalendarda `+` bosilganda o‘sha sananing bloklari chiqadi; hali kelmagan sanaga qo‘shish uchun alohida tasdiq so‘raladi. Bitta kalendar nusxasi bir vaqtning o‘zida faqat bitta faol vazifaga bog‘lanadi.
6. **Holat sinxronlashuvi:** blokda `✓`/`×`/`?` o‘zgarsa bog‘langan kalendar yozuvi ham yangilanadi. Blokdagi vazifa o‘chirilganda kalendar yozuvi va uning oxirgi qayd etilgan holati qoladi. Blokdagi nom tahrirlansa bog‘langan kalendar nomi ham yangilanadi.
7. **Sana ko‘chirish:** pinning kelgusi oylardagi sanasi oxirgi tasdiqlangan sanaga o‘tadi. Yozib bo‘lingan tarixiy `✓`/`×` nusxalar saqlanadi. Avval yaratilgan, ammo hali blokka biriktirilmagan kelgusi `?` nusxalar eskirgan sanada qolmaydi.
8. **Kunlik ogohlantirish:** kalendarda bugungi reja `?` bo‘lsa, birinchi blok boshlanishida bitta umumiy, ovozsiz (uch signalli blok signaliga xalaqit bermaydigan) Android bildirishnomasi yaratiladi. Kuniga bir martalik jadval `calendar_alerts` orqali saqlanadi; telefon qayta yoqilganda qayta rejalashtiriladi. Blok va vazifa uchun oldingi uch signal/shaxsiy ohanglar o‘zgartirilmagan.
9. **SQLite v4 migratsiya:** mavjud `tasks`, `day_results`, `task_events`, `task_pin_templates` saqlangan holda `calendar_plans`, `calendar_entries`, `calendar_exclusions`, `calendar_alerts` jadvallari qo‘shiladi. Kalendar va bloklar alohida ma’lumotlar qatlamiga ega, shu sababli bir vazifa ikkita blok nusxasiga aylanmaydi.
10. **Zaxira:** JSON schema 4 kengaytirildi; avvalgi 1, 2, 3 versiya JSON fayllarini tiklash mexanizmi saqlangan.

## Avvalgi bosqichlar saqlanadi

- Faqat Vazifalar bosh ekrani va moslashgan kengayadigan karta maydoni, pastki Odatlar/Vazifalar panelisiz.
- Foydalanuvchi yuborgan ko‘k qumsoat ikonka va ochilish ekrani.
- `✓` tugmasi natijani saqlab, dekorativ animatsiya nosozligi saqlashga ta’sir qilmasligi uchun alohida ishlaydi.
- Har bir blokning boshlanish-tugash vaqtini `TimePickerDialog` orqali qo‘lda tahrirlash; tanaffuslar va faol blokning pastda ham qolishi.
- Har kuni pinlangan vazifalar va tarix/arxiv; kechagi `×` nusxalarni faol arxivdan olib tashlash.
- Blok almashish uch signali, ohangni tizimdan tanlash, shaxsiy vazifa eslatmasi, bildirishnomadagi `✓`, `×`, «O‘tkazib yuborish» tugmalari.

## GitHub'ga qo‘yish va tekshirish

1. ZIP tarkibini repo ildiziga chiqaring. `.github/workflows/android-build.yml` — ZIP ichida ham mavjud; yonidagi YML fayli ham shu nusxa.
2. Manba paketining o‘zini build qilmasdan tekshirish: `python3 -m unittest discover -s tests -v`.
3. Upstream patchini qo‘llash: `python3 tools/apply_phase4.py upstream`, bunda `upstream` **pinned** Loop commitining katalogi bo‘lishi kerak. Skript ikki marta qo‘llanishni rad etadi.
4. **Faqat 5-bosqichda** GitHub Actions `workflow_dispatch` ni ishga tushiring. YML release build uchun mo‘ljallangan, ammo 4-bosqichda ishga tushirilmagan.
5. Doimiy release imzolash uchun GitHub Secrets: `TASKS_KEYSTORE_BASE64`, `TASKS_KEYSTORE_PASSWORD`, `TASKS_KEY_ALIAS`, `TASKS_KEY_PASSWORD`. Eski APK sertifikatini solishtirish uchun ixtiyoriy `TASKS_EXISTING_CERT_SHA256`.

## Muhim texnik cheklovlar

- Paket nomi **o‘zgarmadi:** `org.isoron.uhabits.tasks.preview`; versiya `2.0.0-stage4`, `versionCode=20305`. O‘rnatilgan debug APK ustiga yangilash uchun *aynan eski imzo sertifikati* kerak. Boshqa release sertifikati bilan to‘g‘ridan-to‘g‘ri yangilash mumkin emas; eski APK'dan JSON backup olib, yangi imzolangan o‘rnatishga ko‘chirish talab qilinishi mumkin.
- Takrorlanayotgan nusxani o‘chirib tashlash uning arxiv va hisoblash tarixini o‘chirmaydi; **bitta sanani o‘chirish** bundan mustasno, shu sana kalendardan yo‘qotiladi, unga bog‘langan blok vazifasi esa saqlanadi. Kelgusi pinni to‘xtatish alohida amaldir.
- Kelajak uchun avvaldan blokka qo‘lda joylashtirilgan vazifalar avtomatik ravishda o‘chirib yuborilmaydi. Sananing pin jadvali keyin o‘zgargan bo‘lsa ham, bu eski bog‘langan vazifalar mustaqil ravishda saqlanadi; ma’lumot yo‘qotishdan ko‘ra ehtiyotkor tanlov.
- Android exact-alarm, notification permission, OEM fon cheklovlari va imzo mosligi 5-bosqichdagi haqiqiy build/qurilma tekshiruvlariga bog‘liq. Odatlar modulining yashirin manba kodlari upstream kompilyatsiya bog‘liqligi sababli qoladi; Odatlar interfeysi kirish nuqtasi emas.

## Manba va litsenziya

Ilova `iSoron/uhabits` manba kodiga tayangan; GPL-3.0-or-later talablariga muvofiq original manba atributlari saqlanadi.
