/* SPDX-License-Identifier: GPL-3.0-or-later */
package org.isoron.uhabits.activities.tasks

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/** One block-transition alarm, and an independent next-due-task reminder alarm. */
internal object TasksAlarms {
    private const val REQUEST = 6805
    private const val NEW_DAY_REQUEST = 6807

    fun schedule(context: Context) {
        val store = TaskStore(context)
        val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val alarm = PendingIntent.getBroadcast(context, REQUEST,
            Intent(context, TasksAlarmReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        manager.cancel(alarm)
        if (!store.configured()) return
        val now = System.currentTimeMillis()
        val zone = ZoneId.systemDefault()
        val today = Instant.ofEpochMilli(now).atZone(zone).toLocalDate()
        val starts = store.blocks().map { it.start }
        val next = (0L..2L).flatMap { delta ->
            val date = today.plusDays(delta)
            starts.map { time -> date.atStartOfDay(zone).plusMinutes(time.toLong()).toInstant().toEpochMilli() }
        }.firstOrNull { it > now + 1000L } ?: return
        scheduleAlarm(manager, next, alarm)
    }

    /** Midnight rollover generates daily pinned instances, even before the first block. */
    fun scheduleNextDay(context: Context) {
        val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pending = PendingIntent.getBroadcast(context, NEW_DAY_REQUEST,
            Intent(context, TasksDailyReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        manager.cancel(pending)
        if (!TaskStore(context).configured()) return
        val tomorrow = LocalDate.now().plusDays(1)
            .atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli() + 2000L
        scheduleAlarm(manager, tomorrow, pending)
    }

    /** Inexact fallback on devices without exact-alarm privileges. */
    fun scheduleAlarm(manager: AlarmManager, at: Long, intent: PendingIntent) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && manager.canScheduleExactAlarms()) {
                manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, intent)
            } else if (Build.VERSION.SDK_INT in Build.VERSION_CODES.M..Build.VERSION_CODES.R) {
                manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, intent)
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, intent)
            } else {
                manager.setExact(AlarmManager.RTC_WAKEUP, at, intent)
            }
        } catch (_: SecurityException) {
            // Exact alarm permission may be revoked between the check and set call.
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, intent)
        }
    }
}

internal object TasksReminders {
    private const val REQUEST = 6806

    fun schedule(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val alarm = PendingIntent.getBroadcast(context, REQUEST,
            Intent(context, TasksReminderReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        alarmManager.cancel(alarm)
        val dueAt = TaskStore(context).nextReminderTime() ?: return
        // Past alarms are processed on the next available wakeup; the receiver bounds staleness.
        TasksAlarms.scheduleAlarm(alarmManager, maxOf(dueAt, System.currentTimeMillis() + 1200L), alarm)
    }
}

internal class TasksAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val async = goAsync()
        try {
            val store = TaskStore(context)
            if (store.configured()) {
                val zone = ZoneId.systemDefault()
                val now = Instant.now().atZone(zone)
                val minutes = now.hour * 60 + now.minute
                // Prevent a stale alarm (clock changes, large Doze delay) from claiming a new block.
                val onBoundary = store.blocks().any {
                    minutes >= it.start && minutes - it.start <= 10
                }
                store.reconcile()
                if (onBoundary) TasksNotifications.showBlock(context)
            }
            TasksAlarms.schedule(context)
            TasksAlarms.scheduleNextDay(context)
            TasksReminders.schedule(context)
            TasksCalendarAlerts.schedule(context)
        } finally { async.finish() }
    }
}

internal class TasksDailyReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val pending = goAsync()
        try {
            val store = TaskStore(context)
            if (store.configured()) store.reconcile()
            TasksAlarms.schedule(context)
            TasksAlarms.scheduleNextDay(context)
            TasksReminders.schedule(context)
            TasksCalendarAlerts.schedule(context)
        } finally { pending.finish() }
    }
}

internal class TasksReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val async = goAsync()
        try {
            val store = TaskStore(context)
            store.claimDueReminders(System.currentTimeMillis()).forEach { task ->
                TasksNotifications.showReminder(context, task)
            }
            TasksReminders.schedule(context)
        } finally { async.finish() }
    }
}

internal class TasksReminderActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val id = intent?.getLongExtra("task_id", -1L) ?: return
        if (id < 0) return
        val store = TaskStore(context)
        val task = store.taskById(id) ?: return
        when (intent.action) {
            "org.isoron.uhabits.tasks.REMINDER_DONE" -> if (task.status == "PENDING" && task.archiveKind == null) store.setStatus(task, "DONE")
            "org.isoron.uhabits.tasks.REMINDER_FAILED" -> if (task.status == "PENDING" && task.archiveKind == null) store.setStatus(task, "FAILED")
            "org.isoron.uhabits.tasks.REMINDER_SKIP" -> store.recordReminderSkipped(task.id)
            else -> return
        }
        TasksNotifications.dismissReminder(context, id)
        TasksReminders.schedule(context)
        TasksCalendarAlerts.schedule(context)
    }
}

internal class TasksBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action in setOf(Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_TIME_CHANGED,
                Intent.ACTION_TIMEZONE_CHANGED, Intent.ACTION_DATE_CHANGED,
                AlarmManager.ACTION_SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED)) {
            TasksAlarms.schedule(context)
            TasksAlarms.scheduleNextDay(context)
            TasksReminders.schedule(context)
            TasksCalendarAlerts.schedule(context)
        }
    }
}
