/* SPDX-License-Identifier: GPL-3.0-or-later */
package org.isoron.uhabits.activities.tasks

import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log

/** A foreground media-playback service so custom selected alarm tones can ring three times
 *  while the app is closed. Each custom pulse is capped at 1.7s; it never plays a long song 3x.
 *  Default packaged WAV already contains three pulses and is played only once.
 */
class TasksSignalService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var player: MediaPlayer? = null
    private var sequence = 0
    private var fallback = false
    private val startNext = object : Runnable {
        override fun run() {
            val bundled = fallback || TasksTones.isBundledDefault(this@TasksSignalService)
            val uri = if (fallback) TasksTones.default(this@TasksSignalService, TasksTones.BLOCK)
                else TasksTones.selected(this@TasksSignalService, TasksTones.BLOCK)
            if (uri == null) { finishSignal(); return }
            if (sequence >= if (bundled) 1 else 3) {
                finishSignal(); return
            }
            sequence++
            try {
                player?.release()
                val p = MediaPlayer().apply {
                    setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                    setDataSource(this@TasksSignalService, uri)
                    prepare()
                }
                player = p
                p.start()
                // The bundled WAV itself contains 3 tones, whereas the chosen custom tone
                // is truncated into three short clips separated by a brief gap.
                handler.postDelayed({
                    runCatching { player?.stop() }
                    player?.release()
                    player = null
                    handler.postDelayed(this, 350L)
                }, if (bundled) 1900L else 1700L)
            } catch (e: Exception) {
                Log.w("TasksSignalService", "Selected tone could not be played", e)
                if (!bundled) {
                    // Keep the user's choice, but play the bundled 3-chime fallback this time.
                    player?.release()
                    player = null
                    fallback = true
                    sequence = 0
                    handler.post(this)
                } else finishSignal()
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // The notification is the SAME notification throughout all three pulses.
        try {
            startForeground(6805, TasksNotifications.blockNotification(this))
        } catch (e: RuntimeException) {
            Log.w("TasksSignalService", "Foreground playback not allowed; using fallback notification", e)
            val manager = getSystemService(android.content.Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            manager.notify(6805, TasksNotifications.blockNotification(this, fallback = true))
            stopSelf()
            return START_NOT_STICKY
        }
        handler.removeCallbacksAndMessages(null)
        player?.release()
        player = null
        sequence = 0
        fallback = false
        handler.post(startNext)
        return START_NOT_STICKY
    }

    private fun finishSignal() {
        handler.removeCallbacksAndMessages(null)
        player?.release()
        player = null
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_DETACH)
        else {
            @Suppress("DEPRECATION")
            stopForeground(false)
        }
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        player?.release()
        player = null
        super.onDestroy()
    }
}
