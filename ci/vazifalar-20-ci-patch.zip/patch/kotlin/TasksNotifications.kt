/* SPDX-License-Identifier: GPL-3.0-or-later */
package org.isoron.uhabits.activities.tasks

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import org.isoron.uhabits.R
import java.security.MessageDigest

/** Exactly one visible block notification; three audible pulses from a short-lived service. */
internal object TasksNotifications {
    private const val BLOCK_ID = 6805
    private const val BLOCK_CHANNEL = "tasks_blocks_silent_v3"
    private const val FALLBACK_CHANNEL = "tasks_blocks_fallback_v3"
    private const val REMINDER_ID = 6820
    private const val CALENDAR_ID = 6812
    private const val CALENDAR_CHANNEL = "tasks_calendar_daily_v1"
    private val tripleVibration = longArrayOf(0L, 160L, 240L, 160L, 240L, 160L)

    private fun allowed(context: Context): Boolean =
        Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(context,
            Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun manager(context: Context) =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    private fun ensureBlockChannel(context: Context, fallback: Boolean = false) {
        if (Build.VERSION.SDK_INT < 26) return
        val id = if (fallback) FALLBACK_CHANNEL else BLOCK_CHANNEL
        val channel = NotificationChannel(id, "Vaqt bloklari", NotificationManager.IMPORTANCE_HIGH)
        channel.description = "Blok almashganda bitta xabar va uch signal"
        if (fallback) {
            channel.setSound(TasksTones.default(context, TasksTones.BLOCK),
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).build())
        } else channel.setSound(null, null) // Service handles the selectable three pulses.
        channel.enableVibration(true)
        channel.vibrationPattern = tripleVibration
        manager(context).createNotificationChannel(channel)
    }

    fun blockNotification(context: Context, fallback: Boolean = false): Notification {
        ensureBlockChannel(context, fallback)
        val open = PendingIntent.getActivity(context, BLOCK_ID,
            Intent(context, TasksActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(context, if (fallback) FALLBACK_CHANNEL else BLOCK_CHANNEL)
            .setSmallIcon(R.drawable.tasks_notification)
            .setContentTitle("Yangi vaqt bloki boshlandi")
            .setContentText("Vazifalarni tekshirish vaqti keldi")
            .setContentIntent(open)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .apply {
                if (fallback) setSound(TasksTones.default(context, TasksTones.BLOCK))
                else setSilent(true)
            }
            .build()
    }

    fun showBlock(context: Context) {
        if (!allowed(context)) return
        try {
            ContextCompat.startForegroundService(context,
                Intent(context, TasksSignalService::class.java))
        } catch (e: RuntimeException) {
            // If background FGS launch is prohibited, still deliver ONE alert with bundled 3-chime audio.
            manager(context).notify(BLOCK_ID, blockNotification(context, fallback = true))
        }
    }

    /** Daily overview is intentionally silent when it coincides with the three-ring block alert. */
    fun showCalendarSummary(context: Context, pending: Int) {
        if (!allowed(context) || pending <= 0) return
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CALENDAR_CHANNEL,
                "Kalendar rejalari", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "Bugungi kalendar vazifalarining qisqa hisoboti"
                setSound(null, null)
            }
            manager(context).createNotificationChannel(channel)
        }
        val open = PendingIntent.getActivity(context, CALENDAR_ID,
            Intent(context, TasksActivity::class.java).apply {
                action = "org.isoron.uhabits.tasks.OPEN_CALENDAR"
                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            }, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        manager(context).notify(CALENDAR_ID, NotificationCompat.Builder(context, CALENDAR_CHANNEL)
            .setSmallIcon(R.drawable.tasks_notification)
            .setContentTitle("Bugungi kalendar vazifalari")
            .setContentText("Bugun rejalashtirilgan $pending ta vazifa kutilmoqda")
            .setContentIntent(open)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build())
    }

    private fun reminderChannel(context: Context): String {
        val uri = TasksTones.selected(context, TasksTones.REMINDER)
        // O+ channels keep their original sound. A new selected URI needs a new channel ID.
        val suffix = MessageDigest.getInstance("SHA-256")
            .digest((uri?.toString() ?: "silent").toByteArray())
            .take(8).joinToString("") { "%02x".format(it) }
        val channelId = "tasks_reminder_$suffix"
        if (Build.VERSION.SDK_INT >= 26) {
            val c = NotificationChannel(channelId, "Vazifa eslatmalari", NotificationManager.IMPORTANCE_HIGH)
            c.description = "Vazifani ilovaga kirmasdan belgilash"
            c.setSound(uri, AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            c.enableVibration(true)
            manager(context).createNotificationChannel(c)
        }
        return channelId
    }

    private fun action(context: Context, taskId: Long, actionName: String, title: String,
                       icon: Int): NotificationCompat.Action {
        val i = Intent(context, TasksReminderActionReceiver::class.java).apply {
            action = "org.isoron.uhabits.tasks.REMINDER_$actionName"
            data = Uri.parse("tasks-action://$taskId/$actionName")
            putExtra("task_id", taskId)
        }
        val pi = PendingIntent.getBroadcast(context, 0, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Action(icon, title, pi)
    }

    fun showReminder(context: Context, task: TaskItem) {
        if (!allowed(context)) return
        val channel = reminderChannel(context)
        val open = PendingIntent.getActivity(context, 0,
            Intent(context, TasksActivity::class.java).apply {
                action = "org.isoron.uhabits.tasks.OPEN_REMINDER"
                data = Uri.parse("tasks-open://${task.id}")
                putExtra("task_id", task.id)
                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            }, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val note = NotificationCompat.Builder(context, channel)
            .setSmallIcon(R.drawable.tasks_notification)
            .setContentTitle(task.title)
            .setContentText("${task.block?.plus(1)?.let { "$it-blok • " } ?: ""}Vazifa eslatmasi • ?")
            .setStyle(NotificationCompat.BigTextStyle().bigText(
                "${task.title}\n${task.block?.plus(1)?.let { "$it-blok • " } ?: ""}Holati: ? Noma’lum"))
            .setContentIntent(open)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setSound(TasksTones.selected(context, TasksTones.REMINDER))
            .addAction(action(context, task.id, "DONE", "✓ Bajarildi", android.R.drawable.checkbox_on_background))
            .addAction(action(context, task.id, "FAILED", "× Bajarilmadi", android.R.drawable.ic_delete))
            .addAction(action(context, task.id, "SKIP", "O‘tkazib yuborish", android.R.drawable.ic_menu_close_clear_cancel))
            .build()
        manager(context).notify("task_reminder_${task.id}", REMINDER_ID, note)
    }

    fun dismissReminder(context: Context, taskId: Long) {
        manager(context).cancel("task_reminder_$taskId", REMINDER_ID)
    }
}
