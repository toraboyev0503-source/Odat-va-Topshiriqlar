/* SPDX-License-Identifier: GPL-3.0-or-later */
package org.isoron.uhabits.activities.tasks

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.time.LocalDate
import java.time.ZoneId

/** Once-per-day calendar summary, scheduled near the first daily block. */
internal object TasksCalendarAlerts {
    private const val REQUEST = 6812

    fun schedule(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pending = PendingIntent.getBroadcast(context, REQUEST,
            Intent(context, TasksCalendarReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        alarmManager.cancel(pending)
        val store = TaskStore(context)
        if (!store.configured()) return
        val now = System.currentTimeMillis()
        val today = LocalDate.now()
        val first = store.blocks().first().start
        val startToday = today.atStartOfDay(ZoneId.systemDefault())
            .plusMinutes(first.toLong()).toInstant().toEpochMilli()
        // If a calendar task was added after the day's work began, notify promptly.
        val alertAt = when {
            startToday > now + 1_000L -> startToday
            !store.calendarAlertDelivered(today) && store.calendarTodayPending() > 0 -> now + 2_000L
            else -> today.plusDays(1).atStartOfDay(ZoneId.systemDefault())
                .plusMinutes(first.toLong()).toInstant().toEpochMilli()
        }
        TasksAlarms.scheduleAlarm(alarmManager, alertAt, pending)
    }
}

internal class TasksCalendarReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val pendingResult = goAsync()
        try {
            val count = TaskStore(context).claimCalendarAlert(LocalDate.now())
            if (count > 0) TasksNotifications.showCalendarSummary(context, count)
            TasksCalendarAlerts.schedule(context)
        } finally {
            pendingResult.finish()
        }
    }
}
