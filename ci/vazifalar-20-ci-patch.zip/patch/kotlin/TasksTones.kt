/* SPDX-License-Identifier: GPL-3.0-or-later */
package org.isoron.uhabits.activities.tasks

import android.content.Context
import android.media.RingtoneManager
import android.net.Uri
import org.isoron.uhabits.R

/** The system tone picker returns URI strings, not a copied audio file. */
internal object TasksTones {
    const val BLOCK = "block"
    const val REMINDER = "reminder"
    private const val PREFS = "tasks_sound_preferences_v1"
    private const val SILENT = "__silent__"

    fun save(context: Context, kind: String, uri: Uri?) {
        require(kind in setOf(BLOCK, REMINDER))
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(kind, uri?.toString() ?: SILENT).apply()
    }

    fun selected(context: Context, kind: String): Uri? {
        val saved = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(kind, null)
        return when (saved) {
            SILENT -> null
            null -> default(context, kind)
            else -> Uri.parse(saved)
        }
    }

    fun default(context: Context, kind: String): Uri = when (kind) {
        BLOCK -> Uri.parse("android.resource://${context.packageName}/${R.raw.tasks_three_signals}")
        else -> RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            ?: Uri.parse("android.resource://${context.packageName}/${R.raw.tasks_three_signals}")
    }

    fun title(context: Context, kind: String): String {
        val uri = selected(context, kind) ?: return "Ovozsiz"
        if (uri == default(context, kind)) return "Standart"
        return runCatching {
            RingtoneManager.getRingtone(context, uri)?.getTitle(context)
        }.getOrNull().takeUnless { it.isNullOrBlank() } ?: "Tanlangan ohang"
    }

    fun isBundledDefault(context: Context): Boolean =
        selected(context, BLOCK) == default(context, BLOCK)
}
