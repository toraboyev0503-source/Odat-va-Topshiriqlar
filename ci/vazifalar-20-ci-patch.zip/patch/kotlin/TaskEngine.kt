/*
 * Tasks module for Loop Habit Tracker 2.3.1.
 * Copyright (C) 2026 OdatlarNazorati contributors.
 * SPDX-License-Identifier: GPL-3.0-or-later
 */
package org.isoron.uhabits.activities.tasks

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import kotlin.math.max

internal data class TaskBlock(val index: Int, val start: Int, val end: Int) {
    fun caption(): String = "${minutesText(start)}–${minutesText(end)}"
}

internal fun minutesText(value: Int): String = "%02d:%02d".format(value / 60, value % 60)

internal data class TaskItem(
    val id: Long,
    val title: String,
    val date: String?,
    val block: Int?,
    val status: String,
    val archiveKind: String?,
    val position: Int,
    val carriedFrom: String?,
    val templateId: Long? = null,
    val reminderAt: Long? = null,
    val reminderDeliveredAt: Long? = null
)

internal data class CalendarEntry(
    val id: Long, val planId: Long, val title: String, val day: LocalDate,
    val status: String, val linkedTaskId: Long?, val monthlyPinned: Boolean
)

internal data class CalendarSummary(val done: Int, val failed: Int, val pending: Int) {
    val total: Int get() = done + failed + pending
    val percentage: Int get() = if (total == 0) 0 else done * 100 / total
}

internal data class DailySummary(val done: Int, val failed: Int, val pending: Int) {
    val total: Int get() = done + failed + pending
    val percentage: Int get() = if (total == 0) 0 else (done * 100 / total)
}

/** No habit tables or databases are touched by this repository. */
internal class TaskStore(context: Context) : SQLiteOpenHelper(context, "odatlar_tasks.db", null, 4) {
    private val pref = context.getSharedPreferences("tasks_config_v1", Context.MODE_PRIVATE)

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            plan_day TEXT,
            block_index INTEGER,
            status TEXT NOT NULL DEFAULT 'PENDING',
            archive_kind TEXT,
            position INTEGER NOT NULL DEFAULT 0,
            carried_from TEXT,
            template_id INTEGER,
            reminder_at INTEGER,
            reminder_delivered_at INTEGER,
            created_at INTEGER NOT NULL,
            updated_at INTEGER NOT NULL
        )""")
        db.execSQL("CREATE INDEX tasks_by_block ON tasks(plan_day, block_index, status, position)")
        db.execSQL("CREATE INDEX tasks_by_archive ON tasks(archive_kind, updated_at)")
        db.execSQL("CREATE INDEX task_reminders_due ON tasks(reminder_at, reminder_delivered_at)")
        db.execSQL("""CREATE TABLE day_results (
            task_id INTEGER NOT NULL,
            day TEXT NOT NULL,
            outcome TEXT NOT NULL,
            PRIMARY KEY(task_id, day)
        )""")
        db.execSQL("CREATE INDEX result_by_day ON day_results(day)")
        createPinTable(db)
        createCalendarTables(db)
        db.execSQL("""CREATE TABLE task_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            task_id INTEGER NOT NULL,
            happened_at INTEGER NOT NULL,
            action TEXT NOT NULL,
            details TEXT NOT NULL DEFAULT ''
        )""")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Append-only v1 -> v2. Old tasks and outcomes must NEVER be dropped.
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE tasks ADD COLUMN template_id INTEGER")
            createPinTable(db)
        }
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE tasks ADD COLUMN reminder_at INTEGER")
            db.execSQL("ALTER TABLE tasks ADD COLUMN reminder_delivered_at INTEGER")
            if (oldVersion >= 2) {
                // Fresh v1->v3 paths already created this column in createPinTable().
                db.execSQL("ALTER TABLE task_pin_templates ADD COLUMN reminder_minute INTEGER")
            }
            db.execSQL("CREATE INDEX IF NOT EXISTS task_reminders_due ON tasks(reminder_at, reminder_delivered_at)")
        }
        if (oldVersion < 4) createCalendarTables(db)
    }

    private fun createPinTable(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE IF NOT EXISTS task_pin_templates (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            home_block INTEGER NOT NULL,
            start_day TEXT NOT NULL,
            enabled INTEGER NOT NULL DEFAULT 1,
            created_at INTEGER NOT NULL,
            reminder_minute INTEGER
        )""")
        db.execSQL("""CREATE UNIQUE INDEX IF NOT EXISTS one_pinned_task_per_day
            ON tasks(template_id, plan_day)
            WHERE template_id IS NOT NULL AND plan_day IS NOT NULL""")
    }

    private fun createCalendarTables(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE IF NOT EXISTS calendar_plans (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            anchor_day TEXT NOT NULL,
            start_day TEXT NOT NULL,
            monthly_pin INTEGER NOT NULL DEFAULT 1,
            enabled INTEGER NOT NULL DEFAULT 1,
            created_at INTEGER NOT NULL,
            updated_at INTEGER NOT NULL
        )""")
        db.execSQL("""CREATE TABLE IF NOT EXISTS calendar_entries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            plan_id INTEGER NOT NULL REFERENCES calendar_plans(id),
            plan_day TEXT NOT NULL,
            title TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'PENDING',
            linked_task_id INTEGER,
            created_at INTEGER NOT NULL,
            updated_at INTEGER NOT NULL,
            UNIQUE(plan_id, plan_day)
        )""")
        db.execSQL("CREATE INDEX IF NOT EXISTS calendar_by_day ON calendar_entries(plan_day, status)")
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS calendar_unique_task ON calendar_entries(linked_task_id) WHERE linked_task_id IS NOT NULL")
        db.execSQL("""CREATE TABLE IF NOT EXISTS calendar_exclusions (
            plan_id INTEGER NOT NULL, plan_day TEXT NOT NULL,
            PRIMARY KEY(plan_id, plan_day)
        )""")
        db.execSQL("""CREATE TABLE IF NOT EXISTS calendar_alerts (
            day TEXT PRIMARY KEY, delivered_at INTEGER NOT NULL
        )""")
    }

    /** Portable backup compatible with the previous preview's SQLite schema. */
    fun exportBackup(): String {
        val result = JSONObject()
            .put("format", "odatlar_tasks_backup_v1")
            .put("schema", 4)
        val options = JSONObject()
        for (name in listOf("initialized", "start", "end", "count", "custom")) {
            if (pref.contains(name)) options.put(name, pref.all[name])
        }
        result.put("options", options)
        val data = JSONObject()
        for (table in backupColumns.keys) {
            val rows = JSONArray()
            readableDatabase.query(table, null, null, null, null, null, "rowid ASC").use { cursor ->
                while (cursor.moveToNext()) {
                    val row = JSONObject()
                    for (i in 0 until cursor.columnCount) {
                        val key = cursor.getColumnName(i)
                        when (cursor.getType(i)) {
                            android.database.Cursor.FIELD_TYPE_NULL -> row.put(key, JSONObject.NULL)
                            android.database.Cursor.FIELD_TYPE_INTEGER -> row.put(key, cursor.getLong(i))
                            android.database.Cursor.FIELD_TYPE_FLOAT -> row.put(key, cursor.getDouble(i))
                            android.database.Cursor.FIELD_TYPE_STRING -> row.put(key, cursor.getString(i))
                            else -> error("Zaxira uchun qo‘llab-quvvatlanmagan qiymat: $key")
                        }
                    }
                    rows.put(row)
                }
            }
            data.put(table, rows)
        }
        return result.put("data", data).toString(2)
    }

    fun importBackup(json: String) {
        require(json.length <= 20_000_000) { "Zaxira fayli juda katta" }
        val root = JSONObject(json)
        require(root.optString("format") == "odatlar_tasks_backup_v1") { "Noma’lum zaxira formati" }
        val schema = root.optInt("schema")
        require(schema in 1..4) { "Zaxira versiyasi mos emas" }
        val inputColumns = when (schema) { 1 -> backupColumnsV1; 2 -> backupColumnsV2; 3 -> backupColumnsV3; else -> backupColumns }
        val data = root.getJSONObject("data")
        val options = root.getJSONObject("options")
        val tables = inputColumns.mapValues { (name, columns) ->
            val array = data.getJSONArray(name)
            require(array.length() <= 50000) { "Zaxira qatorlari juda ko‘p" }
            (0 until array.length()).map { index ->
                val row = array.getJSONObject(index)
                val keys = row.keys().asSequence().toSet()
                require(keys.all { it in columns }) { "Noto‘g‘ri zaxira ustunlari" }
                require(columns.all { row.has(it) }) { "Zaxirada kerakli ustunlar yo‘q" }
                row
            }
        }
        val initialized = options.optBoolean("initialized", false)
        val start = options.optInt("start", 360)
        val end = options.optInt("end", 1320)
        val count = options.optInt("count", 8)
        val custom = options.optString("custom", "")
        require(start in 0..1438 && end in 1..1440 && count in 1..24 && end-start >= count) {
            "Zaxiradagi vaqt sozlamalari noto‘g‘ri"
        }
        if (custom.isNotEmpty()) {
            val array = JSONArray(custom)
            val parsed = (0 until array.length()).map { i ->
                val b = array.getJSONObject(i)
                TaskBlock(i, b.getInt("start"), b.getInt("end"))
            }
            require(validBlocks(parsed)) { "Zaxiradagi blok vaqtlari noto‘g‘ri" }
        }
        writableDatabase.transaction {
            backupColumns.keys.reversed().forEach { delete(it, null, null) }
            for ((table, rows) in tables) {
                for (row in rows) {
                    val values = ContentValues()
                    for (key in inputColumns.getValue(table)) {
                        val value = row.get(key)
                        when {
                            value === JSONObject.NULL -> values.putNull(key)
                            value is Number -> values.put(key, value.toLong())
                            value is String -> values.put(key, value)
                            else -> error("Zaxirada noto‘g‘ri qiymat: $key")
                        }
                    }
                    insertOrThrow(table, null, values)
                }
            }
        }
        pref.edit().clear()
            .putBoolean("initialized", initialized)
            .putInt("start", start)
            .putInt("end", end)
            .putInt("count", count)
            .apply { if (custom.isNotEmpty()) putString("custom", custom) }
            .commit()
    }

    private val backupColumns: Map<String, List<String>> get() = linkedMapOf(
        "tasks" to listOf("id", "title", "plan_day", "block_index", "status",
            "archive_kind", "position", "carried_from", "template_id", "created_at", "updated_at",
            "reminder_at", "reminder_delivered_at"),
        "day_results" to listOf("task_id", "day", "outcome"),
        "task_events" to listOf("id", "task_id", "happened_at", "action", "details"),
        "task_pin_templates" to listOf("id", "title", "home_block", "start_day", "enabled", "created_at", "reminder_minute"),
        "calendar_plans" to listOf("id", "title", "anchor_day", "start_day", "monthly_pin", "enabled", "created_at", "updated_at"),
        "calendar_entries" to listOf("id", "plan_id", "plan_day", "title", "status", "linked_task_id", "created_at", "updated_at"),
        "calendar_exclusions" to listOf("plan_id", "plan_day"),
        "calendar_alerts" to listOf("day", "delivered_at")
    )

    private val backupColumnsV3: Map<String, List<String>> get() =
        backupColumns.filterKeys { it in setOf("tasks", "day_results", "task_events", "task_pin_templates") }

    private val backupColumnsV2: Map<String, List<String>> get() = linkedMapOf(
        "tasks" to listOf("id", "title", "plan_day", "block_index", "status",
            "archive_kind", "position", "carried_from", "template_id", "created_at", "updated_at"),
        "day_results" to listOf("task_id", "day", "outcome"),
        "task_events" to listOf("id", "task_id", "happened_at", "action", "details"),
        "task_pin_templates" to listOf("id", "title", "home_block", "start_day", "enabled", "created_at")
    )

    private val backupColumnsV1: Map<String, List<String>> get() = linkedMapOf(
        "tasks" to listOf("id", "title", "plan_day", "block_index", "status",
            "archive_kind", "position", "carried_from", "created_at", "updated_at"),
        "day_results" to listOf("task_id", "day", "outcome"),
        "task_events" to listOf("id", "task_id", "happened_at", "action", "details")
    )

    fun configured(): Boolean = pref.getBoolean("initialized", false)
    fun blocks(): List<TaskBlock> {
        val custom = pref.getString("custom", null)
        if (custom != null) {
            try {
                val array = JSONArray(custom)
                val parsed = (0 until array.length()).map { i ->
                    val obj = array.getJSONObject(i)
                    TaskBlock(i, obj.getInt("start"), obj.getInt("end"))
                }
                if (validBlocks(parsed)) return parsed
            } catch (_: Exception) { /* Fall back to equal blocks */ }
        }
        val start = pref.getInt("start", 360)
        val end = pref.getInt("end", 1320)
        val count = pref.getInt("count", 8).coerceIn(1, 24)
        return (0 until count).map { index ->
            val a = start + ((end - start).toLong() * index / count).toInt()
            val b = start + ((end - start).toLong() * (index + 1) / count).toInt()
            TaskBlock(index, a, b)
        }
    }

    /** Use only for first-time configuration or EXPLICIT equal-block reset. */
    fun configure(start: Int, end: Int, count: Int) {
        require(start in 0..1438 && end in 1..1440 && end - start >= count && count in 1..24)
        pref.edit().putBoolean("initialized", true).putInt("start", start)
            .putInt("end", end).putInt("count", count).remove("custom").commit()
        // No data loss for removed blocks: move out-of-range tasks and pinned templates.
        writableDatabase.transaction {
            execSQL("""UPDATE tasks SET block_index=? WHERE block_index>=?
                AND status='PENDING' AND archive_kind IS NULL AND plan_day>=?""",
                arrayOf(count - 1, count, LocalDate.now().toString()))
            execSQL("UPDATE task_pin_templates SET home_block=? WHERE home_block>=?", arrayOf(count - 1, count))
        }
    }

    /** Adjust the outer bounds without discarding the internal manual boundaries. */
    fun updateWindowPreservingCustom(start: Int, end: Int) {
        val old = blocks()
        require(start in 0..1438 && end in 1..1440 && end > start)
        val edited = old.mapIndexed { index, b ->
            b.copy(start = if (index == 0) start else b.start,
                   end = if (index == old.lastIndex) end else b.end)
        }
        require(validBlocks(edited)) { "Chegara boshqa blok bilan to‘qnashyapti. Qo‘lda tahrirlang." }
        setCustom(edited)
    }

    fun setCustom(blocks: List<TaskBlock>) {
        require(validBlocks(blocks))
        val array = JSONArray()
        blocks.forEach { array.put(JSONObject().put("start", it.start).put("end", it.end)) }
        pref.edit().putBoolean("initialized", true).putInt("start", blocks.first().start)
            .putInt("end", blocks.last().end).putInt("count", blocks.size)
            .putString("custom", array.toString()).commit()
    }

    private fun validBlocks(items: List<TaskBlock>): Boolean =
        items.isNotEmpty() && items.size <= 24 &&
            items.indices.all { items[it].index == it } &&
            items.first().start >= 0 && items.last().end <= 1440 &&
            items.all { it.start in 0..1439 && it.end in 1..1440 && it.end > it.start } &&
            items.zipWithNext().all { (a, b) -> a.end <= b.start } // gaps are legal

    fun taskById(id: Long): TaskItem? = load("id=?", arrayOf(id.toString()), "id ASC").firstOrNull()

    fun list(date: LocalDate, block: Int): List<TaskItem> = load(
        "plan_day=? AND block_index=? AND archive_kind IS NULL",
        arrayOf(date.toString(), block.toString()), "position ASC, id ASC"
    )

    /** Yesterday's pinned failures remain in results/history, not in the active archive. */
    fun archive(): List<TaskItem> = load(
        "archive_kind IS NOT NULL AND (template_id IS NULL OR plan_day IS NULL OR plan_day>=?)",
        arrayOf(LocalDate.now().toString()), "updated_at DESC"
    )

    private fun load(where: String, args: Array<String>, order: String): List<TaskItem> {
        val out = mutableListOf<TaskItem>()
        readableDatabase.query("tasks", null, where, args, null, null, order).use { cursor ->
            fun string(col: String) = cursor.getString(cursor.getColumnIndexOrThrow(col))
            fun int(col: String) = cursor.getInt(cursor.getColumnIndexOrThrow(col))
            fun nullableString(col: String): String? {
                val i = cursor.getColumnIndexOrThrow(col)
                return if (cursor.isNull(i)) null else cursor.getString(i)
            }
            fun nullableLong(col: String): Long? {
                val i = cursor.getColumnIndexOrThrow(col)
                return if (cursor.isNull(i)) null else cursor.getLong(i)
            }
            fun nullableInt(col: String): Int? {
                val i = cursor.getColumnIndexOrThrow(col)
                return if (cursor.isNull(i)) null else cursor.getInt(i)
            }
            while (cursor.moveToNext()) {
                out.add(TaskItem(cursor.getLong(cursor.getColumnIndexOrThrow("id")), string("title"),
                    nullableString("plan_day"), nullableInt("block_index"), string("status"),
                    nullableString("archive_kind"), int("position"), nullableString("carried_from"),
                    nullableLong("template_id"), nullableLong("reminder_at"),
                    nullableLong("reminder_delivered_at")))
            }
        }
        return out
    }

    fun add(title: String, day: LocalDate?, block: Int?, later: Boolean = false): Long {
        val safeTitle = title.trim().take(500)
        require(safeTitle.isNotEmpty())
        require(later || (day != null && block != null && block in blocks().indices))
        val now = System.currentTimeMillis()
        return writableDatabase.run {
            beginTransaction()
            try {
                val values = ContentValues().apply {
                    put("title", safeTitle)
                    put("plan_day", day?.toString())
                    if (block == null) putNull("block_index") else put("block_index", block)
                    put("status", "PENDING")
                    if (later) put("archive_kind", "LATER") else putNull("archive_kind")
                    put("position", nextPosition(this@run, day, block))
                    put("created_at", now)
                    put("updated_at", now)
                }
                val id = insertOrThrow("tasks", null, values)
                if (!later && day != null) result(this, id, day, "PENDING")
                event(this, id, "CREATED", safeTitle)
                setTransactionSuccessful()
                id
            } finally { endTransaction() }
        }
    }

    private fun nextPosition(db: SQLiteDatabase, day: LocalDate?, block: Int?): Int {
        if (day == null || block == null) return 0
        db.rawQuery("SELECT COALESCE(MAX(position), 0)+1 FROM tasks WHERE plan_day=? AND block_index=?", arrayOf(day.toString(), block.toString())).use {
            return if (it.moveToFirst()) it.getInt(0) else 1
        }
    }

    fun rename(id: Long, title: String) {
        val safe = title.trim().take(500)
        require(safe.isNotBlank())
        writableDatabase.transaction {
            update("tasks", ContentValues().apply { put("title", safe); put("updated_at", System.currentTimeMillis()) }, "id=?", arrayOf(id.toString()))
            if (activeTemplateId(this, id) != null) {
                execSQL("UPDATE task_pin_templates SET title=? WHERE id=(SELECT template_id FROM tasks WHERE id=?)",
                    arrayOf(safe, id))
            }
            // A renamed linked task and its calendar occurrence must share one title.
            val linkedPlan = rawQuery("SELECT plan_id FROM calendar_entries WHERE linked_task_id=?",
                arrayOf(id.toString())).use { c -> if (c.moveToFirst()) c.getLong(0) else null }
            if (linkedPlan != null) {
                execSQL("UPDATE calendar_plans SET title=?,updated_at=? WHERE id=?",
                    arrayOf(safe, System.currentTimeMillis(), linkedPlan))
                execSQL("UPDATE calendar_entries SET title=?,updated_at=? WHERE linked_task_id=?",
                    arrayOf(safe, System.currentTimeMillis(), id))
                execSQL("""UPDATE calendar_entries SET title=?,updated_at=?
                    WHERE plan_id=? AND status='PENDING' AND linked_task_id IS NULL AND plan_day>=?""",
                    arrayOf(safe, System.currentTimeMillis(), linkedPlan, LocalDate.now().toString()))
            }
            event(this, id, "RENAMED", safe)
        }
    }

    /** A pin is a recurring template, distinct from each day's task instance. */
    fun isPinned(task: TaskItem): Boolean {
        val template = task.templateId ?: return false
        readableDatabase.rawQuery("SELECT enabled FROM task_pin_templates WHERE id=?",
            arrayOf(template.toString())).use { c ->
            return c.moveToFirst() && c.getInt(0) == 1
        }
    }

    fun togglePin(task: TaskItem): Boolean {
        val day = task.date?.let(LocalDate::parse) ?: return false
        val block = task.block ?: return false
        require(block in blocks().indices)
        var enabled = false
        writableDatabase.transaction {
            val current = activeTemplateId(this, task.id)
            if (current != null) {
                execSQL("UPDATE task_pin_templates SET enabled=0 WHERE id=?", arrayOf(current))
                event(this, task.id, "UNPINNED", "daily")
            } else {
                val now = System.currentTimeMillis()
                val id = insertOrThrow("task_pin_templates", null, ContentValues().apply {
                    put("title", task.title); put("home_block", block)
                    task.reminderAt?.let { timestamp ->
                        val time = Instant.ofEpochMilli(timestamp).atZone(ZoneId.systemDefault())
                        put("reminder_minute", time.hour * 60 + time.minute)
                    }
                    put("start_day", day.toString()); put("enabled", 1)
                    put("created_at", now)
                })
                update("tasks", ContentValues().apply { put("template_id", id) }, "id=?",
                    arrayOf(task.id.toString()))
                event(this, task.id, "PINNED", "home_block=${block + 1}")
                enabled = true
            }
        }
        return enabled
    }

    private fun activeTemplateId(db: SQLiteDatabase, taskId: Long): Long? {
        db.rawQuery("""SELECT p.id FROM task_pin_templates p
            JOIN tasks t ON t.template_id=p.id
            WHERE t.id=? AND p.enabled=1""", arrayOf(taskId.toString())).use { c ->
            return if (c.moveToFirst()) c.getLong(0) else null
        }
    }

    /** Idempotent generation: one instance per template and calendar date. */
    fun ensurePinned(day: LocalDate) {
        writableDatabase.transaction {
            rawQuery("SELECT id,title,home_block FROM task_pin_templates WHERE enabled=1 AND start_day<=?",
                arrayOf(day.toString())).use { templates ->
                while (templates.moveToNext()) {
                    val templateId = templates.getLong(0)
                    val name = templates.getString(1)
                    val homeBlock = templates.getInt(2)
                    if (homeBlock !in blocks().indices) continue
                    val exists = rawQuery(
                        "SELECT id FROM tasks WHERE template_id=? AND plan_day=? LIMIT 1",
                        arrayOf(templateId.toString(), day.toString())
                    ).use { it.moveToFirst() }
                    if (exists) continue
                    val now = System.currentTimeMillis()
                    val id = insertWithOnConflict("tasks", null, ContentValues().apply {
                        put("title", name); put("plan_day", day.toString()); put("block_index", homeBlock)
                        put("status", "PENDING"); putNull("archive_kind")
                        put("position", nextPosition(this@transaction, day, homeBlock))
                        put("template_id", templateId)
                        templateReminderMinute(this@transaction, templateId)?.let { minute ->
                            put("reminder_at", reminderTimestamp(day, minute))
                        }
                        put("created_at", now); put("updated_at", now)
                    }, SQLiteDatabase.CONFLICT_IGNORE)
                    if (id >= 0) {
                        result(this, id, day, "PENDING")
                        event(this, id, "PIN_GENERATED", "template=$templateId")
                    }
                }
            }
        }
    }

    fun setStatus(task: TaskItem, newStatus: String) {
        require(newStatus in setOf("PENDING", "DONE", "FAILED"))
        val day = requireNotNull(task.date).let(LocalDate::parse)
        writableDatabase.transaction {
            update("tasks", ContentValues().apply {
                put("status", newStatus)
                if (newStatus == "FAILED") put("archive_kind", "FAILED") else putNull("archive_kind")
                if (newStatus != "PENDING") putNull("reminder_at")
                put("updated_at", System.currentTimeMillis())
            }, "id=?", arrayOf(task.id.toString()))
            result(this, task.id, day, newStatus)
            execSQL("UPDATE calendar_entries SET status=?, updated_at=? WHERE linked_task_id=?",
                arrayOf(newStatus, System.currentTimeMillis(), task.id))
            event(this, task.id, "STATUS", newStatus)
        }
    }

    fun restore(task: TaskItem, day: LocalDate, block: Int) = relocate(task, day, block, reset = true)

    fun relocate(task: TaskItem, day: LocalDate, block: Int, reset: Boolean = false) {
        require(block in blocks().indices)
        writableDatabase.transaction {
            val oldDay = task.date
            if (oldDay != null && oldDay != day.toString() && task.status == "PENDING") {
                delete("day_results", "task_id=? AND day=? AND outcome='PENDING'", arrayOf(task.id.toString(), oldDay))
            }
            update("tasks", ContentValues().apply {
                put("plan_day", day.toString()); put("block_index", block)
                put("position", nextPosition(this@transaction, day, block))
                put("carried_from", if (oldDay != null && task.block != null) "$oldDay #${task.block + 1}" else "")
                put("updated_at", System.currentTimeMillis())
                if (oldDay != null && oldDay != day.toString() && task.reminderAt != null &&
                    task.reminderDeliveredAt == null) {
                    val local = Instant.ofEpochMilli(task.reminderAt).atZone(ZoneId.systemDefault())
                    val at = reminderTimestamp(day, local.hour * 60 + local.minute)
                    if (at > System.currentTimeMillis()) put("reminder_at", at)
                    else putNull("reminder_at")
                }
                if (reset) {
                    put("status", "PENDING"); putNull("archive_kind")
                    putNull("reminder_delivered_at")
                }
            }, "id=?", arrayOf(task.id.toString()))
            if (reset || task.status == "PENDING") result(this, task.id, day, "PENDING")
            event(this, task.id, if (reset) "RESTORED" else "MOVED", "$day #${block + 1}")
        }
    }

    fun duplicate(task: TaskItem): Long = add(task.title, task.date?.let(LocalDate::parse), task.block, false)

    fun erase(task: TaskItem) {
        writableDatabase.transaction {
            // Deleting the current pinned task stops future recurrence; no silent new task tomorrow.
            activeTemplateId(this, task.id)?.let { templateId ->
                execSQL("UPDATE task_pin_templates SET enabled=0 WHERE id=?", arrayOf(templateId))
            }
            if (task.status == "PENDING" && task.date != null) {
                delete("day_results", "task_id=? AND day=? AND outcome='PENDING'", arrayOf(task.id.toString(), task.date))
            }
            execSQL("UPDATE calendar_entries SET linked_task_id=NULL WHERE linked_task_id=?", arrayOf(task.id))
            event(this, task.id, "DELETED", task.title)
            delete("tasks", "id=?", arrayOf(task.id.toString()))
        }
    }

    fun reorder(task: TaskItem, direction: Int) {
        val day = task.date?.let(LocalDate::parse) ?: return
        val current = list(day, task.block ?: return)
        val index = current.indexOfFirst { it.id == task.id }
        val target = index + direction
        if (index !in current.indices || target !in current.indices) return
        val shifted = current.toMutableList().apply { add(target, removeAt(index)) }
        writableDatabase.transaction {
            shifted.forEachIndexed { i, row ->
                update("tasks", ContentValues().apply { put("position", i + 1) }, "id=?", arrayOf(row.id.toString()))
            }
        }
    }

    /** A task reminder is an absolute timestamp for its planned date.
     *  Daily pinned tasks additionally store a local clock minute on the recurring template.
     */
    fun setReminder(taskId: Long, minute: Int) {
        require(minute in 0..1439)
        val task = requireNotNull(taskById(taskId)) { "Vazifa topilmadi" }
        val date = requireNotNull(task.date) { "Arxivdagi vazifaga vaqt belgilanmaydi" }.let(LocalDate::parse)
        val at = reminderTimestamp(date, minute)
        val future = at > System.currentTimeMillis() + 1000L
        require(future || isPinned(task)) { "Kelajakdagi vaqtni tanlang" }
        writableDatabase.transaction {
            update("tasks", ContentValues().apply {
                // When today's time already passed, daily pinned reminders begin tomorrow.
                if (future) put("reminder_at", at) else putNull("reminder_at")
                putNull("reminder_delivered_at")
                put("updated_at", System.currentTimeMillis())
            }, "id=?", arrayOf(taskId.toString()))
            activeTemplateId(this, taskId)?.let { templateId ->
                execSQL("UPDATE task_pin_templates SET reminder_minute=? WHERE id=?",
                    arrayOf(minute, templateId))
            }
            event(this, taskId, "REMINDER_SET", minutesText(minute))
        }
    }

    fun clearReminder(taskId: Long) {
        writableDatabase.transaction {
            update("tasks", ContentValues().apply {
                putNull("reminder_at"); putNull("reminder_delivered_at")
                put("updated_at", System.currentTimeMillis())
            }, "id=?", arrayOf(taskId.toString()))
            activeTemplateId(this, taskId)?.let { templateId ->
                execSQL("UPDATE task_pin_templates SET reminder_minute=NULL WHERE id=?", arrayOf(templateId))
            }
            event(this, taskId, "REMINDER_REMOVED", "")
        }
    }

    private fun templateReminderMinute(db: SQLiteDatabase, templateId: Long): Int? =
        db.rawQuery("SELECT reminder_minute FROM task_pin_templates WHERE id=?",
            arrayOf(templateId.toString())).use { cursor ->
            if (cursor.moveToFirst() && !cursor.isNull(0)) cursor.getInt(0) else null
        }

    private fun reminderTimestamp(day: LocalDate, minute: Int): Long =
        day.atStartOfDay(ZoneId.systemDefault()).plusMinutes(minute.toLong()).toInstant().toEpochMilli()

    fun nextReminderTime(): Long? {
        readableDatabase.rawQuery("""SELECT MIN(reminder_at) FROM tasks
            WHERE reminder_at IS NOT NULL AND reminder_delivered_at IS NULL
              AND status='PENDING' AND archive_kind IS NULL""", null).use { cursor ->
            return if (cursor.moveToFirst() && !cursor.isNull(0)) cursor.getLong(0) else null
        }
    }

    /** Claim each due reminder exactly once before showing a notification. */
    fun claimDueReminders(now: Long): List<TaskItem> {
        val due = load("reminder_at IS NOT NULL AND reminder_at<=? AND reminder_delivered_at IS NULL",
            arrayOf((now + 1500L).toString()), "reminder_at ASC, id ASC")
        val claimed = mutableListOf<TaskItem>()
        writableDatabase.transaction {
            for (task in due) {
                val updated = update("tasks", ContentValues().apply { put("reminder_delivered_at", now) },
                    "id=? AND reminder_delivered_at IS NULL", arrayOf(task.id.toString()))
                if (updated > 0 && task.status == "PENDING" && task.archiveKind == null &&
                    task.reminderAt != null && now - task.reminderAt < 2 * 60 * 60 * 1000L) {
                    event(this, task.id, "REMINDER_DELIVERED", "")
                    claimed.add(task)
                }
            }
        }
        return claimed
    }

    /** "Skip" dismisses the reminder without changing task status. */
    fun recordReminderSkipped(taskId: Long) {
        writableDatabase.transaction { event(this, taskId, "REMINDER_SKIPPED", "") }
    }

    /** Month materialization is idempotent: a pinned plan generates at most one entry per date. */
    fun ensureCalendarMonth(month: YearMonth) {
        val now = System.currentTimeMillis()
        writableDatabase.transaction {
            rawQuery("SELECT id,title,anchor_day,start_day FROM calendar_plans WHERE enabled=1 AND monthly_pin=1", null)
                .use { c ->
                    while (c.moveToNext()) {
                        val id = c.getLong(0)
                        val title = c.getString(1)
                        val anchor = LocalDate.parse(c.getString(2))
                        val start = LocalDate.parse(c.getString(3))
                        if (month < YearMonth.from(start) || anchor.dayOfMonth > month.lengthOfMonth()) continue
                        val day = month.atDay(anchor.dayOfMonth)
                        if (day < start) continue
                        val excluded = rawQuery("SELECT 1 FROM calendar_exclusions WHERE plan_id=? AND plan_day=?",
                            arrayOf(id.toString(), day.toString())).use { it.moveToFirst() }
                        if (excluded) continue
                        insertWithOnConflict("calendar_entries", null, ContentValues().apply {
                            put("plan_id", id); put("plan_day", day.toString()); put("title", title)
                            put("status", "PENDING"); put("created_at", now); put("updated_at", now)
                        }, SQLiteDatabase.CONFLICT_IGNORE)
                    }
                }
        }
    }

    fun addCalendar(title: String, day: LocalDate, pinned: Boolean = true): Long {
        val clean = title.trim().take(500)
        require(clean.isNotEmpty())
        val now = System.currentTimeMillis()
        var entryId = -1L
        writableDatabase.transaction {
            val plan = insertOrThrow("calendar_plans", null, ContentValues().apply {
                put("title", clean); put("anchor_day", day.toString()); put("start_day", day.toString())
                put("monthly_pin", if (pinned) 1 else 0); put("enabled", 1)
                put("created_at", now); put("updated_at", now)
            })
            entryId = insertOrThrow("calendar_entries", null, ContentValues().apply {
                put("plan_id", plan); put("plan_day", day.toString()); put("title", clean)
                put("status", "PENDING"); put("created_at", now); put("updated_at", now)
            })
        }
        return entryId
    }

    fun calendarEntry(entryId: Long): CalendarEntry? {
        return calendarLoad("e.id=?", arrayOf(entryId.toString())).firstOrNull()
    }

    fun calendarEntries(day: LocalDate): List<CalendarEntry> {
        ensureCalendarMonth(YearMonth.from(day))
        return calendarLoad("e.plan_day=?", arrayOf(day.toString()))
    }

    fun calendarMonth(month: YearMonth): List<CalendarEntry> {
        ensureCalendarMonth(month)
        return calendarLoad("e.plan_day>=? AND e.plan_day<=?",
            arrayOf(month.atDay(1).toString(), month.atEndOfMonth().toString()))
    }

    private fun calendarLoad(where: String, args: Array<String>): List<CalendarEntry> {
        val out = mutableListOf<CalendarEntry>()
        readableDatabase.rawQuery("""SELECT e.id,e.plan_id,e.title,e.plan_day,e.status,e.linked_task_id,p.monthly_pin
            FROM calendar_entries e JOIN calendar_plans p ON p.id=e.plan_id
            WHERE $where ORDER BY e.id ASC""", args).use { c ->
            while (c.moveToNext()) {
                out.add(CalendarEntry(c.getLong(0), c.getLong(1), c.getString(2),
                    LocalDate.parse(c.getString(3)), c.getString(4),
                    if (c.isNull(5)) null else c.getLong(5), c.getInt(6) == 1))
            }
        }
        return out
    }

    fun calendarSummary(items: List<CalendarEntry>): CalendarSummary = CalendarSummary(
        done = items.count { it.status == "DONE" }, failed = items.count { it.status == "FAILED" },
        pending = items.count { it.status == "PENDING" }
    )

    fun calendarTodayPending(): Int = calendarEntries(LocalDate.now()).count { it.status == "PENDING" }

    fun isCalendarLinked(taskId: Long): Boolean = readableDatabase.rawQuery(
        "SELECT 1 FROM calendar_entries WHERE linked_task_id=? LIMIT 1", arrayOf(taskId.toString())
    ).use { it.moveToFirst() }

    fun renameCalendar(entryId: Long, title: String) {
        val clean = title.trim().take(500)
        require(clean.isNotEmpty())
        val entry = requireNotNull(calendarEntry(entryId))
        val now = System.currentTimeMillis()
        writableDatabase.transaction {
            execSQL("UPDATE calendar_plans SET title=?,updated_at=? WHERE id=?", arrayOf(clean, now, entry.planId))
            execSQL("UPDATE calendar_entries SET title=?,updated_at=? WHERE id=?", arrayOf(clean, now, entryId))
            // Do not rename historical completed occurrences or their task records.
            execSQL("""UPDATE calendar_entries SET title=?,updated_at=?
                WHERE plan_id=? AND plan_day>? AND status='PENDING'""",
                arrayOf(clean, now, entry.day.toString(), entry.planId))
            entry.linkedTaskId?.let { taskId ->
                execSQL("UPDATE tasks SET title=?,updated_at=? WHERE id=?", arrayOf(clean, now, taskId))
            }
        }
    }

    /** Return the new pin state; disabling stops creation of future entries. */
    fun toggleCalendarPin(entryId: Long): Boolean {
        val entry = requireNotNull(calendarEntry(entryId))
        val enabled = !entry.monthlyPinned
        writableDatabase.transaction {
            execSQL("UPDATE calendar_plans SET monthly_pin=?,anchor_day=?,start_day=?,updated_at=? WHERE id=?",
                arrayOf(if (enabled) 1 else 0, entry.day.toString(), entry.day.toString(),
                    System.currentTimeMillis(), entry.planId))
            if (!enabled) {
                // Materialized future previews without actual task or result disappear.
                execSQL("""DELETE FROM calendar_entries WHERE plan_id=? AND plan_day>?
                    AND linked_task_id IS NULL AND status='PENDING'""",
                    arrayOf(entry.planId, LocalDate.now().toString()))
            }
        }
        return enabled
    }

    /** Remove only this occurrence, preserving linked tasks and previous outcomes. */
    fun deleteCalendarOccurrence(entryId: Long) {
        val entry = requireNotNull(calendarEntry(entryId))
        writableDatabase.transaction {
            insertWithOnConflict("calendar_exclusions", null, ContentValues().apply {
                put("plan_id", entry.planId); put("plan_day", entry.day.toString())
            }, SQLiteDatabase.CONFLICT_IGNORE)
            delete("calendar_entries", "id=?", arrayOf(entryId.toString()))
        }
    }

    /** Stop future series; existing historical entries remain as records. */
    fun stopCalendarSeries(entryId: Long) {
        val entry = requireNotNull(calendarEntry(entryId))
        writableDatabase.transaction {
            execSQL("UPDATE calendar_plans SET enabled=0, monthly_pin=0, updated_at=? WHERE id=?",
                arrayOf(System.currentTimeMillis(), entry.planId))
            execSQL("""DELETE FROM calendar_entries WHERE plan_id=? AND plan_day>?
                AND status='PENDING' AND linked_task_id IS NULL""",
                arrayOf(entry.planId, LocalDate.now().toString()))
        }
    }

    /** Attach one calendar occurrence to one day/block; never create duplicate linked tasks. */
    fun linkCalendar(entryId: Long, block: Int): Long {
        require(block in blocks().indices)
        val entry = requireNotNull(calendarEntry(entryId))
        val existing = entry.linkedTaskId?.let { taskById(it) }
        if (existing != null) {
            if (existing.status != "PENDING") setStatus(existing, "PENDING")
            relocate(requireNotNull(taskById(existing.id)), entry.day, block, reset = true)
            return existing.id
        }
        val now = System.currentTimeMillis()
        var taskId = -1L
        writableDatabase.transaction {
            taskId = insertOrThrow("tasks", null, ContentValues().apply {
                put("title", entry.title); put("plan_day", entry.day.toString()); put("block_index", block)
                put("status", "PENDING"); putNull("archive_kind")
                put("position", nextPosition(this@transaction, entry.day, block))
                put("created_at", now); put("updated_at", now)
            })
            execSQL("UPDATE calendar_entries SET linked_task_id=?,status='PENDING',updated_at=? WHERE id=?",
                arrayOf(taskId, now, entryId))
            result(this, taskId, entry.day, "PENDING")
            event(this, taskId, "CALENDAR_LINKED", "entry=$entryId")
        }
        return taskId
    }

    /** Move an occurrence and update the future monthly anchor to its latest date. */
    fun moveCalendar(entryId: Long, destination: LocalDate) {
        val entry = requireNotNull(calendarEntry(entryId))
        if (entry.day == destination) return
        val linked = entry.linkedTaskId?.let { taskById(it) }
        val oldDay = entry.day
        val now = System.currentTimeMillis()
        writableDatabase.transaction {
            val occupied = rawQuery("SELECT 1 FROM calendar_entries WHERE plan_id=? AND plan_day=? AND id<>?",
                arrayOf(entry.planId.toString(), destination.toString(), entryId.toString()))
                .use { it.moveToFirst() }
            require(!occupied) { "Bu kunda shu vazifaning takrori mavjud" }
            // When moving an already-completed occurrence, retain its immutable history;
            // create a fresh planned occurrence on the new date instead.
            if (entry.status == "PENDING") {
                execSQL("UPDATE calendar_entries SET plan_day=?,updated_at=? WHERE id=?",
                    arrayOf(destination.toString(), now, entryId))
                if (linked != null) {
                    if (linked.status == "PENDING") {
                        delete("day_results", "task_id=? AND day=? AND outcome='PENDING'",
                            arrayOf(linked.id.toString(), oldDay.toString()))
                    }
                    update("tasks", ContentValues().apply {
                        put("plan_day", destination.toString()); put("updated_at", now)
                        linked.reminderAt?.let { reminder ->
                            val zoned = Instant.ofEpochMilli(reminder).atZone(ZoneId.systemDefault())
                            val newAt = reminderTimestamp(destination, zoned.hour * 60 + zoned.minute)
                            if (newAt > now) put("reminder_at", newAt) else putNull("reminder_at")
                            putNull("reminder_delivered_at")
                        }
                    }, "id=?", arrayOf(linked.id.toString()))
                    result(this, linked.id, destination, linked.status)
                    event(this, linked.id, "CALENDAR_MOVED", destination.toString())
                }
            } else {
                insertOrThrow("calendar_entries", null, ContentValues().apply {
                    put("plan_id", entry.planId); put("plan_day", destination.toString())
                    put("title", entry.title); put("status", "PENDING")
                    put("created_at", now); put("updated_at", now)
                })
            }
            execSQL("DELETE FROM calendar_exclusions WHERE plan_id=? AND plan_day=?",
                arrayOf(entry.planId, destination.toString()))
            if (entry.monthlyPinned) {
                execSQL("UPDATE calendar_plans SET anchor_day=?,start_day=?,updated_at=? WHERE id=?",
                    arrayOf(destination.toString(), destination.toString(), now, entry.planId))
                // Future unlinked previews were generated for the OLD monthly date.
                execSQL("""DELETE FROM calendar_entries WHERE plan_id=? AND id<>?
                    AND plan_day>=? AND linked_task_id IS NULL AND status='PENDING'
                    AND plan_day<>?""", arrayOf(entry.planId, entryId,
                    minOf(LocalDate.now(), destination).toString(), destination.toString()))
            }
        }
    }

    /** Calendar alert can be emitted once per date and should not replay on restart. */
    fun calendarAlertDelivered(day: LocalDate): Boolean = readableDatabase.rawQuery(
        "SELECT 1 FROM calendar_alerts WHERE day=?", arrayOf(day.toString())
    ).use { it.moveToFirst() }

    fun claimCalendarAlert(day: LocalDate): Int {
        val count = calendarEntries(day).count { it.status == "PENDING" }
        if (count == 0) return 0
        var claimed = false
        writableDatabase.transaction {
            claimed = insertWithOnConflict("calendar_alerts", null, ContentValues().apply {
                put("day", day.toString()); put("delivered_at", System.currentTimeMillis())
            }, SQLiteDatabase.CONFLICT_IGNORE) != -1L
        }
        return if (claimed) count else 0
    }

    fun summary(day: LocalDate): DailySummary {
        var done = 0; var failed = 0; var pending = 0
        readableDatabase.rawQuery("SELECT outcome, count(*) FROM day_results WHERE day=? GROUP BY outcome", arrayOf(day.toString())).use { cursor ->
            while (cursor.moveToNext()) when (cursor.getString(0)) {
                "DONE" -> done = cursor.getInt(1)
                "FAILED" -> failed = cursor.getInt(1)
                "PENDING" -> pending = cursor.getInt(1)
            }
        }
        return DailySummary(done, failed, pending)
    }

    fun reconcile(now: Long = System.currentTimeMillis()): Int {
        val today = Instant.ofEpochMilli(now).atZone(ZoneId.systemDefault()).toLocalDate()
        ensurePinned(today)
        val pending = load("status='PENDING' AND archive_kind IS NULL", emptyArray(), "id ASC")
        var moved = 0
        pending.forEach { task ->
            val day = task.date?.let(LocalDate::parse) ?: return@forEach
            val slot = blocks().getOrNull(task.block ?: -1) ?: return@forEach
            val end = day.atStartOfDay(ZoneId.systemDefault()).plusMinutes(slot.end.toLong())
                .toInstant().toEpochMilli()
            if (now < end) return@forEach
            val (nextDay, nextBlock) = nextAvailable(now, today)
            if (isCalendarLinked(task.id) && nextDay != day) {
                // A date-bound calendar entry must stay anchored to its scheduled day.
                // It may be moved between blocks *within* that day.
                return@forEach
            }
            if (isPinned(task)) {
                // Pinned tasks can move within a day, but must never spill into tomorrow:
                // tomorrow's instance is created from its original home_block.
                if (day != today || nextDay != today) return@forEach
                if (nextBlock != task.block) {
                    relocate(task, today, nextBlock)
                    moved++
                }
            } else if (nextDay != day || nextBlock != task.block) {
                relocate(task, nextDay, nextBlock)
                moved++
            }
        }
        return moved
    }

    /** Returns the first block whose end has not yet passed; after work, tomorrow's first block. */
    fun nextAvailable(now: Long, today: LocalDate): Pair<LocalDate, Int> {
        val local = Instant.ofEpochMilli(now).atZone(ZoneId.systemDefault())
        val minute = local.hour * 60 + local.minute
        val index = blocks().indexOfFirst { it.end > minute }
        return if (index >= 0) today to index else today.plusDays(1) to 0
    }

    private fun result(db: SQLiteDatabase, taskId: Long, day: LocalDate, status: String) {
        db.insertWithOnConflict("day_results", null, ContentValues().apply {
            put("task_id", taskId); put("day", day.toString()); put("outcome", status)
        }, SQLiteDatabase.CONFLICT_REPLACE)
    }

    private fun event(db: SQLiteDatabase, taskId: Long, action: String, details: String) {
        db.insert("task_events", null, ContentValues().apply {
            put("task_id", taskId); put("happened_at", System.currentTimeMillis())
            put("action", action); put("details", details)
        })
    }

    private inline fun SQLiteDatabase.transaction(block: SQLiteDatabase.() -> Unit) {
        beginTransaction()
        try { block(); setTransactionSuccessful() } finally { endTransaction() }
    }
}
