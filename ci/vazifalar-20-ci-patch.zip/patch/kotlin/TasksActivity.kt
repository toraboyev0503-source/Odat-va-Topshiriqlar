/* SPDX-License-Identifier: GPL-3.0-or-later */
package org.isoron.uhabits.activities.tasks

import android.app.AlertDialog
import android.app.TimePickerDialog
import android.Manifest
import android.app.AlarmManager
import android.content.Intent
import android.content.pm.PackageManager
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.GridLayout
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.util.Log
import androidx.activity.result.contract.ActivityResultContracts
import java.nio.charset.StandardCharsets
import nl.dionsegijn.konfetti.xml.KonfettiView
import nl.dionsegijn.konfetti.core.Party
import nl.dionsegijn.konfetti.core.Position
import nl.dionsegijn.konfetti.core.emitter.Emitter
import java.util.concurrent.TimeUnit
import androidx.appcompat.app.AppCompatActivity
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.time.temporal.ChronoUnit
import kotlin.math.max

/** A native view-based task planner, isolated from the existing habit screens. */
class TasksActivity : AppCompatActivity() {
    private lateinit var store: TaskStore
    private lateinit var page: LinearLayout
    private lateinit var konfetti: KonfettiView
    private var selectedDay = LocalDate.now()
    private var selectedBlock: Int? = null
    private var countdown: TextView? = null
    private var countdownEnd: Long = 0L
    private var visibleLiveWindow: String = ""
    private var renderedToday: LocalDate = LocalDate.now()
    private var countdownLabel: TextView? = null
    private val handler = Handler(Looper.getMainLooper())
    private var notificationPermissionRequested = false
    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) { TasksAlarms.schedule(this); TasksAlarms.scheduleNextDay(this); TasksReminders.schedule(this) }
    }
    private val blockTonePicker = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result -> saveTonePick(result, TasksTones.BLOCK) }
    private val reminderTonePicker = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result -> saveTonePick(result, TasksTones.REMINDER) }

    private fun saveTonePick(result: androidx.activity.result.ActivityResult, kind: String) {
        if (result.resultCode != RESULT_OK) return
        val uri = if (Build.VERSION.SDK_INT >= 33) {
            result.data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
        } else {
            @Suppress("DEPRECATION")
            result.data?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
        }
        TasksTones.save(this, kind, uri)
        Toast.makeText(this, "Signal ohangi: ${TasksTones.title(this, kind)}", Toast.LENGTH_SHORT).show()
    }

    private fun showTonePicker(kind: String) {
        val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
            putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
            putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE,
                if (kind == TasksTones.BLOCK) "Blok almashish ohangi" else "Vazifa eslatmasi ohangi")
            putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, TasksTones.selected(this@TasksActivity, kind))
            putExtra(RingtoneManager.EXTRA_RINGTONE_DEFAULT_URI, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true)
        }
        runCatching {
            if (kind == TasksTones.BLOCK) blockTonePicker.launch(intent)
            else reminderTonePicker.launch(intent)
        }.onFailure {
            Toast.makeText(this, "Ushbu qurilmada ohang tanlash oynasi mavjud emas", Toast.LENGTH_LONG).show()
        }
    }

    private fun offerExactAlarmPermission() {
        val alarms = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT < 31 || alarms.canScheduleExactAlarms()) {
            Toast.makeText(this, "Aniq vaqtli signallar faol", Toast.LENGTH_SHORT).show()
            return
        }
        runCatching {
            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                Uri.parse("package:$packageName")))
        }.onFailure { Toast.makeText(this, "Ruxsatni ilova sozlamalaridan yoqing", Toast.LENGTH_LONG).show() }
    }
    private val backupExport = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            runCatching {
                val stream = contentResolver.openOutputStream(uri) ?: error("Saqlash manzili ochilmadi")
                stream.use { it.write(store.exportBackup().toByteArray(StandardCharsets.UTF_8)) }
            }.onSuccess { Toast.makeText(this, "Zaxira saqlandi", Toast.LENGTH_LONG).show() }
                .onFailure { Toast.makeText(this, "Zaxira saqlanmadi: ${it.message}", Toast.LENGTH_LONG).show() }
        }
    }
    private val backupImport = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            AlertDialog.Builder(this)
                .setTitle("Vazifalarni tiklash")
                .setMessage("Amaldagi vazifalar ushbu zaxira bilan almashtiriladi. Davom etilsinmi?")
                .setNegativeButton("Bekor qilish", null)
                .setPositiveButton("Tiklash") { _, _ ->
                    runCatching {
                        val stream = contentResolver.openInputStream(uri) ?: error("Fayl ochilmadi")
                        val data = stream.use { input ->
                            val bytes = input.readBytes()
                            require(bytes.size < 20_000_000) { "Zaxira haddan katta" }
                            String(bytes, StandardCharsets.UTF_8)
                        }
                        store.importBackup(data)
                        selectedDay = LocalDate.now()
                        selectedBlock = null
                        TasksAlarms.schedule(this)
                        TasksAlarms.scheduleNextDay(this)
                        TasksReminders.schedule(this)
                        TasksCalendarAlerts.schedule(this)
                        render()
                    }.onSuccess { Toast.makeText(this, "Zaxira tiklandi", Toast.LENGTH_LONG).show() }
                        .onFailure { Toast.makeText(this, "Zaxira tiklanmadi: ${it.message}", Toast.LENGTH_LONG).show() }
                }.show()
        }
    }
    private val ticker = object : Runnable {
        override fun run() {
            val remaining = max(0L, (countdownEnd - System.currentTimeMillis()) / 1000)
            countdown?.text = "%02d:%02d:%02d".format(remaining / 3600, remaining % 3600 / 60, remaining % 60)
            val now = System.currentTimeMillis()
            val newToday = LocalDate.now()
            if (newToday != renderedToday && selectedDay == renderedToday && selectedBlock == null) {
                selectedDay = newToday // A day change updates the default view, not a manually selected history date.
            }
            val window = liveWindowKey(now)
            if (visibleLiveWindow != window && store.configured()) {
                store.reconcile(now)
                render()
                TasksAlarms.schedule(this)
                TasksAlarms.scheduleNextDay(this)
                TasksReminders.schedule(this)
            }
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = TaskStore(this)
        page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(250, 250, 250)) }
        val container = FrameLayout(this)
        container.addView(page, FrameLayout.LayoutParams(-1, -1))
        konfetti = KonfettiView(this)
        container.addView(konfetti, FrameLayout.LayoutParams(-1, -1))
        konfetti.isClickable = false
        setContentView(container)
        followReminderIntent(intent)
        render()
        if (intent?.action == "org.isoron.uhabits.tasks.OPEN_CALENDAR") {
            page.post { showCalendar() }
        }
        if (!store.configured()) page.post { showConfiguration(true) }
    }

    private fun followReminderIntent(data: Intent?) {
        val taskId = data?.getLongExtra("task_id", -1L) ?: -1L
        if (taskId <= 0) return
        val task = store.taskById(taskId) ?: return
        if (task.date != null) {
            selectedDay = LocalDate.parse(task.date)
            selectedBlock = task.block
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        followReminderIntent(intent)
        render()
        if (intent?.action == "org.isoron.uhabits.tasks.OPEN_CALENDAR") {
            page.post { showCalendar() }
        }
    }

    override fun onResume() {
        super.onResume()
        if (store.configured()) {
            store.reconcile()
            TasksAlarms.schedule(this)
            TasksAlarms.scheduleNextDay(this)
            TasksReminders.schedule(this)
            TasksCalendarAlerts.schedule(this)
            if (Build.VERSION.SDK_INT >= 33 && !notificationPermissionRequested &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                notificationPermissionRequested = true
                notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        render()
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    private fun dp(value: Float): Int =
        (resources.displayMetrics.density * value + 0.5f).toInt()
    private fun shape(color: Int, radius: Float = 14f, border: Int? = null): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        if (border != null) setStroke(dp(1f), border)
    }

    private fun text(value: String, size: Float = 14f, bold: Boolean = false, color: Int = Color.rgb(35, 40, 45)) = TextView(this).apply {
        this.text = value; textSize = size; setTextColor(color)
        if (bold) setTypeface(null, Typeface.BOLD)
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun space(h: Int = 10) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h.toFloat())) }
    private fun row(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    private fun col(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun tilePadding(v: View, px: Int = 12) = v.apply { setPadding(dp(px.toFloat()), dp(px.toFloat()), dp(px.toFloat()), dp(px.toFloat())) }
    private fun button(label: String, click: () -> Unit) = Button(this).apply {
        text = label; textSize = 12f; isAllCaps = false; setOnClickListener { click() }
    }

    /** Narrow actions keep the calendar task title readable on compact phones. */
    private fun smallAction(label: String, click: () -> Unit): TextView = text(label, 20f, true,
        Color.rgb(26, 116, 182)).apply {
        gravity = Gravity.CENTER
        minWidth = dp(36f); minHeight = dp(40f)
        setOnClickListener { click() }
        contentDescription = when (label) {
            "＋" -> "Blokka qo‘shish"
            "✎" -> "Tahrirlash"
            else -> "Qo‘shimcha amallar"
        }
    }

    private fun currentBlock(): Pair<LocalDate, Int> =
        store.nextAvailable(System.currentTimeMillis(), LocalDate.now())

    private fun activeBlockIndex(now: Long = System.currentTimeMillis()): Int? {
        val local = Instant.ofEpochMilli(now).atZone(ZoneId.systemDefault())
        val minute = local.hour * 60 + local.minute
        return store.blocks().indexOfFirst { minute >= it.start && minute < it.end }
            .takeIf { it >= 0 }
    }

    private fun liveWindowKey(now: Long = System.currentTimeMillis()): String {
        val local = Instant.ofEpochMilli(now).atZone(ZoneId.systemDefault())
        return "${local.toLocalDate()}-${activeBlockIndex(now) ?: -1}"
    }
    private fun dayEditable() = selectedDay >= LocalDate.now()

    private fun render() {
        page.removeAllViews(); countdown = null
        renderedToday = LocalDate.now()
        visibleLiveWindow = liveWindowKey()
        val top = col().apply { setPadding(dp(16f), dp(10f), dp(16f), dp(4f)) }
        val heading = row()
        heading.addView(text("Vazifalar", 21f, true), LinearLayout.LayoutParams(0, -2, 1f))
        heading.addView(button("◷ Keyinroq") { showTaskEditor(null, later = true) })
        val plannedToday = store.calendarTodayPending()
        heading.addView(button(if (plannedToday > 0) "▦ ●$plannedToday" else "▦") { showCalendar() })
        heading.addView(button("⚙") { showConfiguration(false) })
        top.addView(heading)
        val dateSummary = store.summary(selectedDay)
        val progress = row()
        progress.addView(button("▦ ${selectedDay}") { showMonitoringCalendar() }, LinearLayout.LayoutParams(0, -2, 1f))
        progress.addView(text("${dateSummary.percentage}%  ✓${dateSummary.done}  ×${dateSummary.failed}  ?${dateSummary.pending}", 13f, true))
        top.addView(progress)
        page.addView(top)

        val body = col().apply { setPadding(dp(12f), dp(7f), dp(12f), dp(10f)) }
        page.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        if (!store.configured()) {
            body.addView(text("Ish vaqti va bloklar sonini belgilang.", 18f))
            body.addView(button("Sozlashni boshlash") { showConfiguration(true) })
        } else {
            val blocks = store.blocks()
            val (liveDay, liveIndex) = currentBlock()
            val focusedIndex = (selectedBlock ?: when {
                selectedDay == liveDay -> liveIndex
                selectedDay == LocalDate.now() && liveDay > selectedDay -> blocks.lastIndex
                else -> 0
            }).coerceIn(blocks.indices)
            val block = blocks[focusedIndex]
            val activeIndex = activeBlockIndex()
            val activeNow = selectedDay == LocalDate.now() && focusedIndex == activeIndex
            val waitingNow = selectedDay == liveDay && focusedIndex == liveIndex && activeIndex == null
            val card = col().apply {
                background = shape(Color.WHITE, 18f, Color.rgb(230, 233, 236))
                elevation = dp(1f).toFloat()
                setPadding(dp(15f), dp(15f), dp(15f), dp(15f))
            }
            val blockHeading = row()
            blockHeading.addView(text("${focusedIndex + 1}-BLOK  ${block.caption()}", 17f, true), LinearLayout.LayoutParams(0, -2, 1f))
            blockHeading.addView(text(if (activeNow) "● JORIY" else if (waitingNow) "◷ NAVBATDA" else "KO‘RISH", 11f, true,
                if (activeNow) Color.rgb(20, 125, 65) else if (waitingNow) Color.rgb(50, 113, 176) else Color.GRAY))
            card.addView(blockHeading)
            if (activeNow || waitingNow) {
                card.addView(space(5))
                countdownLabel = text(if (activeNow) "Blok tugashiga qolgan vaqt" else "Blok boshlanishigacha qolgan vaqt",
                    12f, color = Color.GRAY).apply { gravity = Gravity.CENTER }
                card.addView(countdownLabel)
                countdown = text("", 29f, true).apply { gravity = Gravity.CENTER }
                card.addView(countdown)
                countdownEnd = selectedDay.atStartOfDay(ZoneId.systemDefault())
                    .plusMinutes((if (activeNow) block.end else block.start).toLong()).toInstant().toEpochMilli()
                val elapsed = (System.currentTimeMillis() - selectedDay.atStartOfDay(ZoneId.systemDefault())
                    .plusMinutes(block.start.toLong()).toInstant().toEpochMilli()).coerceAtLeast(0)
                val duration = (block.end - block.start) * 60_000L
                val width = ((elapsed * 100 / max(1L, duration)).toInt()).coerceIn(0, 100)
                val track = LinearLayout(this).apply { background = shape(Color.rgb(234, 238, 241), 9f) }
                track.addView(View(this).apply { background = shape(Color.rgb(65, 125, 205), 9f) },
                    LinearLayout.LayoutParams(0, dp(5f), width.toFloat()))
                track.addView(View(this), LinearLayout.LayoutParams(0, dp(5f), (100-width).toFloat()))
                card.addView(track)
                card.addView(space(8))
            }
            val tasks = store.list(selectedDay, focusedIndex)
            val taskViewport = ScrollView(this).apply { fillViewport = true }
            val taskContents = col()
            taskViewport.addView(taskContents)
            if (tasks.isEmpty()) taskContents.addView(text("Bu blokda hozircha vazifa yo‘q.", 13f, color = Color.GRAY))
            tasks.forEachIndexed { index, task ->
                val taskRow = row().apply {
                    background = shape(if (task.status == "DONE") Color.rgb(236, 236, 236)
                        else Color.rgb(248, 250, 252), 10f, Color.rgb(220, 225, 231))
                    setPadding(dp(8f), dp(5f), dp(4f), dp(5f))
                }
                taskRow.addView(text("%02d".format(index+1), 12f, true, Color.GRAY))
                val name = text(task.title, 14f, color = if (task.status == "DONE") Color.GRAY else Color.DKGRAY)
                name.setPadding(dp(8f), 0, dp(4f), 0)
                val label = col()
                label.addView(name)
                if (store.isPinned(task)) {
                    // Small, understated indicator; does not change the row's main button size.
                    val pinLine = row()
                    pinLine.addView(ImageView(this).apply { setImageResource(org.isoron.uhabits.R.drawable.tasks_pin) },
                        LinearLayout.LayoutParams(dp(12f), dp(12f)))
                    pinLine.addView(text(" Har kuni", 10f, color = Color.rgb(44, 121, 170)))
                    label.addView(pinLine)
                }
                if (task.reminderAt != null) {
                    val reminderTime = Instant.ofEpochMilli(task.reminderAt)
                        .atZone(ZoneId.systemDefault())
                    label.addView(text("◷ %02d:%02d".format(reminderTime.hour, reminderTime.minute),
                        10f, color = Color.rgb(56, 114, 176)))
                }
                if (!task.carriedFrom.isNullOrBlank()) label.addView(text("↪ ${task.carriedFrom}", 10f, color = Color.GRAY))
                taskRow.addView(label, LinearLayout.LayoutParams(0, -2, 1f))
                taskRow.addView(button(if (task.status == "DONE") "✓" else "?") { showStatus(task) })
                taskRow.addView(button("⋮") { showTaskMenu(task) })
                taskRow.setOnLongClickListener { showTaskMenu(task); true }
                taskContents.addView(taskRow)
                taskContents.addView(space(7))
            }
            card.addView(taskViewport, LinearLayout.LayoutParams(-1, 0, 1f))
            if (dayEditable()) {
                val controls = row()
                controls.addView(button("＋ Qo‘shish") { showTaskEditor(null, later = false) }, LinearLayout.LayoutParams(0, -2, 1f))
                controls.addView(button("▣ Arxivdan") { showArchive() }, LinearLayout.LayoutParams(0, -2, 1f))
                card.addView(controls)
            }
            body.addView(card, LinearLayout.LayoutParams(-1, 0, 1f))
            body.addView(space(10))
            // Never remove the active or selected block from the bottom strip.
            // Natural chronological order: earlier blocks on the left, later on the right.
            val stripScroller = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
            val strip = row()
            blocks.forEachIndexed { index, item ->
                strip.addView(miniBlock(index, item, selectedDay == LocalDate.now() && index == activeIndex,
                    index == focusedIndex))
            }
            stripScroller.addView(strip)
            body.addView(stripScroller)
            body.addView(space(10))
            if (selectedBlock != null || selectedDay != LocalDate.now()) {
                body.addView(button("↩ Joriy blokka qaytish") {
                    selectedDay = LocalDate.now(); selectedBlock = null; render()
                })
            }
        }
    }

    private fun miniBlock(index: Int, block: TaskBlock, current: Boolean, selected: Boolean): View {
        return col().apply {
            val bg = if (current) Color.rgb(221, 245, 243) else if (selected) Color.rgb(221, 236, 254)
                else Color.rgb(234, 237, 240)
            background = shape(bg, 9f, if (selected) Color.rgb(29, 123, 218) else null)
            setPadding(dp(9f), dp(8f), dp(9f), dp(8f))
            addView(text("${index + 1}-blok${if (current) " ●" else ""}", 12f, true,
                if (current) Color.rgb(0, 125, 117) else Color.DKGRAY))
            addView(text(block.caption(), 10f, color = Color.DKGRAY))
            addView(text("${store.list(selectedDay, index).size} ta", 10f, color = Color.GRAY))
            setOnClickListener { selectedBlock = index; render() }
            layoutParams = LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(6f) }
        }
    }

    private fun showTaskEditor(existing: TaskItem?, later: Boolean = false) {
        val input = EditText(this).apply {
            hint = "Vazifa nomi"; setSingleLine(false); setText(existing?.title ?: "")
            setSelection(text.length)
            setPadding(dp(18f), dp(12f), dp(18f), dp(12f))
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle(if (existing != null) "Vazifani tahrirlash" else if (later) "Keyinroq bajarish" else "Yangi vazifa")
            .setView(input)
            .setNegativeButton("Bekor qilish", null)
            .setPositiveButton("Saqlash", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val value = input.text.toString().trim()
                if (value.isBlank()) { input.error = "Vazifa nomini kiriting"; return@setOnClickListener }
                if (existing != null) store.rename(existing.id, value)
                else if (later) store.add(value, null, null, later = true)
                else store.add(value, selectedDay, (selectedBlock ?: currentBlock().second).coerceIn(store.blocks().indices))
                dialog.dismiss(); render()
            }
        }
        dialog.show()
    }

    private fun showStatus(task: TaskItem) {
        AlertDialog.Builder(this).setTitle(task.title)
            .setItems(arrayOf("✓ Bajarildi", "× Bajarilmadi — arxivga", "? Hali noma’lum")) { _, which ->
                val outcome = arrayOf("DONE", "FAILED", "PENDING")[which]
                val saved = runCatching { store.setStatus(task, outcome) }
                if (saved.isFailure) {
                    Log.e("TasksActivity", "Could not persist task outcome", saved.exceptionOrNull())
                    Toast.makeText(this, "Vazifa saqlanmadi. Qayta urining.", Toast.LENGTH_LONG).show()
                    return@setItems
                }
                TasksReminders.schedule(this)
                TasksCalendarAlerts.schedule(this)
                if (outcome != "PENDING") TasksNotifications.dismissReminder(this, task.id)
                render()
                if (which == 0) {
                    playCompletionAnimationSafely()
                    Toast.makeText(this, "✓ Bajarildi", Toast.LENGTH_SHORT).show()
                } else if (which == 1) {
                    Toast.makeText(this, "Vazifa arxivga o‘tkazildi", Toast.LENGTH_SHORT).show()
                }
            }.setNegativeButton("Yopish", null).show()
    }

    private fun playCompletionAnimationSafely() {
        // Confetti is decoration. Its failure must never roll back the user's completed task.
        konfetti.post {
            if (isFinishing || isDestroyed || !konfetti.isAttachedToWindow ||
                konfetti.width <= 0 || konfetti.height <= 0) return@post
            runCatching {
                konfetti.start(Party(
                    speed = 0f, maxSpeed = 16f, damping = 0.9f, spread = 360,
                    angle = 0,
                    colors = listOf(0xFF5A9FDF.toInt(), 0xFF79C69D.toInt(),
                        0xFFF0C16B.toInt(), 0xFFDA85B6.toInt()),
                    position = Position.Absolute(konfetti.width / 2f, konfetti.height / 2f),
                    emitter = Emitter(duration = 25, TimeUnit.MILLISECONDS).max(25),
                    timeToLive = 0
                ))
            }.onFailure { Log.w("TasksActivity", "Completion effect skipped", it) }
        }
    }

    private fun showTaskMenu(task: TaskItem) {
        val currentlyPinned = store.isPinned(task)
        val actions = arrayOf("Tahrirlash", "Boshqa blokka ko‘chirish", "Nusxalash", "Yuqoriga", "Pastga",
            if (currentlyPinned) "Pindan chiqarish" else "Har kuni pin qilish",
            "◷ Eslatma o‘rnatish", "O‘chirish")
        AlertDialog.Builder(this).setTitle(task.title).setItems(actions) { _, which ->
            when (which) {
                0 -> showTaskEditor(task)
                1 -> showMovePicker(task)
                2 -> { store.duplicate(task); render() }
                3 -> { store.reorder(task, -1); render() }
                4 -> { store.reorder(task, 1); render() }
                5 -> {
                    runCatching { store.togglePin(task) }
                        .onSuccess { Toast.makeText(this, if (it) "Har kuni shu blokda takrorlanadi" else "Pin o‘chirildi", Toast.LENGTH_SHORT).show() }
                        .onFailure { Toast.makeText(this, "Pin o‘zgarmadi: ${it.message}", Toast.LENGTH_LONG).show() }
                    render()
                }
                6 -> showReminderEditor(task)
                7 -> AlertDialog.Builder(this)
                    .setMessage(if (currentlyPinned) "Vazifa va uning kelajakdagi kundalik takrorlanishi o‘chirilsinmi?" else "Vazifa o‘chirilsinmi?")
                    .setNegativeButton("Yo‘q", null)
                    .setPositiveButton("O‘chirish") { _, _ ->
                        store.erase(task)
                        TasksNotifications.dismissReminder(this, task.id)
                        TasksReminders.schedule(this)
                        TasksCalendarAlerts.schedule(this)
                        render()
                    }.show()
            }
        }.show()
    }

    private fun showReminderEditor(task: TaskItem) {
        if (task.date == null || task.archiveKind != null ||
            (task.status != "PENDING" && !store.isPinned(task))) {
            Toast.makeText(this, "Avval vazifani blokka joylashtiring", Toast.LENGTH_SHORT).show()
            return
        }
        val current = task.reminderAt?.let {
            Instant.ofEpochMilli(it).atZone(ZoneId.systemDefault())
        }
        val now = java.time.ZonedDateTime.now()
        val h = current?.hour ?: now.hour
        val m = current?.minute ?: now.minute
        val choose = TimePickerDialog.OnTimeSetListener { _, hour, minute ->
            runCatching { store.setReminder(task.id, hour * 60 + minute) }
                .onSuccess {
                    TasksReminders.schedule(this)
                    render()
                    Toast.makeText(this, "Eslatma o‘rnatildi: %02d:%02d".format(hour, minute),
                        Toast.LENGTH_SHORT).show()
                }
                .onFailure { Toast.makeText(this,
                    it.message ?: "Eslatma saqlanmadi", Toast.LENGTH_LONG).show() }
        }
        if (task.reminderAt != null) {
            AlertDialog.Builder(this).setTitle("Vazifa eslatmasi")
                .setItems(arrayOf("Vaqtni o‘zgartirish", "Eslatmani o‘chirish")) { _, index ->
                    if (index == 0) TimePickerDialog(this, choose, h, m, true).show()
                    else {
                        store.clearReminder(task.id)
                        TasksReminders.schedule(this)
                        render()
                    }
                }.show()
        } else TimePickerDialog(this, choose, h, m, true).show()
    }

    private fun showMovePicker(task: TaskItem) {
        val grid = GridLayout(this).apply { columnCount = 2; setPadding(dp(8f),dp(8f),dp(8f),dp(8f)) }
        val dialog = AlertDialog.Builder(this).setTitle("Qaysi blokka ko‘chirilsin?")
            .setView(grid).setNegativeButton("Yopish", null).create()
        store.blocks().forEach { block ->
            val b = button("${block.index+1}-BLOK\n${block.caption()}\n${store.list(selectedDay,block.index).size} vazifa") {
                dialog.dismiss(); confirmMove(task, block)
            }
            grid.addView(b, GridLayout.LayoutParams().apply {
                width = dp(151f); height = dp(90f); setMargins(dp(3f),dp(3f),dp(3f),dp(3f))
            })
        }
        dialog.show()
    }

    private fun confirmMove(task: TaskItem, destination: TaskBlock) {
        val message = "${destination.index+1}-blok • ${destination.caption()}\n\n" +
            store.list(selectedDay, destination.index).joinToString("\n") { "• ${it.title}" }
        AlertDialog.Builder(this).setTitle("${destination.index+1}-blok")
            .setMessage(message.ifBlank { "Bu blokda hozircha vazifa yo‘q" })
            .setNegativeButton("×") { _, _ -> showMovePicker(task) }
            .setPositiveButton("✓") { _, _ -> store.relocate(task, selectedDay, destination.index); render() }
            .show()
    }

    private fun showArchive() {
        val content = col().apply { setPadding(dp(12f), dp(8f), dp(12f), dp(8f)) }
        val search = EditText(this).apply { hint = "Arxivdan qidirish"; setSingleLine() }
        content.addView(search)
        val scroller = ScrollView(this)
        val items = col()
        scroller.addView(items)
        content.addView(scroller, LinearLayout.LayoutParams(-1, dp(350f)))
        val dialog = AlertDialog.Builder(this).setTitle("Vazifalar arxivi")
            .setView(content).setNegativeButton("Yopish", null).create()
        fun refreshArchive(query: String) {
            items.removeAllViews()
            store.archive().filter { it.title.contains(query, ignoreCase = true) }.forEach { task ->
                val r = row().apply {
                    background = shape(if (task.archiveKind == "FAILED") Color.rgb(255, 227, 227)
                        else Color.rgb(242, 245, 248), 9f)
                    setPadding(dp(6f),dp(4f),dp(4f),dp(4f))
                }
                val name = text("${if (task.archiveKind == "FAILED") "×" else "◷"}  ${task.title}",13f)
                r.addView(name, LinearLayout.LayoutParams(0,-2,1f))
                name.setOnClickListener {
                    val (day, current) = currentBlock()
                    val destinationDay = if (selectedDay >= LocalDate.now()) selectedDay else day
                    val index = (selectedBlock ?: current).coerceIn(store.blocks().indices)
                    if (store.isPinned(task) && task.date != destinationDay.toString()) {
                        Toast.makeText(this, "Pinlangan vazifani boshqa kunga arxivdan ko‘chirmang: u yangi kunda o‘z blokida paydo bo‘ladi.",
                            Toast.LENGTH_LONG).show()
                        return@setOnClickListener
                    }
                    store.restore(task, destinationDay, index)
                    dialog.dismiss(); render()
                }
                r.addView(button("✎") { dialog.dismiss(); showTaskEditor(task) })
                r.addView(button("⌫") {
                    AlertDialog.Builder(this).setMessage("Arxivdan butunlay o‘chirilsinmi?")
                        .setNegativeButton("Yo‘q", null)
                        .setPositiveButton("O‘chirish") { _, _ -> store.erase(task); refreshArchive(search.text.toString()); render() }.show()
                })
                items.addView(r)
                items.addView(space(6))
            }
            if (items.childCount == 0) items.addView(text("Arxivda mos vazifa topilmadi.", 14f, color = Color.GRAY))
        }
        search.addTextChangedListener(object: TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, st: Int, before: Int, count: Int) { refreshArchive(s?.toString() ?: "") }
            override fun afterTextChanged(s: Editable?) = Unit
        })
        refreshArchive("")
        dialog.show()
    }

    private fun showMonitoringCalendar(initial: YearMonth = YearMonth.from(selectedDay)) {
        val outer = col().apply { setPadding(dp(10f),dp(8f),dp(10f),dp(8f)) }
        val header = row()
        var activeDialog: AlertDialog? = null
        val monthText = text(initial.toString(), 19f, true).apply { gravity = Gravity.CENTER }
        header.addView(button("‹") { activeDialog?.dismiss(); showMonitoringCalendar(initial.minusMonths(1)) })
        header.addView(monthText, LinearLayout.LayoutParams(0,-2,1f))
        header.addView(button("›") { activeDialog?.dismiss(); showMonitoringCalendar(initial.plusMonths(1)) })
        outer.addView(header)
        val monthGrid = GridLayout(this).apply { columnCount = 7 }
        listOf("Du","Se","Ch","Pa","Ju","Sh","Ya").forEach { day ->
            monthGrid.addView(text(day, 11f, true).apply { gravity = Gravity.CENTER },
                GridLayout.LayoutParams().apply { width=dp(40f);height=dp(35f) })
        }
        repeat(initial.atDay(1).dayOfWeek.value - 1) {
            monthGrid.addView(View(this), GridLayout.LayoutParams().apply { width=dp(40f);height=dp(48f) })
        }
        val dialog = AlertDialog.Builder(this).setTitle("Vazifalar monitoringi")
            .setView(outer).setNegativeButton("Yopish", null).create()
        activeDialog = dialog
        for (n in 1..initial.lengthOfMonth()) {
            val date = initial.atDay(n)
            val sum = store.summary(date)
            val cell = text("$n\n${if(sum.total==0) "–" else "${sum.percentage}%"}", 11f,
                date == selectedDay, if (sum.percentage > 74 && sum.total > 0) Color.rgb(20,100,53) else Color.DKGRAY)
            cell.gravity = Gravity.CENTER
            cell.background = shape(if (date == selectedDay) Color.rgb(215,234,255)
                else if (sum.percentage >= 75 && sum.total > 0) Color.rgb(221,246,225)
                else Color.TRANSPARENT, 8f)
            cell.setOnClickListener { selectedDay=date; selectedBlock=null; dialog.dismiss(); render() }
            monthGrid.addView(cell, GridLayout.LayoutParams().apply { width=dp(40f);height=dp(48f) })
        }
        outer.addView(monthGrid)
        val current = store.summary(selectedDay)
        outer.addView(space(8))
        outer.addView(text("${selectedDay}: ${current.percentage}%  •  ✓ ${current.done}  × ${current.failed}  ? ${current.pending}", 13f, true))
        dialog.show()
    }

    /** Planned-date calendar, independent from the existing percentage monitoring dialog. */
    private fun showCalendar(month: YearMonth = YearMonth.from(LocalDate.now())) {
        val entries = store.calendarMonth(month)
        val byDay = entries.groupBy { it.day }
        val sum = store.calendarSummary(entries)
        val form = col().apply { setPadding(dp(10f), dp(8f), dp(10f), dp(10f)) }
        lateinit var dialog: AlertDialog
        val head = row()
        head.addView(button("‹") { dialog.dismiss(); showCalendar(month.minusMonths(1)) })
        head.addView(text("${month.monthValue}-oy • ${month.year}", 18f, true).apply {
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(button("›") { dialog.dismiss(); showCalendar(month.plusMonths(1)) })
        form.addView(head)
        form.addView(space(7))
        val table = GridLayout(this).apply { columnCount = 7 }
        val cellWidth = ((resources.displayMetrics.widthPixels - dp(92f)) / 7).coerceAtLeast(dp(33f))
        for (name in listOf("Du", "Se", "Ch", "Pa", "Ju", "Sh", "Ya")) {
            table.addView(text(name, 11f, true, Color.GRAY).apply { gravity = Gravity.CENTER },
                GridLayout.LayoutParams().apply { width = cellWidth; height = dp(31f) })
        }
        repeat(month.atDay(1).dayOfWeek.value - 1) {
            table.addView(View(this), GridLayout.LayoutParams().apply {
                width = cellWidth; height = dp(55f)
            })
        }
        for (dayNumber in 1..month.lengthOfMonth()) {
            val date = month.atDay(dayNumber)
            val tasks = byDay[date].orEmpty()
            val missed = tasks.count { it.status == "FAILED" }
            val late = date < LocalDate.now() && tasks.any { it.status == "PENDING" }
            val today = date == LocalDate.now()
            val marker = when {
                missed > 0 -> "×$missed"
                late -> "!"
                today && tasks.any { it.status == "PENDING" } -> "●"
                else -> ""
            }
            val label = "$dayNumber\n${if (tasks.isEmpty()) "–" else "${tasks.size} ta"}${if (marker.isEmpty()) "" else " $marker"}"
            val cell = text(label, 10.5f, today, when {
                missed > 0 -> Color.rgb(176, 53, 53)
                late -> Color.rgb(166, 103, 12)
                today -> Color.rgb(13, 104, 211)
                else -> Color.DKGRAY
            }).apply {
                gravity = Gravity.CENTER
                background = shape(if (today) Color.rgb(223, 237, 255)
                    else if (missed > 0) Color.rgb(255, 235, 235)
                    else Color.rgb(245, 247, 249), 7f)
                setOnClickListener { dialog.dismiss(); showCalendarDay(date) }
            }
            table.addView(cell, GridLayout.LayoutParams().apply {
                width = cellWidth; height = dp(55f); setMargins(dp(1f), dp(1f), dp(1f), dp(1f))
            })
        }
        form.addView(table)
        form.addView(space(10))
        form.addView(text("Shu oy: ${sum.total} ta  •  ✓ ${sum.done}  × ${sum.failed}  ? ${sum.pending}",
            13f, true))
        form.addView(text("Kalendar bajarilishi: ${sum.percentage}%", 12f, color = Color.GRAY))
        form.addView(button("＋ Tanlangan kunga vazifa yozish") {
            dialog.dismiss(); showCalendarDay(selectedDay)
        })
        val calendarScroll = ScrollView(this).apply { addView(form) }
        dialog = AlertDialog.Builder(this).setTitle("Rejalashtirish kalendari")
            .setView(calendarScroll).setNegativeButton("Yopish", null).create()
        dialog.show()
    }

    private fun showCalendarDay(day: LocalDate) {
        val tasks = store.calendarEntries(day)
        val sum = store.calendarSummary(tasks)
        val pane = col().apply { setPadding(dp(12f), dp(8f), dp(12f), dp(8f)) }
        pane.addView(text("${day.dayOfMonth}.${day.monthValue}.${day.year}  •  ${tasks.size} ta reja", 15f, true))
        pane.addView(text("✓ ${sum.done}  × ${sum.failed}  ? ${sum.pending}  •  ${sum.percentage}%",
            12f, color = Color.GRAY))
        pane.addView(space(8))
        val listScroll = ScrollView(this)
        val listBox = col()
        listScroll.addView(listBox)
        pane.addView(listScroll, LinearLayout.LayoutParams(-1,
            minOf(dp(345f), (resources.displayMetrics.heightPixels * 0.43f).toInt())))
        val dialog = AlertDialog.Builder(this).setTitle("Kalendar vazifalari")
            .setView(pane).setNegativeButton("Yopish", null).create()
        if (tasks.isEmpty()) listBox.addView(text("Bu kunda rejalangan vazifalar yo‘q.", 13f, color = Color.GRAY))
        for (entry in tasks) {
            val taskRow = row().apply {
                background = shape(if (entry.status == "FAILED") Color.rgb(255, 233, 233)
                    else Color.rgb(247, 249, 251), 10f, Color.rgb(224, 228, 232))
                setPadding(dp(4f), dp(5f), dp(4f), dp(5f))
            }
            val name = col()
            val symbol = when (entry.status) { "DONE" -> "✓"; "FAILED" -> "×"; else -> "?" }
            name.addView(text("$symbol ${entry.title}", 12f, entry.status == "PENDING",
                if (entry.status == "FAILED") Color.rgb(172, 54, 54) else Color.DKGRAY))
            name.addView(text("${if (entry.monthlyPinned) "♢ Har oy" else "Bir martalik"}" +
                if (entry.linkedTaskId != null) "  •  Blokka biriktirilgan" else "", 10f, color = Color.GRAY))
            taskRow.addView(name, LinearLayout.LayoutParams(0, -2, 1f))
            taskRow.addView(smallAction("＋") { dialog.dismiss(); showCalendarBlockPicker(entry) })
            taskRow.addView(smallAction("✎") { dialog.dismiss(); showCalendarEditor(day, entry) })
            taskRow.addView(smallAction("⋮") { dialog.dismiss(); showCalendarEntryActions(entry) })
            listBox.addView(taskRow); listBox.addView(space(6))
        }
        pane.addView(button("＋ Yangi kalendar vazifasi") { dialog.dismiss(); showCalendarEditor(day) })
        pane.addView(button("Kunni vaqt bloklarida ko‘rish") {
            selectedDay = day; selectedBlock = null; dialog.dismiss(); render()
        })
        dialog.show()
    }

    private fun showCalendarEditor(day: LocalDate, entry: CalendarEntry? = null) {
        val input = EditText(this).apply {
            hint = "Vazifa nomi"; setText(entry?.title ?: ""); setSelection(text.length)
        }
        val dialog = AlertDialog.Builder(this).setTitle(if (entry == null)
            "Kalendar vazifasi • $day" else "Kalendar vazifasini tahrirlash")
            .setView(input).setNegativeButton("Bekor qilish", null)
            .setPositiveButton("Saqlash", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val title = input.text.toString().trim()
                if (title.isEmpty()) { input.error = "Vazifa nomini yozing"; return@setOnClickListener }
                runCatching {
                    if (entry == null) store.addCalendar(title, day, pinned = true)
                    else store.renameCalendar(entry.id, title)
                }.onSuccess {
                    TasksCalendarAlerts.schedule(this); dialog.dismiss(); render(); showCalendarDay(day)
                }.onFailure { Toast.makeText(this, it.message ?: "Vazifa saqlanmadi", Toast.LENGTH_LONG).show() }
            }
        }
        dialog.show()
    }

    private fun showCalendarEntryActions(entry: CalendarEntry) {
        val menu = arrayOf(if (entry.monthlyPinned) "Oylik pinni o‘chirish" else "Har oy pin qilish",
            "Boshqa kunga ko‘chirish", "Shu kundagi rejani o‘chirish", "Kelgusi takrorlarni to‘xtatish")
        AlertDialog.Builder(this).setTitle(entry.title).setItems(menu) { _, item ->
            when (item) {
                0 -> runCatching { store.toggleCalendarPin(entry.id) }.onSuccess {
                    TasksCalendarAlerts.schedule(this); render(); showCalendarDay(entry.day)
                }.onFailure { Toast.makeText(this, it.message, Toast.LENGTH_LONG).show() }
                1 -> showCalendarMove(entry)
                2 -> AlertDialog.Builder(this).setTitle("Shu kundagi rejani o‘chirish")
                    .setMessage("Blokka biriktirilgan vazifa qoladi. Faqat kalendar rejasini o‘chirasizmi?")
                    .setNegativeButton("Bekor qilish", null).setPositiveButton("O‘chirish") { _, _ ->
                        store.deleteCalendarOccurrence(entry.id)
                        TasksCalendarAlerts.schedule(this); render(); showCalendarDay(entry.day)
                    }.show()
                3 -> AlertDialog.Builder(this).setTitle("Takrorlashni to‘xtatish")
                    .setMessage("Oldingi natijalar saqlanadi. Kelgusidagi takrorlar to‘xtatilsinmi?")
                    .setNegativeButton("Bekor qilish", null).setPositiveButton("To‘xtatish") { _, _ ->
                        store.stopCalendarSeries(entry.id)
                        TasksCalendarAlerts.schedule(this); render(); showCalendarDay(entry.day)
                    }.show()
            }
        }.setNegativeButton("Yopish", null).show()
    }

    private fun showCalendarBlockPicker(entry: CalendarEntry) {
        if (!store.configured()) {
            Toast.makeText(this, "Avval vaqt bloklarini sozlang", Toast.LENGTH_LONG).show()
            return
        }
        if (entry.day > LocalDate.now()) {
            AlertDialog.Builder(this).setTitle("Rejalashtirilgan kun hali kelmagan")
                .setMessage("Bu vazifaning kuni ${entry.day}. Uni hozirdan blokka biriktirmoqchimisiz?")
                .setNegativeButton("Bekor qilish") { _, _ -> showCalendarDay(entry.day) }
                .setPositiveButton("Baribir qo‘shish") { _, _ -> showCalendarBlockGrid(entry) }
                .show()
        } else showCalendarBlockGrid(entry)
    }

    private fun showCalendarBlockGrid(entry: CalendarEntry) {
        val scroll = ScrollView(this)
        val grid = GridLayout(this).apply { columnCount = 2; setPadding(dp(8f), dp(8f), dp(8f), dp(8f)) }
        scroll.addView(grid)
        lateinit var dialog: AlertDialog
        for (block in store.blocks()) {
            grid.addView(button("${block.index + 1}-blok\n${block.caption()}") {
                AlertDialog.Builder(this).setTitle("${block.index + 1}-blok • ${block.caption()}")
                    .setMessage("“${entry.title}” vazifasini shu blokka biriktirasizmi?")
                    .setNegativeButton("×", null)
                    .setPositiveButton("✓") { _, _ ->
                        runCatching { store.linkCalendar(entry.id, block.index) }.onSuccess {
                            TasksReminders.schedule(this)
                            TasksCalendarAlerts.schedule(this)
                            dialog.dismiss(); render(); showCalendarDay(entry.day)
                        }.onFailure { Toast.makeText(this, it.message, Toast.LENGTH_LONG).show() }
                    }.show()
            }, GridLayout.LayoutParams().apply {
                width = dp(143f); height = dp(76f); setMargins(dp(3f), dp(3f), dp(3f), dp(3f))
            })
        }
        dialog = AlertDialog.Builder(this).setTitle("Qaysi vaqt blokiga?")
            .setView(scroll).setNegativeButton("Yopish") { _, _ -> showCalendarDay(entry.day) }.create()
        dialog.show()
    }

    private fun showCalendarMove(entry: CalendarEntry, month: YearMonth = YearMonth.from(entry.day)) {
        val form = col().apply { setPadding(dp(10f), dp(8f), dp(10f), dp(8f)) }
        lateinit var dialog: AlertDialog
        val heading = row()
        heading.addView(button("‹") { dialog.dismiss(); showCalendarMove(entry, month.minusMonths(1)) })
        heading.addView(text("${month.monthValue}-oy • ${month.year}", 17f, true).apply {
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(0, -2, 1f))
        heading.addView(button("›") { dialog.dismiss(); showCalendarMove(entry, month.plusMonths(1)) })
        form.addView(heading)
        val grid = GridLayout(this).apply { columnCount = 7 }
        val width = ((resources.displayMetrics.widthPixels - dp(92f))/7).coerceAtLeast(dp(33f))
        listOf("Du", "Se", "Ch", "Pa", "Ju", "Sh", "Ya").forEach {
            grid.addView(text(it, 11f, true).apply { gravity = Gravity.CENTER },
                GridLayout.LayoutParams().apply { this.width=width; height=dp(30f) })
        }
        repeat(month.atDay(1).dayOfWeek.value - 1) {
            grid.addView(View(this), GridLayout.LayoutParams().apply { width=width; height=dp(49f) })
        }
        for (n in 1..month.lengthOfMonth()) {
            val day = month.atDay(n)
            val b = button(n.toString()) {
                AlertDialog.Builder(this).setTitle("Sana o‘zgartirilsinmi?")
                    .setMessage("“${entry.title}”\n${entry.day} → $day\nPin yoqilgan bo‘lsa, keyingi oylar ham yangi sanada takrorlanadi.")
                    .setNegativeButton("Bekor qilish", null)
                    .setPositiveButton("✓ Ko‘chirish") { _, _ ->
                        runCatching { store.moveCalendar(entry.id, day) }.onSuccess {
                            TasksReminders.schedule(this); TasksCalendarAlerts.schedule(this)
                            dialog.dismiss(); render(); showCalendarDay(day)
                        }.onFailure { Toast.makeText(this, it.message, Toast.LENGTH_LONG).show() }
                    }.show()
            }
            grid.addView(b, GridLayout.LayoutParams().apply {
                width=width; height=dp(49f); setMargins(dp(1f), dp(1f), dp(1f), dp(1f))
            })
        }
        form.addView(grid)
        val datesScroll = ScrollView(this).apply { addView(form) }
        dialog = AlertDialog.Builder(this).setTitle("Yangi sanani tanlang")
            .setView(datesScroll).setNegativeButton("Yopish") { _, _ -> showCalendarDay(entry.day) }.create()
        dialog.show()
    }

    private fun showConfiguration(initial: Boolean) {
        val existing = store.blocks()
        var from = existing.first().start
        var to = existing.last().end
        val form = col().apply { setPadding(dp(16f), dp(10f), dp(16f), dp(6f)) }
        form.addView(text("Ish vaqti va bloklar soni", 16f, true))
        val startButton = button("Boshlanish: ${minutesText(from)}") { }
        val endButton = button("Tugash: ${minutesText(to)}") { }
        startButton.setOnClickListener {
            TimePickerDialog(this, { _, h, m ->
                from = h * 60 + m; startButton.text = "Boshlanish: ${minutesText(from)}"
            }, from / 60, from % 60, true).show()
        }
        endButton.setOnClickListener {
            TimePickerDialog(this, { _, h, m ->
                to = h * 60 + m; endButton.text = "Tugash: ${minutesText(to)}"
            }, (to / 60).coerceAtMost(23), to % 60, true).show()
        }
        form.addView(startButton)
        form.addView(endButton)
        form.addView(button("Kun oxirigacha (24:00)") {
            to = 1440
            endButton.text = "Tugash: 24:00"
        })
        form.addView(text("Bloklar soni (1–24)", 13f))
        val count = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText(existing.size.toString()); setSingleLine()
        }
        form.addView(count)
        if (!initial) {
            form.addView(button("Bloklarni alohida sozlash (joriy vaqtlar saqlanadi)") {
                showCustomBlocks()
            })
            form.addView(button("Blok signali: ${TasksTones.title(this, TasksTones.BLOCK)}") {
                showTonePicker(TasksTones.BLOCK)
            })
            form.addView(button("Eslatma ohangi: ${TasksTones.title(this, TasksTones.REMINDER)}") {
                showTonePicker(TasksTones.REMINDER)
            })
            form.addView(button("Aniq vaqtli signallar ruxsati") { offerExactAlarmPermission() })
            form.addView(button("Vazifalarni zaxiralash / tiklash") { showBackupOptions() })
        }
        val alert = AlertDialog.Builder(this)
            .setTitle(if (initial) "Vazifalar — dastlabki sozlash" else "Vaqt bloklarini sozlash")
            .setView(form)
            .setCancelable(!initial)
            .setNegativeButton(if (initial) "Keyinroq" else "Yopish", null)
            .setPositiveButton("Saqlash", null).create()
        fun saveConfig(forceEqual: Boolean = false) {
            val n = count.text.toString().toIntOrNull()
            if (n == null || n !in 1..24 || to <= from || to - from < n) {
                Toast.makeText(this, "To‘g‘ri vaqt va bloklar sonini kiriting", Toast.LENGTH_LONG).show()
                return
            }
            if (!initial && !forceEqual && n == existing.size && from == existing.first().start && to == existing.last().end) {
                alert.dismiss(); return // Saving without changes never resets manual slots.
            }
            if (!initial && !forceEqual && n == existing.size) {
                runCatching { store.updateWindowPreservingCustom(from, to) }
                    .onSuccess { TasksAlarms.schedule(this); TasksAlarms.scheduleNextDay(this); TasksReminders.schedule(this); TasksCalendarAlerts.schedule(this); alert.dismiss(); render() }
                    .onFailure { Toast.makeText(this, it.message ?: "Chegaralar mos emas", Toast.LENGTH_LONG).show() }
                return
            }
            val commit = {
                store.configure(from, to, n)
                selectedBlock = null
                TasksAlarms.schedule(this)
                TasksAlarms.scheduleNextDay(this)
                TasksReminders.schedule(this)
                TasksCalendarAlerts.schedule(this)
                alert.dismiss(); render()
            }
            if (!initial) {
                AlertDialog.Builder(this).setTitle("Avtomatik teng taqsimlash")
                    .setMessage("Bu amal qo‘lda belgilangan vaqtlarni almashtiradi. Vazifalar o‘chmaydi. Davom etilsinmi?")
                    .setNegativeButton("Bekor qilish", null)
                    .setPositiveButton("Tasdiqlash") { _, _ -> commit() }.show()
            } else commit()
        }
        alert.setOnShowListener {
            alert.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener { saveConfig() }
        }
        if (!initial) {
            form.addView(button("Avtomatik teng taqsimlash (tasdiq bilan)") { saveConfig(forceEqual = true) })
        }
        alert.show()
    }

    private fun showBackupOptions() {
        AlertDialog.Builder(this)
            .setTitle("Vazifalar — zaxira")
            .setItems(arrayOf("Zaxira faylini yaratish", "Zaxiradan tiklash")) { _, option ->
                if (option == 0) backupExport.launch("Vazifalar-zaxira.json")
                else backupImport.launch(arrayOf("application/json", "text/plain", "*/*"))
            }.show()
    }

    private fun showCustomBlocks() {
        val original = store.blocks() // actual saved values, never regenerated from equal slots.
        val scroller = ScrollView(this)
        val form = col().apply { setPadding(dp(16f), dp(8f), dp(16f), dp(8f)) }
        form.addView(text("Har bir blok alohida boshlanadi va tugaydi. Tanaffus qoldirish mumkin.",
            13f, color = Color.GRAY))
        form.addView(space(8))
        val starts = original.map { it.start }.toMutableList()
        val ends = original.map { it.end }.toMutableList()
        val endButtons = mutableListOf<Button>()
        original.forEachIndexed { index, _ ->
            val blockRow = row()
            blockRow.addView(text("${index + 1}-blok", 13f, true), LinearLayout.LayoutParams(0, -2, 0.60f))
            val startButton = button("${minutesText(starts[index])}") { }
            val endButton = button("${minutesText(ends[index])}") { }
            endButtons.add(endButton)
            startButton.setOnClickListener {
                val value = starts[index]
                TimePickerDialog(this, { _, hour, minute ->
                    starts[index] = hour * 60 + minute
                    startButton.text = minutesText(starts[index])
                }, value / 60, value % 60, true).show()
            }
            endButton.setOnClickListener {
                val value = ends[index]
                TimePickerDialog(this, { _, hour, minute ->
                    ends[index] = hour * 60 + minute
                    endButton.text = minutesText(ends[index])
                }, (value / 60).coerceAtMost(23), value % 60, true).show()
            }
            blockRow.addView(startButton, LinearLayout.LayoutParams(0, -2, 1f))
            blockRow.addView(text("→", 12f), LinearLayout.LayoutParams(-2, -2))
            blockRow.addView(endButton, LinearLayout.LayoutParams(0, -2, 1f))
            form.addView(blockRow)
            form.addView(space(4))
        }
        form.addView(button("Oxirgi blokni 24:00 da tugatish") {
            ends[ends.lastIndex] = 1440
            endButtons.last().text = "24:00"
        })
        scroller.addView(form)
        val dialog = AlertDialog.Builder(this).setTitle("Blok vaqtlarini qo‘lda sozlash")
            .setView(scroller).setNegativeButton("Bekor qilish", null)
            .setPositiveButton("Saqlash", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val chosen = original.indices.map { i -> TaskBlock(i, starts[i], ends[i]) }
                runCatching { store.setCustom(chosen) }
                    .onSuccess {
                        TasksAlarms.schedule(this)
                        TasksAlarms.scheduleNextDay(this)
                        TasksReminders.schedule(this)
                        TasksCalendarAlerts.schedule(this)
                        dialog.dismiss(); render()
                        Toast.makeText(this, "Blok vaqtlaringiz saqlandi", Toast.LENGTH_SHORT).show()
                    }
                    .onFailure {
                        Toast.makeText(this,
                            "Vaqtlar mos emas: har bir blok kamida 1 daqiqa bo‘lsin, bloklar kesishmasin.",
                            Toast.LENGTH_LONG).show()
                    }
            }
        }
        dialog.show()
    }
}
