# 4-bosqich tekshiruv natijasi

- **Holat:** 1+2+3+4 jamlangan manba paketi tayyor.
- **Kotlin qo‘shilgan fayllar:** `TaskEngine`, `TasksActivity`, `TasksAlarms`, `TasksCalendarAlarms`, `TasksNotifications`, `TasksTones`, `TasksSignalService`.
- **Yangi imkoniyatlar:** oylik kalendar, oy/kunning statistikasi, pin, sanalar orasida ko‘chirish, kalendardan blokka biriktirish, bog‘langan `✓`/`×`/`?` va nomni sinxronlash, kunlik ogohlantirish, SQLite v4, JSON backup 1–4 mosligi.
- **Sinov:** Python unittest 24/24 o‘tgan; SQLite DDL va takror nusxani bloklovchi unique indekslar sinovdan o‘tgan; patch maket upstream tuzilmasiga qo‘llangan; XML/YML statik sintaksis tekshirilgan; ZIP CRC tekshiriladi.
- **APK:** build qilinmagan — 5-bosqichga qoldirilgan. Kotlin kompilyatsiyasi, haqiqiy Android 9–16, qurilma signal/xabar ko‘rinishi va yangilanib o‘rnatish hali tasdiqlanmagan.
- **Muhim cheklov:** oldingi debug APK imzolash sertifikati mavjud bo‘lmasa, release build eski APKning ustiga o‘rnatilmaydi. Paketni bir xil saqlashning o‘zi yetarli emas.
