#!/usr/bin/env python3
"""Cumulative stages 1 + 2 + 3 + 4 Tasks Android patch, on pinned Loop v2.3.1 build graph.

No APK is generated here. Keeps the previous tasks SQLite schema and app ID.
"""
from pathlib import Path
import argparse
import shutil
import sys

ROOT = Path(__file__).resolve().parent.parent
REL = Path('uhabits-android')
MANIFEST = REL / 'src/main/AndroidManifest.xml'
GRADLE = REL / 'build.gradle.kts'
KOTLIN_DIR = REL / 'src/main/java/org/isoron/uhabits/activities/tasks'
RES = REL / 'src/main/res'


def replace_once(src, old, new, label):
    if src.count(old) != 1:
        raise ValueError(f'{label}: expected exactly one match, saw {src.count(old)}: {old[:80]}')
    return src.replace(old, new, 1)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('upstream', type=Path)
    args = parser.parse_args()
    upstream = args.upstream.resolve()
    for part in [MANIFEST, GRADLE]:
        if not (upstream / part).exists():
            raise FileNotFoundError(f'Missing expected Loop source: {part}')
    manifest = (upstream / MANIFEST).read_text()
    gradle = (upstream / GRADLE).read_text()
    if 'activities.tasks.TasksActivity' in manifest:
        raise ValueError('Stage 4 already applied; refusing double patch')
    # Old launcher alias points to habits; re-route the existing alias to tasks.
    alias_start = manifest.index('        <activity-alias\n')
    alias_end = manifest.index('        </activity-alias>', alias_start) + len('        </activity-alias>')
    alias = manifest[alias_start:alias_end]
    assert 'android:name=".MainActivity"' in alias
    assert 'android:targetActivity=".activities.habits.list.ListHabitsActivity"' in alias
    alias = alias.replace('android:targetActivity=".activities.habits.list.ListHabitsActivity"',
                          'android:targetActivity=".activities.tasks.TasksActivity"')
    alias = alias.replace('android:label="@string/main_activity_title"',
                          'android:label="Vazifalar"')
    # Launcher icon is applied at application level; alias may override for some launchers.
    alias = alias.replace('android:launchMode="singleTop"',
                          'android:launchMode="singleTop"\n            android:icon="@mipmap/tasks_launcher"')
    manifest = manifest[:alias_start] + alias + manifest[alias_end:]
    # App label/icon, while old hidden habits code remains a build-time dependency.
    app_start, app_end = manifest.index('    <application'), manifest.index('    </application>')
    app_attrs = manifest[app_start:app_end]
    app_attrs = app_attrs.replace('android:icon="@mipmap/ic_launcher"',
                                  'android:icon="@mipmap/tasks_launcher"', 1)
    app_attrs = app_attrs.replace('android:label="@string/main_activity_title"',
                                  'android:label="Vazifalar"', 1)
    manifest = manifest[:app_start] + app_attrs + manifest[app_end:]
    # Keep existing file-provider scoped to app ID, not previous habit package.
    manifest = replace_once(manifest, 'android:authorities="org.isoron.uhabits"',
                             'android:authorities="${applicationId}"', 'FileProvider')
    # Apply only to the tasks Activity: NoActionBar removes duplicate black toolbar.
    insert = '''        <!-- Stage 4: Tasks launcher, block alarms, individual interactive reminders. -->
        <activity
            android:name=".activities.tasks.TasksActivity"
            android:exported="false"
            android:theme="@style/Theme.Tasks" />
        <receiver android:name=".activities.tasks.TasksAlarmReceiver" android:exported="false" />
        <receiver android:name=".activities.tasks.TasksDailyReceiver" android:exported="false" />
        <receiver android:name=".activities.tasks.TasksReminderReceiver" android:exported="false" />
        <receiver android:name=".activities.tasks.TasksCalendarReceiver" android:exported="false" />
        <receiver android:name=".activities.tasks.TasksReminderActionReceiver" android:exported="false" />
        <service android:name=".activities.tasks.TasksSignalService"
            android:exported="false"
            android:foregroundServiceType="mediaPlayback" />
        <receiver android:name=".activities.tasks.TasksBootReceiver" android:exported="false">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
                <action android:name="android.intent.action.TIME_SET" />
                <action android:name="android.intent.action.TIMEZONE_CHANGED" />
                <action android:name="android.intent.action.DATE_CHANGED" />
                <action android:name="android.app.action.SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED" />
            </intent-filter>
        </receiver>
'''
    # Required targetActivity has to be declared before the alias.
    before_alias = manifest.index('        <activity-alias\n')
    manifest = manifest[:before_alias] + insert + manifest[before_alias:]
    # Hide habits screens from other apps. Internal dependency sources unchanged.
    manifest = replace_once(manifest, 'android:name=".activities.habits.list.ListHabitsActivity"\n            android:exported="true"',
        'android:name=".activities.habits.list.ListHabitsActivity"\n            android:exported="false"', 'legacy habits activity')
    # Android 14+ needs foreground service media-playback permissions for the three-ring
    # custom sound, and Android 13+ requires runtime notification permission.
    manifest = manifest.replace('<application', '''<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK" />
    <application''', 1)
    # Fixed installed preview package ID; *same certificate* still required to update.
    gradle = replace_once(gradle, '        applicationId = "org.isoron.uhabits"',
        '        applicationId = "org.isoron.uhabits.tasks.preview"', 'application ID')
    gradle = replace_once(gradle, '        versionCode = 20301', '        versionCode = 20305', 'versionCode')
    gradle = replace_once(gradle, '        versionName = "2.3.1"',
        '        versionName = "2.0.0-stage4"', 'versionName')
    # Make sure Kotlin classes are not copied over existing generated files.
    sources = sorted((ROOT/'patch/kotlin').glob('*.kt'))
    expected = {'TaskEngine.kt', 'TasksActivity.kt', 'TasksAlarms.kt', 'TasksTones.kt', 'TasksNotifications.kt', 'TasksSignalService.kt', 'TasksCalendarAlarms.kt'}
    if {p.name for p in sources} != expected:
        raise ValueError(f'Missing / unexpected Kotlin files: {sources}')
    for resource in [ROOT/'patch/res/raw/tasks_three_signals.wav',
                     ROOT/'patch/res/values/tasks_styles.xml',
                     ROOT/'patch/res/values-v31/tasks_styles.xml',
                     ROOT/'patch/res/drawable/tasks_notification.xml',
                     ROOT/'patch/res/drawable/tasks_splash_background.xml',
                     ROOT/'patch/res/drawable/tasks_splash_logo.png',
                     ROOT/'patch/res/mipmap-anydpi-v26/tasks_launcher.xml']:
        if not resource.is_file():
            raise FileNotFoundError(f'Resource missing: {resource}')
    if (upstream/KOTLIN_DIR).exists() and list((upstream/KOTLIN_DIR).iterdir()):
        raise ValueError('Tasks source directory exists, refusing overwrite')
    (upstream/KOTLIN_DIR).mkdir(parents=True)
    for source in sources:
        shutil.copy2(source, upstream/KOTLIN_DIR/source.name)
    for source in (ROOT/'patch/res').rglob('*'):
        if source.is_file():
            target = upstream/RES/source.relative_to(ROOT/'patch/res')
            target.parent.mkdir(parents=True, exist_ok=True)
            if target.exists():
                raise ValueError(f'Resource collision: {target}')
            shutil.copy2(source, target)
    (upstream/MANIFEST).write_text(manifest)
    (upstream/GRADLE).write_text(gradle)
    print('STAGE 4 APPLIED: Tasks-only launcher, splash, fixed APK identity, no habit tab.')
    print('IMPORTANT: matching original signing certificate is required to update installed app.')


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        print('PHASE3 PATCH FAILED:', e, file=sys.stderr)
        sys.exit(2)
