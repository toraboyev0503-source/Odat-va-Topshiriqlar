#!/usr/bin/env python3
"""Locally back up Tasks from the already installed *debug* preview, via ADB run-as.

Requires the user's own Android phone, developer debugging, and ADB installed.
Does not uninstall, modify or upload any personal data.
"""
from __future__ import annotations
import argparse
import json
import sqlite3
import subprocess
import tempfile
from pathlib import Path
from xml.etree import ElementTree as ET

TABLES = {
    'tasks': ['id','title','plan_day','block_index','status','archive_kind',
              'position','carried_from','created_at','updated_at'],
    'day_results': ['task_id','day','outcome'],
    'task_events': ['id','task_id','happened_at','action','details'],
}


def adb_read(package: str, path: str) -> bytes:
    cmd = ['adb','exec-out','run-as',package,'cat',path]
    result = subprocess.run(cmd, capture_output=True, check=False)
    if result.returncode != 0:
        raise RuntimeError(f'ADB run-as o‘qiy olmadi: {path}; {result.stderr.decode(errors="replace")[:250]}')
    return result.stdout


def main():
    args = argparse.ArgumentParser(description='Old debug-preview Tasks app backup')
    args.add_argument('--package', default='org.isoron.uhabits.tasks.preview')
    args.add_argument('--output', type=Path, default=Path('vazifalar-eski-zaxira.json'))
    p = args.parse_args()
    with tempfile.TemporaryDirectory() as directory:
        db_path = Path(directory)/'odatlar_tasks.db'
        db_path.write_bytes(adb_read(p.package, 'databases/odatlar_tasks.db'))
        # Include uncheckpointed SQLite transactions when WAL mode was enabled.
        for suffix in ('-wal', '-shm'):
            r = subprocess.run(['adb','exec-out','run-as',p.package,'cat',
                                'databases/odatlar_tasks.db'+suffix], capture_output=True)
            if r.returncode == 0 and r.stdout:
                Path(str(db_path)+suffix).write_bytes(r.stdout)
        database = sqlite3.connect(f'file:{db_path}?mode=ro', uri=True)
        database.row_factory = sqlite3.Row
        tables = {}
        try:
            for table, columns in TABLES.items():
                actual = {r[1] for r in database.execute(f'PRAGMA table_info({table})')}
                if not set(columns).issubset(actual):
                    raise RuntimeError(f'Zaxira sxemasi mos emas: {table}')
                tables[table] = [dict(row) for row in database.execute(
                    f'SELECT {", ".join(columns)} FROM {table} ORDER BY rowid')]
        finally:
            database.close()
    pref_xml = adb_read(p.package, 'shared_prefs/tasks_config_v1.xml')
    xml = ET.fromstring(pref_xml)
    options = {}
    for el in xml:
        name = el.attrib.get('name')
        if name not in ('initialized','start','end','count','custom'): continue
        if el.tag in ('int','long'):
            options[name] = int(el.attrib['value'])
        elif el.tag == 'boolean':
            options[name] = el.attrib['value'] == 'true'
        elif el.tag == 'string':
            options[name] = el.text or ''
    payload = {'format':'odatlar_tasks_backup_v1', 'schema':1,
               'options':options, 'data':tables}
    p.output.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
    print('Zaxira yaratildi:',p.output,'; vazifalar:',len(tables['tasks']))
    print('Bu faylni xavfsiz joyda saqlang. Ilovadagi «Vazifalarni tiklash» orqali kiriting.')


if __name__ == '__main__':
    main()
