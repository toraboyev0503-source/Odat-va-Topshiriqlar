# 5-bosqichda tekshiriladigan end-to-end ssenariylar

1. Android 9, 12, 13, 14, 15, 16: faol Vazifalar ekrani, kalendar oynasini ochish va 7 ustunli telefon/foldable ko‘rinishi.
2. Eski v3 bazasi: dastur yangilanganda task va pins saqlanishi; v1–v3 JSON backup importi; v4 export/import natijalarining mosligi.
3. 2026-yil 31-dekabr pinli reja → 2027-yil yanvar 31 da nusxa, fevral 31 nusxasi bo‘lmasin, mart 31 qayta chiqsin.
4. Sana bo‘yicha 3 ta reja: 1 DONE, 1 FAILED, 1 PENDING → oy jami 3; shu sanada `×` belgisi va kun/oyda alohida hisob.
5. Kalendar rejasini 2-blokka qo‘shish, blokda ✓ → kalendarda ✓; blokda × → kalendarda ×; blokdan o‘chirish → kalendar yozuvi qoladi.
6. Kalendar rejasini boshqa kunga ko‘chirish; oylik pinning yangi sanada davom etishi; eski `✓`/`×` tarixni saqlashi.
7. Hali kelmagan kunga biriktirishda tasdiq so‘rash; bekor qilinsa blokda nusxa yaratilmasligi.
8. Bir sanani o‘chirish → aynan shu sanada qayta avtomatik chiqmasligi; butun seriyani to‘xtatish → keyingi oylarga nusxa paydo bo‘lmasligi.
9. Telefon qayta yoqilganda birinchi ish bloki boshlanishida bugungi reja haqida bir marta kalendar ogohlantirishi; blokning uch signali mustaqil ishlashi.
10. Bildirishnomadagi ✓/×/o‘tkazib yuborish va kalendar ichidagi holat, arxiv holati sinxron bo‘lishi.
11. Eski debug APK sertifikati bilan release sertifikati mos kelmasligi: APK ustidan o‘rnatish urinishi o‘rniga zaxiradan ko‘chirish jarayonini sinash.
