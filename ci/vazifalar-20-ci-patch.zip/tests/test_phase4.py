"""Stage-4 structural + real SQLite DDL/invariants checks; not Android compilation."""
from pathlib import Path
from datetime import date
import re
import sqlite3
import unittest
import tempfile
import subprocess
import sys
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
ENGINE=(ROOT/'patch/kotlin/TaskEngine.kt').read_text()
UI=(ROOT/'patch/kotlin/TasksActivity.kt').read_text()
ALARMS=(ROOT/'patch/kotlin/TasksCalendarAlarms.kt').read_text()
NOTIFY=(ROOT/'patch/kotlin/TasksNotifications.kt').read_text()

class Stage4(unittest.TestCase):
    def test_upgrade_v3_to_v4_is_additive(self):
        db=sqlite3.connect(':memory:')
        db.execute('CREATE TABLE tasks(id INTEGER PRIMARY KEY,title TEXT,status TEXT,plan_day TEXT)')
        db.execute("INSERT INTO tasks VALUES(19,'Bajarilgan ish','DONE','2026-11-23')")
        self.assertIn('if (oldVersion < 4) createCalendarTables(db)',ENGINE)
        for table in ('calendar_plans','calendar_entries','calendar_exclusions','calendar_alerts'):
            matches=re.findall(r'CREATE TABLE IF NOT EXISTS '+table+r' \(.*?\)"""',ENGINE,re.S)
            self.assertEqual(len(matches),1,table)
            db.execute(matches[0][:-3])
        for index in ('calendar_by_day','calendar_unique_task'):
            sql=re.search(r'CREATE (?:UNIQUE )?INDEX IF NOT EXISTS '+index+r' .+?"',ENGINE)
            self.assertIsNotNone(sql,index)
            db.execute(sql.group(0)[:-1])
        self.assertEqual(db.execute('SELECT title,status FROM tasks WHERE id=19').fetchone(),('Bajarilgan ish','DONE'))
        db.execute("INSERT INTO calendar_plans VALUES(1,'Kitob','2026-11-12','2026-11-12',1,1,1,1)")
        db.execute("INSERT INTO calendar_entries VALUES(1,1,'2026-11-12','Kitob','PENDING',NULL,1,1)")
        with self.assertRaises(sqlite3.IntegrityError):
            db.execute("INSERT INTO calendar_entries VALUES(2,1,'2026-11-12','Kitob','PENDING',NULL,1,1)")

    def test_monthly_recurrence_last_day_skips_short_month(self):
        self.assertIn('anchor.dayOfMonth > month.lengthOfMonth()',ENGINE)
        self.assertIn('UNIQUE(plan_id, plan_day)',ENGINE)
        self.assertIn('SQLiteDatabase.CONFLICT_IGNORE',ENGINE)
        self.assertIn('calendar_exclusions',ENGINE)
        self.assertIn('fun ensureCalendarMonth(month: YearMonth)',ENGINE)
        self.assertEqual([month for month in range(1,13) if (date(2027 if month != 2 else 2028,month,28).replace(day=28).month == month)],list(range(1,13)))
        # Leap-year February has a 29th day; 31st has no February occurrence.
        import calendar
        self.assertEqual(calendar.monthrange(2028,2)[1],29)
        self.assertNotEqual(calendar.monthrange(2028,2)[1],31)

    def test_status_sync_and_delete_unlinks_instead_of_deleting_calendar_plan(self):
        self.assertIn('UPDATE calendar_entries SET status=?, updated_at=? WHERE linked_task_id=?',ENGINE)
        self.assertIn('UPDATE calendar_entries SET linked_task_id=NULL WHERE linked_task_id=?',ENGINE)
        self.assertIn('fun linkCalendar(entryId: Long, block: Int)',ENGINE)
        self.assertIn('calendar_unique_task',ENGINE)
        self.assertIn('if (isCalendarLinked(task.id) && nextDay != day)',ENGINE)
        self.assertIn('result(this, taskId, entry.day, "PENDING")',ENGINE)
        self.assertIn('fun deleteCalendarOccurrence(entryId: Long)',ENGINE)
        self.assertIn('fun stopCalendarSeries(entryId: Long)',ENGINE)

    def test_move_changes_latest_monthly_anchor_but_preserves_old_outcomes(self):
        self.assertIn('fun moveCalendar(entryId: Long, destination: LocalDate)',ENGINE)
        self.assertIn('UPDATE calendar_plans SET anchor_day=?,start_day=?,updated_at=? WHERE id=?',ENGINE)
        self.assertIn('if (entry.status == "PENDING")',ENGINE)
        self.assertIn('"CALENDAR_MOVED"',ENGINE)
        self.assertIn('delete("day_results", "task_id=? AND day=? AND outcome=',ENGINE)
        self.assertIn('if (entry.monthlyPinned)',ENGINE)

    def test_backup_all_four_schemas(self):
        self.assertIn('require(schema in 1..4)',ENGINE)
        self.assertIn('backupColumnsV1',ENGINE)
        self.assertIn('backupColumnsV2',ENGINE)
        self.assertIn('backupColumnsV3',ENGINE)
        self.assertIn('"calendar_plans" to listOf',ENGINE)
        self.assertIn('"calendar_entries" to listOf',ENGINE)
        self.assertIn('"calendar_exclusions" to listOf',ENGINE)
        self.assertIn('"calendar_alerts" to listOf',ENGINE)
        self.assertIn('.put("schema", 4)',ENGINE)

    def test_calendar_user_interface_and_monitoring_both_kept(self):
        for token in ('private fun showCalendar(month: YearMonth',
                      'private fun showCalendarDay(day: LocalDate)',
                      'private fun showCalendarMove(entry: CalendarEntry',
                      'private fun showCalendarBlockPicker(entry: CalendarEntry)',
                      'private fun showMonitoringCalendar(',
                      'showCalendarEditor(day, entry)', 'Kalendar bajarilishi:',
                      'calendarTodayPending()', 'Baribir qo‘shish'):
            self.assertIn(token,UI)
        self.assertIn('store.addCalendar(title, day, pinned = true)',UI)
        self.assertIn('store.linkCalendar(entry.id, block.index)',UI)
        self.assertIn('store.toggleCalendarPin(entry.id)',UI)
        self.assertIn('store.moveCalendar(entry.id, day)',UI)
        self.assertIn('store.calendarSummary(entries)',UI)

    def test_single_calendar_alert_and_daily_recovery(self):
        self.assertIn('calendarAlertDelivered(today)',ALARMS)
        self.assertIn('claimCalendarAlert(LocalDate.now())',ALARMS)
        self.assertIn('TasksCalendarAlerts.schedule(context)',ALARMS)
        self.assertIn('TasksNotifications.showCalendarSummary(context, count)',ALARMS)
        self.assertIn('NotificationCompat.Builder(context, CALENDAR_CHANNEL)',NOTIFY)
        self.assertIn('"tasks_calendar_daily_v1"',NOTIFY)
        self.assertIn('setSilent(true)',NOTIFY)
        self.assertIn('OPEN_CALENDAR',UI)

    def test_cumulative_patch_v4_and_manifest(self):
        from test_phase1 import MANIFEST,GRADLE
        with tempfile.TemporaryDirectory() as d:
            up=Path(d)
            for filename,content in [('uhabits-android/src/main/AndroidManifest.xml',MANIFEST),('uhabits-android/build.gradle.kts',GRADLE)]:
                dest=up/filename;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(content)
            p=subprocess.run([sys.executable,str(ROOT/'tools/apply_phase4.py'),str(up)],capture_output=True,text=True)
            self.assertEqual(p.returncode,0,p.stderr)
            root=ET.parse(up/'uhabits-android/src/main/AndroidManifest.xml').getroot()
            ns='{http://schemas.android.com/apk/res/android}'
            names=[x.attrib.get(ns+'name') for x in root.findall('application/receiver')]
            self.assertIn('.activities.tasks.TasksCalendarReceiver',names)
            gradle=(up/'uhabits-android/build.gradle.kts').read_text()
            self.assertIn('versionCode = 20305',gradle)
            self.assertIn('versionName = "2.0.0-stage4"',gradle)
            self.assertIn('applicationId = "org.isoron.uhabits.tasks.preview"',gradle)
            self.assertEqual(len(list((up/'uhabits-android/src/main/java/org/isoron/uhabits/activities/tasks').glob('*.kt'))),7)

if __name__=='__main__':unittest.main()
