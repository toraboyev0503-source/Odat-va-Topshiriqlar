"""Structural and database smoke checks; NOT an Android APK build/test."""
from pathlib import Path
import re
import sqlite3
import subprocess
import sys
import tempfile
import unittest
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
ENGINE = (ROOT/'patch/kotlin/TaskEngine.kt').read_text()
UI = (ROOT/'patch/kotlin/TasksActivity.kt').read_text()
SCRIPT = ROOT/'tools/apply_phase4.py'

# Fixture corresponding to v1: old tasks + completed results are preserved in place.
OLD_TASK_SQL = """CREATE TABLE tasks(
    id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL,
    plan_day TEXT, block_index INTEGER, status TEXT NOT NULL DEFAULT 'PENDING',
    archive_kind TEXT, position INTEGER NOT NULL DEFAULT 0,
    carried_from TEXT, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL
)"""

class Stage2Tests(unittest.TestCase):
    def test_sqlite_migration_keeps_original_rows_and_prevents_duplicates(self):
        db = sqlite3.connect(':memory:')
        db.execute(OLD_TASK_SQL)
        db.execute('CREATE TABLE day_results(task_id INTEGER NOT NULL, day TEXT NOT NULL, outcome TEXT NOT NULL, PRIMARY KEY(task_id,day))')
        db.execute("INSERT INTO tasks(id,title,plan_day,block_index,status,created_at,updated_at) VALUES(7,'Kitob', '2026-11-23',2,'DONE',1,1)")
        db.execute("INSERT INTO day_results VALUES(7,'2026-11-23','DONE')")
        self.assertIn('if (oldVersion < 2)',ENGINE)
        db.execute('ALTER TABLE tasks ADD COLUMN template_id INTEGER')
        table_sql = re.search(r'CREATE TABLE IF NOT EXISTS task_pin_templates\s*\(.*?\)"""',ENGINE,re.S)
        self.assertIsNotNone(table_sql)
        db.execute(table_sql.group(0).removesuffix('"""'))
        index_sql = re.search(r'CREATE UNIQUE INDEX IF NOT EXISTS one_pinned_task_per_day\s+ON tasks\(template_id, plan_day\).*?"""',ENGINE,re.S)
        self.assertIsNotNone(index_sql)
        db.execute(index_sql.group(0).removesuffix('"""'))
        self.assertEqual(db.execute('SELECT title,status FROM tasks WHERE id=7').fetchone(),('Kitob','DONE'))
        self.assertEqual(db.execute('SELECT outcome FROM day_results WHERE task_id=7').fetchone(),('DONE',))
        db.execute("INSERT INTO task_pin_templates(id,title,home_block,start_day,enabled,created_at) VALUES(101,'Kitob',2,'2026-11-23',1,1)")
        db.execute("UPDATE tasks SET template_id=101 WHERE id=7")
        with self.assertRaises(sqlite3.IntegrityError):
            db.execute("INSERT INTO tasks(title,plan_day,block_index,status,template_id,created_at,updated_at) VALUES('Kitob','2026-11-23',2,'PENDING',101,1,1)")
        db.execute("INSERT INTO tasks(title,plan_day,block_index,status,template_id,created_at,updated_at) VALUES('Kitob','2026-11-24',2,'PENDING',101,1,1)")
        self.assertEqual(db.execute('SELECT count(*) FROM tasks WHERE template_id=101').fetchone()[0],2)
        db.close()

    def test_manual_time_slots_and_gaps_preserved(self):
        self.assertIn('val original = store.blocks() // actual saved values',UI)
        self.assertIn('TimePickerDialog(this',UI)
        self.assertIn('val starts = original.map { it.start }',UI)
        self.assertIn('val ends = original.map { it.end }',UI)
        self.assertIn('a.end <= b.start',ENGINE)
        self.assertIn('updateWindowPreservingCustom',ENGINE)
        self.assertIn('if (!initial && !forceEqual && n == existing.size && from == existing.first().start',UI)
        self.assertIn('Avtomatik teng taqsimlash (tasdiq bilan)',UI)

    def test_daily_template_and_archive_rules_present(self):
        for token in ('CREATE TABLE IF NOT EXISTS task_pin_templates',
                      'one_pinned_task_per_day','fun togglePin(task: TaskItem)',
                      'fun ensurePinned(day: LocalDate)',
                      'if (day != today || nextDay != today) return@forEach',
                      'template_id IS NULL OR plan_day IS NULL OR plan_day>=?',
                      'fun isPinned(task: TaskItem)'):
            self.assertIn(token,ENGINE)
        self.assertIn('if (isPinned(task)) {',ENGINE)
        self.assertIn('task_pin_templates SET enabled=0',ENGINE)
        self.assertIn('"FAILED"',ENGINE)
        self.assertIn('backupColumnsV1',ENGINE)
        self.assertIn('root.optInt("schema")',ENGINE)
        self.assertIn('"task_pin_templates" to listOf',ENGINE)

    def test_live_block_still_in_strip_and_countdown_handles_gap(self):
        self.assertIn('blocks.forEachIndexed { index, item ->',UI)
        self.assertIn('index == activeIndex',UI)
        self.assertIn('index == focusedIndex',UI)
        self.assertIn('selectedDay == liveDay && focusedIndex == liveIndex && activeIndex == null',UI)
        self.assertIn('Blok boshlanishigacha qolgan vaqt',UI)
        self.assertIn('renderedToday: LocalDate', UI)
        self.assertIn('selectedDay = newToday', UI)
        self.assertIn('liveDay > selectedDay -> blocks.lastIndex', UI)
        alarms=(ROOT/'patch/kotlin/TasksAlarms.kt').read_text()
        self.assertIn('store.blocks().map { it.start }', alarms)
        self.assertIn('R.drawable.tasks_pin',UI)
        ET.parse(ROOT/'patch/res/drawable/tasks_pin.xml')

    def test_cumulative_patch_starts_from_upstream(self):
        from test_phase1 import MANIFEST, GRADLE
        with tempfile.TemporaryDirectory() as d:
            up=Path(d)
            files={
                'uhabits-android/src/main/AndroidManifest.xml':MANIFEST,
                'uhabits-android/build.gradle.kts':GRADLE,
            }
            for rel, contents in files.items():
                target=up/rel
                target.parent.mkdir(parents=True,exist_ok=True)
                target.write_text(contents)
            run=subprocess.run([sys.executable,str(SCRIPT),str(up)],capture_output=True,text=True)
            self.assertEqual(run.returncode,0,run.stderr)
            gradle=(up/'uhabits-android/build.gradle.kts').read_text()
            self.assertIn('versionCode = 20305',gradle)
            self.assertIn('versionName = "2.0.0-stage4"',gradle)
            self.assertIn('org.isoron.uhabits.tasks.preview',gradle)
            source=(up/'uhabits-android/src/main/java/org/isoron/uhabits/activities/tasks/TaskEngine.kt').read_text()
            self.assertIn('ensurePinned',source)
            self.assertIn('template_id',source)
            self.assertTrue((up/'uhabits-android/src/main/res/drawable/tasks_pin.xml').exists())
            run2=subprocess.run([sys.executable,str(SCRIPT),str(up)],capture_output=True,text=True)
            self.assertNotEqual(run2.returncode,0)

if __name__=='__main__': unittest.main()
