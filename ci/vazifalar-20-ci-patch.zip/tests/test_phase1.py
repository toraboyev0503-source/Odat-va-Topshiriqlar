import pathlib
import tempfile
import unittest
import subprocess
import sys
import struct
import wave
import xml.etree.ElementTree as ET

ROOT = pathlib.Path(__file__).resolve().parents[1]
PATCH = ROOT / 'tools/apply_phase4.py'

MANIFEST = '''<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <application android:icon="@mipmap/ic_launcher" android:label="@string/main_activity_title" android:theme="@style/AppBaseTheme">
<activity android:name=".activities.habits.list.ListHabitsActivity"
            android:exported="true" android:label="@string/main_activity_title" />
        <activity-alias
            android:name=".MainActivity"
            android:exported="true"
            android:label="@string/main_activity_title"
            android:launchMode="singleTop"
            android:targetActivity=".activities.habits.list.ListHabitsActivity">
    <intent-filter><action android:name="android.intent.action.MAIN" /></intent-filter>
        </activity-alias>
<provider android:authorities="org.isoron.uhabits" />
    </application>
</manifest>'''
GRADLE = '''android {
 defaultConfig {
        versionCode = 20301
        versionName = "2.3.1"
        applicationId = "org.isoron.uhabits"
 }
}'''

class Phase1Tests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.up = pathlib.Path(self.temp.name)
        files = {
            'uhabits-android/src/main/AndroidManifest.xml': MANIFEST,
            'uhabits-android/build.gradle.kts': GRADLE,
        }
        for name, data in files.items():
            path = self.up / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(data)

    def tearDown(self): self.temp.cleanup()

    def test_tasks_only_launcher_and_data_identity(self):
        run = subprocess.run([sys.executable, str(PATCH), str(self.up)], capture_output=True, text=True)
        self.assertEqual(run.returncode, 0, run.stderr)
        manifest = (self.up/'uhabits-android/src/main/AndroidManifest.xml').read_text()
        ET.fromstring(manifest)
        alias = manifest.split('<activity-alias',1)[1].split('</activity-alias>',1)[0]
        self.assertIn('android:targetActivity=".activities.tasks.TasksActivity"',alias)
        self.assertNotIn('android:targetActivity=".activities.habits.list.ListHabitsActivity"',alias)
        self.assertIn('android:icon="@mipmap/tasks_launcher"',manifest)
        self.assertIn('android:theme="@style/Theme.Tasks"',manifest)
        gradle = (self.up/'uhabits-android/build.gradle.kts').read_text()
        self.assertIn('applicationId = "org.isoron.uhabits.tasks.preview"', gradle)
        self.assertIn('versionCode = 20305', gradle)
        self.assertTrue((self.up/'uhabits-android/src/main/res/drawable/tasks_splash_logo.png').is_file())
        self.assertFalse((self.up/'uhabits-android/src/main/java/org/isoron/uhabits/activities/tasks/TasksBridge.kt').exists())
        repeated = subprocess.run([sys.executable, str(PATCH), str(self.up)], capture_output=True)
        self.assertNotEqual(repeated.returncode, 0)

    def test_res_xml_and_icon_density(self):
        for x in (ROOT/'patch/res').rglob('*.xml'):
            ET.parse(x)
        for d in ('mdpi','hdpi','xhdpi','xxhdpi','xxxhdpi'):
            self.assertTrue((ROOT/f'patch/res/mipmap-{d}/tasks_launcher.png').exists())

    def test_no_habits_navigation_in_task_activity(self):
        kotlin = (ROOT/'patch/kotlin/TasksActivity.kt').read_text()
        self.assertNotIn('bottomBar(',kotlin)
        self.assertNotIn('wrapHabits(',kotlin)
        self.assertIn('taskViewport, LinearLayout.LayoutParams(-1, 0, 1f)',kotlin)
        self.assertIn('playCompletionAnimationSafely()',kotlin)
        self.assertIn('store.exportBackup()',kotlin)
        self.assertIn('store.importBackup(data)',kotlin)

    def test_three_tone_audio_unchanged(self):
        with wave.open(str(ROOT/'patch/res/raw/tasks_three_signals.wav'),'rb') as w:
            samples = struct.unpack('<'+'h'*w.getnframes(),w.readframes(w.getnframes()))
            fs=w.getframerate()
        groups=0; prior=False
        for k in range(0,len(samples),fs//100):
            segment=samples[k:k+fs//100]
            on=bool(segment) and max(map(abs,segment))>600
            if on and not prior: groups+=1
            prior=on
        self.assertEqual(groups,3)

if __name__=='__main__': unittest.main()
