"""Phase 3 checks. No APK compilation is performed in this stage."""
from pathlib import Path
import re
import sqlite3
import subprocess
import sys
import tempfile
import unittest
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
CODE = ROOT / 'patch/kotlin'
ENGINE = (CODE / 'TaskEngine.kt').read_text()
UI = (CODE / 'TasksActivity.kt').read_text()
ALARMS = (CODE / 'TasksAlarms.kt').read_text()
NOTIFY = (CODE / 'TasksNotifications.kt').read_text()
SOUNDS = (CODE / 'TasksSignalService.kt').read_text()
TONES = (CODE / 'TasksTones.kt').read_text()

class Stage3(unittest.TestCase):
    def test_migration_from_v2_keeps_tasks_and_pins(self):
        db = sqlite3.connect(':memory:')
        db.executescript('''CREATE TABLE tasks(id INTEGER PRIMARY KEY, title TEXT NOT NULL,
            plan_day TEXT, block_index INTEGER, status TEXT NOT NULL DEFAULT 'PENDING',
            archive_kind TEXT, position INTEGER NOT NULL DEFAULT 0, carried_from TEXT,
            template_id INTEGER, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL);
            CREATE TABLE task_pin_templates(id INTEGER PRIMARY KEY,title TEXT NOT NULL,
            home_block INTEGER NOT NULL,start_day TEXT NOT NULL,enabled INTEGER NOT NULL,
            created_at INTEGER NOT NULL);
            INSERT INTO task_pin_templates VALUES(14,'Kitob',2,'2026-11-23',1,1);
            INSERT INTO tasks VALUES(8,'Kitob','2026-11-23',2,'DONE',NULL,1,NULL,14,1,1);
        ''')
        self.assertIn('if (oldVersion < 3)',ENGINE)
        for sql in ('ALTER TABLE tasks ADD COLUMN reminder_at INTEGER',
                    'ALTER TABLE tasks ADD COLUMN reminder_delivered_at INTEGER',
                    'ALTER TABLE task_pin_templates ADD COLUMN reminder_minute INTEGER',
                    'CREATE INDEX IF NOT EXISTS task_reminders_due ON tasks(reminder_at, reminder_delivered_at)'):
            self.assertIn(sql, ENGINE)
            db.execute(sql)
        self.assertEqual(db.execute('SELECT title,status,template_id FROM tasks WHERE id=8').fetchone(),
                         ('Kitob','DONE',14))
        db.execute('UPDATE task_pin_templates SET reminder_minute=510 WHERE id=14')
        self.assertEqual(db.execute('SELECT reminder_minute FROM task_pin_templates WHERE id=14').fetchone(),(510,))
        db.close()

    def test_migration_from_v1_has_no_duplicate_pin_column(self):
        self.assertIn('if (oldVersion >= 2)', ENGINE)
        self.assertIn('reminder_minute INTEGER', ENGINE)
        self.assertIn('CREATE TABLE IF NOT EXISTS task_pin_templates', ENGINE)
        self.assertIn('if (oldVersion < 2)',ENGINE)

    def test_pin_reminder_is_recurred_per_day_once(self):
        for token in ('templateReminderMinute(this@transaction, templateId)',
                      'put("reminder_at", reminderTimestamp(day, minute))',
                      'one_pinned_task_per_day',
                      'if (newStatus != "PENDING") putNull("reminder_at")',
                      'fun setReminder(taskId: Long, minute: Int)',
                      'fun clearReminder(taskId: Long)'):
            self.assertIn(token,ENGINE)

    def test_notification_buttons_are_real_immutable_broadcast_actions(self):
        for flag in ('REMINDER_DONE','REMINDER_FAILED','REMINDER_SKIP'):
            self.assertIn(flag,ALARMS)
        for label in ('✓ Bajarildi','× Bajarilmadi','O‘tkazib yuborish'):
            self.assertIn(label,NOTIFY)
        self.assertIn('PendingIntent.FLAG_IMMUTABLE', NOTIFY)
        self.assertIn('data = Uri.parse("tasks-action://$taskId/$actionName")', NOTIFY)
        self.assertIn('store.setStatus(task, "DONE")', ALARMS)
        self.assertIn('store.setStatus(task, "FAILED")', ALARMS)
        self.assertIn('store.recordReminderSkipped(task.id)', ALARMS)
        self.assertIn('manager(context).cancel("task_reminder_$taskId", REMINDER_ID)', NOTIFY)
        self.assertIn('reminder_delivered_at IS NULL', ENGINE)

    def test_three_alerts_one_notification_and_tone_picker(self):
        self.assertIn('startForeground(6805, TasksNotifications.blockNotification(this))', SOUNDS)
        self.assertIn('if (bundled) 1 else 3', SOUNDS)
        self.assertIn('sequence++', SOUNDS)
        self.assertIn('1700L', SOUNDS)
        self.assertIn('ACTION_RINGTONE_PICKER', UI)
        self.assertIn('TasksTones.save(this, kind, uri)', UI)
        self.assertIn('val channelId = "tasks_reminder_$suffix"', NOTIFY)
        self.assertIn('startForegroundService', NOTIFY)
        self.assertIn('tasks_three_signals', TONES)
        self.assertIn('scheduleAlarm', ALARMS)

    def test_patch_manifest_services_and_permissions(self):
        from test_phase1 import MANIFEST, GRADLE
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)
            for relative, data in {
                'uhabits-android/src/main/AndroidManifest.xml':MANIFEST,
                'uhabits-android/build.gradle.kts':GRADLE,
            }.items():
                target = path / relative
                target.parent.mkdir(parents=True,exist_ok=True)
                target.write_text(data)
            r = subprocess.run([sys.executable,str(ROOT/'tools/apply_phase4.py'),str(path)],
                               capture_output=True,text=True)
            self.assertEqual(r.returncode,0,r.stderr)
            manifest=path/'uhabits-android/src/main/AndroidManifest.xml'
            tree=ET.parse(manifest)
            android='{http://schemas.android.com/apk/res/android}'
            application=tree.getroot().find('application')
            service=application.find("service[@%sname='.activities.tasks.TasksSignalService']" % android)
            self.assertIsNotNone(service)
            self.assertEqual(service.get(android+'foregroundServiceType'),'mediaPlayback')
            receivers=[v.get(android+'name') for v in application.findall('receiver')]
            self.assertIn('.activities.tasks.TasksReminderReceiver',receivers)
            self.assertIn('.activities.tasks.TasksReminderActionReceiver',receivers)
            permissions=[e.get(android+'name') for e in tree.getroot().findall('uses-permission')]
            self.assertIn('android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK',permissions)
            output=(path/'uhabits-android/build.gradle.kts').read_text()
            self.assertIn('versionCode = 20305',output)
            self.assertIn('versionName = "2.0.0-stage4"',output)
            files=list((path/'uhabits-android/src/main/java/org/isoron/uhabits/activities/tasks').glob('*.kt'))
            self.assertEqual(len(files),7)
            r2=subprocess.run([sys.executable,str(ROOT/'tools/apply_phase4.py'),str(path)],
                              capture_output=True,text=True)
            self.assertNotEqual(r2.returncode,0)

    def test_backups_keep_all_legacy_schemas(self):
        self.assertIn('require(schema in 1..4)',ENGINE)
        self.assertIn('backupColumnsV1',ENGINE)
        self.assertIn('backupColumnsV2',ENGINE)
        self.assertIn('"reminder_at", "reminder_delivered_at"',ENGINE)
        self.assertIn('"reminder_minute"',ENGINE)
        self.assertIn('TasksReminders.schedule(this)',UI)

if __name__ == '__main__':unittest.main()
