package com.memora.app.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.memora.app.data.local.NoteEntity
import com.memora.app.data.local.NoteType
import com.memora.app.i18n.L
import com.memora.app.i18n.S
import com.memora.app.prefs.AppLanguage
import com.memora.app.ui.components.MemoraTopBar
import com.memora.app.ui.components.NoteCard

@Composable
fun NotesScreen(
    type: NoteType,
    notes: List<NoteEntity>,
    language: AppLanguage,
    canWrite: Boolean,
    onBack: () -> Unit,
    onNew: () -> Unit,
    onWriteRequired: () -> Unit,
    onOpen: (String) -> Unit,
    onSearch: () -> Unit,
    onDelete: (List<String>) -> Unit
) {
    var selected by remember { mutableStateOf(setOf<String>()) }
    var confirmDelete by remember { mutableStateOf(false) }

    BackHandler {
        when {
            confirmDelete -> confirmDelete = false
            selected.isNotEmpty() -> selected = emptySet()
            else -> onBack()
        }
    }

    Column(Modifier.fillMaxSize()) {
        if (selected.isEmpty()) {
            MemoraTopBar(
                title = L.t(language, if (type == NoteType.SHORT) S.SHORT_NOTES else S.LONG_NOTES),
                navigation = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Rounded.ArrowBack, contentDescription = null)
                    }
                },
                actions = {
                    IconButton(onClick = onSearch) {
                        Icon(Icons.Rounded.Search, contentDescription = L.t(language, S.SEARCH))
                    }
                }
            )
        } else {
            MemoraTopBar(
                title = selected.size.toString(),
                navigation = {
                    IconButton(onClick = { selected = emptySet() }) {
                        Icon(Icons.Rounded.Close, contentDescription = null)
                    }
                },
                actions = {
                    IconButton(onClick = { if (canWrite) confirmDelete = true else onWriteRequired() }) {
                        Icon(
                            Icons.Rounded.DeleteOutline,
                            contentDescription = L.t(language, S.DELETE),
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            )
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(
                start = 20.dp, end = 20.dp, top = 8.dp, bottom = 32.dp
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item("new") {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(onClick = { if (canWrite) onNew() else onWriteRequired() }),
                    shape = RoundedCornerShape(24.dp),
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
                ) {
                    Row(
                        Modifier.padding(horizontal = 20.dp, vertical = 18.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Rounded.Add, contentDescription = null)
                        Text(
                            L.t(language, S.NEW_NOTE),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(start = 12.dp)
                        )
                    }
                }
            }

            if (notes.isEmpty()) {
                item("empty") {
                    Text(
                        L.t(language, S.NO_NOTES),
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            items(notes, key = { it.id }) { note ->
                val isSelected = note.id in selected
                NoteCard(
                    note = note,
                    displayTitle = note.title.ifBlank { L.t(language, S.UNTITLED) },
                    language = language,
                    selected = isSelected,
                    onClick = {
                        if (selected.isNotEmpty()) {
                            selected = if (isSelected) selected - note.id else selected + note.id
                        } else {
                            onOpen(note.id)
                        }
                    },
                    onLongClick = if (canWrite) ({
                        selected = if (isSelected) selected - note.id else selected + note.id
                    }) else ({ onWriteRequired() })
                )
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(L.t(language, S.DELETE_CONFIRM_TITLE)) },
            text = { Text(L.t(language, S.DELETE_CONFIRM_TEXT)) },
            confirmButton = {
                TextButton(onClick = {
                    onDelete(selected.toList())
                    selected = emptySet()
                    confirmDelete = false
                }) { Text(L.t(language, S.CONFIRM)) }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) {
                    Text(L.t(language, S.CANCEL))
                }
            }
        )
    }
}
