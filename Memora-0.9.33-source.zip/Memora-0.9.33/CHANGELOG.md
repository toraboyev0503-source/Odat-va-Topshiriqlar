# Memora 0.9.33 — Focus editor redesign

- Editor title now belongs to the same scrollable document flow as the note body, matching the approved Obsidian-like interaction.
- Image, audio, and mood actions are hidden behind one compact tools button above the keyboard.
- Word count and note type are combined into a small unobtrusive status pill.
- Autosave status only appears when useful; the persistent bottom type label was removed.
- Active paragraph bring-into-view behavior is retained and editor scroll/cursor position is restored when reopening a note.
- Current writing-area side margins are preserved.
- Time Trace and Notes archive changes from 0.9.32 remain intact.
- Topilma card canonical visual renderer/spec was not changed.
- Version bumped to `0.9.33` / code `53`.
