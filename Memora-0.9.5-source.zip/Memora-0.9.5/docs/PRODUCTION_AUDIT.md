# Memora 0.9.5 production audit

Audit date: 2026-09-03. Baseline archive SHA-256:
`5A6E36390583EE9099C0613D8B7E38EE1F34AAB17330979709A7A3D114DBE36D`
(matched the checksum supplied with Memora 0.5.7).

## Release gate results

| Area | Result |
|---|---|
| SDK | `compileSdk=36`, `targetSdk=36`; compliant with the 2026 Play target requirement |
| Minimum Android | `minSdk=26` retained as the best compatibility/security balance for this codebase |
| Version | `0.9.5` / code `25` |
| App identity | In-app/launcher `Memora`; Play listing title documented as `Memora – Private Journal` |
| Monetization | One Play subscription, four base-plan IDs, Play offer-token selection |
| Expiry | Repository-level write guard plus UI gates; reading/search/media/statistics/export remain open |
| Offline | AES-GCM cache using a non-exportable Android Keystore key; max 7 days and never beyond Play expiry |
| Content privacy | No journal content enters billing verification; Android backup disabled; cleartext disabled |
| Tracking | No advertising, analytics or crash-reporting SDK configured |
| Signing | Debug and release separated; debug uses the bundled test-only stable key, release credentials remain environment-only |
| CI | Debug workflow runs Android unit tests, lint, APK build and debug-certificate verification; Play release AAB workflow is configured in the next release-infrastructure step |
| Paragraph layout | Centralized 60% gap retained and unit tested |

## Stage 3 Play-policy hardening — 2026-09-06

- Google Play subscription transparency audit found one release-policy risk: the plan cards showed
  localized price/period and the free-trial duration, but did not explicitly state automatic renewal
  and the post-trial charge/cancellation terms on the selection card itself. Stage 3 fixes this in all
  13 UI languages and adds a localization regression test.
- The app already exposes an in-app **Manage in Google Play** action that opens the Google Play
  subscription-management page.
- `targetSdk=36` satisfies the Google Play requirement effective 2026-08-31 for new mobile apps and
  updates.
- `SCHEDULE_EXACT_ALARM` is retained for user-selected writing reminders; the restricted
  auto-granted `USE_EXACT_ALARM` permission is not declared.
- Current new-personal-account production-access rule remains 12 closed-test testers opted in
  continuously for 14 days.

## 0.9.5 final bug-fix audit

- Custom-title editing now uses a dedicated localized Save action in all 13 languages; destructive
  delete confirmation remains isolated to delete flows.
- The GitHub debug workflow is version-agnostic and validates the stable test certificate after build,
  protecting both future source-ZIP selection and in-place debug APK updates.

- Gallery import now uses a persistable document URI; gallery and camera images are staged,
  byte-bounded and decoded off the UI thread with tighter RGB_565 sampling. Oversized/corrupt
  input is rejected with a user-visible failure instead of taking down the process.
- Display image decoding also runs off the UI thread and uses a bounded sampled bitmap; Compose
  no longer manually recycles a bitmap that can still be referenced by a frame.
- Android's mandatory platform splash uses a transparent icon and exits immediately into the approved
  full-screen Memora artwork; the Compose artwork remains edge-to-edge and the gesture/navigation
  region uses the sampled lower-edge artwork color.
- Structural Enter accepts one- or two-newline OEM IME commits as one paragraph break, consumes
  hardware Enter directly, and guards the cross-field focus hand-off so numbered-list continuation
  is created once even after terminal punctuation without a trailing space.
- Route-level Back is centralized to one pop; editor, note-selection and statistics sub-stages keep
  their own single-level Back behavior.
- The Compose floating text-selection toolbar is suppressed in the editor; selection remains enabled
  so OEM/keyboard-provided actions can remain independent.

Verification in this packaging environment: backend contract tests pass (3/3), resource XML parses
cleanly, and the pure Kotlin paragraph/image-sampling helper checks pass. A full Android Gradle build
could not be run here because the Gradle distribution is not available offline; GitHub Actions is the
release gate for `testDebugUnitTest`, `lintRelease`, signing and AAB generation.

## Why minSdk 26 remains optimal

The application already relies on Android 8-era platform behavior and `java.time`,
private scoped app storage, notification channels and modern security primitives.
Lowering the minimum would require desugaring plus additional legacy behavior and
test surface without helping the Play target requirement. Raising it would remove
working Android 8/9 devices without a current technical need. API 26 is therefore
retained for this RC.

## Security hardening performed

- Purchase entitlement is granted only after a `PURCHASED` result is verified by
  Android Publisher API; `PENDING` never grants write access.
- The app sends only package name, product ID and purchase token to the verifier.
- Backup manifests, legacy JSON and media entries have explicit limits.
- Backup paths are normalized, whitelisted to `media/images` or `media/audio`, and
  canonicalized beneath private app storage; missing media is dropped on import.
- Gallery images are bounds-read and sampled before decode to reduce memory-exhaustion risk.
- Automatic notification permission prompting on first launch was removed; reminder
  creation remains the contextual permission point.
- Release builds require HTTPS verification, signing variables, minification and
  resource shrinking.
- The official Gradle wrapper uses the published Gradle 8.13 SHA-256 checksum.

## Residual release-owner actions

These cannot be embedded in source: create the Play developer/app record, configure
the product/base plans/offers and prices, deploy the verifier, grant its service
account Play access, create and protect the upload key, supply GitHub secrets, host
the privacy policy, complete Data safety/content-rating forms, and execute Play
license/internal/closed testing. See `PLAY_CONSOLE_SETUP.md`.

The minimal verifier intentionally has no journal database and no RTDN subscriber.
The app rechecks Play at foreground and uses the bounded offline cache. For a later
multi-device/account backend, add RTDN and durable token state without expanding the
journal-content boundary.
