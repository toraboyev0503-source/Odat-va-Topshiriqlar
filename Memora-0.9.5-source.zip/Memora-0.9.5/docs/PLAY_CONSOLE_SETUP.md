# Memora 0.9.5 — Play Console sozlash yo‘riqnomasi

## 1. Ilova va Store listing

1. Play Console’da yangi app yarating: package/application ID `com.memora.app`.
2. App nomini **Memora – Private Journal** deb kiriting. Bu faqat Store listing;
   telefon ichida nom **Memora** bo‘lib qoladi.
3. Default language sifatida English’ni tanlang. Kerakli listing tarjimalarini
   keyin qo‘shish mumkin; ilovaning o‘zida 13 til va qurilma tilini avtomatik olish bor.
4. App category, contact email, icon, screenshots, feature graphic, short/full
   description, content rating, target audience va privacy-policy URL’ni to‘ldiring.

## 2. Subscription katalogi

Monetize → Products → Subscriptions’da bitta subscription yarating:

- Product ID: `memora_premium` (keyin o‘zgarmaydi)
- Name: `Memora Premium`

Quyidagi auto-renewing base planlarni yarating va aktiv qiling:

| Base plan ID | Billing period | Boshlang‘ich AQSh narxi |
|---|---:|---:|
| `monthly` | 1 month (`P1M`) | $2.00 |
| `quarterly` | 3 months (`P3M`) | $5.49 |
| `semiannual` | 6 months (`P6M`) | $9.99 |
| `annual` | 1 year (`P1Y`) | $17.99 |

Play taklif qilgan mahalliy valyuta narxlarini barcha sotiladigan hududlar uchun
ko‘rib chiqing. Grace period va account hold’ni Play tavsiya qilgan holatda yoqing.

Har bir base plan ostida alohida offer yarating:

| Base plan | Tavsiya offer ID |
|---|---|
| `monthly` | `trial-monthly` |
| `quarterly` | `trial-quarterly` |
| `semiannual` | `trial-semiannual` |
| `annual` | `trial-annual` |

Har bir offer uchun:

1. Tag: `memora-free-trial`.
2. Eligibility: **New customer acquisition → Never had any subscription in this app**.
3. Pricing phase: **Free trial**, duration **1 month (`P1M`)**, bir marta.
4. Trial tugagach shu offer tegishli base plan narxida avtomatik davom etishini tekshiring.
5. Offer va base planni aktiv qiling.

Eligibility’ni ilovadagi lokal taymer emas, Google Play account tarixi belgilaydi;
shu sabab appni o‘chirib-qayta o‘rnatish trialni qayta bermaydi. Boshqa Google account
Play tomonidan boshqa mijoz sifatida ko‘rilishi mumkin.

## 3. Billing verification backend

1. Google Cloud’da **Google Play Android Developer API** va **Cloud Run**’ni yoqing.
2. Alohida runtime service account yarating; JSON key yuklab olmang.
3. Play Console → Users and permissions/API access orqali Cloud loyihani ulang va
   service account’ga faqat `com.memora.app` bo‘yicha subscription/order holatini
   ko‘rish uchun zarur eng kichik ruxsat bering.
4. Source ichidagi `backend/` katalogini Cloud Run’ga deploy qiling; runtime service
   account sifatida yuqoridagi account’ni tanlang. HTTPS Cloud Run URL ishlating.
5. Endpoint oxiri quyidagicha bo‘lsin:
   `/v1/google-play/subscriptions/verify`.
6. Health check: `GET /healthz` → `{"ok":true}`.

Backend faqat `packageName`, `productId`, `purchaseToken` qabul qiladi. Kundalik
matni, sarlavha, rasm, audio, backup, reklama ID yoki qurilma ID yuborilmaydi.

## 4. Play App Signing va GitHub

1. Play App Signing’ni yoqing va yangi upload key yarating; asl fayl/parollarni
   password manager hamda alohida xavfsiz backupda saqlang.
2. Keystore’ni Base64 qiling va GitHub Actions secretlariga kiriting:
   - `MEMORA_UPLOAD_KEYSTORE_BASE64`
   - `MEMORA_KEYSTORE_PASSWORD`
   - `MEMORA_KEY_ALIAS`
   - `MEMORA_KEY_PASSWORD`
3. GitHub repository **Variable** yarating:
   - `MEMORA_BILLING_VERIFICATION_URL=https://.../v1/google-play/subscriptions/verify`
4. `.github/workflows/main.yml` test → lint → signed AAB tartibida ishlaydi.
   `workflow_dispatch` bilan yoki `v0.9.5` tag push qilib ishga tushiring.
5. Artifact ichidagi `app-release.aab`ni avval Internal testing’ga yuklang.

## 5. Billing va entitlement test matritsasi

Play Console license testers va test payment methodlari bilan tekshiring:

- yangi account’da har to‘rt plan narxi va 1 oylik trial ko‘rinadi;
- oldin subscription olgan account’da trial takror ko‘rinmaydi;
- successful, canceled, pending-completed va pending-canceled oqimlari;
- restore/foreground refresh;
- internet uzilganda oxirgi muvaffaqiyatli tekshiruvdan ko‘pi bilan 7 kun yozish;
- Play expiry yaqinroq bo‘lsa, 7 kunni kutmasdan read-only;
- cache muddati yoki obuna tugaganda create/edit/delete/import yopiq;
- read/search/statistics/image/audio/HTML/Word/Memora backup export ochiq;
- internet qaytgach faol obuna qayta tiklanadi.

Yangi personal developer account 2023-11-13 dan keyin ochilgan bo‘lsa, production
access uchun kamida 12 tester closed test’ga uzluksiz 14 kun opt-in holatda turishi
talab qilinadi. Console’dagi joriy talabni yuborish vaqtida yana tekshiring.

## 6. Privacy va Data safety

`docs/PRIVACY_POLICY_TEMPLATE.md`ni o‘z aloqa ma’lumotingiz va effective date bilan
to‘ldirib, ommaviy HTTPS sahifada joylang. Data safety’da journal text, photos,
audio va backup **collected/shared emas**: ular qurilmadan chiqmaydi. Billing
verification purchase token/subscription statusini serverga vaqtincha uzatgani
uchun Play formasining o‘sha paytdagi savollariga mos ravishda purchase history yoki
app functionality/fraud-prevention maqsadini oshkor qiling; encrypted in transit,
not shared, not retained/ephemeral processing holatini haqiqiy deployment bilan
mos kiriting. Formadagi Google Play Billing tomonidan boshqariladigan ma’lumotlarga
oid ko‘rsatmani yuborish kuni qayta o‘qing.

## 7. Yakuniy production checklist

- Internal/closed track Pre-launch report’da blocker yo‘q.
- Billing backend URL production HTTPS va health/verification ishlaydi.
- Barcha base plan/offerlar Active; narx/hudud/soliq sozlamalari tekshirilgan.
- Privacy policy va Data safety bir-biriga mos.
- App access, ads (`No`), content rating va target audience to‘ldirilgan.
- Deobfuscation `mapping.txt` workflow artifactida saqlangan.
- Upload key va secretlar source ZIP/repository ichida yo‘q.
- Production rollout avval kichik staged rollout bilan boshlanadi.

Rasmiy manbalar:

- https://support.google.com/googleplay/android-developer/answer/11926878
- https://developer.android.com/google/play/billing/integrate
- https://developer.android.com/google/play/billing/subscriptions
- https://developers.google.com/android-publisher/api-ref/rest/v3/purchases.subscriptionsv2/get
- https://support.google.com/googleplay/android-developer/answer/14151465
