package com.memora.app.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ArrowDropDown
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.key
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.memora.app.data.local.NoteType
import com.memora.app.data.local.SavedTitleEntity
import com.memora.app.data.model.NoteBlock
import com.memora.app.data.model.NoteBlocksCodec
import com.memora.app.data.repository.MemoraRepository
import com.memora.app.i18n.L
import com.memora.app.i18n.S
import com.memora.app.media.AudioRecorderController
import com.memora.app.media.MediaStorage
import com.memora.app.prefs.AppLanguage
import com.memora.app.prefs.FontChoice
import com.memora.app.ui.components.AudioBlockView
import com.memora.app.ui.components.ImageBlockView
import com.memora.app.ui.components.PlainTextEditor
import com.memora.app.ui.theme.ParagraphMetrics
import com.memora.app.util.TextUtils
import com.memora.app.util.TimeUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private data class RecordingUiState(
    val audioBlockId: String,
    val relativePath: String,
    val startedAt: Long
)

@Composable
fun EditorScreen(
    noteId: String?,
    type: NoteType,
    repository: MemoraRepository,
    savedTitles: List<SavedTitleEntity>,
    language: AppLanguage,
    writingFont: FontChoice,
    uiScale: Float,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val storage = remember { MediaStorage(context.applicationContext) }
    val recorder = remember { AudioRecorderController(context.applicationContext) }
    val existingNoteFlow = remember(noteId) {
        noteId?.let(repository::observeNote)
            ?: kotlinx.coroutines.flow.flowOf<com.memora.app.data.local.NoteEntity?>(null)
    }
    val existingNote by existingNoteFlow.collectAsStateWithLifecycle(initialValue = null)

    var actualId by remember(noteId) { mutableStateOf(noteId) }
    var title by remember(noteId) { mutableStateOf("") }
    var blocks by remember(noteId) { mutableStateOf(NoteBlocksCodec.legacy("")) }
    var createdAt by remember(noteId) { mutableLongStateOf(System.currentTimeMillis()) }
    var updatedAt by remember(noteId) { mutableLongStateOf(createdAt) }
    var initialized by remember(noteId) { mutableStateOf(noteId == null) }
    val existingAtEntry = noteId != null
    var baselineSignature by remember(noteId) { mutableStateOf<String?>(null) }
    var titleMenu by remember { mutableStateOf(false) }
    var titleRequiredError by remember(noteId) { mutableStateOf(false) }
    var activeTextId by remember(noteId) { mutableStateOf(blocks.filterIsInstance<NoteBlock.Text>().firstOrNull()?.id) }
    var activeCursor by remember(noteId) { mutableIntStateOf(0) }
    var requestedFocusId by remember(noteId) { mutableStateOf<String?>(null) }
    var requestedFocusCursor by remember(noteId) { mutableStateOf<Int?>(null) }
    var recording by remember(noteId) { mutableStateOf<RecordingUiState?>(null) }
    var recordingElapsed by remember(noteId) { mutableLongStateOf(0L) }
    var startAfterPermission by remember { mutableStateOf(false) }
    var imageSourceDialog by remember { mutableStateOf(false) }
    var pendingCameraCapture by remember { mutableStateOf<MediaStorage.CameraCapture?>(null) }
    var leaving by remember(noteId) { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val editorScrollState = rememberScrollState()
    val density = LocalDensity.current
    val paragraphGap = with(density) { (ParagraphMetrics.EDITOR_LINE_HEIGHT_SP * uiScale * ParagraphMetrics.GAP_RATIO).sp.toDp() }
    val paragraphMinHeight = with(density) { (ParagraphMetrics.EDITOR_LINE_HEIGHT_SP * uiScale).sp.toDp() }

    LaunchedEffect(existingNote, noteId) {
        val note = existingNote
        if (!initialized && note != null) {
            title = note.title
            blocks = NoteBlocksCodec.decode(note.blocksJson, note.plainText)
            createdAt = note.createdAt
            updatedAt = note.updatedAt
            actualId = note.id
            val firstText = blocks.filterIsInstance<NoteBlock.Text>().firstOrNull()
            activeTextId = firstText?.id
            activeCursor = firstText?.text?.length ?: 0
            baselineSignature = note.title + "\u0000" + NoteBlocksCodec.encode(blocks)
            initialized = true
        }
    }

    val plain = remember(blocks) { NoteBlocksCodec.plainText(blocks) }
    val wordCount = remember(plain) { TextUtils.countWords(plain) }
    val completedAudioDuration = remember(blocks) { NoteBlocksCodec.audioDuration(blocks) }
    val shortAudioWarning = type == NoteType.SHORT &&
        completedAudioDuration + (recordingElapsed.takeIf { recording != null } ?: 0L) > 5 * 60_000L

    suspend fun saveNow() {
        if (!initialized) return
        if (actualId == null && title.isBlank() && plain.isBlank() && !NoteBlocksCodec.hasImages(blocks) && !NoteBlocksCodec.hasAudio(blocks)) return
        val now = System.currentTimeMillis()
        val signature = title + "\u0000" + NoteBlocksCodec.encode(blocks)
        val changedExisting = existingAtEntry && baselineSignature != null && signature != baselineSignature
        val storedUpdatedAt = when {
            !existingAtEntry -> now
            changedExisting -> now
            else -> updatedAt
        }
        actualId = repository.saveNote(
            id = actualId,
            type = type,
            title = title,
            html = TextUtils.plainTextToHtml(plain),
            plainText = plain,
            createdAt = if (existingAtEntry) createdAt else null,
            updatedAt = storedUpdatedAt,
            blocksJson = NoteBlocksCodec.encode(blocks),
            hasImages = NoteBlocksCodec.hasImages(blocks),
            hasAudio = NoteBlocksCodec.hasAudio(blocks)
        )
        if (!existingAtEntry) {
            createdAt = now
            updatedAt = now
        } else if (changedExisting) {
            updatedAt = now
        }
    }

    fun finishRecording() {
        val state = recording ?: return
        val duration = recorder.stop()
        val file = storage.resolve(state.relativePath)
        blocks = if (duration != null && file.exists() && file.length() > 0L) {
            blocks.map { block ->
                if (block is NoteBlock.Audio && block.id == state.audioBlockId) {
                    block.copy(durationMs = duration)
                } else block
            }
        } else {
            NoteBlocksCodec.remove(blocks, state.audioBlockId)
        }
        recording = null
        recordingElapsed = 0L
    }

    fun insertMedia(media: NoteBlock) {
        val (next, focusId) = NoteBlocksCodec.insertAtCursor(blocks, activeTextId, activeCursor, media)
        blocks = next
        requestedFocusCursor = 0
        requestedFocusId = focusId
        activeTextId = focusId
        activeCursor = 0
    }

    fun showImageImportError() {
        Toast.makeText(
            context.applicationContext,
            L.t(language, S.IMPORT_FAILED),
            Toast.LENGTH_LONG
        ).show()
    }

    fun importImage(load: () -> NoteBlock.Image) {
        scope.launch {
            try {
                val image = withContext(Dispatchers.IO) { load() }
                insertMedia(image)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: OutOfMemoryError) {
                // A pathological source image must fail gracefully instead of taking the process down.
                showImageImportError()
            } catch (_: Exception) {
                showImageImportError()
            }
        }
    }

    fun startRecording() {
        if (recording != null) return
        runCatching {
            val session = recorder.start(storage)
            val audio = NoteBlock.Audio(relativePath = session.relativePath, durationMs = 0L)
            val (next, focusId) = NoteBlocksCodec.insertAtCursor(blocks, activeTextId, activeCursor, audio)
            blocks = next
            activeTextId = focusId
            activeCursor = 0
            requestedFocusCursor = 0
            requestedFocusId = focusId
            recording = RecordingUiState(audio.id, session.relativePath, session.startedAt)
            recordingElapsed = 0L
        }
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startAfterPermission = true
    }

    LaunchedEffect(startAfterPermission) {
        if (startAfterPermission) {
            startAfterPermission = false
            startRecording()
        }
    }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            importImage { storage.importImage(uri) }
        }
    }

    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        val capture = pendingCameraCapture
        pendingCameraCapture = null
        if (capture != null) {
            if (success) {
                importImage { storage.importCameraImage(capture) }
            } else {
                storage.discardCameraCapture(capture)
            }
        }
    }

    LaunchedEffect(recording?.audioBlockId) {
        val state = recording ?: return@LaunchedEffect
        while (recording?.audioBlockId == state.audioBlockId) {
            recordingElapsed = (System.currentTimeMillis() - state.startedAt).coerceAtLeast(0L)
            delay(500)
        }
    }

    fun leaveEditor() {
        if (leaving) return
        if (recording != null) finishRecording()
        if (title.isBlank() && (plain.isNotBlank() || actualId != null || NoteBlocksCodec.hasImages(blocks) || NoteBlocksCodec.hasAudio(blocks))) {
            titleRequiredError = true
            return
        }
        leaving = true
        scope.launch {
            try {
                saveNow()
                onBack()
            } finally {
                leaving = false
            }
        }
    }

    val lifecycleOwner = LocalLifecycleOwner.current
    val stopAndSave by rememberUpdatedState(newValue = {
        if (recording != null) finishRecording()
        scope.launch { saveNow() }
    })
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) stopAndSave()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            if (recorder.isRecording()) recorder.cancel()
        }
    }

    BackHandler(onBack = ::leaveEditor)

    LaunchedEffect(title, blocks, initialized) {
        if (!initialized) return@LaunchedEffect
        if (actualId == null && title.isBlank() && plain.isBlank() && !NoteBlocksCodec.hasImages(blocks) && !NoteBlocksCodec.hasAudio(blocks)) return@LaunchedEffect
        delay(260)
        saveNow()
    }

    if (imageSourceDialog) {
        AlertDialog(
            onDismissRequest = { imageSourceDialog = false },
            title = { Text(L.t(language, S.IMAGE_SOURCE)) },
            text = {
                Column {
                    TextButton(
                        onClick = {
                            imageSourceDialog = false
                            runCatching { storage.createCameraCapture() }
                                .onSuccess { capture ->
                                    pendingCameraCapture = capture
                                    cameraLauncher.launch(capture.uri)
                                }
                                .onFailure { showImageImportError() }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(L.t(language, S.CAMERA))
                    }
                    TextButton(
                        onClick = {
                            imageSourceDialog = false
                            imagePicker.launch(arrayOf("image/*"))
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(L.t(language, S.GALLERY))
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { imageSourceDialog = false }) {
                    Text(L.t(language, S.CANCEL))
                }
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .imePadding()
            .padding(bottom = 10.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 8.dp, end = 14.dp, top = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(onClick = ::leaveEditor) {
                Icon(Icons.Rounded.ArrowBack, contentDescription = null)
            }
            if (type == NoteType.SHORT) {
                Text(
                    "$wordCount / 50 ${L.t(language, S.WORDS)}",
                    style = MaterialTheme.typography.labelLarge,
                    color = if (wordCount > 50) MaterialTheme.colorScheme.error
                    else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 14.dp)
                )
            }
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 20.dp)
        ) {
            TextField(
                value = title,
                onValueChange = {
                    title = it
                    if (it.isNotBlank()) titleRequiredError = false
                },
                modifier = Modifier.fillMaxWidth(),
                textStyle = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.SemiBold),
                placeholder = { Text(L.t(language, S.TITLE_HINT)) },
                isError = titleRequiredError,
                supportingText = {
                    if (titleRequiredError) {
                        Text(L.t(language, S.TITLE_REQUIRED), color = MaterialTheme.colorScheme.error)
                    }
                },
                singleLine = true,
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                trailingIcon = {
                    IconButton(onClick = { titleMenu = true }) {
                        Icon(Icons.Rounded.ArrowDropDown, contentDescription = L.t(language, S.SELECT_TITLE))
                    }
                    DropdownMenu(expanded = titleMenu, onDismissRequest = { titleMenu = false }) {
                        savedTitles.forEach { item ->
                            DropdownMenuItem(
                                text = { Text(item.value) },
                                onClick = {
                                    title = item.value
                                    titleRequiredError = false
                                    titleMenu = false
                                }
                            )
                        }
                    }
                },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent
                )
            )

            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    TimeUtils.dateTime(createdAt, language),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (actualId != null && updatedAt > createdAt) {
                    Text(
                        editedText(language, updatedAt),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                modifier = Modifier
                    .align(Alignment.End)
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                    horizontalArrangement = Arrangement.End
                ) {
                    IconButton(onClick = { imageSourceDialog = true }) {
                        Icon(Icons.Rounded.Image, contentDescription = L.t(language, S.ADD_IMAGE))
                    }
                    IconButton(
                        onClick = {
                            if (recording != null) {
                                finishRecording()
                            } else if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                startRecording()
                            } else {
                                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        }
                    ) {
                        Icon(Icons.Rounded.Mic, contentDescription = L.t(language, S.ADD_AUDIO))
                    }
                }
            }

            if (type == NoteType.SHORT && wordCount > 50) {
                Text(
                    L.t(language, S.LIMIT_WARNING),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )
            }
            if (shortAudioWarning) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        Icons.Rounded.WarningAmber,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.error
                    )
                    Text(
                        L.t(language, S.AUDIO_LIMIT_WARNING),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }

            val blockContent: @Composable (Modifier) -> Unit = { contentModifier ->
                Column(
                    modifier = contentModifier.verticalScroll(editorScrollState),
                    verticalArrangement = Arrangement.Top
                ) {
                    blocks.forEachIndexed { index, block ->
                        key(block.id) {
                            when (block) {
                                is NoteBlock.Text -> PlainTextEditor(
                                    text = block.text,
                                    styles = block.styles,
                                    onValueChanged = { value, spans, cursor ->
                                        val result = NoteBlocksCodec.editText(blocks, block.id, value, spans, cursor)
                                        blocks = result.blocks
                                        if (result.focusTextId != block.id) {
                                            activeTextId = result.focusTextId
                                            activeCursor = result.focusCursor
                                            requestedFocusId = result.focusTextId
                                            requestedFocusCursor = result.focusCursor
                                        }
                                    },
                                    onParagraphBreak = { cursor, nextPrefix ->
                                        val result = NoteBlocksCodec.splitParagraph(blocks, block.id, cursor, nextPrefix)
                                        blocks = result.blocks
                                        activeTextId = result.focusTextId
                                        activeCursor = result.focusCursor
                                        requestedFocusId = result.focusTextId
                                        requestedFocusCursor = result.focusCursor
                                    },
                                    onMergeWithPrevious = {
                                        val result = NoteBlocksCodec.mergeWithPrevious(blocks, block.id)
                                        if (result != null) {
                                            blocks = result.blocks
                                            activeTextId = result.focusTextId
                                            activeCursor = result.focusCursor
                                            requestedFocusId = result.focusTextId
                                            requestedFocusCursor = result.focusCursor
                                            true
                                        } else false
                                    },
                                    fontChoice = writingFont,
                                    ink = MaterialTheme.colorScheme.onSurface,
                                    uiScale = uiScale,
                                    onFocused = {
                                        activeTextId = block.id
                                        requestedFocusId = null
                                        requestedFocusCursor = null
                                    },
                                    onCursorChanged = { cursor ->
                                        if (activeTextId == block.id) activeCursor = cursor
                                    },
                                    requestFocus = requestedFocusId == block.id,
                                    requestCursorPosition = if (requestedFocusId == block.id) requestedFocusCursor else null,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(min = paragraphMinHeight)
                                )

                                is NoteBlock.Image -> ImageBlockView(
                                    block = block,
                                    file = storage.resolve(block.relativePath),
                                    editable = true,
                                    onDelete = {
                                        storage.delete(block.relativePath)
                                        blocks = NoteBlocksCodec.remove(blocks, block.id)
                                    }
                                )

                                is NoteBlock.Audio -> {
                                    val isThisRecording = recording?.audioBlockId == block.id
                                    AudioBlockView(
                                        block = block,
                                        file = storage.resolve(block.relativePath),
                                        editable = true,
                                        isRecording = isThisRecording,
                                        recordingElapsedMs = if (isThisRecording) recordingElapsed else block.durationMs,
                                        language = language,
                                        onStopRecording = ::finishRecording,
                                        onDelete = {
                                            storage.delete(block.relativePath)
                                            blocks = NoteBlocksCodec.remove(blocks, block.id)
                                        }
                                    )
                                }
                            }
                        }

                        val next = blocks.getOrNull(index + 1)
                        if (next != null) {
                            val gap = if (block is NoteBlock.Text && next is NoteBlock.Text) paragraphGap else 12.dp
                            Spacer(Modifier.height(gap))
                        }
                    }
                    // A generous writing tail lets the active paragraph scroll comfortably above
                    // the keyboard, similar to long-form editors such as Obsidian.
                    Spacer(Modifier.height(180.dp))
                }
            }

            if (type == NoteType.SHORT) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 6.dp)
                        .weight(1f)
                        .heightIn(max = 460.dp),
                    shape = RoundedCornerShape(28.dp),
                    color = MaterialTheme.colorScheme.surface
                ) {
                    blockContent(Modifier.fillMaxSize().padding(18.dp))
                }
            } else {
                blockContent(
                    Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(top = 4.dp, start = 4.dp, end = 4.dp)
                )
            }
        }
    }
}


private fun editedText(language: AppLanguage, updatedAt: Long): String =
    L.format(language, S.EDITED, TimeUtils.dateTime(updatedAt, language))
