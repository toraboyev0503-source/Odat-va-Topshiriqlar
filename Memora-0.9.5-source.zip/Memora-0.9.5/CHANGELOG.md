# Memora 0.9.5 — Final functional stabilization

- Added optional per-note mood metadata with five values: 😄 / 🙂 / 😐 / 🙁 / 😞.
- Added safe Room migration 3 → 4; existing notes and media remain intact.
- Mood is preserved by Memora backup/restore and can be used as a search filter.
- Reader view shows the selected mood beside the note date.
- Editor title field now grows naturally to multiple wrapped lines instead of scrolling horizontally.
- Reworked editor persistence into a 900 ms debounced, mutex-serialized autosave pipeline; Back/background still flush immediately.
- Added app-private recovery snapshots so recent edits can be recovered after an abnormal process exit.
- Added app-private local crash diagnostics containing stack locations only; note text, titles and media are never logged or uploaded.
- Added editor stress tests for repeated paragraph split/merge, large paste, IME punctuation/Enter, and numbered-list overflow.
- Kept the stable test-only debug signing certificate and version-independent GitHub debug workflow.
- Feature freeze begins after this stabilization build; subsequent work is bug-fix and Play testing only.

# Changelog

## 0.9.5 — final bug-fix gate before Play setup

- Removed the five built-in/system titles that Memora used to force into the Titles screen and title picker. Only titles created by the user are now shown, pinnable, editable and searchable; existing notes keep their stored title text unchanged.
- Fixed the custom-title edit dialog: the primary action now says **Save** instead of reusing the
  destructive **Delete** confirmation label. Added a dedicated `SAVE` translation in all 13 UI
  languages so the fix is correct regardless of the selected language.
- Kept the approved 60% paragraph spacing, structural numbered-list continuation, safe image import,
  single-level Back behavior, full-screen branded launch artwork and suppressed duplicate Compose
  selection toolbar unchanged.
- Preserved the stable bundled test-only debug signing certificate introduced in 0.9.4 so 0.9.5 and
  later GitHub debug APKs can update 0.9.4 in place.
- Replaced the version-hardcoded debug workflow with a universal workflow that automatically selects
  the newest `Memora-*-source.zip`, runs unit tests and lint, builds the APK, and verifies the expected
  debug signing certificate before upload. This prevents old `0.9.x-source.zip not found` workflow
  failures when the app version changes.
- Added a localization regression test for the Save action and corrected the paragraph-gap test name
  to match the established 60% metric.
- Version bumped to `0.9.5` / code `25`. This is the code-freeze bug-fix gate; new feature work is
  deferred until the Play release infrastructure steps.

## 0.9.4 — launch cleanup, numbered paragraphs, stable test updates

- Removed the separate small-logo Android system splash introduced in 0.9.3: the mandatory
  platform splash now uses a transparent icon and blends directly into the existing full-screen
  Memora launch artwork.
- Restored numbered-paragraph continuation in the structural paragraph editor. Soft keyboards that
  commit punctuation and Enter in one callback now preserve the punctuation and create exactly one
  next marker (`1.` → `2.` → `3.`).
- Removed the cross-paragraph timing debounce that could swallow a legitimate Enter and leave
  automatic numbering inactive; duplicate OEM callbacks remain guarded per editor instance.
- Reintroduced the established bundled **test-only** signing certificate for debug builds. Debug
  APKs from 0.9.4 onward use the same package ID and certificate, so later GitHub APKs install as
  updates instead of requiring uninstall/reinstall. Production Play signing remains separate.
- Version bumped to `0.9.4` / code `24`; the 60% paragraph spacing and all 0.9.3 fixes are retained.

## 0.9.3 — GitHub lint/build fix + stability hardening

- Fixed all six blocking Android Lint `NewApi` errors introduced by splash/system-bar XML: API 27/29-only navigation-bar attributes are no longer declared in unqualified `values` resources. Runtime system-bar behavior remains handled safely by `WindowCompat` and existing SDK guards.
- Moved image display decoding off the Compose UI thread and reduced peak bitmap memory with
  bounded RGB_565 sampling; gallery import now uses a document URI with persistable read access.
- Added graceful handling for oversized/corrupt images so image insertion reports a failure instead
  of terminating the app process.
- Shortened the platform splash transition, made the native first frame show the Memora mark
  instead of a blank cream screen, moved nonessential startup scheduling off the main thread, and
  matched the navigation/gesture area to the lower edge of the launch artwork.
- Hardened structural Enter handling for numbered lists: hardware Enter is consumed directly,
  duplicate OEM-IME newline callbacks collapse to one paragraph break, and a cross-field debounce
  prevents the next number from being created twice after terminal punctuation.
- Replaced per-route Back handlers with one central route-level handler while keeping nested editor,
  note-selection and calendar Back behavior; each Back action now removes exactly one level.
- Suppressed Memora's Compose text-selection toolbar in the note editor while leaving text selection
  enabled for device/OEM-native actions.
- Version bumped to `0.9.3` / code `23`; the existing 60% paragraph spacing and 0.9.1 production
  billing/privacy architecture are unchanged.

## 0.9.1 — Stability and navigation bugfix

- Hardened gallery and camera image import with bounded staging, sampled decoding,
  safe cleanup and a user-visible failure message instead of an app exit.
- Limited displayed image decoding and removed decoded bitmap allocations when the
  image leaves the editor or reader.
- Made the launch artwork crop to the full edge-to-edge surface and aligned system
  bars so the lower strip keeps the same background.
- Removed Memora's duplicate copy/cut/paste/select-all toolbar; Android's native
  selection toolbar remains available.
- Enter after a numbered sentence ending in a period now creates exactly one next
  paragraph, without silently inserting a trailing space.
- Made every route use one-step back navigation, prevented rapid editor back races,
  and preserved nested statistics/search state when returning from a note.

## 0.9.0 — Play Release Candidate

- Added Google Play Billing Library 9.1.0 integration for the single
  `memora_premium` subscription and four base plans.
- Added Play-controlled offer selection for a one-month free trial; reinstalling
  the app does not reset Play account eligibility.
- Added backend purchase-token verification, encrypted seven-day offline
  entitlement caching, pending-purchase handling and post-verification acknowledgement.
- Added read-only behavior after expiry while preserving viewing, search,
  statistics, playback and every export format.
- Added automatic device-language selection with English fallback while retaining
  the existing manual choice and all 13 UI languages.
- Kept all journal content local and added no advertising, analytics or crash SDK.
- Separated release signing from debug signing and removed the bundled test key.
- Replaced the custom build bootstrap with the official checksum-pinned Gradle wrapper.
- Added bounded backup/media import and canonical private-storage path validation.
- Added a GitHub Actions test → lint → signed AAB pipeline.
- Retained the 0.5.7 editor/reader paragraph gap at exactly 60% of line-height.

## 0.5.7 baseline

- Structural paragraph blocks, 60% paragraph spacing, short/long notes, media,
  reminders, titles, statistics, search, app lock, 13 languages, HTML/Word export
  and `.memora` backup/import form the preserved functional baseline.
