package com.memora.app.export

import android.content.ContentResolver
import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import com.memora.app.data.local.NoteEntity
import com.memora.app.data.local.NoteType
import com.memora.app.data.model.NoteBlock
import com.memora.app.data.model.NoteBlocksCodec
import com.memora.app.data.repository.MemoraRepository
import com.memora.app.media.MediaStorage
import com.memora.app.prefs.AppLanguage
import com.memora.app.prefs.FontChoice
import com.memora.app.prefs.LockInterval
import com.memora.app.prefs.PaletteChoice
import com.memora.app.prefs.ThemeMode
import com.memora.app.prefs.UserPreferences
import com.memora.app.util.TextUtils
import com.memora.app.util.TimeRange
import com.memora.app.util.TimeUtils
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedOutputStream
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.time.Instant
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream


data class ImportResult(val imported: Int, val duplicatesSkipped: Int)

class ExportManager(
    private val context: Context,
    private val resolver: ContentResolver,
    private val repository: MemoraRepository,
    private val preferences: UserPreferences
) {
    private val storage = MediaStorage(context.applicationContext)

    suspend fun write(request: ExportRequest, uri: Uri, language: AppLanguage) {
        val range = request.range()
        val type = request.scopeNoteType()
        val notes = repository.notesForExport(type, range.start, range.end)
        when (request.format) {
            ExportFormat.WORD -> {
                resolver.openOutputStream(uri)?.use { out ->
                    writeWordPackage(
                        output = out,
                        request = request,
                        notes = notes,
                        language = language
                    )
                } ?: error("Unable to open output file")
            }
            ExportFormat.BACKUP -> {
                resolver.openOutputStream(uri)?.use { out ->
                    writeBackupZip(out, request, notes)
                } ?: error("Unable to open output file")
            }
        }
    }

    private fun writeWordPackage(
        output: java.io.OutputStream,
        request: ExportRequest,
        notes: List<NoteEntity>,
        language: AppLanguage
    ) {
        val built = DocxWriter.build(
            notes = notes,
            language = language,
            layout = request.wordLayout,
            storage = storage
        )
        val docxName = wordDocumentFileName(request)

        ZipOutputStream(BufferedOutputStream(output)).use { zip ->
            zip.putNextEntry(ZipEntry(docxName))
            zip.write(built.docxBytes)
            zip.closeEntry()

            built.audios.forEach { audio ->
                zip.putNextEntry(ZipEntry("Audio/${audio.targetName}"))
                audio.file.inputStream().use { it.copyTo(zip) }
                zip.closeEntry()
            }

            zip.putNextEntry(ZipEntry("README.txt"))
            zip.write(wordPackageReadme(language, docxName, built.audios.isNotEmpty()).toByteArray(Charsets.UTF_8))
            zip.closeEntry()
        }
    }

    private fun wordPackageReadme(language: AppLanguage, docxName: String, hasAudio: Boolean): String = when (language) {
        AppLanguage.EN -> buildString {
            appendLine("Memora Word export")
            appendLine()
            appendLine("1. Extract this ZIP file first.")
            appendLine("2. Open $docxName from the extracted folder.")
            if (hasAudio) {
                appendLine("3. Keep the Audio folder next to the Word file.")
                appendLine("4. Tap an audio link in Word to open the matching .m4a file. If your Word app blocks local links, open the same file directly from the Audio folder.")
            }
        }
        AppLanguage.RU -> buildString {
            appendLine("Экспорт Memora в Word")
            appendLine()
            appendLine("1. Сначала распакуйте ZIP-файл.")
            appendLine("2. Откройте $docxName из распакованной папки.")
            if (hasAudio) {
                appendLine("3. Папка Audio должна оставаться рядом с Word-файлом.")
                appendLine("4. Нажмите ссылку аудио в Word, чтобы открыть соответствующий .m4a. Если Word блокирует локальные ссылки, откройте этот файл напрямую из папки Audio.")
            }
        }
        AppLanguage.UZ -> buildString {
            appendLine("Memora Word eksporti")
            appendLine()
            appendLine("1. Avval ZIP faylni ochib (extract) oling.")
            appendLine("2. Ajratilgan papkadagi $docxName faylini oching.")
            if (hasAudio) {
                appendLine("3. Audio papkasini Word fayli yonida saqlang.")
                appendLine("4. Word ichidagi audio havolasini bossangiz mos .m4a fayl ochiladi. Word lokal havolani bloklasa, o‘sha audioni Audio papkasidan bevosita oching.")
            }
        }
    }

    private suspend fun writeBackupZip(
        output: java.io.OutputStream,
        request: ExportRequest,
        notes: List<NoteEntity>
    ) {
        val root = JSONObject().apply {
            put("format", "MEMORA_BACKUP")
            put("schemaVersion", 2)
            put("createdAt", System.currentTimeMillis())
            put("scope", request.backupScope.name)
            put("notes", JSONArray().apply {
                notes.forEach { n ->
                    put(JSONObject().apply {
                        put("id", n.id)
                        put("type", n.type)
                        put("title", n.title)
                        put("contentHtml", n.contentHtml)
                        put("plainText", n.plainText)
                        put("createdAt", n.createdAt)
                        put("updatedAt", n.updatedAt)
                        put("wordCount", n.wordCount)
                        put("blocksJson", n.blocksJson)
                        put("hasImages", n.hasImages)
                        put("hasAudio", n.hasAudio)
                    })
                }
            })
            if (request.backupScope == BackupScope.BOTH) {
                put("savedTitles", JSONArray().apply {
                    repository.allTitles().forEach { t ->
                        put(JSONObject().apply {
                            put("value", t.value)
                            put("createdAt", t.createdAt)
                        })
                    }
                })
                put("reminders", JSONArray().apply {
                    repository.allReminders().forEach { r ->
                        put(JSONObject().apply {
                            put("hour", r.hour)
                            put("minute", r.minute)
                            put("enabled", r.enabled)
                            put("createdAt", r.createdAt)
                        })
                    }
                })
                val settings = preferences.settings.first()
                put("settings", JSONObject().apply {
                    put("language", settings.language.name)
                    put("themeMode", settings.themeMode.name)
                    put("palette", settings.palette.name)
                    put("uiFont", settings.uiFont.name)
                    put("writingFont", settings.writingFont.name)
                    put("uiScale", settings.uiScale)
                    put("lockEnabled", settings.lockEnabled)
                    put("lockInterval", settings.lockInterval.name)
                })
            }
        }

        ZipOutputStream(BufferedOutputStream(output)).use { zip ->
            zip.putNextEntry(ZipEntry("manifest.json"))
            zip.write(root.toString(2).toByteArray(Charsets.UTF_8))
            zip.closeEntry()

            val paths = notes.flatMap { note ->
                NoteBlocksCodec.decode(note.blocksJson, note.plainText).mapNotNull { block ->
                    when (block) {
                        is NoteBlock.Image -> block.relativePath
                        is NoteBlock.Audio -> block.relativePath
                        is NoteBlock.Text -> null
                    }
                }
            }.distinct()

            paths.forEach { relative ->
                val file = storage.resolve(relative)
                if (file.exists() && file.isFile) {
                    zip.putNextEntry(ZipEntry(relative.replace('\\', '/')))
                    file.inputStream().use { it.copyTo(zip) }
                    zip.closeEntry()
                }
            }
        }
    }

    suspend fun importBackup(uri: Uri): ImportResult {
        val header = resolver.openInputStream(uri)?.use { input ->
            ByteArray(4).also { input.read(it) }
        } ?: error("Unable to open backup")
        return if (header.size >= 2 && header[0] == 'P'.code.toByte() && header[1] == 'K'.code.toByte()) {
            importZipBackup(uri)
        } else {
            val text = resolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                ?: error("Unable to open backup")
            importLegacyJson(JSONObject(text))
        }
    }

    private suspend fun importZipBackup(uri: Uri): ImportResult {
        val manifest = readManifest(uri)
        require(manifest.optString("format") == "MEMORA_BACKUP") { "Not a Memora backup" }
        require(manifest.optInt("schemaVersion", 0) in 1..2) { "Unsupported Memora backup version" }

        data class Pending(val obj: JSONObject, val blocks: List<NoteBlock>)
        val pending = mutableListOf<Pending>()
        var duplicates = 0
        val notesArray = manifest.optJSONArray("notes") ?: JSONArray()
        for (i in 0 until notesArray.length()) {
            val obj = notesArray.getJSONObject(i)
            val title = obj.optString("title", "")
            val plain = obj.optString("plainText", "")
            val createdAt = obj.getLong("createdAt")
            if (repository.isDuplicate(title, plain, createdAt)) {
                duplicates++
                continue
            }
            pending += Pending(
                obj,
                NoteBlocksCodec.decode(obj.optString("blocksJson", ""), plain)
            )
        }

        val neededPaths = pending.flatMap { p ->
            p.blocks.mapNotNull { block ->
                when (block) {
                    is NoteBlock.Image -> block.relativePath
                    is NoteBlock.Audio -> block.relativePath
                    is NoteBlock.Text -> null
                }
            }
        }.toSet()
        val pathMap = importMediaEntries(uri, neededPaths)

        var imported = 0
        pending.forEach { item ->
            val obj = item.obj
            val remapped = item.blocks.map { block ->
                when (block) {
                    is NoteBlock.Image -> block.copy(relativePath = pathMap[block.relativePath] ?: block.relativePath)
                    is NoteBlock.Audio -> block.copy(relativePath = pathMap[block.relativePath] ?: block.relativePath)
                    is NoteBlock.Text -> block
                }
            }
            val type = runCatching { NoteType.valueOf(obj.getString("type")) }.getOrDefault(NoteType.LONG)
            val plain = obj.optString("plainText", NoteBlocksCodec.plainText(remapped))
            val createdAt = obj.getLong("createdAt")
            repository.saveNote(
                id = UUID.randomUUID().toString(),
                type = type,
                title = obj.optString("title", ""),
                html = obj.optString("contentHtml", TextUtils.plainTextToHtml(plain)),
                plainText = plain,
                createdAt = createdAt,
                updatedAt = obj.optLong("updatedAt", createdAt),
                blocksJson = NoteBlocksCodec.encode(remapped),
                hasImages = NoteBlocksCodec.hasImages(remapped),
                hasAudio = NoteBlocksCodec.hasAudio(remapped)
            )
            imported++
        }

        restoreExtras(manifest)
        return ImportResult(imported, duplicates)
    }

    private fun readManifest(uri: Uri): JSONObject {
        resolver.openInputStream(uri)?.use { input ->
            ZipInputStream(input).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    if (!entry.isDirectory && entry.name == "manifest.json") {
                        return JSONObject(zip.readBytes().toString(Charsets.UTF_8))
                    }
                    zip.closeEntry()
                }
            }
        }
        error("Backup manifest is missing")
    }

    private fun importMediaEntries(uri: Uri, neededPaths: Set<String>): Map<String, String> {
        if (neededPaths.isEmpty()) return emptyMap()
        val mapped = mutableMapOf<String, String>()
        resolver.openInputStream(uri)?.use { input ->
            ZipInputStream(input).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    val safe = entry.name.replace('\\', '/').trimStart('/')
                    if (!entry.isDirectory && safe in neededPaths && !safe.contains("../")) {
                        val extension = safe.substringAfterLast('.', "bin")
                        val folder = if (safe.contains("/images/")) "images" else "audio"
                        val relative = storage.storeImported(folder, extension, zip.readBytes())
                        mapped[safe] = relative
                    }
                    zip.closeEntry()
                }
            }
        }
        return mapped
    }

    private suspend fun importLegacyJson(root: JSONObject): ImportResult {
        require(root.optString("format") == "MEMORA_BACKUP") { "Not a Memora backup" }
        require(root.optInt("schemaVersion", 0) in 1..2) { "Unsupported Memora backup version" }
        var imported = 0
        var duplicates = 0
        val notes = root.optJSONArray("notes") ?: JSONArray()
        for (i in 0 until notes.length()) {
            val obj = notes.getJSONObject(i)
            val title = obj.optString("title", "")
            val plain = obj.optString("plainText", "")
            val createdAt = obj.getLong("createdAt")
            if (repository.isDuplicate(title, plain, createdAt)) {
                duplicates++
                continue
            }
            val type = runCatching { NoteType.valueOf(obj.getString("type")) }.getOrDefault(NoteType.LONG)
            val blocks = NoteBlocksCodec.decode(obj.optString("blocksJson", ""), plain)
            repository.saveNote(
                id = UUID.randomUUID().toString(),
                type = type,
                title = title,
                html = obj.optString("contentHtml", TextUtils.plainTextToHtml(plain)),
                plainText = plain,
                createdAt = createdAt,
                updatedAt = obj.optLong("updatedAt", createdAt),
                blocksJson = NoteBlocksCodec.encode(blocks),
                hasImages = NoteBlocksCodec.hasImages(blocks),
                hasAudio = NoteBlocksCodec.hasAudio(blocks)
            )
            imported++
        }
        restoreExtras(root)
        return ImportResult(imported, duplicates)
    }

    private suspend fun restoreExtras(root: JSONObject) {
        root.optJSONArray("savedTitles")?.let { titles ->
            for (i in 0 until titles.length()) {
                val obj = titles.getJSONObject(i)
                repository.addTitle(
                    value = obj.optString("value", ""),
                    createdAt = obj.optLong("createdAt", System.currentTimeMillis())
                )
            }
        }
        root.optJSONArray("reminders")?.let { reminders ->
            val existing = repository.allReminders().map { it.hour to it.minute }.toMutableSet()
            for (i in 0 until reminders.length()) {
                val obj = reminders.getJSONObject(i)
                val pair = obj.optInt("hour", -1) to obj.optInt("minute", -1)
                if (pair.first in 0..23 && pair.second in 0..59 && pair !in existing) {
                    repository.addReminder(
                        hour = pair.first,
                        minute = pair.second,
                        enabled = obj.optBoolean("enabled", true),
                        createdAt = obj.optLong("createdAt", System.currentTimeMillis())
                    )
                    existing += pair
                }
            }
        }
        root.optJSONObject("settings")?.let { settings ->
            runCatching { AppLanguage.valueOf(settings.optString("language")) }
                .getOrNull()?.let { preferences.setLanguage(it) }
            runCatching { ThemeMode.valueOf(settings.optString("themeMode")) }
                .getOrNull()?.let { preferences.setThemeMode(it) }
            runCatching { PaletteChoice.valueOf(settings.optString("palette")) }
                .getOrNull()?.let { preferences.setPalette(it) }
            runCatching { FontChoice.valueOf(settings.optString("uiFont")) }
                .getOrNull()?.let { preferences.setUiFont(it) }
            runCatching { FontChoice.valueOf(settings.optString("writingFont")) }
                .getOrNull()?.let { preferences.setWritingFont(it) }
            if (settings.has("uiScale")) preferences.setUiScale(settings.optDouble("uiScale", 1.0).toFloat())
            if (settings.has("lockEnabled")) preferences.setLockEnabled(settings.optBoolean("lockEnabled", true))
            runCatching { LockInterval.valueOf(settings.optString("lockInterval")) }
                .getOrNull()?.let { preferences.setLockInterval(it) }
        }
    }

    private fun ExportRequest.scopeNoteType(): NoteType? = when (backupScope) {
        BackupScope.SHORT -> NoteType.SHORT
        BackupScope.LONG -> NoteType.LONG
        BackupScope.BOTH -> null
    }

    private fun ExportRequest.range(): TimeRange = when (period) {
        ExportPeriod.ALL -> TimeRange(null, null)
        ExportPeriod.YEAR -> TimeUtils.yearRange(requireNotNull(year))
        ExportPeriod.MONTH -> TimeUtils.monthRange(requireNotNull(year), requireNotNull(month))
    }

    companion object {
        fun suggestedFileName(request: ExportRequest): String {
            val stamp = java.time.LocalDate.now().toString()
            return when (request.format) {
                ExportFormat.WORD -> "Memora-${request.backupScope.name.lowercase()}-$stamp-word.zip"
                ExportFormat.BACKUP -> "Memora-${request.backupScope.name.lowercase()}-$stamp.memora"
            }
        }

        fun wordDocumentFileName(request: ExportRequest): String {
            val stamp = java.time.LocalDate.now().toString()
            return "Memora-${request.backupScope.name.lowercase()}-$stamp.docx"
        }
    }
}

private data class DocxImage(
    val blockId: String,
    val file: File,
    val relationshipId: String,
    val targetName: String,
    val cx: Long,
    val cy: Long,
    val docPrId: Int
)

private data class DocxAudio(
    val blockId: String,
    val file: File,
    val relationshipId: String,
    val targetName: String
)

private data class BuiltDocx(
    val docxBytes: ByteArray,
    val audios: List<DocxAudio>
)

private object DocxWriter {
    fun build(
        notes: List<NoteEntity>,
        language: AppLanguage,
        layout: WordLayout,
        storage: MediaStorage
    ): BuiltDocx {
        val images = mutableListOf<DocxImage>()
        val audios = mutableListOf<DocxAudio>()
        var relNumber = 1
        var imageNumber = 1
        var audioNumber = 1
        var docPr = 1

        notes.forEach { note ->
            NoteBlocksCodec.decode(note.blocksJson, note.plainText).forEach { block ->
                when (block) {
                    is NoteBlock.Image -> {
                        val file = storage.resolve(block.relativePath)
                        if (file.exists()) {
                            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                            BitmapFactory.decodeFile(file.absolutePath, options)
                            val width = options.outWidth.coerceAtLeast(1)
                            val height = options.outHeight.coerceAtLeast(1)
                            val maxCx = 5_200_000L
                            val cy = (maxCx * height.toDouble() / width.toDouble()).toLong().coerceAtMost(7_200_000L)
                            val cx = (cy * width.toDouble() / height.toDouble()).toLong().coerceAtMost(maxCx)
                            images += DocxImage(
                                blockId = block.id,
                                file = file,
                                relationshipId = "rId${relNumber++}",
                                targetName = "image${imageNumber++}.jpeg",
                                cx = cx,
                                cy = cy,
                                docPrId = docPr++
                            )
                        }
                    }
                    is NoteBlock.Audio -> {
                        val file = storage.resolve(block.relativePath)
                        if (file.exists()) {
                            audios += DocxAudio(
                                blockId = block.id,
                                file = file,
                                relationshipId = "rId${relNumber++}",
                                targetName = "audio${audioNumber++}.m4a"
                            )
                        }
                    }
                    is NoteBlock.Text -> Unit
                }
            }
        }

        val docxOutput = ByteArrayOutputStream()
        ZipOutputStream(BufferedOutputStream(docxOutput)).use { zip ->
            add(zip, "[Content_Types].xml", contentTypes())
            add(zip, "_rels/.rels", rootRels())
            add(zip, "docProps/core.xml", coreProps())
            add(zip, "docProps/app.xml", appProps())
            add(zip, "word/styles.xml", styles())
            add(zip, "word/_rels/document.xml.rels", documentRels(images, audios))
            add(zip, "word/document.xml", document(notes, language, layout, images, audios))
            images.forEach { image -> addFile(zip, "word/media/${image.targetName}", image.file) }
        }
        return BuiltDocx(docxBytes = docxOutput.toByteArray(), audios = audios)
    }

    private fun add(zip: ZipOutputStream, name: String, content: String) {
        zip.putNextEntry(ZipEntry(name))
        zip.write(content.toByteArray(Charsets.UTF_8))
        zip.closeEntry()
    }

    private fun addFile(zip: ZipOutputStream, name: String, file: File) {
        zip.putNextEntry(ZipEntry(name))
        file.inputStream().use { it.copyTo(zip) }
        zip.closeEntry()
    }

    private fun contentTypes() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Default Extension="jpeg" ContentType="image/jpeg"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
  <Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>
  <Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
  <Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>
</Types>"""

    private fun rootRels() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
  <Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>
</Relationships>"""

    private fun documentRels(images: List<DocxImage>, audios: List<DocxAudio>): String = buildString {
        append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
        append("<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">")
        images.forEach { image ->
            append("<Relationship Id=\"").append(image.relationshipId)
                .append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/image\" Target=\"media/")
                .append(image.targetName).append("\"/>")
        }
        audios.forEach { audio ->
            append("<Relationship Id=\"").append(audio.relationshipId)
                .append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink\" Target=\"Audio/")
                .append(audio.targetName).append("\" TargetMode=\"External\"/>")
        }
        append("</Relationships>")
    }

    private fun styles() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:style w:type="paragraph" w:default="1" w:styleId="Normal">
    <w:name w:val="Normal"/>
    <w:rPr><w:sz w:val="22"/><w:szCs w:val="22"/></w:rPr>
    <w:pPr><w:spacing w:after="120" w:line="300" w:lineRule="auto"/></w:pPr>
  </w:style>
  <w:style w:type="paragraph" w:styleId="MemoraTitle">
    <w:name w:val="Memora Title"/><w:basedOn w:val="Normal"/>
    <w:rPr><w:b/><w:sz w:val="34"/><w:szCs w:val="34"/></w:rPr>
    <w:pPr><w:spacing w:before="260" w:after="70"/></w:pPr>
  </w:style>
  <w:style w:type="paragraph" w:styleId="MemoraDate">
    <w:name w:val="Memora Date"/><w:basedOn w:val="Normal"/>
    <w:rPr><w:color w:val="777777"/><w:sz w:val="18"/><w:szCs w:val="18"/></w:rPr>
    <w:pPr><w:spacing w:after="120"/></w:pPr>
  </w:style>
  <w:style w:type="paragraph" w:styleId="MemoraDateHeading">
    <w:name w:val="Memora Date Heading"/><w:basedOn w:val="Normal"/>
    <w:rPr><w:b/><w:sz w:val="26"/><w:szCs w:val="26"/></w:rPr>
    <w:pPr><w:spacing w:before="180" w:after="90"/></w:pPr>
  </w:style>
</w:styles>"""

    private fun coreProps(): String {
        val now = Instant.now().toString()
        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties"
 xmlns:dc="http://purl.org/dc/elements/1.1/"
 xmlns:dcterms="http://purl.org/dc/terms/"
 xmlns:dcmitype="http://purl.org/dc/dcmitype/"
 xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <dc:title>Memora export</dc:title><dc:creator>Memora</dc:creator><cp:lastModifiedBy>Memora</cp:lastModifiedBy>
  <dcterms:created xsi:type="dcterms:W3CDTF">$now</dcterms:created>
  <dcterms:modified xsi:type="dcterms:W3CDTF">$now</dcterms:modified>
</cp:coreProperties>"""
    }

    private fun appProps() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"
 xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"><Application>Memora</Application></Properties>"""

    private fun document(
        notes: List<NoteEntity>,
        language: AppLanguage,
        layout: WordLayout,
        images: List<DocxImage>,
        audios: List<DocxAudio>
    ): String {
        val imageByBlock = images.associateBy { it.blockId }
        val audioByBlock = audios.associateBy { it.blockId }
        val body = buildString {
            if (layout == WordLayout.CHRONOLOGICAL) {
                notes.forEach { note ->
                    append(paragraph(displayTitle(note, language), "MemoraTitle"))
                    append(paragraph(TimeUtils.dateTime(note.createdAt, language), "MemoraDate"))
                    appendBlocks(note, language, imageByBlock, audioByBlock)
                    append(emptyParagraph())
                }
            } else {
                val grouped = notes.groupBy { displayTitle(it, language) }
                    .entries.sortedBy { entry -> entry.value.minOfOrNull { it.createdAt } ?: Long.MAX_VALUE }
                grouped.forEach { (title, groupedNotes) ->
                    append(paragraph(title, "MemoraTitle"))
                    groupedNotes.sortedBy { it.createdAt }.forEach { note ->
                        append(paragraph(TimeUtils.dateTime(note.createdAt, language), "MemoraDateHeading"))
                        appendBlocks(note, language, imageByBlock, audioByBlock)
                    }
                    append(emptyParagraph())
                }
            }
        }
        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
 xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
 xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"
 xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"
 xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">
  <w:body>$body
    <w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134" w:header="708" w:footer="708" w:gutter="0"/></w:sectPr>
  </w:body>
</w:document>"""
    }

    private fun StringBuilder.appendBlocks(
        note: NoteEntity,
        language: AppLanguage,
        images: Map<String, DocxImage>,
        audios: Map<String, DocxAudio>
    ) {
        val blocks = NoteBlocksCodec.decode(note.blocksJson, note.plainText)
        blocks.forEach { block ->
            when (block) {
                is NoteBlock.Text -> {
                    val paragraphs = block.text.replace("\r\n", "\n").split("\n")
                    if (paragraphs.isEmpty()) append(paragraph("", "Normal"))
                    else paragraphs.forEach { append(paragraph(it, "Normal")) }
                }
                is NoteBlock.Image -> images[block.id]?.let { append(imageParagraph(it)) }
                is NoteBlock.Audio -> {
                    val label = when (language) {
                        AppLanguage.EN -> "Play audio"
                        AppLanguage.RU -> "Открыть аудио"
                        AppLanguage.UZ -> "Audioni eshitish"
                    }
                    val audio = audios[block.id]
                    if (audio != null) {
                        append(audioHyperlinkParagraph(
                            audio = audio,
                            text = "▶ $label · ${formatDuration(block.durationMs)} · ${audio.targetName}"
                        ))
                    } else {
                        append(paragraph("▶ $label · ${formatDuration(block.durationMs)}", "MemoraDate"))
                    }
                }
            }
        }
    }

    private fun displayTitle(note: NoteEntity, language: AppLanguage): String = note.title.ifBlank {
        when (language) {
            AppLanguage.EN -> "Untitled"
            AppLanguage.RU -> "Без названия"
            AppLanguage.UZ -> "Nomsiz"
        }
    }

    private fun paragraph(text: String, style: String): String =
        """<w:p><w:pPr><w:pStyle w:val="$style"/></w:pPr><w:r><w:t xml:space="preserve">${TextUtils.xmlEscape(text)}</w:t></w:r></w:p>"""

    private fun emptyParagraph() = "<w:p><w:r><w:t></w:t></w:r></w:p>"

    private fun imageParagraph(image: DocxImage): String = """
<w:p><w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0">
  <wp:extent cx="${image.cx}" cy="${image.cy}"/><wp:docPr id="${image.docPrId}" name="Memora image ${image.docPrId}"/>
  <a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">
    <pic:pic><pic:nvPicPr><pic:cNvPr id="0" name="${image.targetName}"/><pic:cNvPicPr/></pic:nvPicPr>
      <pic:blipFill><a:blip r:embed="${image.relationshipId}"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>
      <pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="${image.cx}" cy="${image.cy}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr>
    </pic:pic>
  </a:graphicData></a:graphic>
</wp:inline></w:drawing></w:r></w:p>"""

    private fun audioHyperlinkParagraph(audio: DocxAudio, text: String): String =
        """<w:p><w:pPr><w:pStyle w:val="MemoraDate"/></w:pPr><w:hyperlink r:id="${audio.relationshipId}" w:history="1"><w:r><w:rPr><w:color w:val="2F6FED"/><w:u w:val="single"/></w:rPr><w:t xml:space="preserve">${TextUtils.xmlEscape(text)}</w:t></w:r></w:hyperlink></w:p>"""

    private fun formatDuration(durationMs: Long): String {
        val total = durationMs.coerceAtLeast(0L) / 1000L
        return "%02d:%02d".format(total / 60, total % 60)
    }
}
