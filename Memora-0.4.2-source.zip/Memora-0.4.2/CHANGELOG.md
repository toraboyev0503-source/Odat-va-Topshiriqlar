# Memora 0.4.2

- Word export now creates a portable ZIP package containing the `.docx`, an `Audio/` folder with the original `.m4a` recordings, and a localized `README.txt`.
- Every audio block in the Word document is rendered as a visible blue underlined hyperlink (`▶`) that targets the matching audio file in the sibling `Audio/` folder.
- Images remain embedded directly in the Word document in their original note positions.
- Added localized guidance in the export dialog explaining that the ZIP must be extracted and the Word file and Audio folder kept together.
- `versionCode` increased to 8 and `versionName` to 0.4.2; the stable 0.4.1+ test signing key is preserved so this debug APK can install as an update.

# Memora 0.4.1

- Image action now lets the user choose **Camera** or **Gallery** in both Short and Long note editors.
- Camera capture uses a private FileProvider URI and imports the photo into Memora media storage.
- Added a stable, bundled **test-only debug signing key** so GitHub debug APKs from 0.4.1 onward can update the installed debug app without deleting its local data.
- `versionCode` increased to 7 and `versionName` to 0.4.1.
- Production/release signing remains separate and continues to use environment-provided secrets.

# Memora changelog

## 0.4.0 — Media notes and reminder reliability
- Added inline image blocks to Short and Long Notes. Images can be inserted between text blocks and remain visible while reading.
- Added inline audio recording/playback blocks. Text can continue before and after each recording, and any number of audio blocks can be added.
- Short Notes show a warning when total recorded audio passes 5 minutes without stopping the recording; Long Notes have no audio-duration limit.
- Note list cards show subtle media indicators when a note contains images or audio.
- Word export now includes images in their note position and preserves audio files inside the DOCX package with visible audio markers in the document.
- Added a second Word layout that groups notes by title and uses each note date/time as the subheading; the existing chronological layout remains available.
- Memora backup format upgraded to schema 2 so image/audio files travel with the backup and are restored on import. Existing schema-1 backups remain importable.
- Room database upgraded from version 1 to 2 with a non-destructive migration for media-block metadata.
- Writing reminders now use AlarmManager plus a WorkManager fallback, self-heal on app start, and re-register after reboot/app update/time changes.
- Added a direct Android precise-alarm settings action when exact alarm permission is unavailable.

## 0.3.1 — Writing input fixes
- Fixed a keyboard/IME edge case where typing a comma could be misread as Enter and create an unwanted blank paragraph.
- Periods typed at the end of a sentence now automatically receive one trailing space, while decimals and ellipses are left untouched.
- Kept the existing single-Enter → blank-line paragraph behavior.

## 0.3.0 — Personalization and navigation refinement
- Added a scale control in Theme. The current 0.2.0 sizing remains the 100% default; users can adjust it from 80% to 120%.
- Reduced the left drawer to half of the device width, enabled wrapped menu labels, and gave each menu item a subtle rounded frame/background.
- Unified Short/Long export into one “Save notes” action. Word and Memora backup now both support Short, Long, or Both plus Month/Year/All filters.
- Opening Memora through a writing notification now clears that notification so the launcher badge/dot is removed when no other notifications remain.
- Removed the launcher artwork from the Android system splash; the custom supplied Memora launch artwork remains as the branded opening screen.
- Pressing Enter once in either editor inserts a blank line between paragraphs.
- Monthly statistics notifications now include a localized support message and a one-tap Copy action for the support card number.
- Backup settings now preserve the custom UI scale when a full backup is exported.

## 0.2.0 — UI refinement
- Reduced the writing screens by about 10% and the rest of the app UI by about 20% for a calmer, denser layout.
- Added safe system-bar/cutout insets so controls no longer collide with the device status/navigation areas.
- Made note titles mandatory during normal editing/exit, with localized inline guidance.
- Reworked the Long Note editor into a wide, continuous, borderless writing canvas.
- Kept autosave behavior once a valid title is present.

## 0.1.0 — Initial test build and build fixes
- Short Notes with a 50-word soft limit.
- Long Notes without a writing limit.
- Autosave, reading mode, edit mode and safe multi-select deletion.
- Rich text: bold, italic, underline, strikethrough and quote.
- Saved title presets and search by title/body.
- Word export and Memora backup/import with duplicate protection.
- Daily writing reminders with Short/Long notification actions.
- Monthly and yearly writing-statistics notifications.
- English, Russian and Uzbek UI.
- Theme palettes, app/writing fonts, Light/Dark/System modes.
- Device biometric/credential app lock.
- User-supplied adaptive icon and branded launch screen.
- GitHub Actions debug build and signed-release workflow.
- Kotlin/Compose/Gradle compatibility and lint fixes used during the first GitHub builds.

## 0.3.2
- Replaced the rich-text Android EditText editor with a plain Compose text editor to stop IME/autocorrect updates from creating stray underlines or paragraphs.
- Removed the Bold, Italic, Underline, Strikethrough and Quote toolbar from both note editors.
- Paragraph spacing now reacts only to a verified Enter insertion; commas and normal letters are never transformed.
- Sentence-ending period helper is isolated from IME composing updates.
- App-lock timeout now survives Activity/process recreation by persisting the last background timestamp; a 5-minute setting no longer re-locks after only a few seconds.
- Removed the small top-right “Memora” label from the home screen.
