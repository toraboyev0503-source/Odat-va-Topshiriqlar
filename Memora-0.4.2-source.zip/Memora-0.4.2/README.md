# Memora 0.4.2

Memora is a local-first Android writing app for short and long daily notes. The 0.4.2 build keeps the media-note and reminder features from 0.4.1 and changes Word export into a portable package: a ZIP containing the Word document plus a sibling `Audio/` folder. Audio markers inside Word are real hyperlinks to the matching `.m4a` files, while images remain embedded directly in the document.

## Technology

- Kotlin
- Jetpack Compose + Material 3
- Room database
- DataStore preferences
- Android BiometricPrompt / device credentials
- AlarmManager reminders and statistics schedules
- Local `.memora` backup/import
- Word export package (`.zip` containing `.docx` + `Audio/`)
- English, Russian and Uzbek UI
- Light/Dark/System mode, five curated palettes, UI/writing font choices, and 80–120% interface scaling

Memora does not require a server or an internet connection for normal use.

## GitHub Actions — debug APK

The included `.github/workflows/main.yml` can build either:

1. an extracted Android project in the repository, or
2. a Memora source ZIP stored in the repository root.

If you keep the project as one source ZIP, the workflow file itself must still exist at:

`.github/workflows/main.yml`

GitHub cannot discover a workflow that exists only inside another ZIP.

The debug workflow:

- checks out the repository;
- locates/unpacks the source;
- installs JDK 17;
- installs Gradle 8.13;
- installs Android SDK 36;
- runs `testDebugUnitTest`;
- runs `lintDebug`;
- runs `assembleDebug`;
- uploads `app-debug.apk` as an artifact.

Debug application ID: `com.memora.app.debug`

Release application ID: `com.memora.app`

## Local / Android Studio build

The project includes `gradlew`, `gradlew.bat`, and a small bootstrap wrapper JAR. The bootstrap downloads the verified Gradle 8.13 binary distribution on first use and checks its official SHA-256 checksum.

Examples:

```bash
./gradlew testDebugUnitTest
./gradlew lintDebug
./gradlew assembleDebug
```

## Signed release

`.github/workflows/release.yml` is intentionally manual. It expects these GitHub Secrets:

- `MEMORA_KEYSTORE_BASE64`
- `MEMORA_KEYSTORE_PASSWORD`
- `MEMORA_KEY_ALIAS`
- `MEMORA_KEY_PASSWORD`

Keep the original release keystore permanently. Future Memora updates must use the same signing key.

## Version

- `versionName`: `0.4.2`
- `versionCode`: `8`

## Privacy and backup

Notes are stored locally in Room. Android automatic cloud/device backup is disabled for Memora's private data. Use Memora's own backup export when moving data to another phone.

A combined Memora backup preserves note type, title, text/media blocks, images, audio, creation/edit timestamps, saved titles, reminders, language, theme, palette, fonts and app-lock preference. During import, a note is skipped as a duplicate only when its title, body and creation timestamp all match an existing note.


## 0.4.1 test-update signing

Debug APKs are signed with the bundled `app/keystore/memora-test-debug.jks`. This key is **test-only** and intentionally stable so subsequent GitHub Actions debug APKs can be installed over the previous Memora debug APK without deleting app data.

Test signing certificate SHA-256: `77:2D:4A:04:10:F9:19:FD:0F:E2:77:DA:5E:DC:F4:92:10:25:DD:EC:3E:31:A0:71:D0:9A:79:DD:C8:17:FD:33`. Future debug builds must keep this same test key.

Because builds before 0.4.1 used GitHub runner-generated debug keys, upgrading from 0.4.0 (or older) to 0.4.1 may require **one final uninstall/reinstall**. From 0.4.1 onward, keep this test keystore unchanged and increase `versionCode`; debug APK updates will then install over the previous debug version. Production releases must use a separate private release key through GitHub Secrets.

## Camera images

The image button in both Short and Long editors now offers **Camera** or **Gallery**. Camera photos are captured through Android's FileProvider into a private temporary file, then imported into Memora's private media storage and participate in preview, backup and Word export like gallery images.

## Word + audio export

When **Word** is selected, Memora saves a ZIP package rather than a standalone DOCX. Extract the ZIP first. Its contents are:

- `Memora-....docx` — text and images, with each audio block shown as a blue underlined `▶` hyperlink;
- `Audio/` — the original `.m4a` recordings;
- `README.txt` — localized instructions.

Keep the Word file and the `Audio` folder together. Microsoft Word and other viewers may apply their own security rules to local file links, especially on mobile. If a viewer blocks the hyperlink, the same audio file remains directly playable from the `Audio` folder. Memora backup remains the authoritative format for restoring notes with fully playable media inside Memora.
