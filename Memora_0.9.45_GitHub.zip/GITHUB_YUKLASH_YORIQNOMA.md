## Memora 0.9.45 — Android matn tanlash menyusi tuzatildi (21.11.2026)

- 0.9.44 dagi xato: Android «Nusxa olish / Geminidan so‘rash / …» kontekst menyusi Memora oynasi o‘rnida ochilgan.
- Sabab: avvalgi implementatsiya faqat `LocalTextToolbar`ni almashtirgan, ammo Compose Foundation 1.9+ yangi `LocalTextContextMenuToolbarProvider`/`DropdownProvider`dan foydalanadi.
- Yangi versiyada ikkala Compose API to‘sildi; Memora menyusi endi `TextFieldValue.selection` va `TextLayoutResult`dan mustaqil hisoblanadi.
- Tanlash dastagi (handles) saqlanadi; ko‘rinadigan panelda faqat **Nusxalash / Rasm / Marker** (oldingi bo‘yalgan matnda **X + 3 rang**).
- Qo‘shimcha o‘zgarish yo‘q: Room 9, backup, marker rangini saqlash va ulashish mexanizmi o‘z holida.
- Tekshiruv: manba regressiyasi / sintaksis; Android APK kompilyatsiya va telefonda sinov alohida GitHub build bosqichida bajariladi.

# Memora 0.9.44 — GitHub yuklash va build yo‘riqnomasi

**Hozircha GitHub’ga hech narsa yuklanmaydi.** Bu paket faqat manba ZIP va alohida YAML; APK hali yig‘ilmagan.

1. Foydalanuvchi build qilishga alohida buyruq bergandan so‘ng, `Memora_0.9.45_GitHub.zip` faylini GitHub repozitori asosiy katalogiga yuklang.
2. Alohida `android-build_0.9.45.yml` faylini `.github/workflows/main.yml` yo‘liga (yoki bitta alohida workflow yo‘liga) qo‘ying. ZIP ichida shu mazmun `.github/workflows/android-build.yml` bo‘lib turadi. Ikkita bir xil workflow’ni bir vaqtda ishga tushirish shart emas.
3. Workflow Java 17, Android API 36, mavjud Billing testlari, `tools/regression_0945.py`, unit testlar, lint va `assembleDebug` jarayonlarini bajaradi.
4. Sinov muvaffaqiyatli yakunlansa, `Memora-0.9.45-debug-apk` artefaktini yuklab oling. 0.9.43 debug APK ustiga yangilash uchun paket identifikatori va test imzosi o‘zgartirilmagan.
5. Telefon sinovida H-01–H-09, uzun bosish, marker ustiga bosish, 2/3 qatorlik mini-karta, juda uzun matn, ZIP orqali ko‘p rasmni saqlash va eski highlightlarni tekshiring.

Versiya **0.9.44**, `versionCode 65`, Room **9**. Android APK kompilyatsiyasi mazkur manba tayyorlash bosqichida bajarilmagan.
