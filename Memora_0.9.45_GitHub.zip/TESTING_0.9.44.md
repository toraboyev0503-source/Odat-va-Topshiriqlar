# Memora 0.9.44 — qabul tekshiruvlari

1. 0.9.43 APK ustiga 0.9.44 o‘rnatilganda eski qaydlar, highlight va audiolar o‘z joyida qolishi kerak.
2. Reader’da matnni uzoq bosib tanlang: Android «Hammasini belgilash / Nusxa olish» oynasi chiqmasin; faqat «Nusxalash / Rasm / Marker» Memora kapsulasi chiqsin.
3. Qisman tanlangan matn «Nusxalash» bilan clipboard’ga aynan tushsin.
4. Markerga bir marta bosilganda sariq default qo‘llansin; keyin markerga uzoq bosib yashil tanlang. Boshqa matnda bir marta Marker bosilganda yashil ishlasin; ilovani qayta ochganda ham default yashil bo‘lsin.
5. Bo‘yalgan matnga bir marta teging: belgilash to‘liq aynan o‘sha rangli parchani qamrasin, X va uch rang ko‘rinsin. Pushti tanlansa rang almashsin; X bosilsa rang yo‘qolsin, qalin/kursiv o‘zgarmasin.
6. 2–3 satrni tanlab «Rasm» qiling: karta ixcham, oq joyi me’yorida, ichki oraliqlari muvozanatli; pastda haqiqiy Memora ikonchasi + Memora bo‘lsin.
7. O‘rta/uzun matnni «Rasm» qiling: satrlar kesilmasin; ko‘p sahifada barcha sahifani ko‘ring, ulashing va ZIP ko‘rinishida saqlang. Saqlangan fayllarni boshqa ilovada ochib ko‘ring.
8. Butun qaydni PNG va PDF formatida ulashing: footerda aynan ilova ikonchasi va Memora yozuvi, o‘ngda sahifa raqami chiqsin.
9. Reader’da tepada faqat orqaga va qalam qolishi, lupa va qidiruv paneli bo‘lmasligi kerak. Tahrirlash, avtosaqlash, status panel harakati va pastki amallar regressiya bermasin.
10. Qorong‘i rejim, katta shriftlar, RTL, 13 ta til, gesture navigatsiya va keyboard bilan tekshiring.

**Mahalliy kod nazorati:** `python3 tools/regression_0944.py` va JVM testlar. **Qurilmada tasdiqlash:** GitHub’dan muvaffaqiyatli APK olingach.
