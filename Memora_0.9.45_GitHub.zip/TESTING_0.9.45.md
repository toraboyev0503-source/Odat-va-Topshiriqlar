# Memora 0.9.45 — Native selection menu regression test

## What failed in 0.9.44

On the physical Android phone the long-press action in Reader still opened the OS toolbar
(`Nusxa olish`, `Geminidan so‘rash`, overflow). The old implementation replaced only
`LocalTextToolbar`, but newer Compose Foundation uses `LocalTextContextMenuToolbarProvider`.

## Expected behavior to verify on the real device

1. Open a note in Reader; long-press and drag-select a phrase. **Only** a Memora popup with
   **Nusxalash / Rasm / Marker** is visible. No Android `Ask Gemini`, `Select all`, overflow,
   or second context toolbar appears. Native text selection handles remain usable.
2. Copy selected text. Verify clipboard contains exactly selected text and selection is cleared.
3. Select a short phrase and tap `Rasm`. Verify preview height fits text with no oversized bottom gap.
4. Tap `Marker`, verify the current default color is applied. Long-press `Marker`, choose another
   color, then mark a new phrase: the newly selected color must remain the default.
5. Tap an existing highlighted phrase. Verify the entire run is selected and the quick popup
   offers `X + yellow/green/rose`. Test changing color and removing the highlight with `X`.
6. Test selection near the screen top, bottom, during scroll, and in dark theme.
7. Restart Memora; verify saved marker color remains and note content is unchanged.
8. Verify keyboard editing, backup, sharing, and other screens retain normal behavior.

## Verification status

The source-contract regression checks the two context-menu providers and selection-driven
Memora popup. Android compilation and on-device GUI regression are **not yet executed**.
