package com.habitcore.app.domain

import com.habitcore.app.data.TaskPlanEntity
import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.LocalDate

class TaskScoringTest {
    @Test
    fun dailyScoreIsCompletedOverPlanned() {
        val day = LocalDate.of(2026, 8, 21)
        val plans = (1L..10L).map { id ->
            TaskPlanEntity(taskId = id, epochDay = day.toEpochDay(), completed = id <= 7L)
        }
        assertEquals(70, TaskScoring.percent(TaskScoring.dailyScore(day, plans)))
    }

    @Test
    fun daysWithoutPlansAreExcludedFromPeriodAverage() {
        val d1 = LocalDate.of(2026, 8, 20)
        val d2 = LocalDate.of(2026, 8, 21)
        val d3 = LocalDate.of(2026, 8, 22)
        val plans = listOf(
            TaskPlanEntity(1L, d1.toEpochDay(), true),
            TaskPlanEntity(2L, d1.toEpochDay(), false),
            TaskPlanEntity(3L, d2.toEpochDay(), true)
        )
        assertEquals(75, TaskScoring.percent(TaskScoring.periodScore(listOf(d1, d2, d3), plans)))
    }

    @Test
    fun planFromAnotherDayDoesNotAffectToday() {
        val yesterday = LocalDate.of(2026, 8, 22)
        val today = LocalDate.of(2026, 8, 23)
        val plans = listOf(
            TaskPlanEntity(1L, yesterday.toEpochDay(), false),
            TaskPlanEntity(2L, today.toEpochDay(), true)
        )
        assertEquals(100, TaskScoring.percent(TaskScoring.dailyScore(today, plans)))
        assertEquals(0, TaskScoring.percent(TaskScoring.dailyScore(yesterday, plans)))
    }
}
