package com.habitcore.app.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Sort
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.habitcore.app.data.HabitEntity
import com.habitcore.app.data.HabitEntryEntity
import com.habitcore.app.domain.HabitType
import com.habitcore.app.domain.Schedule
import com.habitcore.app.domain.ScoreCalculator
import kotlinx.coroutines.Job
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

private enum class HabitSort { MANUAL, NAME, COLOR, SCORE }
private data class EntryTarget(val habit: HabitEntity, val day: LocalDate, val origin: Offset)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HabitsScreen(
    vm: AppViewModel,
    onTab: (MainTab) -> Unit,
    onCreate: () -> Unit,
    onEditHabit: (HabitEntity) -> Unit,
    onMonitoring: () -> Unit
) {
    val habits by vm.habits.collectAsState()
    val entries by vm.entries.collectAsState()
    val prefs by vm.prefs.collectAsState()
    val lang = prefs.language
    val today = LocalDate.now()

    // Today first, then yesterday and the previous 3 days.
    val days = remember(today) { (0..4).map { today.minusDays(it.toLong()) } }

    var sort by remember { mutableStateOf(HabitSort.MANUAL) }
    var sortMenu by remember { mutableStateOf(false) }
    var entryTarget by remember { mutableStateOf<EntryTarget?>(null) }
    var actionHabit by remember { mutableStateOf<HabitEntity?>(null) }
    var deleteHabitTarget by remember { mutableStateOf<HabitEntity?>(null) }
    var confettiOrigin by remember { mutableStateOf<Offset?>(null) }
    var showResolvedToday by remember { mutableStateOf(false) }
    var manualOrderIds by remember { mutableStateOf<List<Long>>(emptyList()) }
    var dragging by remember { mutableStateOf(false) }

    val active = remember(habits) {
        habits.filter {
            it.archivedEpochDay == null &&
                it.deletedEpochDay == null
        }
    }

    val persistedManual = remember(active) {
        active.sortedWith(
            compareBy<HabitEntity> { it.sortOrder }
                .thenBy { it.id }
        )
    }

    LaunchedEffect(persistedManual.map { it.id }) {
        if (!dragging) {
            val persistedIds = persistedManual.map { it.id }
            val retained = manualOrderIds.filter { it in persistedIds }
            val missing = persistedIds.filterNot { it in retained }
            manualOrderIds = retained + missing
        }
    }

    val activeById = remember(active) {
        active.associateBy { it.id }
    }

    val effectiveManualIds = remember(
        manualOrderIds,
        persistedManual
    ) {
        val persistedIds = persistedManual.map { it.id }
        val retained = manualOrderIds.filter { it in persistedIds }
        retained + persistedIds.filterNot { it in retained }
    }

    val manualHabits = remember(
        effectiveManualIds,
        activeById
    ) {
        effectiveManualIds.mapNotNull { activeById[it] }
    }

    val entriesByHabit = remember(entries) {
        entries.groupBy { it.habitId }
    }

    val completionStats = remember(active, entriesByHabit, today) {
        active.associate { habit ->
            habit.id to Schedule.completionStats(
                habit,
                today,
                entriesByHabit[habit.id].orEmpty()
            )
        }
    }

    val sortedHabits = when (sort) {
        HabitSort.MANUAL -> manualHabits
        HabitSort.NAME -> active.sortedBy { it.name.lowercase() }
        HabitSort.COLOR -> active.sortedBy { it.colorArgb }
        HabitSort.SCORE -> active.sortedByDescending { habit ->
            val (done, expected) = completionStats[habit.id]
                ?: (0.0 to 0.0)
            if (expected == 0.0) 1.0 else done / expected
        }
    }

    val resolvedTodayIds = remember(entries, today, active) {
        val activeIds = active.map { it.id }.toSet()
        entries.asSequence()
            .filter { entry ->
                entry.habitId in activeIds &&
                    entry.epochDay == today.toEpochDay() &&
                    (entry.status == "DONE" || entry.status == "FAILED")
            }
            .map { it.habitId }
            .toSet()
    }

    val displayed = if (showResolvedToday) {
        sortedHabits
    } else {
        sortedHabits.filterNot { it.id in resolvedTodayIds }
    }

    val todayPercent = ScoreCalculator.percent(
        Schedule.dailyScore(today, active, entries)
    )

    fun moveHabitRelative(
        draggedId: Long,
        targetId: Long,
        placeAfterTarget: Boolean
    ) {
        if (sort != HabitSort.MANUAL || draggedId == targetId) return

        val current = manualOrderIds
            .ifEmpty { effectiveManualIds }
            .toMutableList()

        if (!current.remove(draggedId)) return

        val targetIndex = current.indexOf(targetId)
        if (targetIndex < 0) return

        val insertIndex = (
            targetIndex + if (placeAfterTarget) 1 else 0
        ).coerceIn(0, current.size)

        current.add(insertIndex, draggedId)
        manualOrderIds = current
    }

    Box(Modifier.fillMaxSize()) {
        ThemeBackdrop(Modifier.fillMaxSize())
        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                TopAppBar(
                    title = { Text(tr(lang, "habits"), style = MaterialTheme.typography.titleLarge) },
                    actions = {
                        TextButton(onClick = onMonitoring) {
                            Text(
                                "${tr(lang, "today")} $todayPercent%",
                                color = performanceColor(todayPercent),
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        IconButton(onClick = onCreate) { Icon(Icons.Outlined.Add, null) }

                        if (resolvedTodayIds.isNotEmpty()) {
                            IconButton(onClick = { showResolvedToday = !showResolvedToday }) {
                                Icon(
                                    imageVector = if (showResolvedToday) Icons.Outlined.VisibilityOff else Icons.Outlined.Visibility,
                                    contentDescription = if (showResolvedToday) tr(lang, "hideResolved") else tr(lang, "showResolved")
                                )
                            }
                        }

                        Box {
                            IconButton(onClick = { sortMenu = true }) { Icon(Icons.Outlined.Sort, null) }
                            DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                                DropdownMenuItem(text = { Text(tr(lang, "sortManual")) }, onClick = { sort = HabitSort.MANUAL; sortMenu = false })
                                DropdownMenuItem(text = { Text(tr(lang, "sortName")) }, onClick = { sort = HabitSort.NAME; sortMenu = false })
                                DropdownMenuItem(text = { Text(tr(lang, "sortColor")) }, onClick = { sort = HabitSort.COLOR; sortMenu = false })
                                DropdownMenuItem(text = { Text(tr(lang, "sortScore")) }, onClick = { sort = HabitSort.SCORE; sortMenu = false })
                            }
                        }
                    }
                )
            },
            bottomBar = { AppBottomBar(MainTab.HABITS, lang, onTab) }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                DayHeader(days)
                if (displayed.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(tr(lang, "empty"), style = MaterialTheme.typography.titleMedium)
                            Text(tr(lang, "tapPlus"), color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp))
                        }
                    }
                } else {
                    ReorderableHabitList(
                        habits = displayed,
                        dragEnabled = sort == HabitSort.MANUAL,
                        days = days,
                        entriesByHabit = entriesByHabit,
                        completionStats = completionStats,
                        today = today,
                        onDraggingChanged = { dragging = it },
                        onMove = ::moveHabitRelative,
                        onCommit = { vm.reorderHabits(manualOrderIds.ifEmpty { effectiveManualIds }) },
                        onHabitClick = { actionHabit = it },
                        onDayTap = { habit, day, origin -> entryTarget = EntryTarget(habit, day, origin) }
                    )
                }
            }
        }
        confettiOrigin?.let { origin ->
            ConfettiBurst(origin = origin, onFinished = { confettiOrigin = null })
        }
    }

    entryTarget?.let { target ->
        EntryDialog(
            vm = vm,
            target = target,
            entries = entries,
            lang = lang,
            celebration = prefs.celebration,
            onCelebration = { confettiOrigin = target.origin },
            onDismiss = { entryTarget = null }
        )
    }

    actionHabit?.let { habit ->
        AlertDialog(
            onDismissRequest = { actionHabit = null },
            title = { Text(habit.name) },
            text = {
                Column {
                    TextButton(
                        onClick = {
                            actionHabit = null
                            onEditHabit(habit)
                        }
                    ) {
                        Text(tr(lang, "edit"))
                    }

                    TextButton(
                        onClick = {
                            vm.setPaused(
                                habit.id,
                                !habit.paused
                            )
                            actionHabit = null
                        }
                    ) {
                        Text(
                            if (habit.paused) {
                                tr(lang, "resume")
                            } else {
                                tr(lang, "pause")
                            }
                        )
                    }

                    TextButton(
                        onClick = {
                            vm.archiveHabit(
                                habit.id,
                                today.toEpochDay()
                            )
                            actionHabit = null
                        }
                    ) {
                        Text(tr(lang, "archive"))
                    }

                    TextButton(
                        onClick = {
                            deleteHabitTarget = habit
                            actionHabit = null
                        }
                    ) {
                        Icon(
                            Icons.Outlined.DeleteOutline,
                            null,
                            tint = MaterialTheme.colorScheme.error
                        )
                        Text(
                            tr(lang, "deleteHabit"),
                            color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.padding(start = 6.dp)
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { actionHabit = null }) {
                    Text(tr(lang, "done"))
                }
            }
        )
    }

    deleteHabitTarget?.let { habit ->
        AlertDialog(
            onDismissRequest = { deleteHabitTarget = null },
            title = { Text(tr(lang, "deleteHabit")) },
            text = {
                Text(tr(lang, "deleteHabitConfirm"))
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        vm.deleteHabit(
                            habit.id,
                            today.toEpochDay()
                        )
                        deleteHabitTarget = null
                    }
                ) {
                    Text(
                        tr(lang, "delete"),
                        color = MaterialTheme.colorScheme.error
                    )
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { deleteHabitTarget = null }
                ) {
                    Text(tr(lang, "cancel"))
                }
            }
        )
    }

}

@Composable
private fun ReorderableHabitList(
    habits: List<HabitEntity>,
    dragEnabled: Boolean,
    days: List<LocalDate>,
    entriesByHabit: Map<Long, List<HabitEntryEntity>>,
    completionStats: Map<Long, Pair<Double, Double>>,
    today: LocalDate,
    onDraggingChanged: (Boolean) -> Unit,
    onMove: (Long, Long, Boolean) -> Unit,
    onCommit: () -> Unit,
    onHabitClick: (HabitEntity) -> Unit,
    onDayTap: (HabitEntity, LocalDate, Offset) -> Unit
) {
    val listState = rememberLazyListState()
    var draggedHabitId by remember { mutableStateOf<Long?>(null) }
    var draggedOffset by remember { mutableFloatStateOf(0f) }
    var autoScrollJob by remember { mutableStateOf<Job?>(null) }
    val indexById = remember(habits) {
        habits.mapIndexed { index, habit -> habit.id to index }.toMap()
    }

    fun finishDrag() {
        autoScrollJob?.cancel()
        autoScrollJob = null
        if (draggedHabitId != null) {
            onCommit()
        }
        draggedHabitId = null
        draggedOffset = 0f
        onDraggingChanged(false)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        state = listState
    ) {
        itemsIndexed(
            items = habits,
            key = { _, habit -> habit.id },
            contentType = { _, _ -> "habit" }
        ) { _, habit ->
            val isDragging = draggedHabitId == habit.id
            val (completed, expected) = completionStats[habit.id]
                ?: (0.0 to 0.0)

            val placementModifier = if (isDragging) {
                Modifier
            } else {
                Modifier.animateItem(
                    fadeInSpec = null,
                    placementSpec = tween(durationMillis = 140),
                    fadeOutSpec = null
                )
            }

            HabitRow(
                habit = habit,
                days = days,
                entries = entriesByHabit[habit.id].orEmpty(),
                today = today,
                completed = completed,
                expected = expected,
                modifier = placementModifier
                    .zIndex(if (isDragging) 2f else 0f)
                    .graphicsLayer {
                        translationY = if (isDragging) {
                            draggedOffset
                        } else {
                            0f
                        }
                        shadowElevation = if (isDragging) 10f else 0f
                    }
                    .pointerInput(habit.id, dragEnabled) {
                        if (!dragEnabled) return@pointerInput

                        detectDragGesturesAfterLongPress(
                            onDragStart = {
                                draggedHabitId = habit.id
                                draggedOffset = 0f
                                onDraggingChanged(true)
                            },
                            onDragCancel = {
                                finishDrag()
                            },
                            onDragEnd = {
                                finishDrag()
                            },
                            onDrag = { change, dragAmount ->
                                change.consume()

                                val draggedId = draggedHabitId
                                if (draggedId != null) {
                                    val currentIndex = indexById[draggedId] ?: -1

                                    if (currentIndex >= 0) {
                                        draggedOffset += dragAmount.y

                                        val layoutInfo = listState.layoutInfo
                                        val currentInfo = layoutInfo.visibleItemsInfo
                                            .firstOrNull {
                                                it.index == currentIndex
                                            }

                                        if (currentInfo != null) {
                                            val draggedCenter = currentInfo.offset +
                                                draggedOffset +
                                                currentInfo.size / 2f

                                            val targetInfo = layoutInfo.visibleItemsInfo
                                                .asSequence()
                                                .filter {
                                                    it.index != currentIndex &&
                                                        it.index in habits.indices
                                                }
                                                .firstOrNull { item ->
                                                    draggedCenter >= item.offset &&
                                                        draggedCenter <= item.offset + item.size
                                                }

                                            if (targetInfo != null) {
                                                val targetIndex = targetInfo.index
                                                val offsetCorrection =
                                                    currentInfo.offset - targetInfo.offset

                                                val targetId = habits
                                                    .getOrNull(targetIndex)
                                                    ?.id

                                                if (targetId != null) {
                                                    onMove(
                                                        draggedId,
                                                        targetId,
                                                        targetIndex > currentIndex
                                                    )
                                                    draggedOffset +=
                                                        offsetCorrection.toFloat()
                                                }
                                            }

                                            val edge = 88f
                                            val draggedTop =
                                                currentInfo.offset + draggedOffset
                                            val draggedBottom =
                                                draggedTop + currentInfo.size
                                            val scrollDelta = when {
                                                draggedTop <
                                                    layoutInfo.viewportStartOffset + edge -> -26f

                                                draggedBottom >
                                                    layoutInfo.viewportEndOffset - edge -> 26f

                                                else -> 0f
                                            }

                                            if (
                                                scrollDelta != 0f &&
                                                autoScrollJob?.isActive != true
                                            ) {
                                                autoScrollJob = scope.launch {
                                                    listState.scrollBy(scrollDelta)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        )
                    },
                onHabitClick = {
                    if (draggedHabitId == null) {
                        onHabitClick(habit)
                    }
                },
                onDayTap = { day, origin ->
                    if (draggedHabitId == null) {
                        onDayTap(habit, day, origin)
                    }
                }
            )
        }
    }
}

@Composable
private fun DayHeader(days: List<LocalDate>) {
    val headerHeight = if (appCompact()) 46.dp else 52.dp

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(headerHeight)
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.32f)),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Spacer(Modifier.width(188.dp))
        days.forEach { day ->
            Column(
                Modifier.width(38.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    day.dayOfWeek
                        .getDisplayName(TextStyle.SHORT, Locale.ENGLISH)
                        .take(2)
                        .uppercase(),
                    fontSize = 9.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(day.dayOfMonth.toString(), fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun HabitRow(
    habit: HabitEntity,
    days: List<LocalDate>,
    entries: List<HabitEntryEntity>,
    today: LocalDate,
    completed: Double,
    expected: Double,
    modifier: Modifier = Modifier,
    onHabitClick: () -> Unit,
    onDayTap: (LocalDate, Offset) -> Unit
) {
    val habitColor = Color(habit.colorArgb)
    val rate = if (expected <= 0.0) 1.0 else completed / expected
    val countColor = if (rate < 0.5) Color(0xFFC83D3D) else habitColor
    val rowHeight = if (appCompact()) 56.dp else 64.dp

    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(rowHeight)
            .background(MaterialTheme.colorScheme.surface)
            .border(
                appBorderWidth().coerceAtMost(1.5.dp),
                MaterialTheme.colorScheme.outlineVariant
            ),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            modifier = Modifier
                .width(188.dp)
                .padding(horizontal = 8.dp)
                .clickable(onClick = onHabitClick),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .border(1.4.dp, countColor, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    formatCount(completed),
                    fontSize = 10.sp,
                    color = countColor,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Text(
                habit.name,
                modifier = Modifier
                    .padding(start = 8.dp)
                    .weight(1f),
                fontSize = 13.sp,
                color = if (habit.paused) {
                    MaterialTheme.colorScheme.onSurfaceVariant
                } else {
                    habitColor
                },
                maxLines = 2
            )
        }

        days.forEach { day ->
            val scheduled = Schedule.isScheduled(habit, day, entries)
            val entry = entries.firstOrNull {
                it.habitId == habit.id && it.epochDay == day.toEpochDay()
            }

            DayCell(
                habit = habit,
                day = day,
                entry = entry,
                enabled = scheduled && !day.isAfter(today),
                onTap = onDayTap
            )
        }
    }
}

@Composable
private fun DayCell(
    habit: HabitEntity,
    day: LocalDate,
    entry: HabitEntryEntity?,
    enabled: Boolean,
    onTap: (LocalDate, Offset) -> Unit
) {
    var coords: LayoutCoordinates? by remember { mutableStateOf(null) }
    val color = Color(habit.colorArgb)
    val cellHeight = if (appCompact()) 56.dp else 64.dp

    Box(
        modifier = Modifier
            .width(38.dp)
            .height(cellHeight)
            .onGloballyPositioned { coords = it }
            .pointerInput(enabled, entry) {
                if (enabled) {
                    detectTapGestures { local ->
                        val root = coords?.positionInRoot() ?: Offset.Zero
                        onTap(day, root + local)
                    }
                }
            },
        contentAlignment = Alignment.Center
    ) {
        when {
            !enabled -> {
                Text("·", color = MaterialTheme.colorScheme.outlineVariant)
            }

            entry == null -> {
                Text(
                    "?",
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.65f),
                    fontSize = 13.sp
                )
            }

            habit.type == HabitType.MEASURABLE.name &&
                entry.score in 0.001..0.999 -> {
                Text(
                    "${(entry.score * 100).roundToInt()}",
                    color = color,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            entry.score >= 0.999 -> {
                Icon(
                    Icons.Outlined.Check,
                    null,
                    tint = color,
                    modifier = Modifier.size(18.dp)
                )
            }

            else -> {
                Icon(
                    Icons.Outlined.Close,
                    null,
                    tint = Color(0xFFC83D3D),
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
private fun EntryDialog(
    vm: AppViewModel,
    target: EntryTarget,
    entries: List<HabitEntryEntity>,
    lang: com.habitcore.app.domain.AppLanguage,
    celebration: Boolean,
    onCelebration: () -> Unit,
    onDismiss: () -> Unit
) {
    val existing = entries.firstOrNull {
        it.habitId == target.habit.id &&
            it.epochDay == target.day.toEpochDay()
    }

    var note by remember(existing) { mutableStateOf(existing?.note ?: "") }
    var value by remember(existing) {
        mutableStateOf(existing?.actualValue?.toString() ?: "")
    }

    if (target.habit.type == HabitType.MEASURABLE.name) {
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text(target.habit.name) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = value,
                        onValueChange = { value = it },
                        label = {
                            Text("${tr(lang, "value")} ${target.habit.unit.orEmpty()}")
                        },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = note,
                        onValueChange = { note = it },
                        label = { Text(tr(lang, "notes")) }
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val actual = value.toDoubleOrNull() ?: 0.0
                        val score = ScoreCalculator.measurableScore(
                            actual,
                            target.habit.target
                        )

                        vm.saveEntry(
                            HabitEntryEntity(
                                target.habit.id,
                                target.day.toEpochDay(),
                                if (score >= 0.999) "DONE" else "PARTIAL",
                                actual,
                                score,
                                note
                            )
                        )

                        if (celebration && score >= 0.999) {
                            onCelebration()
                        }

                        onDismiss()
                    }
                ) {
                    Text(tr(lang, "save"))
                }
            },
            dismissButton = {
                TextButton(onClick = onDismiss) {
                    Text(tr(lang, "cancel"))
                }
            }
        )
    } else {
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text(target.habit.name) },
            text = {
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text(tr(lang, "notes")) }
                )
            },
            confirmButton = {
                Row {
                    IconButton(
                        onClick = {
                            vm.saveEntry(
                                HabitEntryEntity(
                                    target.habit.id,
                                    target.day.toEpochDay(),
                                    "DONE",
                                    null,
                                    1.0,
                                    note
                                )
                            )
                            if (celebration) onCelebration()
                            onDismiss()
                        }
                    ) {
                        Icon(
                            Icons.Outlined.Check,
                            tr(lang, "done"),
                            tint = Color(target.habit.colorArgb)
                        )
                    }

                    IconButton(
                        onClick = {
                            vm.saveEntry(
                                HabitEntryEntity(
                                    target.habit.id,
                                    target.day.toEpochDay(),
                                    "FAILED",
                                    null,
                                    0.0,
                                    note
                                )
                            )
                            onDismiss()
                        }
                    ) {
                        Icon(
                            Icons.Outlined.Close,
                            tr(lang, "failed"),
                            tint = Color(0xFFC83D3D)
                        )
                    }

                    TextButton(
                        onClick = {
                            vm.clearEntry(
                                target.habit.id,
                                target.day.toEpochDay()
                            )
                            onDismiss()
                        }
                    ) {
                        Text("?")
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = onDismiss) {
                    Text(tr(lang, "cancel"))
                }
            }
        )
    }
}

@Composable
private fun ConfettiBurst(
    origin: Offset,
    onFinished: () -> Unit
) {
    val progress = remember { Animatable(0f) }

    LaunchedEffect(origin) {
        progress.snapTo(0f)
        progress.animateTo(1f, tween(850))
        onFinished()
    }

    val colors = listOf(
        Color(0xFF4E78A8),
        Color(0xFF4F7A5C),
        Color(0xFFC59A48),
        Color(0xFF8B5E6B),
        Color(0xFF6E82A3)
    )

    Canvas(Modifier.fillMaxSize()) {
        val p = progress.value

        repeat(22) { i ->
            val angle = (2.0 * PI * i / 22.0) + (i % 3) * 0.08
            val distance = 28f + 120f * p * (0.45f + (i % 5) * 0.11f)
            val x = origin.x + cos(angle).toFloat() * distance
            val y = origin.y + sin(angle).toFloat() * distance + 90f * p * p
            val alpha = (1f - p).coerceIn(0f, 1f)

            rotate(i * 17f + p * 120f, pivot = Offset(x, y)) {
                drawRect(
                    colors[i % colors.size].copy(alpha = alpha),
                    topLeft = Offset(x - 4f, y - 2f),
                    size = androidx.compose.ui.geometry.Size(8f, 4f)
                )
            }
        }
    }
}

private fun formatCount(value: Double): String {
    val rounded = value.roundToInt().toDouble()
    return if (kotlin.math.abs(value - rounded) < 0.05) {
        rounded.toInt().toString()
    } else {
        String.format(Locale.US, "%.1f", value)
    }
}
