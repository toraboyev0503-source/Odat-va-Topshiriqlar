@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.habitcore.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Archive
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.DateRange
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import com.habitcore.app.domain.AppLanguage
import java.time.LocalDate
import java.time.Period

@Composable
fun ProfileScreen(
    vm: AppViewModel,
    onTab: (MainTab) -> Unit,
    onTheme: () -> Unit,
    onLanguage: () -> Unit,
    onNotifications: () -> Unit,
    onArchive: () -> Unit,
    onSettings: () -> Unit,
    onReports: () -> Unit,
    onScheduled: () -> Unit,
    onAbout: () -> Unit
) {
    val prefs by vm.prefs.collectAsState()
    val lang = prefs.language
    var name by remember(prefs.userName) { mutableStateOf(prefs.userName) }
    var day by remember(prefs.birthDay) { mutableStateOf(prefs.birthDay?.toString().orEmpty()) }
    var month by remember(prefs.birthMonth) { mutableStateOf(prefs.birthMonth?.toString().orEmpty()) }
    var year by remember(prefs.birthYear) { mutableStateOf(prefs.birthYear?.toString().orEmpty()) }

    Box(Modifier.fillMaxSize()) {
        ThemeBackdrop(Modifier.fillMaxSize())
        Scaffold(
            containerColor = androidx.compose.ui.graphics.Color.Transparent,
            topBar = { TopAppBar(title = { Text(tr(lang, "profile")) }) },
            bottomBar = { AppBottomBar(MainTab.PROFILE, lang, onTab) }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = appShape(),
                    border = BorderStroke(appBorderWidth(), MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(tr(lang, "profile"), style = MaterialTheme.typography.titleLarge)
                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text(tr(lang, "name")) },
                            singleLine = true,
                            shape = appFieldShape()
                        )
                        Text(tr(lang, "birthDate"), style = MaterialTheme.typography.labelLarge)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            SmallNumberField(day, { day = it.filter(Char::isDigit).take(2) }, tr(lang, "day"), Modifier.weight(1f))
                            SmallNumberField(month, { month = it.filter(Char::isDigit).take(2) }, tr(lang, "month"), Modifier.weight(1f))
                            SmallNumberField(year, { year = it.filter(Char::isDigit).take(4) }, tr(lang, "year"), Modifier.weight(1.4f))
                        }
                        profileAge(day, month, year)?.let { age ->
                            Text("${tr(lang, "age")}: $age ${tr(lang, "years")}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                        }
                        Row(
                            Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(tr(lang, "birthdayGreeting"), modifier = Modifier.weight(1f))
                            Switch(
                                checked = prefs.birthdayGreetingEnabled,
                                onCheckedChange = { checked -> vm.updatePrefs { it.copy(birthdayGreetingEnabled = checked) } }
                            )
                        }
                        Button(
                            modifier = Modifier.fillMaxWidth(),
                            onClick = {
                                vm.updatePrefs {
                                    it.copy(
                                        userName = name.trim(),
                                        birthDay = day.toIntOrNull()?.coerceIn(1, 31),
                                        birthMonth = month.toIntOrNull()?.coerceIn(1, 12),
                                        birthYear = year.toIntOrNull()?.takeIf { y -> y in 1900..LocalDate.now().year }
                                    )
                                }
                            }
                        ) { Text(tr(lang, "save")) }
                    }
                }

                ProfileMenuRow(Icons.Outlined.Palette, tr(lang, "theme"), onTheme)
                ProfileMenuRow(Icons.Outlined.Language, tr(lang, "language"), onLanguage)
                ProfileMenuRow(Icons.Outlined.Notifications, tr(lang, "notifications"), onNotifications)
                ProfileMenuRow(Icons.Outlined.BarChart, tr(lang, "reports"), onReports)
                ProfileMenuRow(Icons.Outlined.DateRange, tr(lang, "scheduled"), onScheduled)
                ProfileMenuRow(Icons.Outlined.Archive, tr(lang, "archive"), onArchive)
                ProfileMenuRow(Icons.Outlined.Settings, tr(lang, "settings"), onSettings)
                ProfileMenuRow(Icons.Outlined.Info, tr(lang, "about"), onAbout)
                Spacer(Modifier.size(8.dp))
            }
        }
    }
}

@Composable
private fun SmallNumberField(value: String, onValueChange: (String) -> Unit, label: String, modifier: Modifier) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier,
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        shape = appFieldShape()
    )
}

@Composable
private fun ProfileMenuRow(icon: ImageVector, title: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = appShape(),
        border = BorderStroke(appBorderWidth(), MaterialTheme.colorScheme.outlineVariant)
    ) {
        Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(13.dp))
            Text(title, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
            Text("›", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private fun profileAge(day: String, month: String, year: String): Int? {
    val d = day.toIntOrNull() ?: return null
    val m = month.toIntOrNull() ?: return null
    val y = year.toIntOrNull() ?: return null
    val birth = runCatching { LocalDate.of(y, m, d) }.getOrNull() ?: return null
    if (birth.isAfter(LocalDate.now())) return null
    return Period.between(birth, LocalDate.now()).years
}
