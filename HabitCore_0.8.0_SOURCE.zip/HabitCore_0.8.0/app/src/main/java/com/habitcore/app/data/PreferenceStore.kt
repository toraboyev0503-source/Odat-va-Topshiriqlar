package com.habitcore.app.data

import android.content.Context
import com.habitcore.app.domain.AppLanguage
import com.habitcore.app.domain.AppMode
import com.habitcore.app.domain.AppPrefs
import com.habitcore.app.domain.ReminderSlot
import com.habitcore.app.domain.ThemeChoice

class PreferenceStore(context: Context) {
    private val sp = context.getSharedPreferences("habitcore_prefs", Context.MODE_PRIVATE)

    fun load(): AppPrefs = AppPrefs(
        language = enumValue(sp.getString("language", AppLanguage.EN.name), AppLanguage.EN),
        theme = themeValue(sp.getString("theme", ThemeChoice.MODERN_UNIVERSAL.name)),
        themeAccent = sp.getInt("themeAccent", 0).coerceIn(0, 3),
        mode = enumValue(sp.getString("mode", AppMode.SYSTEM.name), AppMode.SYSTEM),
        celebration = sp.getBoolean("celebration", true),
        notificationsEnabled = sp.getBoolean("notificationsEnabled", true),
        reminder1 = ReminderSlot(sp.getBoolean("r1Enabled", true), sp.getInt("r1Hour", 9), sp.getInt("r1Minute", 0)),
        reminder2 = ReminderSlot(sp.getBoolean("r2Enabled", true), sp.getInt("r2Hour", 14), sp.getInt("r2Minute", 0)),
        reminder3 = ReminderSlot(sp.getBoolean("r3Enabled", true), sp.getInt("r3Hour", 20), sp.getInt("r3Minute", 0)),
        resultDaily = sp.getBoolean("resultDaily", true),
        resultWeekly = sp.getBoolean("resultWeekly", true),
        resultMonthly = sp.getBoolean("resultMonthly", true),
        userName = sp.getString("userName", "").orEmpty(),
        birthDay = nullableInt("birthDay"),
        birthMonth = nullableInt("birthMonth"),
        birthYear = nullableInt("birthYear"),
        birthdayGreetingEnabled = sp.getBoolean("birthdayGreetingEnabled", true)
    )

    fun save(prefs: AppPrefs) {
        val editor = sp.edit()
            .putString("language", prefs.language.name)
            .putString("theme", prefs.theme.name)
            .putInt("themeAccent", prefs.themeAccent.coerceIn(0, 3))
            .putString("mode", prefs.mode.name)
            .putBoolean("celebration", prefs.celebration)
            .putBoolean("notificationsEnabled", prefs.notificationsEnabled)
            .putBoolean("r1Enabled", prefs.reminder1.enabled)
            .putInt("r1Hour", prefs.reminder1.hour)
            .putInt("r1Minute", prefs.reminder1.minute)
            .putBoolean("r2Enabled", prefs.reminder2.enabled)
            .putInt("r2Hour", prefs.reminder2.hour)
            .putInt("r2Minute", prefs.reminder2.minute)
            .putBoolean("r3Enabled", prefs.reminder3.enabled)
            .putInt("r3Hour", prefs.reminder3.hour)
            .putInt("r3Minute", prefs.reminder3.minute)
            .putBoolean("resultDaily", prefs.resultDaily)
            .putBoolean("resultWeekly", prefs.resultWeekly)
            .putBoolean("resultMonthly", prefs.resultMonthly)
            .putString("userName", prefs.userName)
            .putBoolean("birthdayGreetingEnabled", prefs.birthdayGreetingEnabled)

        putNullableInt(editor, "birthDay", prefs.birthDay)
        putNullableInt(editor, "birthMonth", prefs.birthMonth)
        putNullableInt(editor, "birthYear", prefs.birthYear)
        editor.apply()
    }

    private fun nullableInt(key: String): Int? = if (sp.contains(key)) sp.getInt(key, 0) else null

    private fun putNullableInt(editor: android.content.SharedPreferences.Editor, key: String, value: Int?) {
        if (value == null) editor.remove(key) else editor.putInt(key, value)
    }

    private fun themeValue(raw: String?): ThemeChoice {
        val migrated = when (raw) {
            // 0.5/0.6/0.7 theme codes -> closest new family.
            "GRAPHITE" -> ThemeChoice.MINIMAL_PREMIUM
            "SLATE" -> ThemeChoice.DARK_GLASS
            "FOREST" -> ThemeChoice.ORGANIC_CALM
            "NAVY" -> ThemeChoice.PRODUCTIVITY_PRO
            "SAND" -> ThemeChoice.SCANDINAVIAN_SOFT
            "BURGUNDY" -> ThemeChoice.DARK_GOLD_LUXE
            "MATERIAL" -> ThemeChoice.MODERN_UNIVERSAL
            "NEOBRUTAL" -> ThemeChoice.NEO_BRUTALIST
            "SOFT" -> ThemeChoice.SCANDINAVIAN_SOFT
            "MONO" -> ThemeChoice.EDITORIAL_MONO
            else -> null
        }
        if (migrated != null) return migrated
        return enumValue(raw, ThemeChoice.MODERN_UNIVERSAL)
    }

    private inline fun <reified T : Enum<T>> enumValue(value: String?, fallback: T): T =
        runCatching { enumValueOf<T>(value ?: fallback.name) }.getOrDefault(fallback)
}
