package com.habitcore.app.domain

import com.habitcore.app.data.TaskPlanEntity
import java.time.LocalDate
import kotlin.math.roundToInt

object TaskScoring {
    fun dailyScore(day: LocalDate, plans: List<TaskPlanEntity>): Double? {
        val dayPlans = plans.filter { it.epochDay == day.toEpochDay() }
        if (dayPlans.isEmpty()) return null
        return dayPlans.count { it.completed }.toDouble() / dayPlans.size.toDouble()
    }

    fun periodScore(days: List<LocalDate>, plans: List<TaskPlanEntity>): Double? {
        val scores = days.map { dailyScore(it, plans) }.filterNotNull()
        return if (scores.isEmpty()) null else scores.average()
    }

    fun percent(score: Double?): Int? =
        score?.let { (it.coerceIn(0.0, 1.0) * 100.0).roundToInt() }
}
