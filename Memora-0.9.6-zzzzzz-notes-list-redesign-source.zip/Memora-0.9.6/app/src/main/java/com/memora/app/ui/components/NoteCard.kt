package com.memora.app.ui.components

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.memora.app.data.local.NoteEntity
import com.memora.app.data.model.NoteBlock
import com.memora.app.data.model.NoteBlocksCodec
import com.memora.app.i18n.L
import com.memora.app.i18n.S
import com.memora.app.media.MediaStorage
import com.memora.app.prefs.AppLanguage
import com.memora.app.util.TextUtils
import com.memora.app.util.TimeUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import kotlin.math.max

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun NoteCard(
    note: NoteEntity,
    displayTitle: String,
    language: AppLanguage,
    selected: Boolean,
    previewLines: Int = 2,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onDeleteRequest: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val storage = remember(context) { MediaStorage(context) }
    val blocks = remember(note.blocksJson, note.plainText) {
        NoteBlocksCodec.decode(note.blocksJson, note.plainText)
    }
    val imageBlocks = remember(blocks) { blocks.filterIsInstance<NoteBlock.Image>() }
    val audioBlocks = remember(blocks) { blocks.filterIsInstance<NoteBlock.Audio>() }
    val imageCount = max(imageBlocks.size, if (note.hasImages) 1 else 0)
    val audioCount = max(audioBlocks.size, if (note.hasAudio) 1 else 0)
    val imageFiles = remember(imageBlocks, storage) {
        imageBlocks.mapNotNull { block ->
            runCatching { storage.resolve(block.relativePath) }.getOrNull()?.takeIf { it.isFile }
        }
    }
    val accent = remember(displayTitle) { titleAccentColor(displayTitle) }
    var menuExpanded by remember { mutableStateOf(false) }
    val cardShape = RoundedCornerShape(22.dp)

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .combinedClickable(onClick = onClick, onLongClick = onLongClick),
        shape = cardShape,
        color = if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.10f)
        else MaterialTheme.colorScheme.surface,
        border = if (selected) BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)) else null,
        shadowElevation = if (selected) 1.dp else 0.5.dp,
        tonalElevation = 0.dp
    ) {
        BoxWithConstraints(Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .width(5.dp)
                    .fillMaxHeight()
                    .background(accent)
            )

            val mediaWidth = when {
                maxWidth < 300.dp -> 82.dp
                maxWidth < 360.dp -> 104.dp
                else -> 126.dp
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 20.dp, end = 8.dp, top = 15.dp, bottom = 14.dp),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        text = displayTitle,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = TimeUtils.dateTime(note.createdAt, language),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(top = 2.dp)
                    )

                    if (note.plainText.isNotBlank()) {
                        Text(
                            text = TextUtils.preview(note.plainText),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = previewLines.coerceAtLeast(1),
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(top = 9.dp)
                        )
                    }

                    if (imageCount > 0 || audioCount > 0) {
                        Row(
                            modifier = Modifier.padding(top = 9.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (audioCount > 0) {
                                MediaCountBadge(
                                    icon = Icons.Rounded.Mic,
                                    count = audioCount
                                )
                            }
                            if (imageCount > 0) {
                                MediaCountBadge(
                                    icon = Icons.Rounded.Image,
                                    count = imageCount
                                )
                            }
                        }
                    }
                }

                if (imageFiles.isNotEmpty()) {
                    MediaPreviewGrid(
                        files = imageFiles,
                        totalCount = imageCount,
                        width = mediaWidth,
                        modifier = Modifier.padding(top = 3.dp)
                    )
                }

                Box {
                    IconButton(
                        onClick = { menuExpanded = true },
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(
                            Icons.Rounded.MoreVert,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    DropdownMenu(
                        expanded = menuExpanded,
                        onDismissRequest = { menuExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text(L.t(language, S.DELETE)) },
                            leadingIcon = {
                                Icon(Icons.Rounded.DeleteOutline, contentDescription = null)
                            },
                            onClick = {
                                menuExpanded = false
                                onDeleteRequest()
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MediaCountBadge(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    count: Int
) {
    Surface(
        shape = RoundedCornerShape(50),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.62f)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Icon(
                icon,
                contentDescription = null,
                modifier = Modifier.size(17.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = count.toString(),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun MediaPreviewGrid(
    files: List<File>,
    totalCount: Int,
    width: Dp,
    modifier: Modifier = Modifier
) {
    val shown = files.take(4)
    val height = 72.dp
    val gap = 3.dp
    val shape = RoundedCornerShape(12.dp)

    Box(
        modifier = modifier
            .width(width)
            .height(height)
            .clip(shape)
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.30f))
    ) {
        when (shown.size) {
            1 -> ThumbnailCell(shown[0], Modifier.fillMaxSize())
            2 -> Row(
                Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.spacedBy(gap)
            ) {
                ThumbnailCell(shown[0], Modifier.weight(1f).fillMaxHeight())
                ThumbnailCell(shown[1], Modifier.weight(1f).fillMaxHeight())
            }
            3 -> Row(
                Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.spacedBy(gap)
            ) {
                ThumbnailCell(shown[0], Modifier.weight(1f).fillMaxHeight())
                ThumbnailCell(shown[1], Modifier.weight(1f).fillMaxHeight())
                ThumbnailCell(shown[2], Modifier.weight(1f).fillMaxHeight())
            }
            else -> Column(
                Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(gap)
            ) {
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(gap)) {
                    ThumbnailCell(shown[0], Modifier.weight(1f).fillMaxHeight())
                    ThumbnailCell(shown[1], Modifier.weight(1f).fillMaxHeight())
                }
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(gap)) {
                    ThumbnailCell(shown[2], Modifier.weight(1f).fillMaxHeight())
                    Box(Modifier.weight(1f).fillMaxHeight()) {
                        ThumbnailCell(shown[3], Modifier.fillMaxSize())
                        if (totalCount > 4) {
                            Box(
                                Modifier
                                    .fillMaxSize()
                                    .background(Color(0x990E1720)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "+${totalCount - 4}",
                                    color = Color.White,
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ThumbnailCell(
    file: File,
    modifier: Modifier = Modifier
) {
    val key = remember(file.absolutePath, file.lastModified(), file.length()) {
        "${file.absolutePath}:${file.lastModified()}:${file.length()}"
    }
    val bitmap by produceState<Bitmap?>(initialValue = null, key1 = key) {
        value = withContext(Dispatchers.IO) { decodeThumbnail(file) }
    }

    Box(
        modifier = modifier.background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)),
        contentAlignment = Alignment.Center
    ) {
        bitmap?.let { loaded ->
            Image(
                bitmap = loaded.asImageBitmap(),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        }
    }
}

private fun decodeThumbnail(file: File): Bitmap? = runCatching {
    if (!file.exists() || file.length() <= 0L) return@runCatching null
    val bounds = BitmapFactory.Options().also { options ->
        options.inJustDecodeBounds = true
        BitmapFactory.decodeFile(file.absolutePath, options)
    }
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return@runCatching null
    var sample = 1
    val maxSide = max(bounds.outWidth, bounds.outHeight)
    while (maxSide / sample > 320) sample *= 2
    BitmapFactory.decodeFile(
        file.absolutePath,
        BitmapFactory.Options().apply {
            inSampleSize = sample.coerceAtLeast(1)
            inPreferredConfig = Bitmap.Config.RGB_565
            inDither = true
            inScaled = false
        }
    )
}.getOrNull()

private fun titleAccentColor(title: String): Color {
    val normalized = title
        .lowercase(Locale.ROOT)
        .replace('’', '\'')
        .trim()

    return when (normalized) {
        "kunim haqida" -> Color(0xFF4C9CF2)
        "o'zim haqimda" -> Color(0xFFF4AE2B)
        "kun savoli" -> Color(0xFF38CFA3)
        "kichik tikishlar" -> Color(0xFF8D68EB)
        else -> {
            val palette = listOf(
                Color(0xFF4C9CF2),
                Color(0xFFF4AE2B),
                Color(0xFF38CFA3),
                Color(0xFF8D68EB),
                Color(0xFFEF6680),
                Color(0xFF20BFC5),
                Color(0xFF7FA85B),
                Color(0xFFDA7B61)
            )
            palette[Math.floorMod(normalized.hashCode(), palette.size)]
        }
    }
}
