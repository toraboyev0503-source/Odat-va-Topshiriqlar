# Build notes — 0.1.2

Build-fix release.

- Migrated deprecated/erroring `android.kotlinOptions.jvmTarget = "17"` to the Kotlin `compilerOptions` DSL with `JvmTarget.JVM_17`.
- Pinned Compose core libraries to 1.11.4 and Material3 to 1.4.0 so the project remains compatible with compileSdk 36 + AGP 8.13.2.
- versionCode: 2
- versionName: 0.1.2

# Build notes — 0.1.0

Pre-package checks performed in the ChatGPT build environment:
- Android resource XML parsing: passed
- GitHub Actions YAML parsing: passed
- Kotlin source structural/bracket check: passed
- Pure Kotlin efficiency calculator compile/runtime smoke test: passed
- Workflow standalone copy matches the workflow inside the project: passed

A full Android Gradle `assembleDebug` was not executed in this container because it does not contain the Android SDK/Gradle dependency cache. The supplied GitHub Actions workflow is the first authoritative Android compile/lint/test run.


## 0.1.2 build fix
- Replaced manually versioned Compose artifacts with official Compose BOM 2026.06.00.
- material-icons-extended now resolves through the BOM (1.7.8) instead of invalid 1.11.4.
- GitHub workflow split into test, lint, and APK build steps for clearer failure logs.
