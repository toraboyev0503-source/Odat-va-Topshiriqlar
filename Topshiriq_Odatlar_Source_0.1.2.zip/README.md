# Topshiriq va odatlar — 0.1.2

Offline-first Android application written in Kotlin + Jetpack Compose.

## Core architecture
- Kotlin / Jetpack Compose UI
- Room 2.8.4 local database, schema export enabled
- No Firebase, server, login or internet dependency
- AlarmManager + local notifications for task deadlines and habit reminders
- Boot recovery + midnight rollover + app-start catch-up
- Three UI languages: English (default), Russian, Uzbek
- Four quiet palettes + light/dark mode
- Safe drawing insets and IME-aware task editor

## Habits
- Daily habits only
- Simple completion habits
- Quantity habits (minutes, repetitions, steps, pages, etc.)
- Daily quantity progress capped at 100% for overall efficiency while the real value is stored
- Per-habit streak, completion rate, 7/30 day averages, total and best-day statistics
- Optional daily local reminder
- Archive keeps history; delete removes history
- Goal history table preserves historical target meaning after target changes

## Tasks
- Priorities: Very important / Important / Later
- Pending `!` and completed `✓`; no visible X state
- 15-word soft warning; full text can expand
- Future tasks automatically appear in Planned and become visible on their date
- Pending tasks left at day end are recorded as MISSED and recreated for the next day
- Unique `(seriesId, scheduledEpochDay)` index prevents duplicate rollover rows
- Deadline notification: Done marks complete; Not done opens +1 hour rescheduling UI
- Completed/missed task history is kept in Archive

## Efficiency
- Habit score = average of all active habits for that date
- Task score = completed tasks / all tasks for that date
- Overall day score = equal average of habit and task scores
- If only one module has data, that module is the day score
- Year view shows 12 monthly averages; month view shows daily scores

## Build
The included GitHub workflow can build either an extracted project or a single source ZIP in the repository. It installs JDK 17, Android SDK 36, Gradle 8.13, then runs unit tests, lint and `assembleDebug`.

Note: GitHub cannot discover a workflow that exists only inside a ZIP. Put the separately supplied `Topshiriq_Odatlar_main.yml` at `.github/workflows/main.yml` in the repository once.

## Images
Version 0.1.2 uses a neutral placeholder launcher/splash visual. Replace it with the user-provided icon and opening artwork in the next revision without changing app data.
