# Memora 0.9.6 — Play Data safety working answers

This is a source-grounded preparation sheet for Play Console. Recheck the wording of the live form at submission time.

## Security practices

- Data encrypted in transit: **Yes** for the only developer-server request (HTTPS billing verification).
- User can request deletion: Memora has no developer-hosted journal/account database. Uninstall removes private app data; user-controlled exports remain wherever the user saved them.
- Independent security review: **Do not claim unless one has actually been completed.**

## Journal content

The following stays on-device and is not transmitted to the developer:
- note text and titles
- photos
- audio recordings
- mood metadata
- local statistics
- local recovery draft
- Memora/HTML/Word export contents

Therefore these are not developer-collected user data in the source as built.

## Billing verification

Memora sends the following over HTTPS to its own minimal verifier:
- package name
- product ID
- Google Play purchase token

The verifier uses the token only to query Google Play subscription state and returns entitlement information. It is designed not to persist the request.

For the current Play Data safety form:
- Treat the purchase/subscription verification flow as **purchase history / transaction-related data** when the form asks what is transmitted off-device.
- Mark the processing as **ephemeral** only if the deployed backend truly keeps it in memory only for the request and does not log/store the token.
- Purpose: **App functionality** (subscription entitlement verification). Add **Fraud prevention/security** only if the deployed implementation actually uses it for that purpose.
- Shared with third parties: Google Play acts as the billing/platform service. Follow the live form's service-provider/payment-platform instructions instead of claiming that payment card data is received by Memora.
- User payment/card/bank details: Memora source does not receive them.

## SDK/privacy boundary

Source audit shows:
- Google Play Billing SDK
- no ads SDK
- no analytics SDK
- no remote crash-reporting SDK
- local crash diagnostics only, stored in private app storage

## Important deployment check

Do not enable general Cloud Run request logging of raw request bodies or add application logs containing `purchaseToken`. If infrastructure logging changes this behavior, update both Privacy Policy and Data safety answers before release.
