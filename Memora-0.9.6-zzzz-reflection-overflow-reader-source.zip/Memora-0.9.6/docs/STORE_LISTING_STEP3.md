# Memora 0.9.6 — Store listing draft

## English — default listing

**App name**  
Memora – Private Journal

**Short description**  
Private journal for short and long notes, photos, audio and memories.

**Full description**

Memora is a private, local-first journal designed for writing down everyday thoughts, memories and longer reflections without turning your personal writing into an online feed.

Write in two simple formats: Short Notes for quick entries and Long Notes for deeper writing. Add a title, attach a photo, record audio and optionally mark how you felt with one of five mood emojis. Search later by text, title or mood and revisit entries in a clean reading view.

Memora keeps your journal content on your device. Your note text, titles, photos, audio and local statistics are not uploaded to Memora servers. Android cloud/device backup is disabled for Memora data. You can export your own archive as HTML, Word or a Memora backup whenever you want.

Features include:
- Short and Long Notes
- Automatic saving and local recovery after an abnormal close
- Optional mood metadata with five emojis
- Photos from camera or gallery
- In-app audio recording and playback
- Search, favorites, titles and statistics
- Writing reminders
- App lock using your device security
- Light/dark themes and writing fonts
- 13 interface languages
- HTML, Word and Memora backup export

Memora is free to download. Creating, editing, deleting and importing notes requires an active Memora Premium subscription after any eligible trial. Existing notes remain readable after a subscription ends, and search, statistics, media playback and exports remain available.

Subscriptions renew automatically according to the plan shown in Google Play until canceled. Eligible new subscribers may receive a one-month free trial. The exact local price, billing period and trial eligibility are shown before purchase. You can manage or cancel your subscription through Google Play.

## Uzbek listing

**Ilova nomi**  
Memora – Shaxsiy kundalik

**Qisqa tavsif**  
Qisqa va uzun yozuvlar, rasmlar, audio va xotiralar uchun shaxsiy kundalik.

**To‘liq tavsif**

Memora — kundalik fikrlar, xotiralar va uzunroq mulohazalarni yozib borish uchun yaratilgan shaxsiy, local-first kundalik ilovasi.

Ikki oddiy formatda yozing: tezkor qaydlar uchun Qisqa yozuv va batafsil fikrlar uchun Uzun yozuv. Sarlavha qo‘ying, rasm biriktiring, audio yozing va xohlasangiz o‘sha paytdagi kayfiyatingizni beshta smayldan biri bilan belgilang. Keyin matn, sarlavha yoki kayfiyat bo‘yicha qidiring va yozuvlarni toza o‘qish rejimida ko‘ring.

Memora kundalik mazmunini qurilmangizda saqlaydi. Yozuv matni, sarlavhalar, rasmlar, audio va lokal statistika Memora serverlariga yuklanmaydi. Memora ma’lumotlari uchun Android cloud/device backup o‘chirilgan. Arxivingizni istalgan payt HTML, Word yoki Memora backup sifatida eksport qilishingiz mumkin.

Asosiy imkoniyatlar:
- Qisqa va Uzun yozuvlar
- Avtomatik saqlash va favqulodda yopilishdan keyin lokal tiklash
- 5 smaylli ixtiyoriy kayfiyat belgisi
- Kamera yoki galereyadan rasm
- Ilova ichida audio yozish va tinglash
- Qidiruv, sevimlilar, sarlavhalar va statistika
- Yozish eslatmalari
- Qurilma xavfsizligi orqali ilova qulfi
- Kun/tun mavzusi va yozuv shriftlari
- 13 ta interfeys tili
- HTML, Word va Memora backup eksporti

Memora bepul yuklab olinadi. Mos sinov davridan keyin yozuv yaratish, tahrirlash, o‘chirish va import qilish uchun faol Memora Premium obunasi kerak. Obuna tugasa ham mavjud yozuvlarni o‘qish, qidirish, statistika, media tinglash/ko‘rish va eksport ochiq qoladi.

Obuna Google Play’da ko‘rsatilgan reja bo‘yicha bekor qilinmaguncha avtomatik yangilanadi. Mos yangi obunachilarga bir oylik bepul sinov berilishi mumkin. Aniq mahalliy narx, to‘lov davri va trial eligibility xariddan oldin ko‘rsatiladi. Obunani Google Play orqali boshqarish yoki bekor qilish mumkin.
