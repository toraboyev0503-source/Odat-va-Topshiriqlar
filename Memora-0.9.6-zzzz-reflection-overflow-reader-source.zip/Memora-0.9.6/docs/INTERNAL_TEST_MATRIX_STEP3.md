# Memora 0.9.6 — Internal testing matrix

## P0 release blockers

- Fresh install starts without crash.
- Upgrade from stable 0.9.4 debug keeps all local notes/media.
- Room 3→4 migration preserves notes and adds nullable mood safely.
- Short/Long editors save without crash under fast typing, Enter/Backspace and background/foreground.
- Recovery restores the latest local snapshot after abnormal process termination.
- Export/import never deletes original notes on failure.
- Release build has no debug entitlement and requires production HTTPS verifier.
- Play purchase is verified server-side before write entitlement is granted.
- Subscription screen shows price + period + auto-renewal terms; trial accounts also see post-trial charge/cancel terms.

## Editor

- Empty new note can leave safely.
- Non-empty note enforces title requirement as designed.
- Long title wraps and editor header grows naturally.
- 5 mood emojis render without labels underneath in the editor picker.
- Mood can be set, changed and removed.
- Mood survives app restart, backup/restore and appears in Reader/Search filter.
- 1000+ split/merge cycle does not crash.
- Numbered paragraphs continue once per Enter.

## Media

- Gallery import success / cancel / corrupt image / oversized image.
- Camera capture success / cancel.
- Audio permission deny / allow.
- Record, stop, seek and reopen audio.
- Short-note 5-minute audio warning does not stop recording.

## Notifications

- Notification permission deny keeps app usable.
- Reminder permission grant produces reminder.
- Exact-alarm special access deny falls back safely.
- Boot/restart reschedules reminders.

## Subscription

- Eligible tester sees 1-month trial and the post-trial auto-renew/cancel disclosure.
- Ineligible tester sees normal plan without false trial claim.
- Monthly / quarterly / semiannual / annual price is localized by Play.
- Purchase success → active write access.
- Pending → no premature write entitlement.
- Cancel purchase UI → app remains stable.
- Restore purchases works.
- Cancel active subscription → access remains until Play expiry.
- Expired subscription → read-only; existing notes/search/stats/media/export remain open.
- Offline after recent successful verification → max 7-day grace, never beyond Play expiry.
- Manage subscription opens Google Play subscription management.

## Export/import

- HTML index opens and month/type navigation works.
- Images/audio embedded as designed.
- Word export contains text/images and linked audio package.
- Memora backup preserves text, title, mood, images and audio.
- Import duplicate behavior is stable.

## Device coverage

At minimum test:
- Android 8/9 class device or emulator (minSdk boundary)
- Android 13/14 notification/exact-alarm behavior
- Android 16 / API 36 target behavior
- one low-memory physical device
- one non-English UI language and RTL Arabic
