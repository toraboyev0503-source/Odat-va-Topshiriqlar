package com.memora.app.data.repository

import com.memora.app.data.local.AppDatabase
import com.memora.app.data.local.NoteEntity
import com.memora.app.data.local.NoteType
import com.memora.app.data.local.ReminderEntity
import com.memora.app.data.local.SavedTitleEntity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class NoteWriteAccessException : IllegalStateException("An active Memora subscription is required to change notes")

sealed interface NoteSaveResult {
    data class Success(val noteId: String) : NoteSaveResult
    data object ReadOnly : NoteSaveResult
    data class Failed(val cause: Throwable) : NoteSaveResult
}

class MemoraRepository(
    private val db: AppDatabase,
    private val canMutateNotes: () -> Boolean = { true }
) {
    private val notes = db.noteDao()
    private val titles = db.savedTitleDao()
    private val reminders = db.reminderDao()

    fun observeNotes(type: NoteType): Flow<List<NoteEntity>> =
        notes.observeByType(type.name)

    fun observeAllNotes(): Flow<List<NoteEntity>> = notes.observeAll()
    fun observeNote(id: String): Flow<NoteEntity?> = notes.observeById(id)
    fun observeCount(type: NoteType): Flow<Int> = notes.observeCount(type.name)
    fun observeTitles(): Flow<List<SavedTitleEntity>> = titles.observeAll()
    fun observeReminders(): Flow<List<ReminderEntity>> = reminders.observeAll()

    suspend fun getNote(id: String): NoteEntity? = notes.getById(id)

    /**
     * Note writes never use expected states such as an expired subscription as exceptions.
     * Callers can safely keep an in-memory/recovery snapshot when writing becomes unavailable.
     */
    suspend fun saveNote(
        id: String?,
        type: NoteType,
        title: String,
        html: String,
        plainText: String,
        createdAt: Long?,
        updatedAt: Long = System.currentTimeMillis(),
        blocksJson: String = "",
        hasImages: Boolean = false,
        hasAudio: Boolean = false,
        mood: String? = null
    ): NoteSaveResult {
        if (!canMutateNotes()) return NoteSaveResult.ReadOnly
        val noteId = id ?: UUID.randomUUID().toString()
        val created = createdAt ?: updatedAt
        return try {
            notes.upsert(
                NoteEntity(
                    id = noteId,
                    type = type.name,
                    title = title.trim(),
                    contentHtml = html,
                    plainText = plainText,
                    createdAt = created,
                    updatedAt = updatedAt,
                    wordCount = countWords(plainText),
                    blocksJson = blocksJson,
                    hasImages = hasImages,
                    hasAudio = hasAudio,
                    mood = mood
                )
            )
            NoteSaveResult.Success(noteId)
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (t: Throwable) {
            NoteSaveResult.Failed(t)
        }
    }

    suspend fun deleteNotes(ids: List<String>) {
        requireWritable()
        notes.deleteByIds(ids)
    }

    suspend fun addTitle(value: String, createdAt: Long = System.currentTimeMillis()): Boolean {
        val cleaned = value.trim()
        if (cleaned.isBlank()) return false
        return titles.insert(SavedTitleEntity(value = cleaned, createdAt = createdAt)) != -1L
    }

    suspend fun deleteTitle(title: SavedTitleEntity) = titles.delete(title)

    suspend fun renameTitle(title: SavedTitleEntity, newValue: String, affectExistingNotes: Boolean) {
        if (affectExistingNotes) requireWritable()
        val cleaned = newValue.trim()
        if (cleaned.isBlank() || cleaned == title.value) return
        if (affectExistingNotes) {
            notes.renameTitleInNotes(title.value, cleaned, System.currentTimeMillis())
        }
        titles.rename(title.id, cleaned)
    }

    suspend fun setTitlePinned(title: SavedTitleEntity, pinned: Boolean) {
        titles.setPinned(title.id, if (pinned) System.currentTimeMillis() else null)
    }

    suspend fun addReminder(
        hour: Int,
        minute: Int,
        enabled: Boolean = true,
        createdAt: Long = System.currentTimeMillis()
    ): Long = reminders.insert(
        ReminderEntity(hour = hour, minute = minute, enabled = enabled, createdAt = createdAt)
    )

    suspend fun updateReminder(reminder: ReminderEntity) = reminders.upsert(reminder)
    suspend fun deleteReminder(reminder: ReminderEntity) = reminders.delete(reminder)
    suspend fun enabledReminders(): List<ReminderEntity> = reminders.getEnabled()
    suspend fun reminderById(id: Long): ReminderEntity? = reminders.getById(id)

    fun observeCountBetween(type: NoteType, start: Long, end: Long): Flow<Int> =
        notes.observeCountBetween(type.name, start, end)

    suspend fun countBetween(type: NoteType, start: Long, end: Long): Int =
        notes.countBetween(type.name, start, end)

    suspend fun count(type: NoteType): Int = notes.count(type.name)

    suspend fun notesForExport(
        type: NoteType?,
        start: Long?,
        end: Long?
    ): List<NoteEntity> = notes.getForExport(type?.name, start, end)

    suspend fun isDuplicate(title: String, plainText: String, createdAt: Long): Boolean =
        notes.duplicateCount(title, plainText, createdAt) > 0

    suspend fun allTitles(): List<SavedTitleEntity> = titles.getAll()
    suspend fun allReminders(): List<ReminderEntity> = reminders.getAll()

    fun requireWritable() {
        if (!canMutateNotes()) throw NoteWriteAccessException()
    }

    companion object {
        fun countWords(text: String): Int =
            text.trim().split(Regex("\\s+")).count { it.isNotBlank() }
    }
}
