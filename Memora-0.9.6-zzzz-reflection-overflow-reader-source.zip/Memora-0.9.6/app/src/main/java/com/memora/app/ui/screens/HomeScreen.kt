package com.memora.app.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memora.app.i18n.L
import com.memora.app.i18n.S
import com.memora.app.prefs.AppLanguage
import com.memora.app.reflections.HomeReflection
import kotlin.math.floor
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

private val TiniqSage = Color(0xFF789786)
private val TiniqLavender = Color(0xFFE9E1F2)
private val TiniqMist = Color(0xFFDDEAF1)
private val TiniqInk = Color(0xFF202923)
private val TiniqMuted = Color(0xFF6F7973)

@Composable
fun HomeScreen(
    language: AppLanguage,
    shortCount: Int,
    longCount: Int,
    isDark: Boolean,
    reflection: HomeReflection?,
    uiScale: Float,
    onReflectionSeen: (HomeReflection) -> Unit,
    onToggleDark: () -> Unit,
    onShort: () -> Unit,
    onLong: () -> Unit
) {
    var readerReflection by remember { mutableStateOf<HomeReflection?>(null) }
    var reflectionSeen by remember(reflection?.id) { mutableStateOf(false) }
    val commitReflectionSeen: (HomeReflection) -> Unit = { item ->
        if (!reflectionSeen) {
            reflectionSeen = true
            onReflectionSeen(item)
        }
    }

    // Home is visual chrome, not a long-form reading surface.  Keep its composition
    // premium and stable above 120%, while the rest of the app may scale up to 150%.
    val inheritedDensity = LocalDensity.current
    val safeScale = uiScale.coerceIn(0.8f, 1.5f)
    val homeScale = safeScale.coerceAtMost(1.2f)
    val homeDensity = Density(
        density = inheritedDensity.density * (homeScale / safeScale),
        fontScale = inheritedDensity.fontScale
    )

    CompositionLocalProvider(LocalDensity provides homeDensity) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                HomeHeader(
                    language = language,
                    isDark = isDark,
                    onToggleDark = onToggleDark
                )

                Column(Modifier.padding(horizontal = 24.dp)) {
                    HomeNoteTypeCard(
                        title = L.t(language, S.SHORT_NOTES),
                        count = shortCount,
                        language = language,
                        icon = {
                            Icon(
                                Icons.Rounded.Description,
                                contentDescription = null,
                                tint = TiniqSage,
                                modifier = Modifier.size(32.dp)
                            )
                        },
                        tint = TiniqMist,
                        onClick = onShort
                    )
                    Spacer(Modifier.height(16.dp))
                    HomeNoteTypeCard(
                        title = L.t(language, S.LONG_NOTES),
                        count = longCount,
                        language = language,
                        icon = {
                            Icon(
                                Icons.Rounded.MenuBook,
                                contentDescription = null,
                                tint = Color(0xFF7777A8),
                                modifier = Modifier.size(32.dp)
                            )
                        },
                        tint = TiniqLavender,
                        onClick = onLong
                    )
                }

                // Reflection is always centred in the free space between the note cards
                // and bottom navigation. The stage never steals unequal space from above/below:
                // it either wraps its content or caps itself with an equal outer breathing gap.
                BoxWithConstraints(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(horizontal = 24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    val stageMaxHeight = if (maxHeight > 212.dp) maxHeight - 32.dp else maxHeight
                    HomeReflectionStage(
                        reflection = reflection,
                        isDark = isDark,
                        maxStageHeight = stageMaxHeight,
                        onSeen = commitReflectionSeen,
                        onOpen = { item -> readerReflection = item }
                    )
                }
            }
        }
    }

    // This dialog is deliberately outside the capped Home density provider, therefore
    // it uses the real global app scale (up to 150%) for accessibility.
    readerReflection?.let { item ->
        HomeReflectionReaderDialog(
            reflection = item,
            isDark = isDark,
            onSeen = commitReflectionSeen,
            onDismiss = { readerReflection = null }
        )
    }
}

@Composable
private fun HomeHeader(
    language: AppLanguage,
    isDark: Boolean,
    onToggleDark: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 28.dp, end = 28.dp, top = 28.dp, bottom = 22.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                "Memora",
                style = MaterialTheme.typography.displayMedium.copy(fontSize = 44.sp),
                fontWeight = FontWeight.SemiBold,
                color = if (isDark) MaterialTheme.colorScheme.onBackground else TiniqInk
            )
            Text(
                L.t(language, S.HOME_TAGLINE),
                style = MaterialTheme.typography.bodyLarge.copy(fontSize = 18.sp),
                color = if (isDark) MaterialTheme.colorScheme.onSurfaceVariant else TiniqMuted,
                modifier = Modifier.padding(top = 1.dp)
            )
        }

        Surface(
            shape = CircleShape,
            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.88f),
            shadowElevation = 2.dp
        ) {
            IconButton(onClick = onToggleDark, modifier = Modifier.size(52.dp)) {
                Icon(
                    if (isDark) Icons.Rounded.DarkMode else Icons.Rounded.LightMode,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

@Composable
private fun HomeNoteTypeCard(
    title: String,
    count: Int,
    language: AppLanguage,
    icon: @Composable () -> Unit,
    tint: Color,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(26.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.985f),
        shadowElevation = 1.dp
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 21.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = tint.copy(alpha = 0.66f),
                modifier = Modifier.size(68.dp)
            ) {
                Box(contentAlignment = Alignment.Center) { icon() }
            }
            Column(Modifier.weight(1f).padding(start = 20.dp)) {
                Text(
                    title,
                    style = MaterialTheme.typography.headlineSmall.copy(fontSize = 26.sp),
                    fontWeight = FontWeight.Medium
                )
                Text(
                    "$count ${L.t(language, S.NOTES)}",
                    style = MaterialTheme.typography.bodyLarge.copy(fontSize = 17.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 3.dp)
                )
            }
            Icon(
                Icons.Rounded.ArrowForward,
                contentDescription = null,
                modifier = Modifier.size(27.dp)
            )
        }
    }
}

@Composable
private fun HomeReflectionStage(
    reflection: HomeReflection?,
    isDark: Boolean,
    maxStageHeight: androidx.compose.ui.unit.Dp,
    onSeen: (HomeReflection) -> Unit,
    onOpen: (HomeReflection) -> Unit
) {
    val frameProgress = remember(reflection?.id) { Animatable(0f) }
    val quoteProgress = remember(reflection?.id) { Animatable(0f) }
    val lineProgress = remember(reflection?.id) { Animatable(0f) }
    var visibleLines by remember(reflection?.id) { mutableIntStateOf(0) }
    var textLayout by remember(reflection?.id) { mutableStateOf<TextLayoutResult?>(null) }
    var seenCommitted by remember(reflection?.id) { mutableStateOf(false) }

    // Reserve room for the quote ornament, paddings and (only when needed) the overflow cue.
    // The remaining height is converted to a deterministic max line count so the Home frame
    // remains centred and never collides with the bottom bar even at larger UI scales.
    val density = LocalDensity.current
    val maxVisibleLines = remember(maxStageHeight, density) {
        val stagePx = with(density) { maxStageHeight.toPx() }
        val reservedPx = with(density) { (58.dp + 44.dp + 34.dp).toPx() }
        val linePx = with(density) { 27.sp.toPx() }
        floor(((stagePx - reservedPx).coerceAtLeast(linePx * 2f)) / linePx)
            .toInt()
            .coerceIn(2, 24)
    }

    LaunchedEffect(reflection?.id, maxVisibleLines) {
        val item = reflection ?: return@LaunchedEffect
        // Home remains visually quiet for five seconds before the reflection ceremony begins.
        delay(5_000)
        frameProgress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 850, easing = FastOutSlowInEasing)
        )
        quoteProgress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 280, easing = FastOutSlowInEasing)
        )
        lineProgress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 430, easing = FastOutSlowInEasing)
        )

        val layout = snapshotFlow { textLayout }.first { it != null } ?: return@LaunchedEffect
        for (line in 1..layout.lineCount) {
            visibleLines = line
            // Slightly slower than the first prototype: magical but calm, not hurried.
            delay(300)
        }

        // If Home shows the complete text, the original seen rule remains. If it is truncated,
        // seeing is deferred until the framed reader has actually exposed the full content.
        if (!layout.hasVisualOverflow) {
            delay(1_000)
            if (!seenCommitted) {
                seenCommitted = true
                onSeen(item)
            }
        }
    }

    val layout = textLayout
    val isOverflowing = layout?.hasVisualOverflow == true
    val revealFinished = layout != null && layout.lineCount > 0 && visibleLines >= layout.lineCount
    val revealBottomTarget = when {
        visibleLines <= 0 || layout == null -> 0f
        else -> layout.getLineBottom((visibleLines - 1).coerceAtMost(layout.lineCount - 1))
    }
    val revealBottom by animateFloatAsState(
        targetValue = revealBottomTarget,
        animationSpec = tween(durationMillis = 340, easing = FastOutSlowInEasing),
        label = "reflectionTextReveal"
    )
    val cueAlpha by animateFloatAsState(
        targetValue = if (isOverflowing && revealFinished) 1f else 0f,
        animationSpec = tween(durationMillis = 260, easing = FastOutSlowInEasing),
        label = "reflectionContinuationCue"
    )

    val frameColor = if (isDark) {
        MaterialTheme.colorScheme.primary.copy(alpha = 0.58f)
    } else {
        TiniqSage.copy(alpha = 0.62f)
    }
    val textColor = if (isDark) MaterialTheme.colorScheme.onSurface else TiniqInk
    val fadeColor = MaterialTheme.colorScheme.background
    val canOpen = reflection != null && revealFinished

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(max = maxStageHeight)
            .clickable(enabled = canOpen) { reflection?.let(onOpen) },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.matchParentSize()) {
            if (frameProgress.value <= 0f) return@Canvas
            val p = frameProgress.value
            val inset = 2.dp.toPx()
            val stroke = 1.25.dp.toPx()
            val radius = 28.dp.toPx()
            val w = size.width - inset * 2f
            val h = size.height - inset * 2f
            val left = inset
            val top = inset
            val right = inset + w
            val bottom = inset + h
            val horizontal = (w - radius * 2f).coerceAtLeast(0f)
            val vertical = (h - radius * 2f).coerceAtLeast(0f)

            // Two origins: top-left grows right/down; bottom-right grows left/up.
            drawLine(
                color = frameColor,
                start = Offset(left + radius, top),
                end = Offset(left + radius + horizontal * p, top),
                strokeWidth = stroke,
                cap = StrokeCap.Round
            )
            drawLine(
                color = frameColor,
                start = Offset(left, top + radius),
                end = Offset(left, top + radius + vertical * p),
                strokeWidth = stroke,
                cap = StrokeCap.Round
            )
            drawLine(
                color = frameColor,
                start = Offset(right - radius, bottom),
                end = Offset(right - radius - horizontal * p, bottom),
                strokeWidth = stroke,
                cap = StrokeCap.Round
            )
            drawLine(
                color = frameColor,
                start = Offset(right, bottom - radius),
                end = Offset(right, bottom - radius - vertical * p),
                strokeWidth = stroke,
                cap = StrokeCap.Round
            )

            drawArc(
                color = frameColor,
                startAngle = 180f,
                sweepAngle = 90f,
                useCenter = false,
                topLeft = Offset(left, top),
                size = androidx.compose.ui.geometry.Size(radius * 2f, radius * 2f),
                style = Stroke(stroke, cap = StrokeCap.Round)
            )
            drawArc(
                color = frameColor,
                startAngle = 0f,
                sweepAngle = 90f,
                useCenter = false,
                topLeft = Offset(right - radius * 2f, bottom - radius * 2f),
                size = androidx.compose.ui.geometry.Size(radius * 2f, radius * 2f),
                style = Stroke(stroke, cap = StrokeCap.Round)
            )

            val finish = ((p - 0.88f) / 0.12f).coerceIn(0f, 1f)
            if (finish > 0f) {
                drawArc(
                    color = frameColor.copy(alpha = frameColor.alpha * finish),
                    startAngle = 270f,
                    sweepAngle = 90f,
                    useCenter = false,
                    topLeft = Offset(right - radius * 2f, top),
                    size = androidx.compose.ui.geometry.Size(radius * 2f, radius * 2f),
                    style = Stroke(stroke, cap = StrokeCap.Round)
                )
                drawArc(
                    color = frameColor.copy(alpha = frameColor.alpha * finish),
                    startAngle = 90f,
                    sweepAngle = 90f,
                    useCenter = false,
                    topLeft = Offset(left, bottom - radius * 2f),
                    size = androidx.compose.ui.geometry.Size(radius * 2f, radius * 2f),
                    style = Stroke(stroke, cap = StrokeCap.Round)
                )
            }
        }

        if (reflection != null) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 26.dp, vertical = 22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(58.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(Modifier.fillMaxSize()) {
                        val p = lineProgress.value
                        if (p > 0f) {
                            val y = size.height * 0.54f
                            val gap = 34.dp.toPx()
                            val edge = 18.dp.toPx()
                            val cx = size.width / 2f
                            val leftTarget = cx - gap
                            val rightTarget = cx + gap
                            drawLine(
                                color = frameColor.copy(alpha = 0.72f),
                                start = Offset(edge, y),
                                end = Offset(edge + (leftTarget - edge) * p, y),
                                strokeWidth = 1.1.dp.toPx(),
                                cap = StrokeCap.Round
                            )
                            drawLine(
                                color = frameColor.copy(alpha = 0.72f),
                                start = Offset(size.width - edge, y),
                                end = Offset(size.width - edge - (size.width - edge - rightTarget) * p, y),
                                strokeWidth = 1.1.dp.toPx(),
                                cap = StrokeCap.Round
                            )
                        }
                    }
                    Text(
                        text = "“",
                        fontSize = 48.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = frameColor.copy(alpha = quoteProgress.value),
                        modifier = Modifier.padding(top = 10.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp)
                ) {
                    Text(
                        text = reflection.text,
                        style = MaterialTheme.typography.bodyLarge.copy(
                            fontSize = 19.sp,
                            lineHeight = 27.sp,
                            fontStyle = FontStyle.Normal
                        ),
                        color = textColor,
                        textAlign = TextAlign.Center,
                        maxLines = maxVisibleLines,
                        onTextLayout = { textLayout = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .drawWithContent {
                                if (revealBottom > 0f) {
                                    clipRect(
                                        left = 0f,
                                        top = 0f,
                                        right = size.width,
                                        bottom = revealBottom.coerceAtMost(size.height)
                                    ) {
                                        this@drawWithContent.drawContent()
                                    }
                                }
                            }
                    )

                    if (isOverflowing && revealFinished) {
                        // The last visible line dissolves rather than ending abruptly. This also
                        // gently directs the eye toward the continuation cue below.
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .fillMaxWidth()
                                .height(30.dp)
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(
                                            Color.Transparent,
                                            fadeColor.copy(alpha = 0.94f)
                                        )
                                    )
                                )
                        )
                    }
                }

                if (isOverflowing && revealFinished) {
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = frameColor.copy(alpha = 0.09f * cueAlpha),
                        border = BorderStroke(
                            width = 1.dp,
                            color = frameColor.copy(alpha = 0.32f * cueAlpha)
                        ),
                        modifier = Modifier
                            .padding(top = 7.dp)
                            .size(width = 42.dp, height = 27.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Rounded.KeyboardArrowDown,
                                contentDescription = null,
                                tint = frameColor.copy(alpha = cueAlpha),
                                modifier = Modifier.size(21.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeReflectionReaderDialog(
    reflection: HomeReflection,
    isDark: Boolean,
    onSeen: (HomeReflection) -> Unit,
    onDismiss: () -> Unit
) {
    val frameColor = if (isDark) {
        MaterialTheme.colorScheme.primary.copy(alpha = 0.66f)
    } else {
        TiniqSage.copy(alpha = 0.70f)
    }
    val textColor = if (isDark) MaterialTheme.colorScheme.onSurface else TiniqInk
    val scrollState = rememberScrollState()
    var textLaidOut by remember(reflection.id) { mutableStateOf(false) }
    var readerSeenCommitted by remember(reflection.id) { mutableStateOf(false) }

    // The reflection is considered truly seen only when the complete text is reachable/visible.
    // If scrolling is required, the user must reach the bottom and remain there for one second.
    LaunchedEffect(reflection.id) {
        while (!readerSeenCommitted) {
            snapshotFlow {
                textLaidOut && (scrollState.maxValue == 0 || scrollState.value >= scrollState.maxValue)
            }.first { it }
            delay(1_000)
            val stillComplete = textLaidOut &&
                (scrollState.maxValue == 0 || scrollState.value >= scrollState.maxValue)
            if (stillComplete) {
                readerSeenCommitted = true
                onSeen(reflection)
            }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.90f)
                    .fillMaxHeight(0.80f),
                shape = RoundedCornerShape(32.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.2.dp, frameColor),
                shadowElevation = 12.dp
            ) {
                Box(Modifier.fillMaxSize()) {
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(8.dp)
                    ) {
                        Icon(
                            Icons.Rounded.Close,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(start = 24.dp, end = 24.dp, top = 22.dp, bottom = 24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(62.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Canvas(Modifier.fillMaxSize()) {
                                val y = size.height * 0.55f
                                val gap = 34.dp.toPx()
                                val edge = 18.dp.toPx()
                                val cx = size.width / 2f
                                drawLine(
                                    color = frameColor.copy(alpha = 0.72f),
                                    start = Offset(edge, y),
                                    end = Offset(cx - gap, y),
                                    strokeWidth = 1.1.dp.toPx(),
                                    cap = StrokeCap.Round
                                )
                                drawLine(
                                    color = frameColor.copy(alpha = 0.72f),
                                    start = Offset(size.width - edge, y),
                                    end = Offset(cx + gap, y),
                                    strokeWidth = 1.1.dp.toPx(),
                                    cap = StrokeCap.Round
                                )
                            }
                            Text(
                                text = "“",
                                fontSize = 52.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = frameColor,
                                modifier = Modifier.padding(top = 10.dp)
                            )
                        }

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .verticalScroll(scrollState)
                                    .padding(horizontal = 8.dp, vertical = 8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = reflection.text,
                                    style = MaterialTheme.typography.bodyLarge.copy(
                                        fontSize = 21.sp,
                                        lineHeight = 32.sp
                                    ),
                                    color = textColor,
                                    textAlign = TextAlign.Center,
                                    onTextLayout = { textLaidOut = true },
                                    modifier = Modifier.padding(bottom = 20.dp)
                                )
                            }

                            if (scrollState.maxValue > 0 && scrollState.value < scrollState.maxValue) {
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.BottomCenter)
                                        .fillMaxWidth()
                                        .height(34.dp)
                                        .background(
                                            Brush.verticalGradient(
                                                listOf(
                                                    Color.Transparent,
                                                    MaterialTheme.colorScheme.surface.copy(alpha = 0.96f)
                                                )
                                            )
                                        )
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
