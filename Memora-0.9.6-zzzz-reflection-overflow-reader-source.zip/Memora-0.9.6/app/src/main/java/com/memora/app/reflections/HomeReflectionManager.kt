package com.memora.app.reflections

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.memora.app.prefs.AppLanguage
import kotlinx.coroutines.flow.first
import org.json.JSONArray

private val Context.homeReflectionDataStore by preferencesDataStore("memora_home_reflection_state")

data class HomeReflection(
    val id: Int,
    val text: String
)

class HomeReflectionManager(private val context: Context) {
    private object Keys {
        val lastShownAt = longPreferencesKey("last_shown_at")
        val seenIds = stringPreferencesKey("seen_ids")
    }

    /**
     * Test-only cooldown. Production value will be 4 hours after the content pack is approved.
     */
    private val cooldownMs = 60_000L

    suspend fun nextEligible(
        language: AppLanguage,
        now: Long = System.currentTimeMillis()
    ): HomeReflection? {
        val prefs = context.homeReflectionDataStore.data.first()
        val lastShownAt = prefs[Keys.lastShownAt] ?: 0L
        if (lastShownAt > 0L && now - lastShownAt < cooldownMs) return null

        val reflections = loadReflections(language)
        if (reflections.isEmpty()) return null

        val seen = parseSeenIds(prefs[Keys.seenIds])
        val unseen = reflections.filterNot { it.id in seen }
        val pool = if (unseen.isNotEmpty()) {
            unseen
        } else {
            // A completed cycle starts over only after every content id has been shown once.
            context.homeReflectionDataStore.edit { it[Keys.seenIds] = "" }
            reflections
        }
        return pool.random()
    }

    suspend fun markSeen(
        reflectionId: Int,
        shownAt: Long = System.currentTimeMillis()
    ) {
        context.homeReflectionDataStore.edit { prefs ->
            val ids = parseSeenIds(prefs[Keys.seenIds]).toMutableSet()
            ids += reflectionId
            prefs[Keys.seenIds] = ids.sorted().joinToString(",")
            prefs[Keys.lastShownAt] = shownAt
        }
    }

    private fun loadReflections(language: AppLanguage): List<HomeReflection> {
        val preferred = "reflections/${language.tag}.json"
        val json = runCatching { context.assets.open(preferred).bufferedReader().use { it.readText() } }
            .getOrElse {
                context.assets.open("reflections/uz.json").bufferedReader().use { it.readText() }
            }
        val array = JSONArray(json)
        return buildList {
            for (index in 0 until array.length()) {
                val item = array.getJSONObject(index)
                add(
                    HomeReflection(
                        id = item.getInt("id"),
                        text = item.getString("text")
                    )
                )
            }
        }
    }

    private fun parseSeenIds(raw: String?): Set<Int> = raw
        .orEmpty()
        .split(',')
        .mapNotNull { it.trim().toIntOrNull() }
        .toSet()
}
