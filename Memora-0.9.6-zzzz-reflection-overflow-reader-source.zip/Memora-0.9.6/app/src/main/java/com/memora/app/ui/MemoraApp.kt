package com.memora.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.memora.app.billing.EntitlementState
import com.memora.app.billing.SubscriptionPlan
import com.memora.app.data.local.NoteType
import com.memora.app.data.local.ReminderEntity
import com.memora.app.data.repository.MemoraRepository
import com.memora.app.export.ExportRequest
import com.memora.app.notifications.AlarmScheduler
import com.memora.app.prefs.ThemeMode
import com.memora.app.reflections.HomeReflectionManager
import com.memora.app.prefs.UserPreferences
import com.memora.app.prefs.UserSettings
import com.memora.app.ui.components.ExportDialog
import com.memora.app.ui.components.MemoraBottomBar
import com.memora.app.ui.components.NewNoteSheet
import com.memora.app.ui.components.RootTab
import com.memora.app.ui.screens.EditorScreen
import com.memora.app.ui.screens.HomeScreen
import com.memora.app.ui.screens.LanguageScreen
import com.memora.app.ui.screens.NotesScreen
import com.memora.app.ui.screens.ReaderScreen
import com.memora.app.ui.screens.RemindersScreen
import com.memora.app.ui.screens.SearchLandingScreen
import com.memora.app.ui.screens.SearchScreen
import com.memora.app.ui.screens.SecurityScreen
import com.memora.app.ui.screens.SettingsHubScreen
import com.memora.app.ui.screens.StatisticsScreen
import com.memora.app.ui.screens.StatsSnapshot
import com.memora.app.ui.screens.SubscriptionScreen
import com.memora.app.ui.screens.ThemeScreen
import com.memora.app.ui.screens.TitlesScreen
import com.memora.app.util.TimeUtils
import kotlinx.coroutines.launch

private object Routes {
    const val HOME = "home"
    const val SEARCH_LANDING = "search_landing"
    const val CALENDAR_ROOT = "calendar_root"
    const val SETTINGS_HUB = "settings_hub"
    const val NOTES = "notes/{type}"
    const val EDITOR = "editor/{type}/{id}"
    const val READER = "reader/{id}"
    const val SEARCH = "search/{type}"
    const val TITLES = "titles"
    const val REMINDERS = "reminders"
    const val STATS = "statistics"
    const val LANGUAGE = "language"
    const val THEME = "theme"
    const val SECURITY = "security"
    const val SUBSCRIPTION = "subscription"

    fun notes(type: NoteType) = "notes/${type.name}"
    fun editor(type: NoteType, id: String?) = "editor/${type.name}/${id ?: "new"}"
    fun reader(id: String) = "reader/$id"
    fun search(type: NoteType) = "search/${type.name}"
}

@Composable
fun MemoraApp(
    repository: MemoraRepository,
    preferences: UserPreferences,
    settings: UserSettings,
    entitlement: EntitlementState,
    subscriptionPlans: List<SubscriptionPlan>,
    pendingEditorType: String?,
    onPendingEditorConsumed: () -> Unit,
    onExport: (ExportRequest) -> Unit,
    onImport: () -> Unit,
    onRequestNotifications: () -> Unit,
    onRequestExactTiming: () -> Unit,
    onPurchasePlan: (String) -> Unit,
    onRefreshSubscription: () -> Unit,
    onManageSubscription: () -> Unit
) {
    val navController = rememberNavController()
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val reflectionManager = remember(context) { HomeReflectionManager(context.applicationContext) }
    var showExportDialog by remember { mutableStateOf(false) }
    var showNewNoteSheet by remember { mutableStateOf(false) }
    val backOne: () -> Unit = { navController.popBackStack() }

    fun openSingle(route: String) {
        navController.navigate(route) { launchSingleTop = true }
    }

    fun openRoot(route: String) {
        navController.navigate(route) {
            popUpTo(Routes.HOME) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    fun openEditor(type: NoteType) {
        showNewNoteSheet = false
        if (entitlement.canWrite) navController.navigate(Routes.editor(type, null))
        else openSingle(Routes.SUBSCRIPTION)
    }

    val shortNotes by repository.observeNotes(NoteType.SHORT).collectAsStateWithLifecycle(emptyList())
    val longNotes by repository.observeNotes(NoteType.LONG).collectAsStateWithLifecycle(emptyList())
    val allNotes by repository.observeAllNotes().collectAsStateWithLifecycle(emptyList())
    val titles by repository.observeTitles().collectAsStateWithLifecycle(emptyList())
    val reminders by repository.observeReminders().collectAsStateWithLifecycle(emptyList())

    val allShort by repository.observeCount(NoteType.SHORT).collectAsStateWithLifecycle(0)
    val allLong by repository.observeCount(NoteType.LONG).collectAsStateWithLifecycle(0)

    val dayRange = remember { TimeUtils.currentDayRange() }
    val todayShort by repository.observeCountBetween(NoteType.SHORT, dayRange.start!!, dayRange.end!!)
        .collectAsStateWithLifecycle(0)
    val todayLong by repository.observeCountBetween(NoteType.LONG, dayRange.start!!, dayRange.end!!)
        .collectAsStateWithLifecycle(0)

    val monthRange = remember { TimeUtils.currentMonthRange() }
    val yearRange = remember { TimeUtils.currentYearRange() }
    val monthShort by repository.observeCountBetween(NoteType.SHORT, monthRange.start!!, monthRange.end!!)
        .collectAsStateWithLifecycle(0)
    val monthLong by repository.observeCountBetween(NoteType.LONG, monthRange.start!!, monthRange.end!!)
        .collectAsStateWithLifecycle(0)
    val yearShort by repository.observeCountBetween(NoteType.SHORT, yearRange.start!!, yearRange.end!!)
        .collectAsStateWithLifecycle(0)
    val yearLong by repository.observeCountBetween(NoteType.LONG, yearRange.start!!, yearRange.end!!)
        .collectAsStateWithLifecycle(0)

    val stats = StatsSnapshot(
        todayShort = todayShort,
        todayLong = todayLong,
        allShort = allShort,
        allLong = allLong,
        monthShort = monthShort,
        monthLong = monthLong,
        yearShort = yearShort,
        yearLong = yearLong
    )
    val isDark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val currentBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = currentBackStackEntry?.destination?.route

    val rootTab = when (currentRoute) {
        Routes.HOME -> RootTab.HOME
        Routes.SEARCH_LANDING -> RootTab.SEARCH
        Routes.CALENDAR_ROOT -> RootTab.CALENDAR
        Routes.SETTINGS_HUB -> RootTab.SETTINGS
        else -> null
    }

    // Nested screens keep their own BackHandler for local states. At the route level, Back always
    // returns exactly one navigation level; root tabs naturally collapse back to Home.
    BackHandler(enabled = currentRoute != Routes.HOME) {
        navController.popBackStack()
    }

    LaunchedEffect(pendingEditorType, entitlement.canWrite) {
        val raw = pendingEditorType ?: return@LaunchedEffect
        val type = runCatching { NoteType.valueOf(raw) }.getOrNull() ?: return@LaunchedEffect
        val destination = if (entitlement.canWrite) Routes.editor(type, null) else Routes.SUBSCRIPTION
        navController.navigate(destination) {
            launchSingleTop = true
        }
        onPendingEditorConsumed()
    }

    val deviceDensity = LocalDensity.current
    val compactDensity = Density(
        density = deviceDensity.density * 0.80f * settings.uiScale,
        fontScale = deviceDensity.fontScale
    )

    CompositionLocalProvider(
        LocalDensity provides compactDensity,
        LocalLayoutDirection provides if (settings.language.rtl) LayoutDirection.Rtl else LayoutDirection.Ltr
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .windowInsetsPadding(WindowInsets.safeDrawing)
            ) {
                NavHost(
                    navController = navController,
                    startDestination = Routes.HOME,
                    modifier = Modifier
                        .fillMaxSize()
                        .then(if (rootTab != null) Modifier.padding(bottom = 82.dp) else Modifier)
                ) {
                    composable(Routes.HOME) {
                        var homeReflection by remember(settings.language) { mutableStateOf<com.memora.app.reflections.HomeReflection?>(null) }
                        LaunchedEffect(settings.language) {
                            homeReflection = reflectionManager.nextEligible(settings.language)
                        }
                        HomeScreen(
                            language = settings.language,
                            shortCount = allShort,
                            longCount = allLong,
                            isDark = isDark,
                            reflection = homeReflection,
                            uiScale = settings.uiScale,
                            onReflectionSeen = { item ->
                                scope.launch { reflectionManager.markSeen(item.id) }
                            },
                            onToggleDark = {
                                scope.launch {
                                    preferences.setThemeMode(if (isDark) ThemeMode.LIGHT else ThemeMode.DARK)
                                }
                            },
                            onShort = { openSingle(Routes.notes(NoteType.SHORT)) },
                            onLong = { openSingle(Routes.notes(NoteType.LONG)) }
                        )
                    }

                    composable(Routes.SEARCH_LANDING) {
                        SearchLandingScreen(
                            language = settings.language,
                            shortCount = allShort,
                            longCount = allLong,
                            onShort = { openSingle(Routes.search(NoteType.SHORT)) },
                            onLong = { openSingle(Routes.search(NoteType.LONG)) }
                        )
                    }

                    composable(Routes.CALENDAR_ROOT) {
                        StatisticsScreen(
                            stats = stats,
                            allNotes = allNotes,
                            language = settings.language,
                            onBack = { openRoot(Routes.HOME) },
                            onOpenNote = { navController.navigate(Routes.reader(it)) },
                            startAtCalendar = true
                        )
                    }

                    composable(Routes.SETTINGS_HUB) {
                        SettingsHubScreen(
                            language = settings.language,
                            isDark = isDark,
                            onExport = { showExportDialog = true },
                            onImport = {
                                if (entitlement.canWrite) onImport()
                                else openSingle(Routes.SUBSCRIPTION)
                            },
                            onSubscription = { openSingle(Routes.SUBSCRIPTION) },
                            onReminders = { openSingle(Routes.REMINDERS) },
                            onTitles = { openSingle(Routes.TITLES) },
                            onLanguage = { openSingle(Routes.LANGUAGE) },
                            onStatistics = { openSingle(Routes.STATS) },
                            onTheme = { openSingle(Routes.THEME) },
                            onSecurity = { openSingle(Routes.SECURITY) },
                            onToggleDark = {
                                scope.launch {
                                    preferences.setThemeMode(if (isDark) ThemeMode.LIGHT else ThemeMode.DARK)
                                }
                            }
                        )
                    }

                    composable(
                        route = Routes.NOTES,
                        arguments = listOf(navArgument("type") { type = NavType.StringType })
                    ) { entry ->
                        val type = NoteType.valueOf(entry.arguments?.getString("type") ?: NoteType.SHORT.name)
                        val notes = if (type == NoteType.SHORT) shortNotes else longNotes
                        NotesScreen(
                            type = type,
                            notes = notes,
                            language = settings.language,
                            canWrite = entitlement.canWrite,
                            onBack = backOne,
                            onNew = { navController.navigate(Routes.editor(type, null)) },
                            onWriteRequired = { openSingle(Routes.SUBSCRIPTION) },
                            onOpen = { navController.navigate(Routes.reader(it)) },
                            onSearch = { navController.navigate(Routes.search(type)) },
                            onDelete = { ids ->
                                if (entitlement.canWrite) scope.launch { repository.deleteNotes(ids) }
                                else openSingle(Routes.SUBSCRIPTION)
                            }
                        )
                    }

                    composable(
                        route = Routes.EDITOR,
                        arguments = listOf(
                            navArgument("type") { type = NavType.StringType },
                            navArgument("id") { type = NavType.StringType }
                        )
                    ) { entry ->
                        if (!entitlement.canWrite) {
                            LaunchedEffect(Unit) {
                                navController.popBackStack()
                                navController.navigate(Routes.SUBSCRIPTION) { launchSingleTop = true }
                            }
                            return@composable
                        }
                        val type = NoteType.valueOf(entry.arguments?.getString("type") ?: NoteType.SHORT.name)
                        val idArg = entry.arguments?.getString("id")
                        val compact = LocalDensity.current
                        CompositionLocalProvider(
                            LocalDensity provides Density(
                                density = compact.density * 1.125f,
                                fontScale = compact.fontScale
                            )
                        ) {
                            EditorScreen(
                                noteId = idArg?.takeUnless { it == "new" },
                                type = type,
                                repository = repository,
                                savedTitles = titles,
                                language = settings.language,
                                writingFont = settings.writingFont,
                                uiScale = settings.uiScale,
                                onBack = backOne
                            )
                        }
                    }

                    composable(
                        route = Routes.READER,
                        arguments = listOf(navArgument("id") { type = NavType.StringType })
                    ) { entry ->
                        val id = entry.arguments?.getString("id").orEmpty()
                        val note by repository.observeNote(id).collectAsStateWithLifecycle(initialValue = null)
                        ReaderScreen(
                            note = note,
                            language = settings.language,
                            writingFont = settings.writingFont,
                            canEdit = entitlement.canWrite,
                            onBack = backOne,
                            onEdit = {
                                note?.let {
                                    navController.navigate(
                                        Routes.editor(NoteType.valueOf(it.type), it.id)
                                    )
                                }
                            },
                            onWriteRequired = { openSingle(Routes.SUBSCRIPTION) }
                        )
                    }

                    composable(
                        route = Routes.SEARCH,
                        arguments = listOf(navArgument("type") { type = NavType.StringType })
                    ) { entry ->
                        val type = NoteType.valueOf(entry.arguments?.getString("type") ?: NoteType.SHORT.name)
                        SearchScreen(
                            type = type,
                            notes = if (type == NoteType.SHORT) shortNotes else longNotes,
                            titles = titles,
                            language = settings.language,
                            onBack = backOne,
                            onOpen = { navController.navigate(Routes.reader(it)) }
                        )
                    }

                    composable(Routes.TITLES) {
                        TitlesScreen(
                            titles = titles,
                            language = settings.language,
                            onBack = backOne,
                            onAdd = { value -> scope.launch { repository.addTitle(value) } },
                            onDelete = { title -> scope.launch { repository.deleteTitle(title) } },
                            onEdit = { title, value, affect ->
                                if (affect && !entitlement.canWrite) {
                                    openSingle(Routes.SUBSCRIPTION)
                                } else {
                                    scope.launch { repository.renameTitle(title, value, affect) }
                                }
                            },
                            onPin = { title, pinned -> scope.launch { repository.setTitlePinned(title, pinned) } }
                        )
                    }

                    composable(Routes.REMINDERS) {
                        val context = androidx.compose.ui.platform.LocalContext.current
                        RemindersScreen(
                            reminders = reminders,
                            language = settings.language,
                            exactTimingAvailable = AlarmScheduler(context).canScheduleExact(),
                            onBack = backOne,
                            onRequestNotifications = onRequestNotifications,
                            onRequestExactTiming = onRequestExactTiming,
                            onAdd = { hour, minute ->
                                scope.launch {
                                    val id = repository.addReminder(hour, minute)
                                    if (id != -1L) {
                                        AlarmScheduler(context).scheduleReminder(
                                            ReminderEntity(id = id, hour = hour, minute = minute, enabled = true)
                                        )
                                    }
                                }
                            },
                            onToggle = { reminder, enabled ->
                                scope.launch {
                                    val changed = reminder.copy(enabled = enabled)
                                    repository.updateReminder(changed)
                                    if (enabled) AlarmScheduler(context).scheduleReminder(changed)
                                    else AlarmScheduler(context).cancelReminder(changed.id)
                                }
                            },
                            onDelete = { reminder ->
                                scope.launch {
                                    AlarmScheduler(context).cancelReminder(reminder.id)
                                    repository.deleteReminder(reminder)
                                }
                            }
                        )
                    }

                    composable(Routes.STATS) {
                        StatisticsScreen(
                            stats = stats,
                            allNotes = allNotes,
                            language = settings.language,
                            onBack = backOne,
                            onOpenNote = { navController.navigate(Routes.reader(it)) }
                        )
                    }

                    composable(Routes.LANGUAGE) {
                        LanguageScreen(
                            current = settings.language,
                            onBack = backOne,
                            onSelect = { scope.launch { preferences.setLanguage(it) } }
                        )
                    }

                    composable(Routes.THEME) {
                        ThemeScreen(
                            settings = settings,
                            onBack = backOne,
                            onPalette = { scope.launch { preferences.setPalette(it) } },
                            onUiFont = { scope.launch { preferences.setUiFont(it) } },
                            onWritingFont = { scope.launch { preferences.setWritingFont(it) } },
                            onUiScale = { scope.launch { preferences.setUiScale(it) } }
                        )
                    }

                    composable(Routes.SUBSCRIPTION) {
                        SubscriptionScreen(
                            language = settings.language,
                            entitlement = entitlement,
                            plans = subscriptionPlans,
                            onBack = backOne,
                            onSubscribe = onPurchasePlan,
                            onRestore = onRefreshSubscription,
                            onManage = onManageSubscription
                        )
                    }

                    composable(Routes.SECURITY) {
                        SecurityScreen(
                            settings = settings,
                            onBack = backOne,
                            onEnabled = { scope.launch { preferences.setLockEnabled(it) } },
                            onInterval = { scope.launch { preferences.setLockInterval(it) } }
                        )
                    }
                }

                if (rootTab != null) {
                    // Root navigation is app chrome. Cap it at 120% so 150% reading scale
                    // never makes the bottom bar consume a disproportionate part of the screen.
                    val inheritedRootDensity = LocalDensity.current
                    val safeRootScale = settings.uiScale.coerceIn(0.8f, 1.5f)
                    val chromeScale = safeRootScale.coerceAtMost(1.2f)
                    val chromeDensity = Density(
                        density = inheritedRootDensity.density * (chromeScale / safeRootScale),
                        fontScale = inheritedRootDensity.fontScale
                    )
                    CompositionLocalProvider(LocalDensity provides chromeDensity) {
                        MemoraBottomBar(
                            language = settings.language,
                            selected = rootTab,
                            onHome = { openRoot(Routes.HOME) },
                            onSearch = { openRoot(Routes.SEARCH_LANDING) },
                            onAdd = { showNewNoteSheet = true },
                            onCalendar = { openRoot(Routes.CALENDAR_ROOT) },
                            onSettings = { openRoot(Routes.SETTINGS_HUB) },
                            modifier = Modifier.align(Alignment.BottomCenter)
                        )
                    }
                }
            }
        }

        if (showExportDialog) {
            ExportDialog(
                language = settings.language,
                onDismiss = { showExportDialog = false },
                onExport = {
                    showExportDialog = false
                    onExport(it)
                }
            )
        }

        if (showNewNoteSheet) {
            NewNoteSheet(
                language = settings.language,
                onDismiss = { showNewNoteSheet = false },
                onShort = { openEditor(NoteType.SHORT) },
                onLong = { openEditor(NoteType.LONG) }
            )
        }
    }
}
