package com.memora.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Title
import androidx.compose.material.icons.rounded.Upload
import androidx.compose.material.icons.rounded.WorkspacePremium
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.memora.app.i18n.L
import com.memora.app.i18n.S
import com.memora.app.prefs.AppLanguage

@Composable
fun SettingsHubScreen(
    language: AppLanguage,
    isDark: Boolean,
    onExport: () -> Unit,
    onImport: () -> Unit,
    onSubscription: () -> Unit,
    onReminders: () -> Unit,
    onTitles: () -> Unit,
    onLanguage: () -> Unit,
    onStatistics: () -> Unit,
    onTheme: () -> Unit,
    onSecurity: () -> Unit,
    onToggleDark: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(
            start = 20.dp,
            end = 20.dp,
            top = 20.dp,
            bottom = 24.dp
        ),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Column(Modifier.padding(bottom = 8.dp)) {
                Text("Memora", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.SemiBold)
                Text(
                    L.t(language, S.HOME_TAGLINE),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }

        item { SettingsItem(Icons.Rounded.Download, L.t(language, S.SAVE_NOTES), onExport) }
        item { SettingsItem(Icons.Rounded.Upload, L.t(language, S.IMPORT_FILE), onImport) }
        item { SettingsItem(Icons.Rounded.WorkspacePremium, L.t(language, S.SUBSCRIPTION), onSubscription) }
        item { SettingsItem(Icons.Rounded.Notifications, L.t(language, S.WRITING_TIME), onReminders) }
        item { SettingsItem(Icons.Rounded.Title, L.t(language, S.TITLES), onTitles) }
        item { SettingsItem(Icons.Rounded.Language, L.t(language, S.LANGUAGE), onLanguage) }
        item { SettingsItem(Icons.Rounded.BarChart, L.t(language, S.STATISTICS), onStatistics) }
        item { SettingsItem(Icons.Rounded.Palette, L.t(language, S.THEME), onTheme) }
        item { SettingsItem(Icons.Rounded.Lock, L.t(language, S.SECURITY), onSecurity) }
        item {
            SettingsItem(
                if (isDark) Icons.Rounded.LightMode else Icons.Rounded.DarkMode,
                if (isDark) L.t(language, S.LIGHT) else L.t(language, S.DARK),
                onToggleDark
            )
        }
    }
}

@Composable
private fun SettingsItem(icon: ImageVector, text: String, onClick: () -> Unit) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 1.dp
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(end = 14.dp)
            )
            Text(text, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            Text("›", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
