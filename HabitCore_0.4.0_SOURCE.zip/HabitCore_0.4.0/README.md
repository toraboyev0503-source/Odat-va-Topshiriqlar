# HabitCore 0.4.0

## Changes

### Habits
- "Habits" top title is replaced by a direction selector.
- Add unlimited directions with the `+` control.
- Each direction has its own habits and its own monitoring.
- Existing habits are migrated safely to the `General` direction.
- Last five days are shown in the requested order: today → yesterday → older.
- Manual habit order now works: tap a habit, then use ↑ / ↓.
- Name / color / score sorting remains available.
- Result notifications show every habit direction in one notification.

### Tasks
- Completed tasks can be returned to unfinished state.
- Priority has four visual states:
  - none = neutral circle
  - very important = red
  - important = orange
  - later = yellow
- Priority order: red → orange → yellow → none; then date/time.
- Reopening a completed task also updates its daily task score.

## Data-safe update system

Database version: 4.

`fallbackToDestructiveMigration()` has been removed.

The 3 → 4 Room migration:
- creates the directions table,
- keeps every existing habit, habit result, task and monitoring record,
- assigns old habits to `General`,
- adds the new `categoryId` without deleting the database.

Future database changes must be implemented as explicit Room migrations.

## Test signing

Starting with 0.4.0, debug APKs are signed with the same bundled TEST key:
`app/signing/habitcore-test.keystore`

This is only for pilot/testing builds, not for Play Store release signing.

Because builds before 0.4.0 used the runner's default debug key, Android may reject the first
0.4.0 install as a signature mismatch. Do not uninstall first if that happens.

Safety tools are included:
- `tools/backup-current-data.bat`
- `tools/restore-data.bat`

They use ADB + `run-as` and are intended only for these debuggable pilot APKs.

From 0.4.0 onward, keep the same test keystore in every source build so normal Android update
installation preserves app data.

## GitHub ZIP workflow

Put `HabitCore_0.4.0_SOURCE.zip` in the repository root.
Put `main.yml` at `.github/workflows/main.yml`.

Artifact:
`HabitCore-0.4.0-debug-apk`
