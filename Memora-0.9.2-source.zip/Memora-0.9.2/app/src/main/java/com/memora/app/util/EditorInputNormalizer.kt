package com.memora.app.util

/**
 * Conservative IME helper. Paragraph creation is handled structurally by PlainTextEditor. Text is
 * never silently changed here: in particular, punctuation stays exactly as the user typed it.
 */
object EditorInputNormalizer {
    data class Result(val text: String, val cursor: Int, val changed: Boolean)

    fun normalize(
        previousText: String,
        incomingText: String,
        incomingCursor: Int,
        hasComposition: Boolean
    ): Result {
        val safeCursor = incomingCursor.coerceIn(0, incomingText.length)
        return Result(incomingText, safeCursor, false)
    }

    /**
     * Detects an Enter insertion from both hardware keys and composing IMEs. Some OEM keyboards
     * commit punctuation and then report two newline characters in one callback; that still means
     * one structural paragraph break for Memora and must not create duplicate numbered rows.
     */
    fun paragraphBreakCursor(
        previousText: String,
        incomingText: String,
        incomingCursor: Int
    ): Int? {
        val delta = incomingText.length - previousText.length
        if (delta !in 1..2) return null
        val cursor = incomingCursor.coerceIn(0, incomingText.length)
        val insertedStart = cursor - delta
        if (insertedStart < 0) return null
        val inserted = incomingText.substring(insertedStart, cursor)
        if (inserted.any { it != '\n' }) return null
        if (incomingText.removeRange(insertedStart, cursor) != previousText) return null
        return insertedStart.coerceIn(0, previousText.length)
    }

    /** Returns only the next list marker, never a newline. */
    fun numberedListPrefix(text: String, cursor: Int): String {
        val before = text.substring(0, cursor.coerceIn(0, text.length))
        val currentLine = before.substringAfterLast('\n')
        val match = Regex("^\\s*(\\d+)\\.\\s+\\S.*$").matchEntire(currentLine) ?: return ""
        val number = match.groupValues[1].toLongOrNull() ?: return ""
        if (number == Long.MAX_VALUE) return ""
        return "${number + 1}. "
    }
}
