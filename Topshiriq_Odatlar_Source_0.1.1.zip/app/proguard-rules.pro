# 0.1.0: no custom shrinking rules yet. Release minification is disabled during testing.
