package uz.topshiriqodatlar.app.domain

object EfficiencyCalculator {
    fun progress(value: Double, target: Double): Double {
        if (target <= 0.0) return 0.0
        return (value / target).coerceIn(0.0, 1.0)
    }

    fun averagePercent(progressValues: List<Double>): Double? {
        if (progressValues.isEmpty()) return null
        return progressValues.average().coerceIn(0.0, 1.0) * 100.0
    }

    fun taskPercent(completed: Int, total: Int): Double? {
        if (total <= 0) return null
        return (completed.toDouble() / total.toDouble()).coerceIn(0.0, 1.0) * 100.0
    }

    fun overall(habitsPercent: Double?, tasksPercent: Double?): Double? = when {
        habitsPercent != null && tasksPercent != null -> (habitsPercent + tasksPercent) / 2.0
        habitsPercent != null -> habitsPercent
        tasksPercent != null -> tasksPercent
        else -> null
    }
}
