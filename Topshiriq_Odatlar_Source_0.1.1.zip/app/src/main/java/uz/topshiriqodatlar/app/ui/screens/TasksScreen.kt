package uz.topshiriqodatlar.app.ui.screens

import android.app.AlarmManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.KeyboardArrowUp
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import uz.topshiriqodatlar.app.MainViewModel
import uz.topshiriqodatlar.app.data.AppSettings
import uz.topshiriqodatlar.app.data.TaskEntity
import uz.topshiriqodatlar.app.data.TaskPriority
import uz.topshiriqodatlar.app.data.TaskStatus
import uz.topshiriqodatlar.app.domain.UiStrings
import uz.topshiriqodatlar.app.ui.RoundMenuButton
import uz.topshiriqodatlar.app.ui.SideMenu
import uz.topshiriqodatlar.app.ui.percentText
import uz.topshiriqodatlar.app.ui.theme.SemanticColors
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime

@Composable
fun TasksScreen(
    viewModel: MainViewModel,
    strings: UiStrings,
    settings: AppSettings,
    rescheduleTaskId: Long?,
    onConsumeReschedule: () -> Unit,
    onBack: () -> Unit,
    onStatistics: () -> Unit,
    onArchive: () -> Unit
) {
    val tasks by viewModel.tasksToday.collectAsState()
    val efficiency by viewModel.todayEfficiency.collectAsState()
    var drawer by remember { mutableStateOf(false) }
    var newTask by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<TaskEntity?>(null) }
    var rescheduling by remember { mutableStateOf<TaskEntity?>(null) }
    var pendingDelete by remember { mutableStateOf<TaskEntity?>(null) }

    LaunchedEffect(rescheduleTaskId) {
        if (rescheduleTaskId != null) {
            rescheduling = viewModel.getTask(rescheduleTaskId)
            onConsumeReschedule()
        }
    }

    val active = tasks.filter { it.status == TaskStatus.PENDING }
    val completed = tasks.filter { it.status == TaskStatus.COMPLETED }
    val listState = rememberLazyListState()

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
            Row(
                Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RoundMenuButton({ drawer = true })
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(strings.tasks, style = MaterialTheme.typography.headlineSmall)
                    Text("${strings.today} · ${percentText(efficiency?.totalPercent)}", color = MaterialTheme.colorScheme.secondary)
                }
                FloatingActionButton(onClick = { newTask = true }, modifier = Modifier.size(48.dp), shape = CircleShape) {
                    Icon(Icons.Outlined.Add, contentDescription = strings.addTask)
                }
            }

            ExactAlarmBanner(strings)
            if (tasks.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(strings.noTasks, color = MaterialTheme.colorScheme.secondary)
                }
            } else {
                LazyColumn(state = listState, verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    if (active.isNotEmpty()) item { Text(strings.active, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary) }
                    items(active, key = { it.id }) { task ->
                        TaskCard(task, strings, listState.isScrollInProgress, onToggle = { viewModel.toggleTask(task) }, onEdit = { editing = task }, onDelete = { pendingDelete = task })
                    }
                    if (completed.isNotEmpty()) {
                        item {
                            Column(Modifier.padding(vertical = 10.dp)) {
                                HorizontalDivider()
                                Spacer(Modifier.height(10.dp))
                                Text(strings.finished, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary)
                            }
                        }
                        items(completed, key = { it.id }) { task ->
                            TaskCard(task, strings, listState.isScrollInProgress, onToggle = { viewModel.toggleTask(task) }, onEdit = { editing = task }, onDelete = { pendingDelete = task })
                        }
                    }
                    item { Spacer(Modifier.height(80.dp)) }
                }
            }
        }

        SideMenu(
            visible = drawer,
            settings = settings,
            strings = strings,
            showArchive = true,
            onDismiss = { drawer = false },
            onStatistics = onStatistics,
            onArchive = onArchive,
            onLanguage = viewModel.settingsRepository::setLanguage,
            onPalette = viewModel.settingsRepository::setPalette,
            onDarkMode = viewModel.settingsRepository::setDarkMode
        )
    }

    if (newTask) {
        TaskEditorDialog(strings, null, lockSchedule = false, onDismiss = { newTask = false }) { text, priority, date, minutes ->
            viewModel.addTask(text, priority, date, minutes)
            newTask = false
        }
    }
    editing?.let { task ->
        TaskEditorDialog(strings, task, lockSchedule = task.status != TaskStatus.PENDING, onDismiss = { editing = null }) { text, priority, date, minutes ->
            viewModel.updateTask(task, text, priority, date, minutes)
            editing = null
        }
    }
    rescheduling?.let { task ->
        RescheduleDialog(strings, task, onDismiss = { rescheduling = null }) { date, minutes ->
            viewModel.rescheduleTask(task.id, date, minutes)
            rescheduling = null
        }
    }
    pendingDelete?.let { task ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text(strings.delete) },
            text = { Text(strings.deleteConfirm) },
            confirmButton = {
                Button(onClick = { viewModel.deleteTask(task); pendingDelete = null }) { Text(strings.delete) }
            },
            dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text(strings.cancel) } }
        )
    }
}

@Composable
private fun ExactAlarmBanner(strings: UiStrings) {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return
    val context = LocalContext.current
    val alarm = context.getSystemService(AlarmManager::class.java)
    if (alarm.canScheduleExactAlarms()) return
    Card(
        modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(12.dp)) {
            Text(strings.exactAlarmNote, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
            TextButton(onClick = {
                runCatching {
                    context.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${context.packageName}")))
                }
            }) { Text(strings.settings) }
        }
    }
}

@Composable
fun TaskCard(
    task: TaskEntity,
    strings: UiStrings,
    listScrolling: Boolean,
    onToggle: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    var expanded by remember(task.id) { mutableStateOf(false) }
    var interaction by remember(task.id) { mutableIntStateOf(0) }
    var menu by remember(task.id) { mutableStateOf(false) }
    val words = remember(task.text) { task.text.trim().split(Regex("\\s+")).filter { it.isNotBlank() } }
    val long = words.size > 15
    val shown = if (expanded || !long) task.text else words.take(15).joinToString(" ") + "…"

    LaunchedEffect(expanded, interaction, listScrolling) {
        if (expanded && !listScrolling) {
            delay(5_000)
            expanded = false
        }
    }

    val priorityColor = when (task.priority) {
        TaskPriority.VERY_IMPORTANT -> SemanticColors.VeryImportant
        TaskPriority.IMPORTANT -> SemanticColors.Important
        else -> SemanticColors.Later
    }
    val container = if (task.status == TaskStatus.COMPLETED) {
        SemanticColors.Done.copy(alpha = .12f).compositeOver(MaterialTheme.colorScheme.surface)
    } else priorityColor.copy(alpha = .08f).compositeOver(MaterialTheme.colorScheme.surface)

    Card(
        colors = CardDefaults.cardColors(containerColor = container),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth().clickable { interaction++; if (long) expanded = !expanded }
    ) {
        Column(Modifier.fillMaxWidth().padding(15.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(shown, style = MaterialTheme.typography.bodyLarge)
                    Spacer(Modifier.height(5.dp))
                    Text(strings.priorityLabel(task.priority), color = priorityColor, style = MaterialTheme.typography.labelMedium)
                }
                Box {
                    IconButton(onClick = { interaction++; menu = true }) { Icon(Icons.Outlined.MoreVert, contentDescription = null) }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text(strings.editTask) }, leadingIcon = { Icon(Icons.Outlined.Edit, null) }, onClick = { menu = false; onEdit() })
                        DropdownMenuItem(text = { Text(strings.delete) }, leadingIcon = { Icon(Icons.Outlined.DeleteOutline, null) }, onClick = { menu = false; onDelete() })
                    }
                }
                Surface(
                    onClick = { interaction++; onToggle() },
                    shape = CircleShape,
                    color = if (task.status == TaskStatus.COMPLETED) SemanticColors.Done else priorityColor.copy(alpha = .15f),
                    modifier = Modifier.size(50.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(if (task.status == TaskStatus.COMPLETED) "✓" else "!", color = if (task.status == TaskStatus.COMPLETED) Color.White else priorityColor, style = MaterialTheme.typography.titleMedium)
                    }
                }
            }
            if (long) {
                Icon(
                    if (expanded) Icons.Outlined.KeyboardArrowUp else Icons.Outlined.KeyboardArrowDown,
                    contentDescription = null,
                    modifier = Modifier.align(Alignment.CenterHorizontally).size(22.dp)
                )
            }
        }
    }
}

@Composable
fun TaskEditorDialog(
    strings: UiStrings,
    original: TaskEntity?,
    lockSchedule: Boolean,
    onDismiss: () -> Unit,
    onSave: (String, Int, Long, Int?) -> Unit
) {
    val initialDate = original?.let { LocalDate.ofEpochDay(it.scheduledEpochDay) } ?: LocalDate.now()
    val initialMinutes = original?.deadlineMinutesOfDay ?: run {
        val t = LocalTime.now().plusHours(1)
        t.hour * 60 + t.minute
    }
    var text by remember(original?.id) { mutableStateOf(original?.text ?: "") }
    var priority by remember(original?.id) { mutableIntStateOf(original?.priority ?: TaskPriority.IMPORTANT) }
    var day by remember(original?.id) { mutableStateOf(initialDate.dayOfMonth.toString().padStart(2, '0')) }
    var month by remember(original?.id) { mutableStateOf(initialDate.monthValue.toString().padStart(2, '0')) }
    var year by remember(original?.id) { mutableStateOf(initialDate.year.toString()) }
    var hour by remember(original?.id) { mutableStateOf((initialMinutes / 60).toString().padStart(2, '0')) }
    var minute by remember(original?.id) { mutableStateOf((initialMinutes % 60).toString().padStart(2, '0')) }
    var error by remember { mutableStateOf<String?>(null) }
    val focusRequester = remember { FocusRequester() }
    val words = text.trim().split(Regex("\\s+")).count { it.isNotBlank() }

    LaunchedEffect(Unit) {
        if (original == null) {
            delay(180)
            focusRequester.requestFocus()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.imePadding(),
        title = { Text(if (original == null) strings.addTask else strings.editTask) },
        text = {
            Column(
                Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    label = { Text(strings.taskText) },
                    modifier = Modifier.fillMaxWidth().focusRequester(focusRequester),
                    minLines = 3,
                    keyboardActions = KeyboardActions()
                )
                if (words > 15) Text(strings.wordLimitWarning, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                Text("${strings.priority}: ${strings.priorityLabel(priority)}", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(priority == TaskPriority.VERY_IMPORTANT, { priority = TaskPriority.VERY_IMPORTANT }, { Text(strings.veryImportant) })
                    FilterChip(priority == TaskPriority.IMPORTANT, { priority = TaskPriority.IMPORTANT }, { Text(strings.important) })
                }
                FilterChip(priority == TaskPriority.LATER, { priority = TaskPriority.LATER }, { Text(strings.later) })

                Text(strings.date, style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    NumberField(day, { day = digits(it, 2) }, "DD", lockSchedule, Modifier.weight(1f))
                    NumberField(month, { month = digits(it, 2) }, "MM", lockSchedule, Modifier.weight(1f))
                    NumberField(year, { year = digits(it, 4) }, "YYYY", lockSchedule, Modifier.weight(1.35f))
                }
                Text(strings.deadline, style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    NumberField(hour, { hour = digits(it, 2) }, "HH", lockSchedule, Modifier.weight(1f))
                    NumberField(minute, { minute = digits(it, 2) }, "MM", lockSchedule, Modifier.weight(1f))
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            Button(onClick = {
                val date = parseDate(day, month, year)
                val h = hour.toIntOrNull()
                val m = minute.toIntOrNull()
                val dateTime = if (date != null && h != null && m != null && h in 0..23 && m in 0..59) LocalDateTime.of(date, LocalTime.of(h, m)) else null
                error = when {
                    text.isBlank() -> strings.emptyTask
                    date == null -> strings.invalidDate
                    h == null || h !in 0..23 || m == null || m !in 0..59 -> strings.invalidTime
                    !lockSchedule && dateTime != null && dateTime.isBefore(LocalDateTime.now()) -> strings.invalidTime
                    else -> null
                }
                if (error == null && date != null && h != null && m != null) onSave(text, priority, date.toEpochDay(), h * 60 + m)
            }) { Text(strings.save) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(strings.cancel) } }
    )
}

@Composable
private fun RescheduleDialog(strings: UiStrings, task: TaskEntity, onDismiss: () -> Unit, onSave: (Long, Int) -> Unit) {
    val suggested = remember(task.id) { LocalDateTime.now().plusHours(1) }
    var day by remember { mutableStateOf(suggested.dayOfMonth.toString().padStart(2, '0')) }
    var month by remember { mutableStateOf(suggested.monthValue.toString().padStart(2, '0')) }
    var year by remember { mutableStateOf(suggested.year.toString()) }
    var hour by remember { mutableStateOf(suggested.hour.toString().padStart(2, '0')) }
    var minute by remember { mutableStateOf(suggested.minute.toString().padStart(2, '0')) }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(strings.reschedule) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text(task.text)
                Text(strings.rescheduleHint, color = MaterialTheme.colorScheme.secondary, style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    NumberField(day, { day = digits(it, 2) }, "DD", false, Modifier.weight(1f))
                    NumberField(month, { month = digits(it, 2) }, "MM", false, Modifier.weight(1f))
                    NumberField(year, { year = digits(it, 4) }, "YYYY", false, Modifier.weight(1.35f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    NumberField(hour, { hour = digits(it, 2) }, "HH", false, Modifier.weight(1f))
                    NumberField(minute, { minute = digits(it, 2) }, "MM", false, Modifier.weight(1f))
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            Button(onClick = {
                val date = parseDate(day, month, year)
                val h = hour.toIntOrNull()
                val m = minute.toIntOrNull()
                val dateTime = if (date != null && h != null && m != null && h in 0..23 && m in 0..59) LocalDateTime.of(date, LocalTime.of(h, m)) else null
                error = when {
                    date == null -> strings.invalidDate
                    h == null || h !in 0..23 || m == null || m !in 0..59 -> strings.invalidTime
                    dateTime != null && dateTime.isBefore(LocalDateTime.now()) -> strings.invalidTime
                    else -> null
                }
                if (error == null && date != null && h != null && m != null) onSave(date.toEpochDay(), h * 60 + m)
            }) { Text(strings.save) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(strings.cancel) } }
    )
}

@Composable
private fun NumberField(value: String, onValue: (String) -> Unit, label: String, locked: Boolean, modifier: Modifier) {
    var wasFocused by remember { mutableStateOf(false) }
    OutlinedTextField(
        value = value,
        onValueChange = onValue,
        label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        singleLine = true,
        enabled = !locked,
        modifier = modifier.onFocusChanged { state ->
            if (!locked && state.isFocused && !wasFocused) onValue("")
            wasFocused = state.isFocused
        }
    )
}

private fun digits(value: String, max: Int) = value.filter(Char::isDigit).take(max)
private fun parseDate(day: String, month: String, year: String): LocalDate? = try {
    LocalDate.of(year.toInt(), month.toInt(), day.toInt())
} catch (_: Exception) { null }

private fun Color.compositeOver(background: Color): Color {
    val a = alpha + background.alpha * (1f - alpha)
    if (a <= 0f) return Color.Transparent
    return Color(
        red = (red * alpha + background.red * background.alpha * (1f - alpha)) / a,
        green = (green * alpha + background.green * background.alpha * (1f - alpha)) / a,
        blue = (blue * alpha + background.blue * background.alpha * (1f - alpha)) / a,
        alpha = a
    )
}
