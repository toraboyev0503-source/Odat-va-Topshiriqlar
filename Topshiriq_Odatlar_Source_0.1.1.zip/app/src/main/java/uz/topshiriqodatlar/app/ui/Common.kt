package uz.topshiriqodatlar.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Archive
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.outlined.LightMode
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.Translate
import androidx.compose.material3.AssistChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import uz.topshiriqodatlar.app.data.AppLanguage
import uz.topshiriqodatlar.app.data.AppPalette
import uz.topshiriqodatlar.app.data.AppSettings
import uz.topshiriqodatlar.app.domain.UiStrings

@Composable
fun RoundMenuButton(onClick: () -> Unit, modifier: Modifier = Modifier) {
    val lineColor = MaterialTheme.colorScheme.onSurface
    Surface(
        onClick = onClick,
        modifier = modifier.size(44.dp),
        shape = CircleShape,
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 1.dp
    ) {
        Box(contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(20.dp)) {
                drawLine(lineColor, Offset(size.width * .18f, size.height * .34f), Offset(size.width * .82f, size.height * .34f), 2.3f, StrokeCap.Round)
                drawLine(lineColor, Offset(size.width * .18f, size.height * .66f), Offset(size.width * .66f, size.height * .66f), 2.3f, StrokeCap.Round)
            }
        }
    }
}

@Composable
fun SideMenu(
    visible: Boolean,
    settings: AppSettings,
    strings: UiStrings,
    showArchive: Boolean,
    onDismiss: () -> Unit,
    onStatistics: () -> Unit,
    onArchive: () -> Unit,
    onLanguage: (String) -> Unit,
    onPalette: (String) -> Unit,
    onDarkMode: (Boolean) -> Unit
) {
    AnimatedVisibility(visible = visible) {
        Box(Modifier.fillMaxSize()) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = .28f))
                    .clickable(onClick = onDismiss)
            )
            Surface(
                modifier = Modifier.fillMaxHeight().fillMaxWidth(.64f),
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 8.dp,
                shape = RoundedCornerShape(topEnd = 26.dp, bottomEnd = 26.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(strings.menu, style = MaterialTheme.typography.headlineSmall)
                    MenuRow(Icons.Outlined.BarChart, strings.statistics) { onDismiss(); onStatistics() }
                    if (showArchive) MenuRow(Icons.Outlined.Archive, strings.archive) { onDismiss(); onArchive() }
                    HorizontalDivider(Modifier.padding(vertical = 4.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Translate, contentDescription = null)
                        Spacer(Modifier.width(10.dp))
                        Text(strings.language, style = MaterialTheme.typography.titleMedium)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(AppLanguage.EN to "EN", AppLanguage.RU to "RU", AppLanguage.UZ to "UZ").forEach { (code, label) ->
                            AssistChip(onClick = { onLanguage(code) }, label = { Text(label) })
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Palette, contentDescription = null)
                        Spacer(Modifier.width(10.dp))
                        Text(strings.theme, style = MaterialTheme.typography.titleMedium)
                    }
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf(
                            AppPalette.STONE to strings.stone,
                            AppPalette.PAPER to strings.paper,
                            AppPalette.GRAPHITE to strings.graphite,
                            AppPalette.SAND to strings.sand
                        ).forEach { (code, label) ->
                            Text(
                                text = if (settings.palette == code) "• $label" else label,
                                modifier = Modifier.fillMaxWidth().clickable { onPalette(code) }.padding(vertical = 5.dp),
                                style = MaterialTheme.typography.bodyLarge
                            )
                        }
                    }
                    Spacer(Modifier.weight(1f))
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.background,
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    ) {
                        IconButton(onClick = { onDarkMode(!settings.darkMode) }) {
                            Icon(
                                if (settings.darkMode) Icons.Outlined.LightMode else Icons.Outlined.DarkMode,
                                contentDescription = strings.lightDark,
                                modifier = Modifier.graphicsLayer { rotationZ = if (settings.darkMode) 8f else 0f }
                            )
                        }
                    }
                    Text(strings.lightDark, modifier = Modifier.align(Alignment.CenterHorizontally), style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}

@Composable
private fun MenuRow(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null)
        Spacer(Modifier.width(12.dp))
        Text(text, style = MaterialTheme.typography.titleMedium)
    }
}

fun percentText(value: Double?): String = value?.let { "${kotlin.math.round(it).toInt()}%" } ?: "—"
