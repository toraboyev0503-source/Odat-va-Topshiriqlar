package uz.topshiriqodatlar.app.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface HabitDao {
    @Query("SELECT * FROM habits WHERE archivedEpochDay IS NULL ORDER BY createdAt ASC")
    fun observeActiveHabits(): Flow<List<HabitEntity>>

    @Query("SELECT * FROM habits ORDER BY createdAt ASC")
    suspend fun getAllHabits(): List<HabitEntity>

    @Query("SELECT * FROM habits WHERE id = :id LIMIT 1")
    suspend fun getHabit(id: Long): HabitEntity?

    @Insert
    suspend fun insertHabit(habit: HabitEntity): Long

    @Update
    suspend fun updateHabit(habit: HabitEntity)

    @Delete
    suspend fun deleteHabit(habit: HabitEntity)

    @Upsert
    suspend fun upsertEntry(entry: HabitEntryEntity)

    @Query("DELETE FROM habit_entries WHERE habitId = :habitId AND dateEpochDay = :dateEpochDay")
    suspend fun deleteEntry(habitId: Long, dateEpochDay: Long)

    @Query("SELECT * FROM habit_entries WHERE dateEpochDay = :dateEpochDay")
    fun observeEntriesForDate(dateEpochDay: Long): Flow<List<HabitEntryEntity>>

    @Query("SELECT * FROM habit_entries WHERE habitId = :habitId AND dateEpochDay BETWEEN :fromEpochDay AND :toEpochDay ORDER BY dateEpochDay ASC")
    suspend fun getEntriesForHabitRange(habitId: Long, fromEpochDay: Long, toEpochDay: Long): List<HabitEntryEntity>

    @Query("SELECT * FROM habit_entries WHERE dateEpochDay BETWEEN :fromEpochDay AND :toEpochDay ORDER BY dateEpochDay ASC")
    suspend fun getEntriesRange(fromEpochDay: Long, toEpochDay: Long): List<HabitEntryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGoalHistory(history: HabitGoalHistoryEntity)

    @Query("SELECT * FROM habit_goal_history WHERE habitId = :habitId ORDER BY effectiveEpochDay ASC")
    suspend fun getGoalHistory(habitId: Long): List<HabitGoalHistoryEntity>

    @Query("SELECT * FROM habit_goal_history ORDER BY habitId ASC, effectiveEpochDay ASC")
    suspend fun getAllGoalHistory(): List<HabitGoalHistoryEntity>
}

@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks WHERE scheduledEpochDay = :dateEpochDay AND status != 'MISSED' ORDER BY CASE WHEN status = 'PENDING' THEN 0 ELSE 1 END, priority ASC, createdAt ASC")
    fun observeTasksForDate(dateEpochDay: Long): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE scheduledEpochDay > :todayEpochDay AND status = 'PENDING' ORDER BY scheduledEpochDay ASC, priority ASC, createdAt ASC")
    fun observePlanned(todayEpochDay: Long): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE status IN ('COMPLETED','MISSED') ORDER BY scheduledEpochDay DESC, createdAt DESC LIMIT :limit")
    fun observeHistory(limit: Int = 500): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE id = :id LIMIT 1")
    suspend fun getTask(id: Long): TaskEntity?

    @Query("SELECT * FROM tasks WHERE scheduledEpochDay BETWEEN :fromEpochDay AND :toEpochDay ORDER BY scheduledEpochDay ASC")
    suspend fun getTasksRange(fromEpochDay: Long, toEpochDay: Long): List<TaskEntity>

    @Query("SELECT * FROM tasks WHERE status = 'PENDING' AND scheduledEpochDay < :todayEpochDay ORDER BY scheduledEpochDay ASC, createdAt ASC")
    suspend fun getOverduePending(todayEpochDay: Long): List<TaskEntity>

    @Query("SELECT * FROM tasks WHERE status = 'PENDING'")
    suspend fun getAllPending(): List<TaskEntity>

    @Query("SELECT * FROM tasks WHERE seriesId = :seriesId AND scheduledEpochDay = :dateEpochDay LIMIT 1")
    suspend fun findSeriesOnDate(seriesId: String, dateEpochDay: Long): TaskEntity?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertTask(task: TaskEntity): Long

    @Update
    suspend fun updateTask(task: TaskEntity)

    @Delete
    suspend fun deleteTask(task: TaskEntity)
}
