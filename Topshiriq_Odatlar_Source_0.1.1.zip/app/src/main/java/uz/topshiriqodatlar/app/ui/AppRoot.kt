package uz.topshiriqodatlar.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import kotlinx.coroutines.delay
import java.time.Duration
import java.time.LocalDateTime
import uz.topshiriqodatlar.app.MainViewModel
import uz.topshiriqodatlar.app.R
import uz.topshiriqodatlar.app.domain.Localizer
import uz.topshiriqodatlar.app.ui.screens.ArchiveScreen
import uz.topshiriqodatlar.app.ui.screens.HabitDetailScreen
import uz.topshiriqodatlar.app.ui.screens.HabitsScreen
import uz.topshiriqodatlar.app.ui.screens.HomeScreen
import uz.topshiriqodatlar.app.ui.screens.StatisticsScreen
import uz.topshiriqodatlar.app.ui.screens.TasksScreen
import uz.topshiriqodatlar.app.ui.theme.TopshiriqOdatlarTheme

private sealed interface Destination {
    data object Home : Destination
    data object Habits : Destination
    data object Tasks : Destination
    data object Statistics : Destination
    data object Archive : Destination
    data class HabitDetail(val id: Long) : Destination
}

@Composable
fun AppRoot(
    viewModel: MainViewModel,
    rescheduleTaskId: Long?,
    openTaskId: Long?,
    openHabitId: Long?,
    onConsumeReschedule: () -> Unit,
    onConsumeOpenTask: () -> Unit,
    onConsumeOpenHabit: () -> Unit
) {
    val settings by viewModel.settings.collectAsState()
    val strings = remember(settings.language) { Localizer.strings(settings.language) }
    var destination: Destination by remember { mutableStateOf(Destination.Home) }
    var statsReturn: Destination by remember { mutableStateOf(Destination.Habits) }
    var splash by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        viewModel.refreshDay()
        delay(650)
        splash = false
    }
    LaunchedEffect(Unit) {
        while (true) {
            val now = LocalDateTime.now()
            val nextMidnight = now.toLocalDate().plusDays(1).atStartOfDay().plusSeconds(1)
            delay(Duration.between(now, nextMidnight).toMillis().coerceAtLeast(1_000L))
            viewModel.refreshDay()
        }
    }
    LaunchedEffect(rescheduleTaskId) {
        if (rescheduleTaskId != null) destination = Destination.Tasks
    }
    LaunchedEffect(openTaskId) {
        if (openTaskId != null) {
            destination = Destination.Tasks
            onConsumeOpenTask()
        }
    }
    LaunchedEffect(openHabitId) {
        if (openHabitId != null) {
            destination = Destination.HabitDetail(openHabitId)
            onConsumeOpenHabit()
        }
    }

    TopshiriqOdatlarTheme(settings) {
        Box(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
            if (splash) {
                Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    Image(painterResource(R.drawable.ic_launcher_foreground), contentDescription = null, modifier = Modifier.size(112.dp))
                    Spacer(Modifier.height(14.dp))
                    Text(strings.appName, style = MaterialTheme.typography.titleLarge)
                }
            } else {
                when (val d = destination) {
                    Destination.Home -> HomeScreen(strings, { destination = Destination.Habits }, { destination = Destination.Tasks })
                    Destination.Habits -> HabitsScreen(
                        viewModel, strings, settings,
                        onBack = { destination = Destination.Home },
                        onStatistics = { statsReturn = Destination.Habits; destination = Destination.Statistics },
                        onHabitDetail = { destination = Destination.HabitDetail(it) }
                    )
                    Destination.Tasks -> TasksScreen(
                        viewModel, strings, settings,
                        rescheduleTaskId = rescheduleTaskId,
                        onConsumeReschedule = onConsumeReschedule,
                        onBack = { destination = Destination.Home },
                        onStatistics = { statsReturn = Destination.Tasks; destination = Destination.Statistics },
                        onArchive = { destination = Destination.Archive }
                    )
                    Destination.Statistics -> StatisticsScreen(viewModel, strings, onBack = { destination = statsReturn })
                    Destination.Archive -> ArchiveScreen(viewModel, strings, onBack = { destination = Destination.Tasks })
                    is Destination.HabitDetail -> HabitDetailScreen(viewModel, strings, d.id, onBack = { destination = Destination.Habits })
                }
            }
        }
    }

    BackHandler(enabled = destination != Destination.Home) {
        destination = when (destination) {
            Destination.Archive -> Destination.Tasks
            Destination.Statistics -> statsReturn
            is Destination.HabitDetail -> Destination.Habits
            else -> Destination.Home
        }
    }
}
