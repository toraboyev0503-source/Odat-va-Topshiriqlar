package uz.topshiriqodatlar.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.ChevronLeft
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import uz.topshiriqodatlar.app.MainViewModel
import uz.topshiriqodatlar.app.data.AppLanguage
import uz.topshiriqodatlar.app.domain.DailyEfficiency
import uz.topshiriqodatlar.app.domain.DayDetails
import uz.topshiriqodatlar.app.domain.UiStrings
import uz.topshiriqodatlar.app.ui.percentText
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.Month
import java.time.YearMonth
import java.time.format.TextStyle
import java.util.Locale

@Composable
fun StatisticsScreen(viewModel: MainViewModel, strings: UiStrings, onBack: () -> Unit) {
    val today = LocalDate.now()
    val settings by viewModel.settings.collectAsState()
    val locale = remember(settings.language) { when (settings.language) { AppLanguage.RU -> Locale("ru"); AppLanguage.UZ -> Locale("uz"); else -> Locale.ENGLISH } }
    var year by remember { mutableStateOf(today.year) }
    var month by remember { mutableStateOf<YearMonth?>(null) }
    var selectedDay by remember { mutableStateOf<Long?>(null) }
    val start = LocalDate.of(year, 1, 1).toEpochDay()
    val end = LocalDate.of(year, 12, 31).toEpochDay()
    val stats by produceState<List<DailyEfficiency>?>(null, year) {
        value = viewModel.efficiencies(start, end)
    }

    val data = stats
    if (data == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        return
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { if (month != null) month = null else onBack() }) {
                Icon(Icons.Outlined.ArrowBack, contentDescription = strings.back)
            }
            Spacer(Modifier.width(6.dp))
            Text(strings.statistics, style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f))
            if (month == null) {
                IconButton(onClick = { year-- }) { Icon(Icons.Outlined.ChevronLeft, null) }
                Text(year.toString(), style = MaterialTheme.typography.titleMedium)
                IconButton(onClick = { year++ }) { Icon(Icons.Outlined.ChevronRight, null) }
            }
        }

        if (month == null) {
            YearGrid(year, data, today, locale) { month = YearMonth.of(year, it) }
        } else {
            MonthCalendar(month!!, data, today, locale) { selectedDay = it }
        }
    }

    selectedDay?.let { day ->
        val details by produceState<DayDetails?>(null, day) { value = viewModel.dayDetails(day) }
        details?.let {
            AlertDialog(
                onDismissRequest = { selectedDay = null },
                title = { Text("${strings.dayDetails} · ${LocalDate.ofEpochDay(day)}") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("${strings.habitsScore}: ${percentText(it.efficiency.habitsPercent)}")
                        Text("${strings.tasksScore}: ${percentText(it.efficiency.tasksPercent)}")
                        Text("${strings.overallScore}: ${percentText(it.efficiency.totalPercent)}", style = MaterialTheme.typography.titleMedium)
                    }
                },
                confirmButton = { TextButton(onClick = { selectedDay = null }) { Text("OK") } }
            )
        }
    }
}

@Composable
private fun YearGrid(year: Int, data: List<DailyEfficiency>, today: LocalDate, locale: Locale, onMonth: (Int) -> Unit) {
    val byDay = remember(data) { data.associateBy { it.epochDay } }
    val months = (1..12).toList()
    LazyVerticalGrid(columns = GridCells.Fixed(3), verticalArrangement = Arrangement.spacedBy(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        items(months) { m ->
            val ym = YearMonth.of(year, m)
            val lastDay = minOf(ym.atEndOfMonth(), today).takeIf { year <= today.year } ?: ym.atEndOfMonth()
            val values = if (year > today.year || (year == today.year && m > today.monthValue)) emptyList() else
                (1..lastDay.dayOfMonth).mapNotNull { d -> byDay[ym.atDay(d).toEpochDay()]?.totalPercent }
            val avg = values.takeIf { it.isNotEmpty() }?.average()
            Card(
                onClick = { onMonth(m) },
                modifier = Modifier.fillMaxWidth().aspectRatio(1.05f),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.SpaceBetween) {
                    Text(Month.of(m).getDisplayName(TextStyle.SHORT, locale), style = MaterialTheme.typography.titleMedium)
                    Text(percentText(avg), style = MaterialTheme.typography.headlineSmall)
                }
            }
        }
    }
}

@Composable
private fun MonthCalendar(month: YearMonth, data: List<DailyEfficiency>, today: LocalDate, locale: Locale, onDay: (Long) -> Unit) {
    val byDay = remember(data) { data.associateBy { it.epochDay } }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Text("${month.month.getDisplayName(TextStyle.FULL, locale)} ${month.year}", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(bottom = 12.dp))
        val weekdayLabels = (1..7).map { DayOfWeek.of(it).getDisplayName(TextStyle.NARROW_STANDALONE, locale) }
        Row(Modifier.fillMaxWidth()) {
            weekdayLabels.forEach { label -> Box(Modifier.weight(1f), contentAlignment = Alignment.Center) { Text(label, color = MaterialTheme.colorScheme.secondary) } }
        }
        Spacer(Modifier.height(6.dp))
        val leading = month.atDay(1).dayOfWeek.value - 1
        val cells = leading + month.lengthOfMonth()
        val rows = (cells + 6) / 7
        repeat(rows) { r ->
            Row(Modifier.fillMaxWidth()) {
                repeat(7) { c ->
                    val index = r * 7 + c
                    val dayNum = index - leading + 1
                    if (dayNum !in 1..month.lengthOfMonth()) {
                        Spacer(Modifier.weight(1f).aspectRatio(1f))
                    } else {
                        val date = month.atDay(dayNum)
                        val score = byDay[date.toEpochDay()]?.totalPercent
                        Card(
                            modifier = Modifier.weight(1f).aspectRatio(1f).padding(2.dp).clickable(enabled = !date.isAfter(today)) { onDay(date.toEpochDay()) },
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(Modifier.fillMaxSize().padding(6.dp), verticalArrangement = Arrangement.SpaceBetween) {
                                Text(dayNum.toString(), style = MaterialTheme.typography.labelLarge)
                                Text(percentText(if (date.isAfter(today)) null else score), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                            }
                        }
                    }
                }
            }
        }
    }
}
