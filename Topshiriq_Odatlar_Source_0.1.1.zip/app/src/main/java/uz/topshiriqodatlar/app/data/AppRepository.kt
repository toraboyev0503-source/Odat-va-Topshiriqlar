package uz.topshiriqodatlar.app.data

import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import uz.topshiriqodatlar.app.domain.DailyEfficiency
import uz.topshiriqodatlar.app.domain.DayDetails
import uz.topshiriqodatlar.app.domain.EfficiencyCalculator
import uz.topshiriqodatlar.app.domain.HabitStats
import uz.topshiriqodatlar.app.domain.HabitWithToday
import java.time.LocalDate
import java.util.UUID

class AppRepository(private val db: AppDatabase) {
    private val habits = db.habitDao()
    private val tasks = db.taskDao()

    fun observeHabitsForDay(epochDay: Long): Flow<List<HabitWithToday>> =
        combine(habits.observeActiveHabits(), habits.observeEntriesForDate(epochDay)) { habitList, entries ->
            val map = entries.associateBy { it.habitId }
            habitList
                .filter { it.createdEpochDay <= epochDay && (it.archivedEpochDay == null || it.archivedEpochDay >= epochDay) }
                .map { habit ->
                    val entry = map[habit.id]
                    val progress = when (habit.type) {
                        HabitType.QUANTITY -> EfficiencyCalculator.progress(entry?.value ?: 0.0, habit.targetValue)
                        else -> if (entry?.completed == true) 1.0 else 0.0
                    }
                    HabitWithToday(habit, entry, progress)
                }
        }

    fun observeTasksForDay(epochDay: Long) = tasks.observeTasksForDate(epochDay)
    fun observePlanned(todayEpochDay: Long) = tasks.observePlanned(todayEpochDay)
    fun observeHistory() = tasks.observeHistory()

    suspend fun getHabit(habitId: Long): HabitEntity? = habits.getHabit(habitId)
    suspend fun getAllHabits(): List<HabitEntity> = habits.getAllHabits()

    suspend fun addHabit(
        name: String,
        type: String,
        targetValue: Double,
        unit: String,
        accentIndex: Int,
        reminderHour: Int?,
        reminderMinute: Int?,
        today: Long = LocalDate.now().toEpochDay()
    ): HabitEntity {
        val habit = HabitEntity(
            name = name.trim(),
            type = type,
            targetValue = if (type == HabitType.QUANTITY) targetValue.coerceAtLeast(0.0001) else 1.0,
            unit = if (type == HabitType.QUANTITY) unit.trim() else "",
            accentIndex = accentIndex,
            createdEpochDay = today,
            reminderHour = reminderHour,
            reminderMinute = reminderMinute
        )
        val id = habits.insertHabit(habit)
        val saved = habit.copy(id = id)
        habits.insertGoalHistory(
            HabitGoalHistoryEntity(
                habitId = id,
                effectiveEpochDay = today,
                targetValue = saved.targetValue,
                unit = saved.unit
            )
        )
        return saved
    }

    suspend fun updateHabit(
        original: HabitEntity,
        name: String,
        type: String,
        targetValue: Double,
        unit: String,
        reminderHour: Int?,
        reminderMinute: Int?,
        today: Long = LocalDate.now().toEpochDay()
    ): HabitEntity {
        val newTarget = if (type == HabitType.QUANTITY) targetValue.coerceAtLeast(0.0001) else 1.0
        val newUnit = if (type == HabitType.QUANTITY) unit.trim() else ""
        val updated = original.copy(
            name = name.trim(),
            type = type,
            targetValue = newTarget,
            unit = newUnit,
            reminderHour = reminderHour,
            reminderMinute = reminderMinute,
            updatedAt = System.currentTimeMillis()
        )
        db.withTransaction {
            habits.updateHabit(updated)
            if (original.targetValue != newTarget || original.unit != newUnit || original.type != type) {
                habits.insertGoalHistory(
                    HabitGoalHistoryEntity(
                        habitId = original.id,
                        effectiveEpochDay = today,
                        targetValue = newTarget,
                        unit = newUnit
                    )
                )
            }
        }
        return updated
    }

    suspend fun archiveHabit(habit: HabitEntity, today: Long = LocalDate.now().toEpochDay()) {
        habits.updateHabit(habit.copy(archivedEpochDay = today, updatedAt = System.currentTimeMillis()))
    }

    suspend fun deleteHabit(habit: HabitEntity) = habits.deleteHabit(habit)

    suspend fun toggleSimpleHabit(habit: HabitEntity, epochDay: Long = LocalDate.now().toEpochDay()) {
        val current = habits.getEntriesForHabitRange(habit.id, epochDay, epochDay).firstOrNull()
        if (current?.completed == true) {
            habits.deleteEntry(habit.id, epochDay)
        } else {
            habits.upsertEntry(
                HabitEntryEntity(
                    id = current?.id ?: 0,
                    habitId = habit.id,
                    dateEpochDay = epochDay,
                    value = 1.0,
                    completed = true
                )
            )
        }
    }

    suspend fun setQuantity(habit: HabitEntity, value: Double, epochDay: Long = LocalDate.now().toEpochDay()) {
        val current = habits.getEntriesForHabitRange(habit.id, epochDay, epochDay).firstOrNull()
        if (value <= 0.0) {
            habits.deleteEntry(habit.id, epochDay)
            return
        }
        val target = targetForDate(habit, epochDay)
        habits.upsertEntry(
            HabitEntryEntity(
                id = current?.id ?: 0,
                habitId = habit.id,
                dateEpochDay = epochDay,
                value = value,
                completed = value >= target
            )
        )
    }

    suspend fun addTask(
        text: String,
        priority: Int,
        scheduledEpochDay: Long,
        deadlineMinutesOfDay: Int?
    ): TaskEntity {
        val task = TaskEntity(
            seriesId = UUID.randomUUID().toString(),
            text = text.trim(),
            priority = priority,
            scheduledEpochDay = scheduledEpochDay,
            deadlineMinutesOfDay = deadlineMinutesOfDay
        )
        val id = tasks.insertTask(task)
        return task.copy(id = id)
    }

    suspend fun updateTask(task: TaskEntity, text: String, priority: Int, scheduledEpochDay: Long, deadlineMinutesOfDay: Int?): TaskEntity {
        val conflict = tasks.findSeriesOnDate(task.seriesId, scheduledEpochDay)
        if (conflict != null && conflict.id != task.id) return task
        val updated = task.copy(
            text = text.trim(),
            priority = priority,
            scheduledEpochDay = scheduledEpochDay,
            deadlineMinutesOfDay = deadlineMinutesOfDay
        )
        tasks.updateTask(updated)
        return updated
    }

    suspend fun setTaskCompleted(taskId: Long, completed: Boolean): TaskEntity? {
        val task = tasks.getTask(taskId) ?: return null
        val updated = task.copy(
            status = if (completed) TaskStatus.COMPLETED else TaskStatus.PENDING,
            completedAt = if (completed) System.currentTimeMillis() else null
        )
        tasks.updateTask(updated)
        return updated
    }

    suspend fun deleteTask(task: TaskEntity) = tasks.deleteTask(task)

    suspend fun getTask(taskId: Long): TaskEntity? = tasks.getTask(taskId)

    suspend fun rescheduleTask(taskId: Long, newEpochDay: Long, newMinutesOfDay: Int): TaskEntity? {
        val task = tasks.getTask(taskId) ?: return null
        val conflict = tasks.findSeriesOnDate(task.seriesId, newEpochDay)
        if (conflict != null && conflict.id != task.id) return null
        val updated = task.copy(
            scheduledEpochDay = newEpochDay,
            deadlineMinutesOfDay = newMinutesOfDay,
            status = TaskStatus.PENDING,
            completedAt = null
        )
        tasks.updateTask(updated)
        return updated
    }

    /**
     * Marks every overdue pending task occurrence as MISSED and recreates the same series for
     * every skipped date. Intermediate days are MISSED; today's occurrence is PENDING.
     * Unique(seriesId, scheduledEpochDay) prevents duplicate rollover rows.
     */
    suspend fun rolloverOverdue(todayEpochDay: Long = LocalDate.now().toEpochDay()): List<TaskEntity> {
        val createdToday = mutableListOf<TaskEntity>()
        db.withTransaction {
            val overdue = tasks.getOverduePending(todayEpochDay)
            for (original in overdue) {
                tasks.updateTask(original.copy(status = TaskStatus.MISSED, completedAt = null))
                var day = original.scheduledEpochDay + 1
                var previousId = original.id
                while (day <= todayEpochDay) {
                    val existing = tasks.findSeriesOnDate(original.seriesId, day)
                    if (existing != null) {
                        previousId = existing.id
                        day++
                        continue
                    }
                    val status = if (day == todayEpochDay) TaskStatus.PENDING else TaskStatus.MISSED
                    val occurrence = original.copy(
                        id = 0,
                        scheduledEpochDay = day,
                        status = status,
                        createdAt = System.currentTimeMillis(),
                        completedAt = null,
                        rolledFromTaskId = previousId
                    )
                    val newId = tasks.insertTask(occurrence)
                    if (newId > 0) {
                        val saved = occurrence.copy(id = newId)
                        previousId = newId
                        if (status == TaskStatus.PENDING) createdToday += saved
                    }
                    day++
                }
            }
        }
        return createdToday
    }

    suspend fun getAllPendingTasks(): List<TaskEntity> = tasks.getAllPending()

    suspend fun efficiencyForDay(epochDay: Long): DailyEfficiency {
        val allHabits = habits.getAllHabits().filter {
            it.createdEpochDay <= epochDay && (it.archivedEpochDay == null || it.archivedEpochDay >= epochDay)
        }
        val entries = habits.getEntriesRange(epochDay, epochDay).associateBy { it.habitId }
        val habitProgress = allHabits.map { habit ->
            val entry = entries[habit.id]
            if (habit.type == HabitType.QUANTITY) {
                EfficiencyCalculator.progress(entry?.value ?: 0.0, targetForDate(habit, epochDay))
            } else if (entry?.completed == true) 1.0 else 0.0
        }
        val habitsPercent = EfficiencyCalculator.averagePercent(habitProgress)

        val dayTasks = tasks.getTasksRange(epochDay, epochDay)
        val tasksPercent = EfficiencyCalculator.taskPercent(
            completed = dayTasks.count { it.status == TaskStatus.COMPLETED },
            total = dayTasks.size
        )
        return DailyEfficiency(
            epochDay = epochDay,
            habitsPercent = habitsPercent,
            tasksPercent = tasksPercent,
            totalPercent = EfficiencyCalculator.overall(habitsPercent, tasksPercent)
        )
    }

    suspend fun efficiencies(fromEpochDay: Long, toEpochDay: Long): List<DailyEfficiency> {
        if (toEpochDay < fromEpochDay) return emptyList()
        val allHabits = habits.getAllHabits()
        val entriesByDay = habits.getEntriesRange(fromEpochDay, toEpochDay).groupBy { it.dateEpochDay }
        val goalHistory = habits.getAllGoalHistory().groupBy { it.habitId }
        val tasksByDay = tasks.getTasksRange(fromEpochDay, toEpochDay).groupBy { it.scheduledEpochDay }

        return (fromEpochDay..toEpochDay).map { day ->
            val active = allHabits.filter { it.createdEpochDay <= day && (it.archivedEpochDay == null || it.archivedEpochDay >= day) }
            val entryMap = entriesByDay[day].orEmpty().associateBy { it.habitId }
            val progress = active.map { habit ->
                val entry = entryMap[habit.id]
                if (habit.type == HabitType.QUANTITY) {
                    val target = goalHistory[habit.id].orEmpty().lastOrNull { it.effectiveEpochDay <= day }?.targetValue ?: habit.targetValue
                    EfficiencyCalculator.progress(entry?.value ?: 0.0, target)
                } else if (entry?.completed == true) 1.0 else 0.0
            }
            val hp = EfficiencyCalculator.averagePercent(progress)
            val dayTasks = tasksByDay[day].orEmpty()
            val tp = EfficiencyCalculator.taskPercent(dayTasks.count { it.status == TaskStatus.COMPLETED }, dayTasks.size)
            DailyEfficiency(day, hp, tp, EfficiencyCalculator.overall(hp, tp))
        }
    }

    suspend fun dayDetails(epochDay: Long): DayDetails {
        val allHabits = habits.getAllHabits().filter {
            it.createdEpochDay <= epochDay && (it.archivedEpochDay == null || it.archivedEpochDay >= epochDay)
        }
        val entries = habits.getEntriesRange(epochDay, epochDay).associateBy { it.habitId }
        val habitRows = allHabits.map { habit ->
            val entry = entries[habit.id]
            val p = if (habit.type == HabitType.QUANTITY) {
                EfficiencyCalculator.progress(entry?.value ?: 0.0, targetForDate(habit, epochDay))
            } else if (entry?.completed == true) 1.0 else 0.0
            HabitWithToday(habit, entry, p)
        }
        return DayDetails(
            efficiency = efficiencyForDay(epochDay),
            habits = habitRows,
            tasks = tasks.getTasksRange(epochDay, epochDay)
        )
    }

    suspend fun habitStats(habitId: Long, todayEpochDay: Long = LocalDate.now().toEpochDay()): HabitStats? {
        val habit = habits.getHabit(habitId) ?: return null
        val end = minOf(todayEpochDay, habit.archivedEpochDay ?: todayEpochDay)
        if (end < habit.createdEpochDay) return null
        val entries = habits.getEntriesForHabitRange(habitId, habit.createdEpochDay, end)
        val entryMap = entries.associateBy { it.dateEpochDay }
        val goalHistory = habits.getGoalHistory(habitId)
        fun goalAt(day: Long): Double = if (habit.type == HabitType.QUANTITY) {
            goalHistory.lastOrNull { it.effectiveEpochDay <= day }?.targetValue ?: habit.targetValue
        } else 1.0
        val values = mutableListOf<Pair<Long, Double>>()
        val successes = mutableSetOf<Long>()
        var day = habit.createdEpochDay
        while (day <= end) {
            val e = entryMap[day]
            val target = goalAt(day)
            val value = if (habit.type == HabitType.QUANTITY) e?.value ?: 0.0 else if (e?.completed == true) 1.0 else 0.0
            values += day to value
            val reached = if (habit.type == HabitType.QUANTITY) value >= target else e?.completed == true
            if (reached) successes += day
            day++
        }

        var current = 0
        var cursor = end
        if (end == todayEpochDay && cursor !in successes) cursor--
        while (cursor >= habit.createdEpochDay && cursor in successes) {
            current++
            cursor--
        }
        var longest = 0
        var running = 0
        for ((d, _) in values) {
            if (d in successes) {
                running++
                if (running > longest) longest = running
            } else running = 0
        }
        val rawValues = values.map { it.second }
        fun avgLast(days: Int): Double = rawValues.takeLast(days).let { if (it.isEmpty()) 0.0 else it.average() }

        return HabitStats(
            habit = habit,
            currentStreak = current,
            longestStreak = longest,
            completionRate = if (values.isEmpty()) 0.0 else successes.size.toDouble() / values.size * 100.0,
            totalValue = rawValues.sum(),
            maxValue = rawValues.maxOrNull() ?: 0.0,
            sevenDayAverage = avgLast(7),
            thirtyDayAverage = avgLast(30),
            reachedGoalDays = successes.size,
            trackedDays = values.size,
            dailyValues = values
        )
    }

    private suspend fun targetForDate(habit: HabitEntity, epochDay: Long): Double {
        if (habit.type != HabitType.QUANTITY) return 1.0
        val history = habits.getGoalHistory(habit.id)
        return history.lastOrNull { it.effectiveEpochDay <= epochDay }?.targetValue ?: habit.targetValue
    }
}
