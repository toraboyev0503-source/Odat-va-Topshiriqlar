package uz.topshiriqodatlar.app

import android.app.Application
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import uz.topshiriqodatlar.app.data.AppDatabase
import uz.topshiriqodatlar.app.data.AppRepository
import uz.topshiriqodatlar.app.data.SettingsRepository
import uz.topshiriqodatlar.app.notifications.LocalAlarmScheduler
import uz.topshiriqodatlar.app.notifications.NotificationHelper
import java.time.LocalDate

class TopshiriqOdatlarApplication : Application() {
    val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    lateinit var repository: AppRepository
        private set
    lateinit var settingsRepository: SettingsRepository
        private set
    lateinit var scheduler: LocalAlarmScheduler
        private set

    override fun onCreate() {
        super.onCreate()
        repository = AppRepository(AppDatabase.get(this))
        settingsRepository = SettingsRepository(this)
        scheduler = LocalAlarmScheduler(this)
        NotificationHelper.createChannels(this)

        applicationScope.launch {
            val created = repository.rolloverOverdue(LocalDate.now().toEpochDay())
            created.forEach(scheduler::scheduleTask)
            repository.getAllPendingTasks().forEach(scheduler::scheduleTask)
            repository.getAllHabits().filter { it.archivedEpochDay == null }.forEach(scheduler::scheduleHabit)
            scheduler.scheduleNextMidnight()
        }
    }
}
