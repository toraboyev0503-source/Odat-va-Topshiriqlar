package uz.topshiriqodatlar.app.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

object HabitType {
    const val SIMPLE = "SIMPLE"
    const val QUANTITY = "QUANTITY"
}

object TaskStatus {
    const val PENDING = "PENDING"
    const val COMPLETED = "COMPLETED"
    const val MISSED = "MISSED"
}

object TaskPriority {
    const val VERY_IMPORTANT = 0
    const val IMPORTANT = 1
    const val LATER = 2
}

@Entity(tableName = "habits")
data class HabitEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val type: String = HabitType.SIMPLE,
    val targetValue: Double = 1.0,
    val unit: String = "",
    val accentIndex: Int = 0,
    val createdEpochDay: Long,
    val archivedEpochDay: Long? = null,
    val reminderHour: Int? = null,
    val reminderMinute: Int? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "habit_entries",
    foreignKeys = [
        ForeignKey(
            entity = HabitEntity::class,
            parentColumns = ["id"],
            childColumns = ["habitId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["habitId"]),
        Index(value = ["habitId", "dateEpochDay"], unique = true),
        Index(value = ["dateEpochDay"])
    ]
)
data class HabitEntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val habitId: Long,
    val dateEpochDay: Long,
    val value: Double = 0.0,
    val completed: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "habit_goal_history",
    foreignKeys = [
        ForeignKey(
            entity = HabitEntity::class,
            parentColumns = ["id"],
            childColumns = ["habitId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["habitId"]),
        Index(value = ["habitId", "effectiveEpochDay"], unique = true)
    ]
)
data class HabitGoalHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val habitId: Long,
    val effectiveEpochDay: Long,
    val targetValue: Double,
    val unit: String
)

@Entity(
    tableName = "tasks",
    indices = [
        Index(value = ["scheduledEpochDay"]),
        Index(value = ["status"]),
        Index(value = ["seriesId", "scheduledEpochDay"], unique = true)
    ]
)
data class TaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val seriesId: String,
    val text: String,
    val priority: Int,
    val scheduledEpochDay: Long,
    val deadlineMinutesOfDay: Int? = null,
    val status: String = TaskStatus.PENDING,
    val createdAt: Long = System.currentTimeMillis(),
    val completedAt: Long? = null,
    val rolledFromTaskId: Long? = null
)
