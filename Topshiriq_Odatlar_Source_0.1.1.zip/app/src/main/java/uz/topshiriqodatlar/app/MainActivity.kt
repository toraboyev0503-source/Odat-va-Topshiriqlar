package uz.topshiriqodatlar.app

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.viewmodel.compose.viewModel
import uz.topshiriqodatlar.app.ui.AppRoot

class MainActivity : ComponentActivity() {
    private var rescheduleTaskId by mutableStateOf<Long?>(null)
    private var openTaskId by mutableStateOf<Long?>(null)
    private var openHabitId by mutableStateOf<Long?>(null)

    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handleIntent(intent)
        if (Build.VERSION.SDK_INT >= 33) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent {
            val vm: MainViewModel = viewModel()
            AppRoot(
                viewModel = vm,
                rescheduleTaskId = rescheduleTaskId,
                openTaskId = openTaskId,
                openHabitId = openHabitId,
                onConsumeReschedule = { rescheduleTaskId = null },
                onConsumeOpenTask = { openTaskId = null },
                onConsumeOpenHabit = { openHabitId = null }
            )
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        rescheduleTaskId = intent?.getLongExtra(EXTRA_RESCHEDULE_TASK_ID, -1L)?.takeIf { it > 0 }
        openTaskId = intent?.getLongExtra(EXTRA_OPEN_TASK_ID, -1L)?.takeIf { it > 0 }
        openHabitId = intent?.getLongExtra(EXTRA_OPEN_HABIT_ID, -1L)?.takeIf { it > 0 }
    }

    companion object {
        const val EXTRA_RESCHEDULE_TASK_ID = "reschedule_task_id"
        const val EXTRA_OPEN_TASK_ID = "open_task_id"
        const val EXTRA_OPEN_HABIT_ID = "open_habit_id"
    }
}

