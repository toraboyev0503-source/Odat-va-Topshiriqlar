package uz.topshiriqodatlar.app.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

object AppLanguage {
    const val EN = "en"
    const val RU = "ru"
    const val UZ = "uz"
}

object AppPalette {
    const val STONE = "stone"
    const val PAPER = "paper"
    const val GRAPHITE = "graphite"
    const val SAND = "sand"
}

data class AppSettings(
    val language: String = AppLanguage.EN,
    val palette: String = AppPalette.STONE,
    val darkMode: Boolean = false
)

class SettingsRepository(context: Context) {
    private val prefs = context.getSharedPreferences("app_settings", Context.MODE_PRIVATE)
    private val _settings = MutableStateFlow(load())
    val settings: StateFlow<AppSettings> = _settings

    private fun load() = AppSettings(
        language = prefs.getString("language", AppLanguage.EN) ?: AppLanguage.EN,
        palette = prefs.getString("palette", AppPalette.STONE) ?: AppPalette.STONE,
        darkMode = prefs.getBoolean("darkMode", false)
    )

    fun setLanguage(language: String) = update(_settings.value.copy(language = language))
    fun setPalette(palette: String) = update(_settings.value.copy(palette = palette))
    fun setDarkMode(enabled: Boolean) = update(_settings.value.copy(darkMode = enabled))

    private fun update(value: AppSettings) {
        prefs.edit()
            .putString("language", value.language)
            .putString("palette", value.palette)
            .putBoolean("darkMode", value.darkMode)
            .apply()
        _settings.value = value
    }
}
