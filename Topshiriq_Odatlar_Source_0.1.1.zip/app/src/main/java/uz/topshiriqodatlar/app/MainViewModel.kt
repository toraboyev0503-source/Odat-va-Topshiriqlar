package uz.topshiriqodatlar.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import uz.topshiriqodatlar.app.data.HabitEntity
import uz.topshiriqodatlar.app.data.TaskEntity
import uz.topshiriqodatlar.app.data.TaskStatus
import uz.topshiriqodatlar.app.domain.DailyEfficiency
import uz.topshiriqodatlar.app.domain.EfficiencyCalculator
import uz.topshiriqodatlar.app.domain.DayDetails
import uz.topshiriqodatlar.app.domain.HabitStats
import java.time.LocalDate

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as TopshiriqOdatlarApplication
    val repository = app.repository
    val settingsRepository = app.settingsRepository
    val settings = settingsRepository.settings

    private val _today = MutableStateFlow(LocalDate.now().toEpochDay())
    val todayEpochDay = _today

    val habitsToday = _today.flatMapLatest(repository::observeHabitsForDay)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val tasksToday = _today.flatMapLatest(repository::observeTasksForDay)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val plannedTasks = _today.flatMapLatest(repository::observePlanned)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val historyTasks = repository.observeHistory()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val todayEfficiency = combine(habitsToday, tasksToday) { habitRows, taskRows ->
        val habitsPercent = EfficiencyCalculator.averagePercent(habitRows.map { it.progress })
        val tasksPercent = EfficiencyCalculator.taskPercent(
            completed = taskRows.count { it.status == TaskStatus.COMPLETED },
            total = taskRows.size
        )
        DailyEfficiency(
            epochDay = _today.value,
            habitsPercent = habitsPercent,
            tasksPercent = tasksPercent,
            totalPercent = EfficiencyCalculator.overall(habitsPercent, tasksPercent)
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), DailyEfficiency(_today.value, null, null, null))

    init {
        refreshDay()
    }

    fun refreshDay() {
        val today = LocalDate.now().toEpochDay()
        _today.value = today
        viewModelScope.launch {
            val created = repository.rolloverOverdue(today)
            created.forEach(app.scheduler::scheduleTask)
            refreshEfficiency()
        }
    }

    fun refreshEfficiency() = Unit

    fun addHabit(
        name: String,
        type: String,
        targetValue: Double,
        unit: String,
        accentIndex: Int,
        reminderHour: Int?,
        reminderMinute: Int?
    ) = viewModelScope.launch {
        val habit = repository.addHabit(name, type, targetValue, unit, accentIndex, reminderHour, reminderMinute)
        app.scheduler.scheduleHabit(habit)
        refreshEfficiency()
    }

    fun updateHabit(
        original: HabitEntity,
        name: String,
        type: String,
        targetValue: Double,
        unit: String,
        reminderHour: Int?,
        reminderMinute: Int?
    ) = viewModelScope.launch {
        app.scheduler.cancelHabit(original.id)
        val updated = repository.updateHabit(original, name, type, targetValue, unit, reminderHour, reminderMinute)
        app.scheduler.scheduleHabit(updated)
        refreshEfficiency()
    }

    fun archiveHabit(habit: HabitEntity) = viewModelScope.launch {
        app.scheduler.cancelHabit(habit.id)
        repository.archiveHabit(habit)
        refreshEfficiency()
    }

    fun deleteHabit(habit: HabitEntity) = viewModelScope.launch {
        app.scheduler.cancelHabit(habit.id)
        repository.deleteHabit(habit)
        refreshEfficiency()
    }

    fun toggleHabit(habit: HabitEntity) = viewModelScope.launch {
        repository.toggleSimpleHabit(habit, _today.value)
        refreshEfficiency()
    }

    fun setQuantity(habit: HabitEntity, value: Double) = viewModelScope.launch {
        repository.setQuantity(habit, value, _today.value)
        refreshEfficiency()
    }

    fun addTask(text: String, priority: Int, date: Long, deadlineMinutes: Int?) = viewModelScope.launch {
        val task = repository.addTask(text, priority, date, deadlineMinutes)
        app.scheduler.scheduleTask(task)
        refreshEfficiency()
    }

    fun updateTask(task: TaskEntity, text: String, priority: Int, date: Long, deadlineMinutes: Int?) = viewModelScope.launch {
        app.scheduler.cancelTask(task.id)
        val updated = repository.updateTask(task, text, priority, date, deadlineMinutes)
        if (updated.status == TaskStatus.PENDING) app.scheduler.scheduleTask(updated)
        refreshEfficiency()
    }

    fun toggleTask(task: TaskEntity) = viewModelScope.launch {
        val complete = task.status != TaskStatus.COMPLETED
        val updated = repository.setTaskCompleted(task.id, complete)
        if (complete) app.scheduler.cancelTask(task.id) else updated?.let(app.scheduler::scheduleTask)
        refreshEfficiency()
    }

    fun deleteTask(task: TaskEntity) = viewModelScope.launch {
        app.scheduler.cancelTask(task.id)
        repository.deleteTask(task)
        refreshEfficiency()
    }

    fun rescheduleTask(taskId: Long, date: Long, minutes: Int, onResult: (Boolean) -> Unit = {}) = viewModelScope.launch {
        app.scheduler.cancelTask(taskId)
        val updated = repository.rescheduleTask(taskId, date, minutes)
        if (updated != null) app.scheduler.scheduleTask(updated)
        refreshEfficiency()
        onResult(updated != null)
    }

    suspend fun getTask(id: Long): TaskEntity? = repository.getTask(id)
    suspend fun habitStats(id: Long): HabitStats? = repository.habitStats(id)
    suspend fun efficiencies(from: Long, to: Long): List<DailyEfficiency> = repository.efficiencies(from, to)
    suspend fun dayDetails(epochDay: Long): DayDetails = repository.dayDetails(epochDay)
}
