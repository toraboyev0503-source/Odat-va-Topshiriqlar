package uz.topshiriqodatlar.app.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import kotlinx.coroutines.launch
import uz.topshiriqodatlar.app.TopshiriqOdatlarApplication
import uz.topshiriqodatlar.app.data.TaskStatus
import java.time.LocalDate

class TaskAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val taskId = intent.getLongExtra(EXTRA_TASK_ID, -1L)
        if (taskId <= 0) return
        val pendingResult = goAsync()
        val app = context.applicationContext as TopshiriqOdatlarApplication
        app.applicationScope.launch {
            try {
                when (intent.action) {
                    ACTION_COMPLETE -> {
                        app.repository.setTaskCompleted(taskId, true)
                        app.scheduler.cancelTask(taskId)
                        NotificationHelper.cancelTask(context, taskId)
                    }
                    else -> {
                        val task = app.repository.getTask(taskId)
                        if (task?.status == TaskStatus.PENDING) NotificationHelper.showTask(context, task)
                    }
                }
            } finally {
                pendingResult.finish()
            }
        }
    }

    companion object {
        const val ACTION_DUE = "uz.topshiriqodatlar.ACTION_TASK_DUE"
        const val ACTION_COMPLETE = "uz.topshiriqodatlar.ACTION_TASK_COMPLETE"
        const val EXTRA_TASK_ID = "task_id"
    }
}

class HabitAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val habitId = intent.getLongExtra(EXTRA_HABIT_ID, -1L)
        if (habitId <= 0) return
        val pendingResult = goAsync()
        val app = context.applicationContext as TopshiriqOdatlarApplication
        app.applicationScope.launch {
            try {
                val habit = app.repository.getHabit(habitId)
                if (habit != null && habit.archivedEpochDay == null) {
                    NotificationHelper.showHabit(context, habit)
                    app.scheduler.scheduleHabit(habit)
                }
            } finally {
                pendingResult.finish()
            }
        }
    }

    companion object {
        const val ACTION_DUE = "uz.topshiriqodatlar.ACTION_HABIT_DUE"
        const val EXTRA_HABIT_ID = "habit_id"
    }
}

class MidnightReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pendingResult = goAsync()
        val app = context.applicationContext as TopshiriqOdatlarApplication
        app.applicationScope.launch {
            try {
                val created = app.repository.rolloverOverdue(LocalDate.now().toEpochDay())
                created.forEach(app.scheduler::scheduleTask)
                app.scheduler.scheduleNextMidnight()
            } finally {
                pendingResult.finish()
            }
        }
    }

    companion object {
        const val ACTION_MIDNIGHT = "uz.topshiriqodatlar.ACTION_MIDNIGHT"
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pendingResult = goAsync()
        val app = context.applicationContext as TopshiriqOdatlarApplication
        app.applicationScope.launch {
            try {
                val created = app.repository.rolloverOverdue(LocalDate.now().toEpochDay())
                created.forEach(app.scheduler::scheduleTask)
                app.repository.getAllPendingTasks().forEach(app.scheduler::scheduleTask)
                app.repository.getAllHabits().filter { it.archivedEpochDay == null }.forEach(app.scheduler::scheduleHabit)
                app.scheduler.scheduleNextMidnight()
            } finally {
                pendingResult.finish()
            }
        }
    }
}
