package uz.topshiriqodatlar.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Archive
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import uz.topshiriqodatlar.app.MainViewModel
import uz.topshiriqodatlar.app.data.AppSettings
import uz.topshiriqodatlar.app.data.HabitEntity
import uz.topshiriqodatlar.app.data.HabitType
import uz.topshiriqodatlar.app.domain.HabitWithToday
import uz.topshiriqodatlar.app.domain.UiStrings
import uz.topshiriqodatlar.app.ui.RoundMenuButton
import uz.topshiriqodatlar.app.ui.SideMenu
import uz.topshiriqodatlar.app.ui.percentText

@Composable
fun HabitsScreen(
    viewModel: MainViewModel,
    strings: UiStrings,
    settings: AppSettings,
    onBack: () -> Unit,
    onStatistics: () -> Unit,
    onHabitDetail: (Long) -> Unit
) {
    val rows by viewModel.habitsToday.collectAsState()
    val efficiency by viewModel.todayEfficiency.collectAsState()
    var drawer by remember { mutableStateOf(false) }
    var editor by remember { mutableStateOf<HabitEntity?>(null) }
    var newHabit by remember { mutableStateOf(false) }
    var quantityHabit by remember { mutableStateOf<HabitWithToday?>(null) }
    var pendingDelete by remember { mutableStateOf<HabitEntity?>(null) }
    var pendingArchive by remember { mutableStateOf<HabitEntity?>(null) }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
            Row(
                Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RoundMenuButton({ drawer = true })
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(strings.habits, style = MaterialTheme.typography.headlineSmall)
                    Text("${strings.today} · ${percentText(efficiency?.totalPercent)}", color = MaterialTheme.colorScheme.secondary)
                }
                FloatingActionButton(onClick = { newHabit = true }, modifier = Modifier.size(48.dp), shape = CircleShape) {
                    Icon(Icons.Outlined.Add, contentDescription = strings.addHabit)
                }
            }

            if (rows.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(strings.noHabits, color = MaterialTheme.colorScheme.secondary)
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(rows, key = { it.habit.id }) { row ->
                        HabitCard(
                            row = row,
                            strings = strings,
                            onOpen = { onHabitDetail(row.habit.id) },
                            onToggle = { viewModel.toggleHabit(row.habit) },
                            onQuantity = { quantityHabit = row },
                            onEdit = { editor = row.habit },
                            onArchive = { pendingArchive = row.habit },
                            onDelete = { pendingDelete = row.habit }
                        )
                    }
                    item { Spacer(Modifier.height(80.dp)) }
                }
            }
        }

        SideMenu(
            visible = drawer,
            settings = settings,
            strings = strings,
            showArchive = false,
            onDismiss = { drawer = false },
            onStatistics = onStatistics,
            onArchive = {},
            onLanguage = viewModel.settingsRepository::setLanguage,
            onPalette = viewModel.settingsRepository::setPalette,
            onDarkMode = viewModel.settingsRepository::setDarkMode
        )
    }

    if (newHabit) {
        HabitEditorDialog(strings, null, onDismiss = { newHabit = false }) { name, type, target, unit, hour, minute ->
            viewModel.addHabit(name, type, target, unit, 0, hour, minute)
            newHabit = false
        }
    }
    editor?.let { habit ->
        HabitEditorDialog(strings, habit, onDismiss = { editor = null }) { name, type, target, unit, hour, minute ->
            viewModel.updateHabit(habit, name, type, target, unit, hour, minute)
            editor = null
        }
    }
    quantityHabit?.let { row ->
        QuantityDialog(strings, row, onDismiss = { quantityHabit = null }) { value ->
            viewModel.setQuantity(row.habit, value)
            quantityHabit = null
        }
    }
    pendingArchive?.let { habit ->
        AlertDialog(
            onDismissRequest = { pendingArchive = null },
            title = { Text(strings.archive) },
            text = { Text(strings.archiveConfirm) },
            confirmButton = {
                Button(onClick = { viewModel.archiveHabit(habit); pendingArchive = null }) { Text(strings.archive) }
            },
            dismissButton = { TextButton(onClick = { pendingArchive = null }) { Text(strings.cancel) } }
        )
    }
    pendingDelete?.let { habit ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text(strings.delete) },
            text = { Text(strings.deleteConfirm) },
            confirmButton = {
                Button(onClick = { viewModel.deleteHabit(habit); pendingDelete = null }) { Text(strings.delete) }
            },
            dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text(strings.cancel) } }
        )
    }
}

@Composable
private fun HabitCard(
    row: HabitWithToday,
    strings: UiStrings,
    onOpen: () -> Unit,
    onToggle: () -> Unit,
    onQuantity: () -> Unit,
    onEdit: () -> Unit,
    onArchive: () -> Unit,
    onDelete: () -> Unit
) {
    var menu by remember { mutableStateOf(false) }
    val habit = row.habit
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f).clickable(onClick = onOpen)) {
                Text(habit.name, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(7.dp))
                if (habit.type == HabitType.QUANTITY) {
                    val value = row.entry?.value ?: 0.0
                    Text("${formatNumber(value)} / ${formatNumber(habit.targetValue)} ${habit.unit}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                    Spacer(Modifier.height(6.dp))
                    LinearProgressIndicator(progress = { row.progress.toFloat() }, modifier = Modifier.fillMaxWidth(.92f))
                } else {
                    Text(percentText(row.progress * 100.0), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                }
            }
            Spacer(Modifier.width(10.dp))
            if (habit.type == HabitType.QUANTITY) {
                OutlinedButton(onClick = onQuantity, shape = CircleShape, modifier = Modifier.size(58.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)) {
                    Text(formatNumber(row.entry?.value ?: 0.0), style = MaterialTheme.typography.labelLarge)
                }
            } else {
                Surface(
                    onClick = onToggle,
                    shape = CircleShape,
                    color = if (row.progress >= 1.0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.background,
                    modifier = Modifier.size(52.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(if (row.progress >= 1.0) "✓" else "!", color = if (row.progress >= 1.0) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface)
                    }
                }
            }
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Outlined.MoreVert, contentDescription = null) }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text(strings.editHabit) }, leadingIcon = { Icon(Icons.Outlined.Edit, null) }, onClick = { menu = false; onEdit() })
                    DropdownMenuItem(text = { Text(strings.archive) }, leadingIcon = { Icon(Icons.Outlined.Archive, null) }, onClick = { menu = false; onArchive() })
                    DropdownMenuItem(text = { Text(strings.delete) }, leadingIcon = { Icon(Icons.Outlined.DeleteOutline, null) }, onClick = { menu = false; onDelete() })
                }
            }
        }
    }
}

@Composable
private fun HabitEditorDialog(
    strings: UiStrings,
    original: HabitEntity?,
    onDismiss: () -> Unit,
    onSave: (String, String, Double, String, Int?, Int?) -> Unit
) {
    var name by remember(original) { mutableStateOf(original?.name ?: "") }
    var type by remember(original) { mutableStateOf(original?.type ?: HabitType.SIMPLE) }
    var target by remember(original) { mutableStateOf(if (original?.type == HabitType.QUANTITY) formatNumber(original.targetValue) else "") }
    var unit by remember(original) { mutableStateOf(original?.unit ?: "") }
    var reminderEnabled by remember(original) { mutableStateOf(original?.reminderHour != null) }
    var hour by remember(original) { mutableStateOf(original?.reminderHour?.toString()?.padStart(2, '0') ?: "08") }
    var minute by remember(original) { mutableStateOf(original?.reminderMinute?.toString()?.padStart(2, '0') ?: "00") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (original == null) strings.addHabit else strings.editHabit) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text(strings.habitName) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = type == HabitType.SIMPLE, onClick = { type = HabitType.SIMPLE }, label = { Text(strings.simple) })
                    FilterChip(selected = type == HabitType.QUANTITY, onClick = { type = HabitType.QUANTITY }, label = { Text(strings.quantity) })
                }
                if (type == HabitType.QUANTITY) {
                    OutlinedTextField(target, { target = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text(strings.dailyTarget) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(unit, { unit = it }, label = { Text(strings.unit) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
                FilterChip(selected = reminderEnabled, onClick = { reminderEnabled = !reminderEnabled }, label = { Text(if (reminderEnabled) strings.reminder else strings.noReminder) })
                if (reminderEnabled) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(hour, { hour = it.filter(Char::isDigit).take(2) }, label = { Text("HH") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.weight(1f))
                        OutlinedTextField(minute, { minute = it.filter(Char::isDigit).take(2) }, label = { Text("MM") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.weight(1f))
                    }
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            Button(onClick = {
                val t = target.toDoubleOrNull() ?: 0.0
                val h = hour.toIntOrNull()
                val m = minute.toIntOrNull()
                error = when {
                    name.isBlank() -> strings.emptyName
                    type == HabitType.QUANTITY && t <= 0 -> strings.dailyTarget
                    reminderEnabled && (h == null || h !in 0..23 || m == null || m !in 0..59) -> strings.invalidTime
                    else -> null
                }
                if (error == null) onSave(name, type, if (type == HabitType.QUANTITY) t else 1.0, unit, if (reminderEnabled) h else null, if (reminderEnabled) m else null)
            }) { Text(strings.save) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(strings.cancel) } }
    )
}

@Composable
private fun QuantityDialog(strings: UiStrings, row: HabitWithToday, onDismiss: () -> Unit, onSave: (Double) -> Unit) {
    var value by remember(row.habit.id) { mutableStateOf(formatNumber(row.entry?.value ?: 0.0)) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(row.habit.name) },
        text = {
            OutlinedTextField(
                value = value,
                onValueChange = { value = it.filter { c -> c.isDigit() || c == '.' } },
                label = { Text("${strings.quantityPrompt} (${row.habit.unit})") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true
            )
        },
        confirmButton = { Button(onClick = { onSave(value.toDoubleOrNull() ?: 0.0) }) { Text(strings.save) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(strings.cancel) } }
    )
}

private fun formatNumber(value: Double): String = if (value % 1.0 == 0.0) value.toLong().toString() else "%.1f".format(value)
