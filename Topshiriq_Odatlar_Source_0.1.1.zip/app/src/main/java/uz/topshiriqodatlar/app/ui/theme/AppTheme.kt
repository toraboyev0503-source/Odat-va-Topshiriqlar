package uz.topshiriqodatlar.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import uz.topshiriqodatlar.app.data.AppPalette
import uz.topshiriqodatlar.app.data.AppSettings

private data class Palette(
    val lightBg: Color,
    val lightSurface: Color,
    val lightPrimary: Color,
    val lightSecondary: Color,
    val darkBg: Color,
    val darkSurface: Color,
    val darkPrimary: Color,
    val darkSecondary: Color
)

private val stone = Palette(
    lightBg = Color(0xFFF2F0EA),
    lightSurface = Color(0xFFFAF8F3),
    lightPrimary = Color(0xFF2D2D2A),
    lightSecondary = Color(0xFF6E6B64),
    darkBg = Color(0xFF171715),
    darkSurface = Color(0xFF22221F),
    darkPrimary = Color(0xFFE8E5DD),
    darkSecondary = Color(0xFFB8B4AA)
)

private val paper = Palette(
    lightBg = Color(0xFFF7F4EC), lightSurface = Color(0xFFFFFCF5),
    lightPrimary = Color(0xFF272522), lightSecondary = Color(0xFF746E64),
    darkBg = Color(0xFF181714), darkSurface = Color(0xFF24221D),
    darkPrimary = Color(0xFFF1ECE1), darkSecondary = Color(0xFFC4BCAD)
)

private val graphite = Palette(
    lightBg = Color(0xFFEDEEEF), lightSurface = Color(0xFFF8F8F8),
    lightPrimary = Color(0xFF202226), lightSecondary = Color(0xFF666A72),
    darkBg = Color(0xFF111317), darkSurface = Color(0xFF1C1F24),
    darkPrimary = Color(0xFFE8EAF0), darkSecondary = Color(0xFFAEB4C0)
)

private val sand = Palette(
    lightBg = Color(0xFFF3EBDD), lightSurface = Color(0xFFFCF6EC),
    lightPrimary = Color(0xFF332D25), lightSecondary = Color(0xFF7D6D5A),
    darkBg = Color(0xFF1B1712), darkSurface = Color(0xFF282119),
    darkPrimary = Color(0xFFF0E2CD), darkSecondary = Color(0xFFC2AD91)
)

@Composable
fun TopshiriqOdatlarTheme(settings: AppSettings, content: @Composable () -> Unit) {
    val p = when (settings.palette) {
        AppPalette.PAPER -> paper
        AppPalette.GRAPHITE -> graphite
        AppPalette.SAND -> sand
        else -> stone
    }
    val scheme = if (settings.darkMode) {
        darkColorScheme(
            background = p.darkBg,
            surface = p.darkSurface,
            primary = p.darkPrimary,
            onPrimary = p.darkBg,
            secondary = p.darkSecondary,
            onBackground = p.darkPrimary,
            onSurface = p.darkPrimary,
            outline = p.darkSecondary.copy(alpha = .45f)
        )
    } else {
        lightColorScheme(
            background = p.lightBg,
            surface = p.lightSurface,
            primary = p.lightPrimary,
            onPrimary = p.lightSurface,
            secondary = p.lightSecondary,
            onBackground = p.lightPrimary,
            onSurface = p.lightPrimary,
            outline = p.lightSecondary.copy(alpha = .45f)
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

object SemanticColors {
    val VeryImportant = Color(0xFF8C3B3B)
    val Important = Color(0xFF9A7138)
    val Later = Color(0xFF5F6F7E)
    val Done = Color(0xFF4E6B57)
    val Missed = Color(0xFF7E5B5B)
}
