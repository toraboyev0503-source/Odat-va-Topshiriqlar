package uz.topshiriqodatlar.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import uz.topshiriqodatlar.app.MainViewModel
import uz.topshiriqodatlar.app.data.HabitType
import uz.topshiriqodatlar.app.domain.HabitStats
import uz.topshiriqodatlar.app.domain.UiStrings
import kotlin.math.roundToInt

@Composable
fun HabitDetailScreen(viewModel: MainViewModel, strings: UiStrings, habitId: Long, onBack: () -> Unit) {
    val stats by produceState<HabitStats?>(initialValue = null, habitId) { value = viewModel.habitStats(habitId) }
    val data = stats
    if (data == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        return
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)) {
        Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Outlined.ArrowBack, contentDescription = strings.back) }
            Spacer(Modifier.width(8.dp))
            Column {
                Text(data.habit.name, style = MaterialTheme.typography.headlineSmall)
                Text(strings.statistics, color = MaterialTheme.colorScheme.secondary)
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard(strings.currentStreak, data.currentStreak.toString(), Modifier.weight(1f))
            StatCard(strings.longestStreak, data.longestStreak.toString(), Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard(strings.completionRate, "${data.completionRate.roundToInt()}%", Modifier.weight(1f))
            StatCard(strings.reachedGoal, "${data.reachedGoalDays}/${data.trackedDays}", Modifier.weight(1f))
        }

        if (data.habit.type == HabitType.QUANTITY) {
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard(strings.sevenDayAverage, "${fmt(data.sevenDayAverage)} ${data.habit.unit}", Modifier.weight(1f))
                StatCard(strings.thirtyDayAverage, "${fmt(data.thirtyDayAverage)} ${data.habit.unit}", Modifier.weight(1f))
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard(strings.total, "${fmt(data.totalValue)} ${data.habit.unit}", Modifier.weight(1f))
                StatCard(strings.bestDay, "${fmt(data.maxValue)} ${data.habit.unit}", Modifier.weight(1f))
            }
        }

        Spacer(Modifier.height(18.dp))
        Text(strings.thirtyDayAverage, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        TrendChart(data.dailyValues.takeLast(30).map { it.second })
        Spacer(Modifier.height(28.dp))
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(14.dp)) {
            Text(value, style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(4.dp))
            Text(label, color = MaterialTheme.colorScheme.secondary, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun TrendChart(values: List<Double>) {
    val color = MaterialTheme.colorScheme.primary
    val grid = MaterialTheme.colorScheme.outline.copy(alpha = .25f)
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth()) {
        Canvas(Modifier.fillMaxWidth().height(180.dp).padding(16.dp)) {
            drawLine(grid, Offset(0f, size.height), Offset(size.width, size.height), 1f)
            if (values.size < 2) return@Canvas
            val max = (values.maxOrNull() ?: 0.0).coerceAtLeast(1.0)
            val path = Path()
            values.forEachIndexed { index, value ->
                val x = index.toFloat() / (values.lastIndex.coerceAtLeast(1)) * size.width
                val y = size.height - (value / max).toFloat() * size.height
                if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            drawPath(path, color, style = Stroke(width = 3f, cap = StrokeCap.Round))
        }
    }
}

private fun fmt(v: Double): String = if (v % 1.0 == 0.0) v.toLong().toString() else "%.1f".format(v)
