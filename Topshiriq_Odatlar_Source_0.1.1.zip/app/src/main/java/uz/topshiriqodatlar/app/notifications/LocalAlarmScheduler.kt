package uz.topshiriqodatlar.app.notifications

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import uz.topshiriqodatlar.app.data.HabitEntity
import uz.topshiriqodatlar.app.data.TaskEntity
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

class LocalAlarmScheduler(private val context: Context) {
    private val alarmManager = context.getSystemService(AlarmManager::class.java)

    fun scheduleTask(task: TaskEntity) {
        val minutes = task.deadlineMinutesOfDay ?: return
        val date = LocalDate.ofEpochDay(task.scheduledEpochDay)
        val time = LocalTime.of(minutes / 60, minutes % 60)
        val trigger = LocalDateTime.of(date, time).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        if (trigger <= System.currentTimeMillis()) return
        val intent = Intent(context, TaskAlarmReceiver::class.java).apply {
            action = TaskAlarmReceiver.ACTION_DUE
            putExtra(TaskAlarmReceiver.EXTRA_TASK_ID, task.id)
        }
        schedule(trigger, pendingBroadcast(task.id.toInt(), intent))
    }

    fun cancelTask(taskId: Long) {
        val intent = Intent(context, TaskAlarmReceiver::class.java).apply { action = TaskAlarmReceiver.ACTION_DUE }
        alarmManager.cancel(pendingBroadcast(taskId.toInt(), intent))
    }

    fun scheduleHabit(habit: HabitEntity) {
        val hour = habit.reminderHour ?: return
        val minute = habit.reminderMinute ?: return
        var dateTime = LocalDateTime.of(LocalDate.now(), LocalTime.of(hour, minute))
        if (!dateTime.atZone(ZoneId.systemDefault()).toInstant().isAfter(java.time.Instant.now())) {
            dateTime = dateTime.plusDays(1)
        }
        val intent = Intent(context, HabitAlarmReceiver::class.java).apply {
            action = HabitAlarmReceiver.ACTION_DUE
            putExtra(HabitAlarmReceiver.EXTRA_HABIT_ID, habit.id)
        }
        schedule(
            dateTime.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli(),
            pendingBroadcast(HABIT_REQUEST_OFFSET + habit.id.toInt(), intent)
        )
    }

    fun cancelHabit(habitId: Long) {
        val intent = Intent(context, HabitAlarmReceiver::class.java).apply { action = HabitAlarmReceiver.ACTION_DUE }
        alarmManager.cancel(pendingBroadcast(HABIT_REQUEST_OFFSET + habitId.toInt(), intent))
    }

    fun scheduleNextMidnight() {
        val next = LocalDate.now().plusDays(1).atStartOfDay().plusSeconds(10)
            .atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        val intent = Intent(context, MidnightReceiver::class.java).apply { action = MidnightReceiver.ACTION_MIDNIGHT }
        scheduleInexact(next, pendingBroadcast(MIDNIGHT_REQUEST, intent))
    }

    private fun schedule(triggerAtMillis: Long, operation: PendingIntent) {
        try {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S || alarmManager.canScheduleExactAlarms()) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, operation)
            } else {
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, operation)
            }
        } catch (_: SecurityException) {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, operation)
        }
    }

    private fun scheduleInexact(triggerAtMillis: Long, operation: PendingIntent) {
        alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, operation)
    }

    private fun pendingBroadcast(requestCode: Int, intent: Intent): PendingIntent = PendingIntent.getBroadcast(
        context,
        requestCode,
        intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    companion object {
        private const val HABIT_REQUEST_OFFSET = 1_000_000
        private const val MIDNIGHT_REQUEST = 2_000_001
    }
}
