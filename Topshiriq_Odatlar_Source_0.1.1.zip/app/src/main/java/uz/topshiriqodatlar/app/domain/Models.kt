package uz.topshiriqodatlar.app.domain

import uz.topshiriqodatlar.app.data.HabitEntity
import uz.topshiriqodatlar.app.data.HabitEntryEntity
import uz.topshiriqodatlar.app.data.TaskEntity


data class HabitWithToday(
    val habit: HabitEntity,
    val entry: HabitEntryEntity?,
    val progress: Double
)

data class DailyEfficiency(
    val epochDay: Long,
    val habitsPercent: Double?,
    val tasksPercent: Double?,
    val totalPercent: Double?
)

data class HabitStats(
    val habit: HabitEntity,
    val currentStreak: Int,
    val longestStreak: Int,
    val completionRate: Double,
    val totalValue: Double,
    val maxValue: Double,
    val sevenDayAverage: Double,
    val thirtyDayAverage: Double,
    val reachedGoalDays: Int,
    val trackedDays: Int,
    val dailyValues: List<Pair<Long, Double>>
)

data class DayDetails(
    val efficiency: DailyEfficiency,
    val habits: List<HabitWithToday>,
    val tasks: List<TaskEntity>
)
