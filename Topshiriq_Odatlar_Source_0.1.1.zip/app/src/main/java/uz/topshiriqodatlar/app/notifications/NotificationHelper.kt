package uz.topshiriqodatlar.app.notifications

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import uz.topshiriqodatlar.app.MainActivity
import uz.topshiriqodatlar.app.R
import uz.topshiriqodatlar.app.TopshiriqOdatlarApplication
import uz.topshiriqodatlar.app.data.HabitEntity
import uz.topshiriqodatlar.app.data.TaskEntity
import uz.topshiriqodatlar.app.domain.Localizer

object NotificationHelper {
    private const val TASK_CHANNEL = "task_deadlines"
    private const val HABIT_CHANNEL = "habit_reminders"

    fun createChannels(context: Context) {
        val manager = context.getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(TASK_CHANNEL, "Task deadlines", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Offline deadline reminders"
            }
        )
        manager.createNotificationChannel(
            NotificationChannel(HABIT_CHANNEL, "Habit reminders", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "Daily habit reminders"
            }
        )
    }

    @SuppressLint("MissingPermission")
    fun showTask(context: Context, task: TaskEntity) {
        if (!canNotify(context)) return
        val app = context.applicationContext as TopshiriqOdatlarApplication
        val s = Localizer.strings(app.settingsRepository.settings.value.language)

        val completeIntent = Intent(context, TaskAlarmReceiver::class.java).apply {
            action = TaskAlarmReceiver.ACTION_COMPLETE
            putExtra(TaskAlarmReceiver.EXTRA_TASK_ID, task.id)
        }
        val completePending = PendingIntent.getBroadcast(
            context,
            3_000_000 + task.id.toInt(),
            completeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val rescheduleIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(MainActivity.EXTRA_RESCHEDULE_TASK_ID, task.id)
        }
        val reschedulePending = PendingIntent.getActivity(
            context,
            4_000_000 + task.id.toInt(),
            rescheduleIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(MainActivity.EXTRA_OPEN_TASK_ID, task.id)
        }
        val openPending = PendingIntent.getActivity(
            context,
            5_000_000 + task.id.toInt(),
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, TASK_CHANNEL)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(s.priorityLabel(task.priority))
            .setContentText(task.text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(task.text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(openPending)
            .addAction(0, s.doneAction, completePending)
            .addAction(0, s.notDoneAction, reschedulePending)
            .build()

        NotificationManagerCompat.from(context).notify(task.id.toInt(), notification)
    }

    @SuppressLint("MissingPermission")
    fun showHabit(context: Context, habit: HabitEntity) {
        if (!canNotify(context)) return
        val app = context.applicationContext as TopshiriqOdatlarApplication
        val s = Localizer.strings(app.settingsRepository.settings.value.language)
        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(MainActivity.EXTRA_OPEN_HABIT_ID, habit.id)
        }
        val openPending = PendingIntent.getActivity(
            context,
            6_000_000 + habit.id.toInt(),
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, HABIT_CHANNEL)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(s.reminder)
            .setContentText(habit.name)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(openPending)
            .build()
        NotificationManagerCompat.from(context).notify(1_000_000 + habit.id.toInt(), notification)
    }

    fun cancelTask(context: Context, taskId: Long) {
        NotificationManagerCompat.from(context).cancel(taskId.toInt())
    }

    private fun canNotify(context: Context): Boolean =
        android.os.Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
}
