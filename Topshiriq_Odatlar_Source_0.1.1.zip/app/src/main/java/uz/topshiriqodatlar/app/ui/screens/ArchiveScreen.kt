package uz.topshiriqodatlar.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import uz.topshiriqodatlar.app.MainViewModel
import uz.topshiriqodatlar.app.data.TaskEntity
import uz.topshiriqodatlar.app.data.TaskStatus
import uz.topshiriqodatlar.app.domain.UiStrings
import java.time.LocalDate

@Composable
fun ArchiveScreen(viewModel: MainViewModel, strings: UiStrings, onBack: () -> Unit) {
    val planned by viewModel.plannedTasks.collectAsState()
    val history by viewModel.historyTasks.collectAsState()
    var tab by remember { mutableStateOf(0) }
    var editing by remember { mutableStateOf<TaskEntity?>(null) }
    var deleting by remember { mutableStateOf<TaskEntity?>(null) }
    val list = if (tab == 0) planned else history

    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Outlined.ArrowBack, contentDescription = strings.back) }
            Spacer(Modifier.width(8.dp))
            Text(strings.archive, style = MaterialTheme.typography.headlineSmall)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = tab == 0, onClick = { tab = 0 }, label = { Text(strings.plan) })
            FilterChip(selected = tab == 1, onClick = { tab = 1 }, label = { Text(strings.history) })
        }
        Spacer(Modifier.height(12.dp))
        if (list.isEmpty()) {
            Text(if (tab == 0) strings.noPlanned else strings.noHistory, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.padding(top = 40.dp))
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                items(list, key = { it.id }) { task ->
                    ArchiveTaskCard(task, strings, onEdit = { editing = task }, onDelete = { deleting = task })
                }
                item { Spacer(Modifier.height(48.dp)) }
            }
        }
    }

    editing?.let { task ->
        TaskEditorDialog(strings, task, lockSchedule = task.status != TaskStatus.PENDING, onDismiss = { editing = null }) { text, priority, date, minutes ->
            viewModel.updateTask(task, text, priority, date, minutes)
            editing = null
        }
    }
    deleting?.let { task ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text(strings.delete) },
            text = { Text(strings.deleteConfirm) },
            confirmButton = {
                TextButton(onClick = { viewModel.deleteTask(task); deleting = null }) { Text(strings.delete) }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text(strings.cancel) } }
        )
    }
}

@Composable
private fun ArchiveTaskCard(task: TaskEntity, strings: UiStrings, onEdit: () -> Unit, onDelete: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(task.text, style = MaterialTheme.typography.bodyLarge)
                Spacer(Modifier.height(4.dp))
                val date = LocalDate.ofEpochDay(task.scheduledEpochDay)
                val state = when (task.status) {
                    TaskStatus.COMPLETED -> strings.completed
                    TaskStatus.MISSED -> strings.missed
                    else -> strings.pending
                }
                Text("$date · $state · ${strings.priorityLabel(task.priority)}", color = MaterialTheme.colorScheme.secondary, style = MaterialTheme.typography.bodySmall)
            }
            IconButton(onClick = onEdit) { Icon(Icons.Outlined.Edit, contentDescription = strings.editTask) }
            IconButton(onClick = onDelete) { Icon(Icons.Outlined.DeleteOutline, contentDescription = strings.delete) }
        }
    }
}
