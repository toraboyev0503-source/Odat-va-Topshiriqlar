package uz.topshiriqodatlar.app.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class EfficiencyCalculatorTest {
    @Test
    fun quantityProgress_isCappedAtOneHundredPercent() {
        assertEquals(1.0, EfficiencyCalculator.progress(12_000.0, 10_000.0), 0.0001)
        assertEquals(0.75, EfficiencyCalculator.progress(7_500.0, 10_000.0), 0.0001)
    }

    @Test
    fun overall_averagesHabitsAndTasksEqually() {
        assertEquals(73.35, EfficiencyCalculator.overall(80.0, 66.7)!!, 0.0001)
    }

    @Test
    fun overall_usesOnlyAvailableModule() {
        assertEquals(82.0, EfficiencyCalculator.overall(82.0, null)!!, 0.0001)
        assertEquals(70.0, EfficiencyCalculator.overall(null, 70.0)!!, 0.0001)
        assertNull(EfficiencyCalculator.overall(null, null))
    }

    @Test
    fun taskPercent_countsPendingAsNotCompleted() {
        assertEquals(80.0, EfficiencyCalculator.taskPercent(4, 5)!!, 0.0001)
    }
}
