# Memora 0.9.34

Android source package for the Memora 0.9.34 test build.

## Build
- `versionName`: `0.9.34`
- `versionCode`: `54`
- Debug builds keep the existing stable Memora test signing key so they install as updates over prior debug builds.

## 0.9.34 scope
- Direct Topilma composer from the center + menu
- Recent/default source selection and compact source sheet
- Camera/Gallery copy flow integrated into the composer
- OCR rectification/deskew, paragraph-aware selection, and editable review
- Unified local-first Back behavior
- Compact equal-size New Note choices using active-theme tinting

The approved Topilma card visual spec and renderer are intentionally unchanged.
