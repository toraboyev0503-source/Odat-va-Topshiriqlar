package com.memora.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.memora.app.billing.EntitlementState
import com.memora.app.billing.SubscriptionPlan
import com.memora.app.data.local.NoteEntity
import com.memora.app.data.local.NoteType
import com.memora.app.data.local.ReminderEntity
import com.memora.app.data.local.TimeTracePhotoEntity
import com.memora.app.data.model.NoteBlock
import com.memora.app.data.model.NoteBlocksCodec
import com.memora.app.data.repository.MemoraRepository
import com.memora.app.data.repository.TopilmaReviewSessionState
import com.memora.app.data.repository.TopilmalarRepository
import com.memora.app.export.ExportRequest
import com.memora.app.media.MediaStorage
import com.memora.app.notifications.AlarmScheduler
import com.memora.app.obsidian.ObsidianSyncManager
import com.memora.app.prefs.ThemeMode
import com.memora.app.prefs.UserPreferences
import com.memora.app.prefs.UserSettings
import com.memora.app.timetrace.TimeTraceStorage
import com.memora.app.ui.components.ExportDialog
import com.memora.app.ui.components.MemoraBottomBar
import com.memora.app.ui.components.NewNoteSheet
import com.memora.app.ui.components.RootTab
import com.memora.app.ui.screens.AboutScreen
import com.memora.app.ui.screens.CalendarHubScreen
import com.memora.app.ui.screens.DataBackupScreen
import com.memora.app.ui.screens.EditorScreen
import com.memora.app.ui.screens.HomeScreen
import com.memora.app.ui.screens.LanguageScreen
import com.memora.app.ui.screens.NotesHubScreen
import com.memora.app.ui.screens.ObsidianScreen
import com.memora.app.ui.screens.ReaderScreen
import com.memora.app.ui.screens.RemindersScreen
import com.memora.app.ui.screens.SecurityScreen
import com.memora.app.ui.screens.SettingsHubV2Screen
import com.memora.app.ui.screens.SubscriptionScreen
import com.memora.app.ui.screens.ThemeScreen
import com.memora.app.ui.screens.TimeTraceScreen
import com.memora.app.ui.screens.TitlesScreen
import com.memora.app.ui.screens.TopilmalarScreen
import com.memora.app.ui.screens.TopilmaCommentsScreen
import com.memora.app.ui.theme.MemoraMotion
import java.time.LocalDate
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch

private object Routes {
    const val HOME = "home"
    const val NOTES_HUB = "notes_hub/{filter}"
    const val CALENDAR_ROOT = "calendar_root"
    const val TOPILMALAR = "topilmalar/{tab}"
    const val TOPILMA_COMMENTS = "topilma_comments/{id}"
    const val SETTINGS_HUB = "settings_hub"
    const val EDITOR = "editor/{type}/{id}"
    const val READER = "reader/{id}"
    const val TITLES = "titles"
    const val REMINDERS = "reminders"
    const val LANGUAGE = "language"
    const val THEME = "theme"
    const val SECURITY = "security"
    const val OBSIDIAN = "obsidian"
    const val SUBSCRIPTION = "subscription"
    const val DATA_BACKUP = "data_backup"
    const val TIME_TRACE = "time_trace"
    const val ABOUT = "about"

    fun notes(type: NoteType? = null) = "notes_hub/${type?.name ?: "ALL"}"
    fun editor(type: NoteType, id: String?) = "editor/${type.name}/${id ?: "new"}"
    fun reader(id: String) = "reader/$id"
    fun topilmalar(review: Boolean = false) = "topilmalar/${if (review) "REVIEW" else "SOURCES"}"
    fun topilmalarCreate() = "topilmalar/CREATE"
    fun topilmaComments(id: String) = "topilma_comments/$id"
}

@Composable
fun MemoraApp(
    repository: MemoraRepository,
    topilmalarRepository: TopilmalarRepository,
    obsidianSync: ObsidianSyncManager,
    preferences: UserPreferences,
    settings: UserSettings,
    entitlement: EntitlementState,
    subscriptionPlans: List<SubscriptionPlan>,
    pendingEditorType: String?,
    onPendingEditorConsumed: () -> Unit,
    pendingOpenTimeTrace: Boolean,
    onPendingTimeTraceConsumed: () -> Unit,
    pendingOpenTopilmalarReview: Boolean,
    onPendingTopilmalarReviewConsumed: () -> Unit,
    onExport: (ExportRequest) -> Unit,
    onImport: () -> Unit,
    onRequestNotifications: () -> Unit,
    onRequestExactTiming: () -> Unit,
    onPurchasePlan: (String) -> Unit,
    onRefreshSubscription: () -> Unit,
    onManageSubscription: () -> Unit
) {
    val navController = rememberNavController()
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val mediaStorage = remember(context) { MediaStorage(context.applicationContext) }
    var showExportDialog by remember { mutableStateOf(false) }
    var showNewNoteSheet by remember { mutableStateOf(false) }
    val backOne: () -> Unit = { navController.popBackStack() }

    fun openSingle(route: String) { navController.navigate(route) { launchSingleTop = true } }
    fun openRoot(route: String) {
        navController.navigate(route) {
            popUpTo(Routes.HOME) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }
    fun openEditor(type: NoteType) {
        showNewNoteSheet = false
        if (entitlement.canWrite) navController.navigate(Routes.editor(type, null))
        else openSingle(Routes.SUBSCRIPTION)
    }

    suspend fun deleteNoteAndMedia(note: NoteEntity) {
        repository.deleteNotes(listOf(note.id))
        NoteBlocksCodec.decode(note.blocksJson, note.plainText).forEach { block ->
            when (block) {
                is NoteBlock.Image -> mediaStorage.delete(block.relativePath)
                is NoteBlock.Audio -> mediaStorage.delete(block.relativePath)
                is NoteBlock.Text -> Unit
            }
        }
    }

    val titles by repository.observeTitles().collectAsStateWithLifecycle(emptyList())
    val reminders by repository.observeReminders().collectAsStateWithLifecycle(emptyList())
    val allNotes by repository.observeAllNotes().collectAsStateWithLifecycle(emptyList())
    val tracePhotos by repository.observeTimeTracePhotos().collectAsStateWithLifecycle(emptyList())

    val shortFlow = remember(repository) { repository.observeCount(NoteType.SHORT).distinctUntilChanged() }
    val longFlow = remember(repository) { repository.observeCount(NoteType.LONG).distinctUntilChanged() }
    val allShort by shortFlow.collectAsStateWithLifecycle(0)
    val allLong by longFlow.collectAsStateWithLifecycle(0)

    val isDark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val currentBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = currentBackStackEntry?.destination?.route
    val currentTopilmalarMode = currentBackStackEntry?.arguments?.getString("tab")
    val rootTab = when (currentRoute) {
        Routes.HOME -> RootTab.HOME
        Routes.NOTES_HUB -> RootTab.NOTES
        Routes.TOPILMALAR -> if (currentTopilmalarMode == "CREATE") null else RootTab.TOPILMALAR
        Routes.SETTINGS_HUB -> RootTab.SETTINGS
        else -> null
    }

    // Back always closes the most local layer first. Route popping is disabled while an app-level
    // sheet/dialog is open so one Back press can never jump past it to Home.
    BackHandler(enabled = showNewNoteSheet || showExportDialog) {
        when {
            showNewNoteSheet -> showNewNoteSheet = false
            showExportDialog -> showExportDialog = false
        }
    }
    BackHandler(enabled = currentRoute != Routes.HOME && !showNewNoteSheet && !showExportDialog) {
        navController.popBackStack()
    }

    LaunchedEffect(pendingEditorType, entitlement.canWrite) {
        val raw = pendingEditorType ?: return@LaunchedEffect
        val type = runCatching { NoteType.valueOf(raw) }.getOrNull() ?: return@LaunchedEffect
        val destination = if (entitlement.canWrite) Routes.editor(type, null) else Routes.SUBSCRIPTION
        navController.navigate(destination) { launchSingleTop = true }
        onPendingEditorConsumed()
    }

    LaunchedEffect(pendingOpenTimeTrace, entitlement.canWrite) {
        if (!pendingOpenTimeTrace) return@LaunchedEffect
        navController.navigate(if (entitlement.canWrite) Routes.TIME_TRACE else Routes.SUBSCRIPTION) { launchSingleTop = true }
        onPendingTimeTraceConsumed()
    }

    LaunchedEffect(pendingOpenTopilmalarReview) {
        if (!pendingOpenTopilmalarReview) return@LaunchedEffect
        navController.navigate(Routes.topilmalar(review = true)) { launchSingleTop = true }
        onPendingTopilmalarReviewConsumed()
    }

    val deviceDensity = LocalDensity.current
    val compactDensity = Density(
        density = deviceDensity.density * 0.80f * settings.uiScale,
        fontScale = deviceDensity.fontScale
    )

    CompositionLocalProvider(
        LocalDensity provides compactDensity,
        LocalLayoutDirection provides if (settings.language.rtl) LayoutDirection.Rtl else LayoutDirection.Ltr
    ) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Box(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
                NavHost(
                    navController = navController,
                    startDestination = Routes.HOME,
                    modifier = Modifier.fillMaxSize().then(if (rootTab != null) Modifier.padding(bottom = 82.dp) else Modifier),
                    enterTransition = {
                        fadeIn(
                            animationSpec = tween(
                                durationMillis = 200,
                                easing = MemoraMotion.EmphasizedDecelerate
                            )
                        )
                    },
                    exitTransition = {
                        fadeOut(
                            animationSpec = tween(
                                durationMillis = 180,
                                easing = MemoraMotion.EmphasizedAccelerate
                            )
                        )
                    },
                    popEnterTransition = {
                        fadeIn(
                            animationSpec = tween(
                                durationMillis = 200,
                                easing = MemoraMotion.EmphasizedDecelerate
                            )
                        )
                    },
                    popExitTransition = {
                        fadeOut(
                            animationSpec = tween(
                                durationMillis = 180,
                                easing = MemoraMotion.EmphasizedAccelerate
                            )
                        )
                    }
                ) {
                    composable(Routes.HOME) {
                        var homeReview by remember { mutableStateOf<TopilmaReviewSessionState?>(null) }
                        LaunchedEffect(settings.topilmalarDailyCount, entitlement.canWrite) {
                            if (entitlement.canWrite) {
                                homeReview = runCatching {
                                    topilmalarRepository.getOrCreateDailySession(settings.topilmalarDailyCount)
                                }.getOrNull()
                            }
                        }
                        val todayKey = remember { TimeTraceStorage.todayKey() }
                        HomeScreen(
                            language = settings.language,
                            shortCount = allShort,
                            longCount = allLong,
                            isDark = isDark,
                            uiScale = settings.uiScale,
                            onToggleDark = { scope.launch { preferences.setThemeMode(if (isDark) ThemeMode.LIGHT else ThemeMode.DARK) } },
                            onShort = { openRoot(Routes.notes(NoteType.SHORT)) },
                            onLong = { openRoot(Routes.notes(NoteType.LONG)) },
                            timeTraceTodaySaved = tracePhotos.any { it.dateKey == todayKey },
                            timeTraceStreak = traceStreak(tracePhotos),
                            onTimeTrace = {
                                if (entitlement.canWrite) openSingle(Routes.TIME_TRACE) else openSingle(Routes.SUBSCRIPTION)
                            },
                            reviewReadyCount = homeReview?.let { (it.items.size - it.currentIndex).coerceAtLeast(0) } ?: 0,
                            reviewCompleted = homeReview?.completed == true,
                            onReview = { openRoot(Routes.topilmalar(review = true)) }
                        )
                    }

                    composable(
                        Routes.NOTES_HUB,
                        arguments = listOf(navArgument("filter") { type = NavType.StringType })
                    ) { entry ->
                        val filter = entry.arguments?.getString("filter")
                        val initialType = runCatching { filter?.takeUnless { it == "ALL" }?.let(NoteType::valueOf) }.getOrNull()
                        NotesHubScreen(
                            notes = allNotes,
                            language = settings.language,
                            initialType = initialType,
                            canEdit = entitlement.canWrite,
                            onOpen = { navController.navigate(Routes.reader(it)) },
                            onEdit = { note ->
                                if (entitlement.canWrite) {
                                    navController.navigate(Routes.editor(NoteType.valueOf(note.type), note.id))
                                } else openSingle(Routes.SUBSCRIPTION)
                            },
                            onDelete = { note ->
                                if (entitlement.canWrite) scope.launch { deleteNoteAndMedia(note) }
                                else openSingle(Routes.SUBSCRIPTION)
                            }
                        )
                    }

                    composable(Routes.CALENDAR_ROOT) {
                        CalendarHubScreen(
                            notes = allNotes,
                            language = settings.language,
                            onOpenNote = { navController.navigate(Routes.reader(it)) }
                        )
                    }

                    composable(
                        Routes.TOPILMALAR,
                        arguments = listOf(navArgument("tab") { type = NavType.StringType })
                    ) { entry ->
                        val mode = entry.arguments?.getString("tab")
                        TopilmalarScreen(
                            repository = topilmalarRepository,
                            preferences = preferences,
                            settings = settings,
                            canEdit = entitlement.canWrite,
                            onRequestNotifications = onRequestNotifications,
                            onRequestExactTiming = onRequestExactTiming,
                            onOpenComments = { id -> navController.navigate(Routes.topilmaComments(id)) },
                            onCreateFlowExit = { if (mode == "CREATE") navController.popBackStack() },
                            openReviewInitially = mode == "REVIEW",
                            openCreateInitially = mode == "CREATE"
                        )
                    }

                    composable(
                        Routes.TOPILMA_COMMENTS,
                        arguments = listOf(navArgument("id") { type = NavType.StringType })
                    ) { entry ->
                        val cardId = entry.arguments?.getString("id").orEmpty()
                        TopilmaCommentsScreen(
                            cardId = cardId,
                            repository = topilmalarRepository,
                            canEdit = entitlement.canWrite,
                            onBack = backOne
                        )
                    }

                    composable(Routes.SETTINGS_HUB) {
                        SettingsHubV2Screen(
                            settings = settings,
                            onReminders = { openSingle(Routes.REMINDERS) },
                            onTitles = { openSingle(Routes.TITLES) },
                            onCalendar = { openSingle(Routes.CALENDAR_ROOT) },
                            onTheme = { openSingle(Routes.THEME) },
                            onLanguage = { openSingle(Routes.LANGUAGE) },
                            onData = { openSingle(Routes.DATA_BACKUP) },
                            onSecurity = { openSingle(Routes.SECURITY) },
                            onObsidian = { openSingle(Routes.OBSIDIAN) },
                            onSubscription = { openSingle(Routes.SUBSCRIPTION) },
                            onAbout = { openSingle(Routes.ABOUT) }
                        )
                    }

                    composable(Routes.OBSIDIAN) {
                        ObsidianScreen(
                            settings = settings,
                            manager = obsidianSync,
                            onBack = backOne
                        )
                    }

                    composable(Routes.ABOUT) {
                        AboutScreen(language = settings.language, onBack = backOne)
                    }

                    composable(Routes.TIME_TRACE) {
                        TimeTraceScreen(
                            photos = tracePhotos,
                            language = settings.language,
                            settings = settings,
                            repository = repository,
                            preferences = preferences,
                            onRequestNotifications = onRequestNotifications,
                            onRequestExactTiming = onRequestExactTiming,
                            onBack = backOne
                        )
                    }

                    composable(Routes.DATA_BACKUP) {
                        DataBackupScreen(
                            language = settings.language,
                            onBack = backOne,
                            onExport = { showExportDialog = true },
                            onImport = {
                                if (entitlement.canWrite) onImport() else openSingle(Routes.SUBSCRIPTION)
                            },
                            onTopilmalarHtml = { includeComments ->
                                onExport(
                                    ExportRequest(
                                        format = com.memora.app.export.ExportFormat.MULTIMEDIA,
                                        period = com.memora.app.export.ExportPeriod.ALL,
                                        target = com.memora.app.export.ExportTarget.TOPILMALAR,
                                        includeComments = includeComments
                                    )
                                )
                            },
                            onTopilmalarWord = { includeComments ->
                                onExport(
                                    ExportRequest(
                                        format = com.memora.app.export.ExportFormat.WORD,
                                        period = com.memora.app.export.ExportPeriod.ALL,
                                        target = com.memora.app.export.ExportTarget.TOPILMALAR,
                                        includeComments = includeComments
                                    )
                                )
                            }
                        )
                    }

                    composable(
                        route = Routes.EDITOR,
                        arguments = listOf(
                            navArgument("type") { type = NavType.StringType },
                            navArgument("id") { type = NavType.StringType }
                        )
                    ) { entry ->
                        if (!entitlement.canWrite) {
                            LaunchedEffect(Unit) {
                                navController.popBackStack()
                                navController.navigate(Routes.SUBSCRIPTION) { launchSingleTop = true }
                            }
                            return@composable
                        }
                        val type = NoteType.valueOf(entry.arguments?.getString("type") ?: NoteType.SHORT.name)
                        val idArg = entry.arguments?.getString("id")
                        val compact = LocalDensity.current
                        CompositionLocalProvider(LocalDensity provides Density(compact.density * 1.125f, compact.fontScale)) {
                            EditorScreen(
                                noteId = idArg?.takeUnless { it == "new" },
                                type = type,
                                repository = repository,
                                savedTitles = titles,
                                language = settings.language,
                                writingFont = settings.writingFont,
                                uiScale = settings.uiScale,
                                onBack = backOne
                            )
                        }
                    }

                    composable(Routes.READER, arguments = listOf(navArgument("id") { type = NavType.StringType })) { entry ->
                        val id = entry.arguments?.getString("id").orEmpty()
                        val note by repository.observeNote(id).collectAsStateWithLifecycle(initialValue = null)
                        ReaderScreen(
                            note = note,
                            language = settings.language,
                            writingFont = settings.writingFont,
                            canEdit = entitlement.canWrite,
                            onBack = backOne,
                            onEdit = { note?.let { navController.navigate(Routes.editor(NoteType.valueOf(it.type), it.id)) } },
                            onDelete = {
                                note?.let { current ->
                                    scope.launch {
                                        deleteNoteAndMedia(current)
                                        navController.popBackStack()
                                    }
                                }
                            },
                            onWriteRequired = { openSingle(Routes.SUBSCRIPTION) },
                            onAddToTopilmalar = { text, title ->
                                scope.launch {
                                    topilmalarRepository.capture(
                                        com.memora.app.data.repository.TopilmaCaptureRequest(
                                            text = text,
                                            sourceTitle = title,
                                            originAppPackage = context.packageName,
                                            originAppName = "Memora"
                                        )
                                    )
                                }
                            }
                        )
                    }

                    composable(Routes.TITLES) {
                        TitlesScreen(
                            titles = titles,
                            language = settings.language,
                            onBack = backOne,
                            onAdd = { value -> scope.launch { repository.addTitle(value) } },
                            onDelete = { title -> scope.launch { repository.deleteTitle(title) } },
                            onEdit = { title, value, _ -> scope.launch { repository.renameTitle(title, value, false) } },
                            onPin = { title, pinned -> scope.launch { repository.setTitlePinned(title, pinned) } }
                        )
                    }

                    composable(Routes.REMINDERS) {
                        val local = LocalContext.current
                        RemindersScreen(
                            reminders = reminders,
                            language = settings.language,
                            exactTimingAvailable = AlarmScheduler(local).canScheduleExact(),
                            onBack = backOne,
                            onRequestNotifications = onRequestNotifications,
                            onRequestExactTiming = onRequestExactTiming,
                            onAdd = { hour, minute ->
                                scope.launch {
                                    val id = repository.addReminder(hour, minute)
                                    if (id != -1L) AlarmScheduler(local).scheduleReminder(ReminderEntity(id = id, hour = hour, minute = minute, enabled = true))
                                }
                            },
                            onToggle = { reminder, enabled ->
                                scope.launch {
                                    val changed = reminder.copy(enabled = enabled)
                                    repository.updateReminder(changed)
                                    if (enabled) AlarmScheduler(local).scheduleReminder(changed) else AlarmScheduler(local).cancelReminder(changed.id)
                                }
                            },
                            onDelete = { reminder -> scope.launch { AlarmScheduler(local).cancelReminder(reminder.id); repository.deleteReminder(reminder) } },
                            monthlySummaryEnabled = settings.monthlySummaryEnabled,
                            yearlySummaryEnabled = settings.yearlySummaryEnabled,
                            onMonthlySummary = { scope.launch { preferences.setMonthlySummaryEnabled(it) } },
                            onYearlySummary = { scope.launch { preferences.setYearlySummaryEnabled(it) } }
                        )
                    }

                    composable(Routes.LANGUAGE) {
                        LanguageScreen(current = settings.language, onBack = backOne, onSelect = { scope.launch { preferences.setLanguage(it) } })
                    }
                    composable(Routes.THEME) {
                        ThemeScreen(
                            settings = settings,
                            onBack = backOne,
                            onPalette = { scope.launch { preferences.setPalette(it) } },
                            onThemeMode = { scope.launch { preferences.setThemeMode(it) } },
                            onUiFont = { scope.launch { preferences.setUiFont(it) } },
                            onWritingFont = { scope.launch { preferences.setWritingFont(it) } },
                            onUiScale = { scope.launch { preferences.setUiScale(it) } }
                        )
                    }
                    composable(Routes.SUBSCRIPTION) {
                        SubscriptionScreen(
                            language = settings.language,
                            entitlement = entitlement,
                            plans = subscriptionPlans,
                            onBack = backOne,
                            onSubscribe = onPurchasePlan,
                            onRestore = onRefreshSubscription,
                            onManage = onManageSubscription
                        )
                    }
                    composable(Routes.SECURITY) {
                        SecurityScreen(
                            settings = settings,
                            onBack = backOne,
                            onEnabled = { scope.launch { preferences.setLockEnabled(it) } },
                            onInterval = { scope.launch { preferences.setLockInterval(it) } }
                        )
                    }
                }

                if (rootTab != null) {
                    val inherited = LocalDensity.current
                    val safe = settings.uiScale.coerceIn(.8f, 1.5f)
                    val chrome = safe.coerceAtMost(1.2f)
                    CompositionLocalProvider(LocalDensity provides Density(inherited.density * (chrome / safe), inherited.fontScale)) {
                        MemoraBottomBar(
                            language = settings.language,
                            selected = rootTab,
                            onHome = { openRoot(Routes.HOME) },
                            onNotes = { openRoot(Routes.notes()) },
                            onAdd = { showNewNoteSheet = true },
                            onTopilmalar = { openRoot(Routes.topilmalar()) },
                            onSettings = { openRoot(Routes.SETTINGS_HUB) },
                            modifier = Modifier.align(Alignment.BottomCenter)
                        )
                    }
                }
            }
        }

        if (showExportDialog) {
            ExportDialog(language = settings.language, onDismiss = { showExportDialog = false }, onExport = { showExportDialog = false; onExport(it) })
        }
        if (showNewNoteSheet) {
            NewNoteSheet(
                language = settings.language,
                onDismiss = { showNewNoteSheet = false },
                onShort = { openEditor(NoteType.SHORT) },
                onTopilma = {
                    showNewNoteSheet = false
                    if (entitlement.canWrite) navController.navigate(Routes.topilmalarCreate())
                    else openSingle(Routes.SUBSCRIPTION)
                },
                onLong = { openEditor(NoteType.LONG) }
            )
        }
    }
}

private fun traceStreak(photos: List<TimeTracePhotoEntity>): Int {
    if (photos.isEmpty()) return 0
    val days = photos.mapNotNull { runCatching { TimeTraceStorage.parseDate(it.dateKey) }.getOrNull() }.toSet()
    var cursor = LocalDate.now()
    if (cursor !in days) cursor = cursor.minusDays(1)
    var count = 0
    while (cursor in days) { count++; cursor = cursor.minusDays(1) }
    return count
}
