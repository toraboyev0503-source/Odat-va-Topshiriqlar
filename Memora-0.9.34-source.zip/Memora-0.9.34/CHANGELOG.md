# Memora 0.9.34 — Direct Topilma composer + OCR/back-flow polish

- New-note sheet reordered to Qisqa matn → Uzun matn → Topilma, equalized and compacted.
- Selection/action surfaces now use the active palette accent tint instead of a fixed-looking pale background.
- Center + → Topilma now opens the writing composer directly.
- Last-used Topilma source is selected by default; source picker is recent-first with + New source at the bottom.
- Copy action sits beside the source and opens Camera / Gallery in a compact sheet.
- Topilma writing surface follows the cleaner Memora focus-editor direction.
- OCR adds safe auto page rectification, small-angle deskew, paragraph-aware reading order, tighter selection snapping, and an editable review step before insertion.
- Back navigation closes the most local layer first and Topilma creation returns one internal step at a time.
- Source changes during a Topilma draft now update card source metadata consistently.
- Topilma card visual renderer/spec was not changed.
- Version bumped to `0.9.34` / code `54`.
