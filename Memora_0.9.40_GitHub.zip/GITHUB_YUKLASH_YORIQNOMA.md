# Memora 0.9.40 — GitHub yuklash yo‘riqnomasi

**Hozircha GitHub'ga yuklamang** — foydalanuvchi alohida buyruq berganidan keyin yuklanadi.

Keyingi bosqichda `Memora_0.9.40_GitHub.zip` arxivini GitHub repozitoriysining ildiziga joylash kifoya; ZIPni ochish shart emas. `.github/workflows/main.yml` faylini alohida berilgan `android-build_0.9.40.yml` bilan almashtirish yoki uni `.github/workflows/android-build.yml` sifatida joylash kerak. Ikkita bir xil workflow'ni birga ishga tushirmaslik tavsiya qilinadi.

GitHub Actions ZIPni avtomatik ochadi, Kotlin unit testlarini, lint, APK yig‘ish va backend testlarini bajaradi. Build muvaffaqiyatli bo‘lsa artefakt nomi `Memora-0.9.40-debug-apk` bo‘ladi. Emulator migratsiya testini `workflow_dispatch` orqali `run_android_tests=true` holatida alohida ishga tushirish mumkin.

**Ehtiyot:** 0.9.39 APK ustiga yangilashdan oldin `.memora` zaxirangizni saqlang; migratsiyani emulatorda yoki zaxiraviy qurilmada sinang. Debug imzo oldingi Memora test key bilan bir xil.
