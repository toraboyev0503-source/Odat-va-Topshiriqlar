package com.memora.app.ui.screens

import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AutoStories
import androidx.compose.material.icons.rounded.Book
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.memora.app.data.local.TopilmaSourceRow
import com.memora.app.data.local.TopilmaSourceType
import com.memora.app.data.repository.TopilmalarRepository
import com.memora.app.media.TopilmalarMediaStorage
import com.memora.app.ui.theme.MemoraDesign
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

@Composable
fun TopilmaSourcePickerScreen(
    repository: TopilmalarRepository,
    canEdit: Boolean,
    onBack: () -> Unit,
    onSelect: (TopilmaSourceRow) -> Unit
) {
    val sources by repository.observeSources().collectAsStateWithLifecycle(emptyList())
    var query by remember { mutableStateOf("") }
    var showCreate by remember { mutableStateOf(false) }
    val visible = remember(sources, query) {
        val needle = query.trim().lowercase()
        sources
            .sortedByDescending { it.lastAddedAt }
            .filter { needle.isBlank() || it.title.lowercase().contains(needle) || it.author.orEmpty().lowercase().contains(needle) }
    }

    BackHandler(onBack = onBack)
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 8.dp, end = 12.dp, top = 8.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, contentDescription = "Orqaga") }
            Column(Modifier.weight(1f)) {
                Text("Topilma manbasi", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                Text("Topilma qaysi manbaga tegishli?", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Surface(
                onClick = { if (canEdit) showCreate = true },
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primary.copy(alpha = .11f),
                modifier = Modifier.size(40.dp)
            ) {
                Box(contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Add, contentDescription = "Yangi manba") }
            }
        }
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            placeholder = { Text("Manba yoki muallifni qidiring") },
            leadingIcon = { Icon(Icons.Rounded.Search, null) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp)
        )
        if (visible.isEmpty()) {
            Column(
                Modifier.fillMaxSize().padding(30.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(Icons.Rounded.AutoStories, null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.primary)
                Text(
                    if (sources.isEmpty()) "Hozircha manba yo‘q" else "Mos manba topilmadi",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 12.dp)
                )
                if (sources.isEmpty()) {
                    Text("Yuqoridagi + orqali birinchi manbani qo‘shing.", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 5.dp))
                }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(start = 18.dp, end = 18.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(9.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(visible, key = { it.id }) { source ->
                    SourcePickerRow(source = source, onClick = { onSelect(source) })
                }
            }
        }
    }
    if (showCreate) {
        CreateSourceDialog(
            repository = repository,
            onDismiss = { showCreate = false },
            onCreated = { showCreate = false }
        )
    }
}

@Composable
private fun SourcePickerRow(source: TopilmaSourceRow, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(MemoraDesign.radiusMedium),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = MemoraDesign.shadowSubtle
    ) {
        Row(Modifier.padding(horizontal = 13.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
            SourcePickerCover(source, Modifier.size(width = 44.dp, height = 56.dp))
            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                Text(source.title, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                source.author?.takeIf { it.isNotBlank() }?.let {
                    Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary.copy(alpha = .10f)) {
                Text(
                    source.cardCount.toString(),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                )
            }
        }
    }
}

@Composable
private fun SourcePickerCover(source: TopilmaSourceRow, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val path = source.coverPath
    val bitmap by produceState<android.graphics.Bitmap?>(null, path) {
        value = path?.let { relativePath ->
            withContext(Dispatchers.IO) {
                runCatching { decodeSourcePickerThumbnail(TopilmalarMediaStorage(context).resolve(relativePath), 240) }.getOrNull()
            }
        }
    }
    Surface(shape = RoundedCornerShape(7.dp), color = MaterialTheme.colorScheme.primary.copy(alpha = .10f), modifier = modifier) {
        if (bitmap != null) Image(bitmap!!.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Box(contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Book, null, tint = MaterialTheme.colorScheme.primary) }
    }
}

@Composable
private fun CreateSourceDialog(
    repository: TopilmalarRepository,
    onDismiss: () -> Unit,
    onCreated: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var title by remember { mutableStateOf("") }
    var author by remember { mutableStateOf("") }
    var uri by remember { mutableStateOf("") }
    var type by remember { mutableStateOf(TopilmaSourceType.BOOK) }
    var typeMenu by remember { mutableStateOf(false) }
    var coverUri by remember { mutableStateOf<Uri?>(null) }
    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { coverUri = it }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Yangi manba") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Nomi") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(author, { author = it }, label = { Text("Muallif / yaratuvchi") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(uri, { uri = it }, label = { Text("URL / URI (ixtiyoriy)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Box {
                    OutlinedButton(onClick = { typeMenu = true }) { Text(createSourceTypeLabel(type)) }
                    DropdownMenu(expanded = typeMenu, onDismissRequest = { typeMenu = false }) {
                        TopilmaSourceType.entries.forEach { option ->
                            DropdownMenuItem(
                                text = { Text(createSourceTypeLabel(option)) },
                                onClick = { type = option; typeMenu = false }
                            )
                        }
                    }
                }
                OutlinedButton(onClick = { gallery.launch("image/*") }) {
                    Icon(Icons.Rounded.PhotoLibrary, null)
                    Text(if (coverUri == null) " Muqova rasmini tanlash" else " Muqova tanlandi ✓")
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    scope.launch {
                        val id = repository.createSource(
                            title = title,
                            author = author.ifBlank { null },
                            type = type,
                            uri = uri.ifBlank { null }
                        )
                        coverUri?.let { selected ->
                            runCatching {
                                TopilmalarMediaStorage(context).storeSharedImage(selected, context.contentResolver.getType(selected)).relativePath
                            }.getOrNull()?.let { repository.setSourceCover(id, it) }
                        }
                        onCreated()
                    }
                },
                enabled = title.isNotBlank()
            ) { Text("Qo‘shish") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor qilish") } }
    )
}

@Composable
fun TopilmaQuickEditorScreen(
    source: TopilmaSourceRow,
    repository: TopilmalarRepository,
    canEdit: Boolean,
    onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var text by remember(source.id) { mutableStateOf("") }
    var cardId by remember(source.id) { mutableStateOf<String?>(null) }
    var saving by remember { mutableStateOf(false) }
    val saveMutex = remember(source.id) { Mutex() }

    suspend fun persist() {
        if (!canEdit) return
        saveMutex.withLock {
            // A text-keyed LaunchedEffect is cancelled whenever the user types again.
            // Shield the actual DB write so a committed insert cannot be cancelled before
            // cardId is captured, which would otherwise risk creating a duplicate draft.
            withContext(NonCancellable) {
                val clean = text.trim()
                if (clean.isBlank()) {
                    cardId?.let { repository.softDelete(listOf(it)); cardId = null }
                    saving = false
                    return@withContext
                }
                saving = true
                val id = cardId
                if (id == null) {
                    cardId = repository.createManualCard(source.id, clean)
                } else {
                    repository.card(id)?.let { repository.updateCard(it, clean) }
                }
                saving = false
            }
        }
    }

    LaunchedEffect(text) {
        if (text.isBlank() && cardId == null) return@LaunchedEffect
        delay(700)
        persist()
    }

    fun finish() {
        scope.launch {
            persist()
            onBack()
        }
    }

    BackHandler { finish() }
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = ::finish) { Icon(Icons.Rounded.ArrowBack, contentDescription = "Orqaga") }
            SourcePickerCover(source, Modifier.size(width = 36.dp, height = 46.dp))
            Column(Modifier.weight(1f).padding(start = 10.dp)) {
                Text(source.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                source.author?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1) }
            }
            Text(
                if (saving) "Saqlanmoqda…" else if (cardId != null) "Saqlandi ✓" else "Autosave",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            placeholder = { Text("Topilmangizni yozing…") },
            modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 10.dp),
            enabled = canEdit,
            minLines = 12
        )
    }
}

private fun createSourceTypeLabel(type: TopilmaSourceType) = when (type) {
    TopilmaSourceType.BOOK -> "Kitob"
    TopilmaSourceType.ARTICLE_WEBSITE -> "Maqola / sayt"
    TopilmaSourceType.CHAT -> "Chat"
    TopilmaSourceType.SOCIAL -> "Ijtimoiy tarmoq"
    TopilmaSourceType.DOCUMENT -> "Hujjat"
    TopilmaSourceType.MESSAGE -> "Xabar"
    TopilmaSourceType.OTHER -> "Boshqa"
}

private fun decodeSourcePickerThumbnail(file: File, target: Int): android.graphics.Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(file.absolutePath, bounds)
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    var sample = 1
    while (bounds.outWidth / sample > target * 2 || bounds.outHeight / sample > target * 2) sample *= 2
    return BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
}
