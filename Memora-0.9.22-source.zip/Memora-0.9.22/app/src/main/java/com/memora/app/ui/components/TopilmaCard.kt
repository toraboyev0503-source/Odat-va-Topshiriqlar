package com.memora.app.ui.components

import android.graphics.BitmapFactory
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ChatBubbleOutline
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memora.app.data.local.TopilmaCardRow
import com.memora.app.data.local.TopilmaSourceType
import com.memora.app.media.TopilmalarMediaStorage
import com.memora.app.ui.theme.MemoraDesign
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun TopilmaCard(
    row: TopilmaCardRow,
    canEdit: Boolean,
    onShare: () -> Unit,
    onLike: () -> Unit,
    onComments: () -> Unit,
    modifier: Modifier = Modifier,
    selected: Boolean = false,
    onOpen: (() -> Unit)? = null,
    onLongPress: (() -> Unit)? = null,
    onEdit: (() -> Unit)? = null,
    onToggleFavorite: (() -> Unit)? = null,
    onToggleReview: (() -> Unit)? = null,
    onDelete: (() -> Unit)? = null,
    onOpenSource: (() -> Unit)? = null,
    forceExpanded: Boolean = false,
    showExpandControl: Boolean = true
) {
    var expanded by remember(row.id) { mutableStateOf(forceExpanded) }
    var canExpand by remember(row.id, row.text) { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var pulseLike by remember(row.id) { mutableStateOf(false) }
    var previousLikeCount by remember(row.id) { mutableStateOf(row.likeCount) }
    LaunchedEffect(row.likeCount) {
        if (row.likeCount > previousLikeCount) {
            pulseLike = true
            delay(120)
            pulseLike = false
        }
        previousLikeCount = row.likeCount
    }
    val likeScale by animateFloatAsState(if (pulseLike) 1.16f else 1f, label = "topilmaLikePulse")
    val clickable = onOpen != null || onLongPress != null

    Card(
        modifier = modifier
            .fillMaxWidth()
            .then(
                if (clickable) {
                    Modifier.combinedClickable(
                        onClick = { onOpen?.invoke() },
                        onLongClick = { onLongPress?.invoke() }
                    )
                } else Modifier
            ),
        shape = RoundedCornerShape(MemoraDesign.radiusMedium),
        colors = CardDefaults.cardColors(
            containerColor = if (selected) {
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
            } else {
                MaterialTheme.colorScheme.surface
            }
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = MemoraDesign.shadowSubtle)
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .animateContentSize()
                .padding(horizontal = 15.dp, vertical = 14.dp)
        ) {
            Row(verticalAlignment = Alignment.Top) {
                TopilmaCardCover(row, Modifier.size(width = 46.dp, height = 58.dp))
                Column(Modifier.weight(1f).padding(start = 12.dp, top = 1.dp)) {
                    Text(
                        text = row.sourceTitle ?: "Manbasi aniqlanmagan",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        lineHeight = 20.sp
                    )
                    row.sourceAuthor?.takeIf { it.isNotBlank() }?.let { author ->
                        Text(
                            text = author,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                }
                if (onEdit != null || onToggleFavorite != null || onToggleReview != null || onDelete != null || onOpenSource != null) {
                    Box {
                        IconButton(onClick = { menuOpen = true }, modifier = Modifier.size(36.dp)) {
                            Icon(Icons.Rounded.MoreVert, contentDescription = "Ko‘proq")
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            onOpenSource?.let { action ->
                                DropdownMenuItem(
                                    text = { Text("Manbaga o‘tish") },
                                    leadingIcon = { Icon(Icons.Rounded.OpenInNew, null) },
                                    onClick = { menuOpen = false; action() }
                                )
                            }
                            onEdit?.let { action ->
                                DropdownMenuItem(
                                    text = { Text("Tahrirlash") },
                                    leadingIcon = { Icon(Icons.Rounded.Edit, null) },
                                    enabled = canEdit,
                                    onClick = { menuOpen = false; action() }
                                )
                            }
                            onToggleFavorite?.let { action ->
                                DropdownMenuItem(
                                    text = { Text(if (row.favorite) "Sevimlidan olib tashlash" else "Sevimli") },
                                    leadingIcon = { Icon(if (row.favorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, null) },
                                    enabled = canEdit,
                                    onClick = { menuOpen = false; action() }
                                )
                            }
                            onToggleReview?.let { action ->
                                DropdownMenuItem(
                                    text = { Text(if (row.excludedFromReview) "Qayta ko‘rishga qo‘shish" else "Qayta ko‘rsatma") },
                                    leadingIcon = {
                                        Icon(if (row.excludedFromReview) Icons.Rounded.Visibility else Icons.Rounded.VisibilityOff, null)
                                    },
                                    enabled = canEdit,
                                    onClick = { menuOpen = false; action() }
                                )
                            }
                            onDelete?.let { action ->
                                DropdownMenuItem(
                                    text = { Text("O‘chirish") },
                                    leadingIcon = { Icon(Icons.Rounded.DeleteOutline, null) },
                                    enabled = canEdit,
                                    onClick = { menuOpen = false; action() }
                                )
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(11.dp))
            Text(
                text = row.text.ifBlank { "Rasmli Topilma" },
                style = MaterialTheme.typography.bodyLarge.copy(lineHeight = 25.sp),
                maxLines = if (expanded || forceExpanded) Int.MAX_VALUE else 2,
                overflow = if (expanded || forceExpanded) TextOverflow.Clip else TextOverflow.Ellipsis,
                onTextLayout = { result ->
                    if (!expanded && !forceExpanded) canExpand = result.hasVisualOverflow
                }
            )

            if (showExpandControl && canExpand && !forceExpanded) {
                Surface(
                    onClick = { expanded = !expanded },
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .75f),
                    modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 8.dp).size(30.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            if (expanded) Icons.Rounded.KeyboardArrowUp else Icons.Rounded.KeyboardArrowDown,
                            contentDescription = if (expanded) "Yopish" else "To‘liq ko‘rish",
                            modifier = Modifier.size(20.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Row(
                Modifier.fillMaxWidth().padding(top = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(
                    onClick = onShare,
                    contentPadding = PaddingValues(horizontal = 7.dp, vertical = 5.dp)
                ) {
                    Icon(Icons.Rounded.Share, contentDescription = "Ulashish", modifier = Modifier.size(21.dp))
                }

                TextButton(
                    onClick = onLike,
                    enabled = canEdit,
                    contentPadding = PaddingValues(horizontal = 7.dp, vertical = 5.dp)
                ) {
                    Icon(
                        imageVector = if (row.likeCount > 0) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        contentDescription = "Like",
                        modifier = Modifier.size(22.dp).graphicsLayer(scaleX = likeScale, scaleY = likeScale),
                        tint = if (row.likeCount > 0) MaterialTheme.colorScheme.error.copy(alpha = .72f) else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (row.likeCount > 0) {
                        Text(
                            text = row.likeCount.toString(),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(start = 4.dp)
                        )
                    }
                }

                TextButton(
                    onClick = onComments,
                    contentPadding = PaddingValues(horizontal = 7.dp, vertical = 5.dp)
                ) {
                    Icon(Icons.Rounded.ChatBubbleOutline, contentDescription = "Izohlar", modifier = Modifier.size(21.dp))
                    if (row.commentCount > 0) {
                        Text(
                            text = row.commentCount.toString(),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(start = 4.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TopilmaCardCover(row: TopilmaCardRow, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val path = row.sourceCoverPath
    val bitmap by produceState<android.graphics.Bitmap?>(null, path) {
        value = path?.let { relativePath ->
            withContext(Dispatchers.IO) {
                runCatching { decodeTopilmaCardThumbnail(TopilmalarMediaStorage(context).resolve(relativePath), 256) }.getOrNull()
            }
        }
    }
    Surface(
        shape = RoundedCornerShape(7.dp),
        color = MaterialTheme.colorScheme.primary.copy(alpha = .10f),
        modifier = modifier.clip(RoundedCornerShape(7.dp))
    ) {
        val current = bitmap
        if (current != null) {
            Image(current.asImageBitmap(), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    text = when (row.sourceType) {
                        TopilmaSourceType.BOOK.name -> "B"
                        TopilmaSourceType.ARTICLE_WEBSITE.name -> "A"
                        TopilmaSourceType.CHAT.name -> "C"
                        TopilmaSourceType.SOCIAL.name -> "S"
                        TopilmaSourceType.DOCUMENT.name -> "D"
                        else -> "M"
                    },
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

private fun decodeTopilmaCardThumbnail(file: File, target: Int): android.graphics.Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(file.absolutePath, bounds)
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    var sample = 1
    while (bounds.outWidth / sample > target * 2 || bounds.outHeight / sample > target * 2) sample *= 2
    return BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
}
