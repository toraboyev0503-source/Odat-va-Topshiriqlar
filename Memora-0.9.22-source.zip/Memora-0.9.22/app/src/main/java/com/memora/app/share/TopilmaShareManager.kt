package com.memora.app.share

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.FileProvider
import com.memora.app.data.local.TopilmaCardRow
import com.memora.app.media.TopilmalarMediaStorage
import java.io.File
import java.io.FileOutputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object TopilmaShareManager {
    fun shareText(context: Context, card: TopilmaCardRow, includeSource: Boolean) {
        val text = buildString {
            append(card.text)
            if (includeSource && !card.sourceTitle.isNullOrBlank()) {
                append("\n\n— ").append(card.sourceTitle)
                if (!card.sourceAuthor.isNullOrBlank()) append(", ").append(card.sourceAuthor)
            }
        }
        context.startActivity(
            Intent.createChooser(
                Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, text)
                },
                "Topilmani ulashish"
            )
        )
    }

    /**
     * T-171: share always renders the complete Topilma card, never the collapsed
     * two-line state shown in the scrolling list. The bitmap keeps a small outer
     * margin so the rounded card corners remain visible in the shared image.
     */
    suspend fun shareCardImage(context: Context, card: TopilmaCardRow) {
        val uri = withContext(Dispatchers.IO) {
            val bitmap = render(context, card)
            val directory = File(context.cacheDir, "shares").apply { mkdirs() }
            val file = File(directory, "topilma-${card.id}.png")
            FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            bitmap.recycle()
            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        }
        withContext(Dispatchers.Main) {
            context.startActivity(
                Intent.createChooser(
                    Intent(Intent.ACTION_SEND).apply {
                        type = "image/png"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    },
                    "Kartochka rasmini ulashish"
                )
            )
        }
    }

    private fun render(context: Context, card: TopilmaCardRow): Bitmap {
        val width = 1080
        val outer = 44f
        val cardLeft = outer
        val cardRight = width - outer
        val innerLeft = cardLeft + 42f
        val innerRight = cardRight - 42f
        val contentWidth = (innerRight - innerLeft).toInt()

        val title = card.sourceTitle?.takeIf { it.isNotBlank() } ?: "Manbasi aniqlanmagan"
        val author = card.sourceAuthor.orEmpty()
        val body = card.text.ifBlank { "Rasmli Topilma" }

        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(40, 42, 41)
            textSize = 36f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val authorPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(105, 108, 106)
            textSize = 28f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        }
        val bodyPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(35, 36, 35)
            textSize = when {
                body.length < 180 -> 43f
                body.length < 420 -> 39f
                body.length < 900 -> 35f
                else -> 32f
            }
            typeface = Typeface.create(Typeface.SERIF, Typeface.NORMAL)
        }

        val coverW = 92f
        val coverH = 116f
        val headerTextWidth = (contentWidth - coverW - 30f - 52f).toInt().coerceAtLeast(300)
        val titleLayout = StaticLayout.Builder.obtain(title, 0, title.length, titlePaint, headerTextWidth)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setMaxLines(2)
            .setEllipsize(android.text.TextUtils.TruncateAt.END)
            .build()
        val authorLayout = if (author.isNotBlank()) {
            StaticLayout.Builder.obtain(author, 0, author.length, authorPaint, headerTextWidth)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setMaxLines(1)
                .setEllipsize(android.text.TextUtils.TruncateAt.END)
                .build()
        } else null

        val bodyLayout = StaticLayout.Builder.obtain(body, 0, body.length, bodyPaint, contentWidth)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setLineSpacing(8f, 1f)
            .build()

        val cardTop = outer
        val headerTop = cardTop + 42f
        val bodyTop = headerTop + maxOf(coverH, titleLayout.height.toFloat() + (authorLayout?.height ?: 0) + 10f) + 34f
        val actionsHeight = 112f
        val cardBottom = maxOf(bodyTop + bodyLayout.height + 34f + actionsHeight, cardTop + 590f)
        val bitmapHeight = (cardBottom + outer).toInt()

        val bitmap = Bitmap.createBitmap(width, bitmapHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.rgb(248, 243, 239))

        val cardPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            setShadowLayer(10f, 0f, 3f, Color.argb(32, 0, 0, 0))
        }
        canvas.drawRoundRect(cardLeft, cardTop, cardRight, cardBottom, 38f, 38f, cardPaint)

        val coverLeft = innerLeft
        val coverTop = headerTop
        val thumbnail = card.sourceCoverPath?.let { relativePath ->
            runCatching { decodeThumbnail(TopilmalarMediaStorage(context).resolve(relativePath), 220) }.getOrNull()
        }
        if (thumbnail != null) {
            canvas.save()
            val clip = Path().apply { addRoundRect(RectF(coverLeft, coverTop, coverLeft + coverW, coverTop + coverH), 10f, 10f, Path.Direction.CW) }
            canvas.clipPath(clip)
            canvas.drawBitmap(thumbnail, null, RectF(coverLeft, coverTop, coverLeft + coverW, coverTop + coverH), Paint(Paint.ANTI_ALIAS_FLAG))
            canvas.restore()
            thumbnail.recycle()
        } else {
            val fallback = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(233, 239, 235) }
            canvas.drawRoundRect(coverLeft, coverTop, coverLeft + coverW, coverTop + coverH, 10f, 10f, fallback)
            canvas.drawText("M", coverLeft + 28f, coverTop + 72f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(64, 100, 84); textSize = 46f; typeface = Typeface.DEFAULT_BOLD
            })
        }

        val textLeft = coverLeft + coverW + 28f
        canvas.save()
        canvas.translate(textLeft, headerTop + 2f)
        titleLayout.draw(canvas)
        canvas.restore()
        authorLayout?.let {
            canvas.save()
            canvas.translate(textLeft, headerTop + titleLayout.height + 8f)
            it.draw(canvas)
            canvas.restore()
        }

        // Three-dot menu glyph mirrors the live card header.
        val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(115, 116, 115) }
        val dotY = headerTop + 18f
        val dotX = innerRight - 20f
        listOf(-15f, 0f, 15f).forEach { offset -> canvas.drawCircle(dotX + offset, dotY, 3.6f, dotPaint) }

        canvas.save()
        canvas.translate(innerLeft, bodyTop)
        bodyLayout.draw(canvas)
        canvas.restore()

        val actionY = cardBottom - 58f
        val iconColor = Color.rgb(54, 56, 55)
        val muted = Color.rgb(95, 98, 96)
        val actionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = iconColor
            strokeWidth = 5f
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        val countPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = muted
            textSize = 28f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }

        // Share icon: tray + upward arrow.
        val shareX = innerLeft + 115f
        canvas.drawLine(shareX - 24f, actionY + 20f, shareX - 24f, actionY + 43f, actionPaint)
        canvas.drawLine(shareX - 24f, actionY + 43f, shareX + 24f, actionY + 43f, actionPaint)
        canvas.drawLine(shareX + 24f, actionY + 43f, shareX + 24f, actionY + 20f, actionPaint)
        canvas.drawLine(shareX, actionY + 28f, shareX, actionY - 25f, actionPaint)
        canvas.drawLine(shareX, actionY - 25f, shareX - 15f, actionY - 8f, actionPaint)
        canvas.drawLine(shareX, actionY - 25f, shareX + 15f, actionY - 8f, actionPaint)

        // Heart icon. Filled softly red after the first like, outline otherwise.
        val heartX = width / 2f
        val heartPath = Path().apply {
            moveTo(heartX, actionY + 35f)
            cubicTo(heartX - 58f, actionY - 2f, heartX - 40f, actionY - 42f, heartX - 16f, actionY - 30f)
            cubicTo(heartX - 5f, actionY - 25f, heartX, actionY - 13f, heartX, actionY - 13f)
            cubicTo(heartX, actionY - 13f, heartX + 5f, actionY - 25f, heartX + 16f, actionY - 30f)
            cubicTo(heartX + 40f, actionY - 42f, heartX + 58f, actionY - 2f, heartX, actionY + 35f)
            close()
        }
        val heartPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (card.likeCount > 0) Color.rgb(212, 101, 110) else iconColor
            style = if (card.likeCount > 0) Paint.Style.FILL else Paint.Style.STROKE
            strokeWidth = 5f
        }
        canvas.drawPath(heartPath, heartPaint)
        if (card.likeCount > 0) canvas.drawText(card.likeCount.toString(), heartX + 50f, actionY + 10f, countPaint)

        // Comment bubble.
        val commentX = innerRight - 115f
        val bubble = RectF(commentX - 30f, actionY - 28f, commentX + 30f, actionY + 20f)
        canvas.drawRoundRect(bubble, 13f, 13f, actionPaint)
        val tail = Path().apply {
            moveTo(commentX - 8f, actionY + 20f)
            lineTo(commentX - 18f, actionY + 36f)
            lineTo(commentX + 2f, actionY + 21f)
        }
        canvas.drawPath(tail, actionPaint)
        if (card.commentCount > 0) canvas.drawText(card.commentCount.toString(), commentX + 45f, actionY + 10f, countPaint)

        return bitmap
    }

    private fun decodeThumbnail(file: File, target: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (bounds.outWidth / sample > target * 2 || bounds.outHeight / sample > target * 2) sample *= 2
        return BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
    }
}
