# Memora 0.9.39 — Quiet Navigation / overlap fix

- Removed detail-screen fadeIn/fadeOut; root-tab switches are immediate.
- Detail navigation enters by a quiet 12 dp slide over 170 ms; Back slides the outgoing detail out over 170 ms.
- Wrapped all 19 Navigation Compose destinations in opaque, palette-aware full-screen Surfaces to prevent text ghosting.
- Made NavHost full-size and stable; moved bottom-bar padding inside the root destinations.
- Kept five-button bottom navigation hidden through the entire detail exit transition and during keyboard entry.
- Added pure Kotlin navigation policy and JUnit tests; made the slide RTL-aware.
- `versionName = 0.9.39`, `versionCode = 60`; Room schema, signing key and debug package ID unchanged.
- Static and pure Kotlin tests are not a substitute for GitHub build and device visual verification.

---

# Memora 0.9.38 — Harmony UI (U-01–U-06)

- **U-01 Navigation:** removed whole-screen simultaneous fade on root tabs; details use subtle horizontal motion and shorter transitions.
- **U-02 Notes archive:** current-year notes remain expanded by day; completed years become a single collapsible year folder, without month folders; search shows all matching notes directly.
- **U-03 Overlays and keyboard:** unified palette-aware Material 3 tonal surface roles, shared `MemoraSheet` / `MemoraDialog`, compact new-note sheet and search filters, themed date picker; hide the five-button bottom bar and its reserved space when the IME opens.
- **U-04 Language:** compact theme-aligned selectable language cards, supporting all 13 existing language choices and RTL.
- **U-05 Theme:** light/dark/system previews, five live palette samples, font previews, scale slider and localized reset/mode names.
- **U-06 Security:** coherent app-lock header and clear selection cards for existing lock intervals.
- **Compatibility:** `versionName = 0.9.38`, `versionCode = 59`; same debug application identity/signing certificate, Room schema 8, existing settings, content and exports preserved.
- **Validation:** 185 static regression checks, two Topilma visual checks, 5 backend tests and a pure Kotlin archive policy smoke test passed locally. Android Gradle compile, instrumentation, lint, device test and in-place APK upgrade remain unverified until CI/device runs.

---

# Memora 0.9.37 — audit fixes M-01–M-12

- Single, up-to-date GitHub Actions workflow with lint, unit tests, APK build, backend tests and optional emulator migration check.
- Preserve note data and attached media when save fails; enforce required title and recover drafts.
- Separate local save from Obsidian sync errors; improve Topilmalar selection count.
- Transactional database import, staged media restoration and rollback cleanup on error.
- Bounded OCR image staging; Topilmalar integration preference now drives source suggestions.
- Targeted integration UI localization/theming, migration test coverage, backend throttling and limited refactoring.
- Version updated to `0.9.37` / `58`, with Room schema kept at `8`.

See `docs/RELEASE_0.9.37.md` for test status and remaining device/build verification.

# Memora 0.9.36 — external Topilma source chooser

- “Topilmaga saqlash” now opens a compact bottom source chooser before saving.
- The last-used source is the primary large option with cover/title.
- The next five recently used sources appear as compact horizontal cover tiles with short titles.
- Tapping any source saves immediately; no second confirmation is required.
- “Barcha manbalar” opens a searchable full source list.
- Current-source metadata is surfaced as a separate suggestion only when usable title/author/URL metadata is available.
- Detected new sources are created only after the user explicitly selects the suggestion.
- Detected source contexts are remembered and mapped back to the selected existing source on later captures.
- External app names are fallback metadata only, not the preferred source.
- Browser URL metadata continues to be enriched asynchronously into article/site title, author and image/favicon where available.
- Back/outside tap dismisses the chooser without saving.
- Canonical Topilma card visuals remain unchanged.
- Version bumped to `0.9.36` / code `57`.

# Memora 0.9.35 — Topilma scanner + external app integrations + Back fix

## 0.9.35.1
- Installation compatibility build: Accessibility Service component temporarily removed from the APK.
- Explicit Android “Topilmaga saqlash” PROCESS_TEXT integration remains available.
- Scanner/OCR and Topilma creation/back-navigation improvements remain unchanged.

- Topilma copy icon is now a scanner icon.
- Camera copy flow now uses Google ML Kit Document Scanner FULL mode with automatic page detection, perspective correction, crop and cleanup.
- The old custom perspective transform is no longer applied to OCR input, avoiding bent/skewed page rendering.
- OCR keeps line/paragraph-aware reading order, adds full-line tap selection, range dragging and editable review before insertion.
- Settings now includes “Topilmalar integratsiyasi”.
- Users can add/remove launchable apps such as ChatGPT, Chrome and eReader from the allowed-app list.
- Android PROCESS_TEXT integration adds “Topilmaga saqlash” to compatible text-selection menus.
- Optional quick monitoring uses an Accessibility Service for selected apps and offers a small save prompt after copied text is detected.
- External captures create/reuse Topilma sources automatically and use app metadata as fallback.
- Browser captures attempt to detect the current URL; network enrichment fetches page title, author, Open Graph image or favicon when available.
- ChatGPT-like apps map to a Chat source; eReader/book apps map to a Book source with available metadata.
- Topilma editor Back now waits only for safe local save; it no longer forces synchronous Obsidian sync before navigating back.
- Toolbar Back and system Back share the same guarded exit path; local sheets/dialogs close first; repeated taps are ignored.
- Save failures are shown in the editor instead of leaving the screen apparently frozen.
- Canonical Topilma card visual renderer/spec remains unchanged.
- Version bumped to `0.9.35` / code `55`.
