# Memora 0.9.39 — Quiet Navigation fix

Android e-journal / Topilmalar app (Kotlin, Jetpack Compose, Room).

- `versionName`: **0.9.39**; `versionCode`: **60**.
- Debug application ID and signing key unchanged from 0.9.38.
- Room schema version **8**; note data, settings, media and backup format unchanged.

## Q-01–Q-11: video-observed navigation artifact remediation

- Root tabs switch immediately, without fading or sliding.
- Detail pages use a **170 ms / 12 dp** horizontal slide; Back reverses the movement.
- Every destination now owns a full-size opaque, theme-colored background. This prevents the previous screen's title or text appearing through a new screen.
- `NavHost` viewport never changes size when the bottom tab bar appears or disappears. Each root destination instead reserves its own tab bar space.
- The five-button bottom bar remains hidden until exiting details finish their transitions, and hides during keyboard entry. RTL reverses the horizontal slide.
- 19 navigation destinations are covered by the same wrapper; Topilmalar `CREATE` is treated as a detail.

See [`docs/RELEASE_0.9.39.md`](docs/RELEASE_0.9.39.md) for test scenarios, limitations and acceptance criteria.

## Build

Upload `Memora_0.9.39_GitHub.zip` to the GitHub repository root (keep it zipped). Place the companion `android-build.yml` in `.github/workflows/`, replacing the earlier version. The included `.github/workflows/android-build.yml` matches the companion file.

GitHub Actions runs static regression, Topilmalar checks, Billing backend tests, JVM tests, Android lint and debug APK assembly. Emulator Room migration test is optional via workflow dispatch.

**Status:** Static and pure Kotlin checks can run locally; Android build and actual device visual verification require GitHub/Android SDK and have not been performed by this package step.

## Earlier changes

0.9.38 U-01–U-06 design improvements are retained. See [`docs/RELEASE_0.9.38.md`](docs/RELEASE_0.9.38.md).
