# Memora 0.9.39 — GitHub'da APK yig'ish

## Telefon orqali, bitta ZIP bilan

1. `Memora_0.9.39_GitHub.zip` faylini GitHub repozitoriyingizning **asosiy (root) katalogi**ga yuklang. Uni ochish shart emas.
2. Birga berilgan `android-build.yml` faylini `.github/workflows/` papkasiga yuklang. Unda mavjud `main.yml` bo'lsa, iloji bo'lsa uning o'rniga shu yangi YAML mazmunini qo'ying; aks holda yangi `android-build.yml` nomli workflow sifatida qo'shing.
3. Agar eski `main.yml` va/yoki `memora-release.yml` ishlayotgan bo'lsa, ular eski kodni ishga tushirib alohida muvaffaqiyatsiz build berishi mumkin. **Actions > Memora 0.9.39 Android Build** ni tanlang. Takroriy eski workflow'larni keyinchalik o'chiring yoki o'chirib qo'ying.
4. Yangi buildda `Code and visual regression`, `Billing backend tests` va `Compile, unit tests, lint and APK` bosqichlari muvaffaqiyatli tugaganini tekshiring.
5. `Artifacts` bo'limidan `Memora-0.9.39-debug-apk` ni yuklab oling.

**Muhim:** GitHub'ga `android-build.yml` faylini repozitoriyning ildiziga emas, albatta `.github/workflows/` ga qo'ying. ZIP esa ildizda bo'lishi kerak. YAML'dagi ZIP nomi aynan `Memora_0.9.39_GitHub.zip`.

## O'rnatish va ma'lumotlar

Ilovani eski debug versiyasi ustiga yangilab o'rnating; uninstall yoki clear data qilmang. Birinchi sinovdan oldin zaxira nusxa oling. Bu debug APK faqat bir xil `.debug` application ID va imzo bilan oldingi test versiyasini yangilay oladi. Google Play release versiyasini debug APK bilan yangilab bo'lmaydi.

## Tekshiruv cheklovi

Android Gradle build va APK real telefonda sinovdan o'tkazilishi GitHub va qurilmada qoladi. Statik regressiya, Topilmalar dizayn tekshiruvlari, backend va arxiv qoidasi lokal o'tdi.
