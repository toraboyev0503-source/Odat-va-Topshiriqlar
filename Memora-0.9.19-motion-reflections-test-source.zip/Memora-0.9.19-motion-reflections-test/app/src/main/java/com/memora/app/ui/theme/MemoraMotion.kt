package com.memora.app.ui.theme

import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Easing

/**
 * Central motion tokens for Memora.
 *
 * Interactive motion is intentionally quick so taps feel immediate, while atmospheric
 * motion (Home reflection ceremony, Time Trace slideshow crossfade, branded splash) stays
 * calm. Keeping the timings here prevents individual screens from drifting apart.
 */
object MemoraMotion {
    const val Press = 100
    const val Fast = 140
    const val FastExit = 130
    const val Standard = 210
    const val StandardExit = 170
    const val Dialog = 160
    const val Snackbar = 170
    const val Ambient = 520

    // Quick response with a soft landing; no bounce/overshoot.
    val EmphasizedDecelerate: Easing = CubicBezierEasing(0.05f, 0.70f, 0.10f, 1.00f)
    val EmphasizedAccelerate: Easing = CubicBezierEasing(0.30f, 0.00f, 0.80f, 0.15f)
}
