# Memora 0.9.19 Motion/Content Test Build

Memora is a private, local-first Android journal for short and long notes. The
launcher and in-app name are **Memora**; the intended Google Play listing title
is **Memora – Private Journal**.

## Release configuration

- Android application ID: `com.memora.app`
- `versionName`: `0.9.19`; `versionCode`: `39`
- `compileSdk` / `targetSdk`: 36
- `minSdk`: 26 (Android 8.0+)
- Google Play Billing product: `memora_premium`
- Base plans: `monthly`, `quarterly`, `semiannual`, `annual`
- 1-month trial offer tag: `memora-free-trial`
- Paragraph gap: exactly 60% of line-height through `ParagraphMetrics.GAP_RATIO`
- Title presets: no built-in/system presets; the title list and picker contain only user-created saved titles


## 0.9.19 test scope

This build is an on-device motion/content test. Interactive navigation is intentionally faster while atmospheric motion stays calm. The Home reflection frame now has aligned audited content in all 13 supported app languages (`650` items per language). Run `python3 tools/validate_reflections.py` before a build to validate the asset pack.

## Privacy model

Notes, titles, images, audio, statistics and backup contents stay in the app's
private storage. Android cloud/device backup is disabled. The only app network
traffic is Google Play Billing and a purchase-verification HTTPS request containing
`packageName`, `productId` and the Google Play `purchaseToken`. There are no ads,
analytics or crash-tracking SDKs.

An active subscription permits create/edit/delete/import. Expiry switches Memora
to read-only: existing notes, search, statistics, media playback and HTML/Word/
Memora exports remain available. A successfully verified entitlement is cached,
encrypted by Android Keystore, for at most seven offline days and never beyond the
subscription expiry reported by Google Play.

## Build and test

Use JDK 17 and the official, checksum-pinned Gradle 8.13 wrapper:

```bash
./gradlew testDebugUnitTest
./gradlew lintRelease
```

Debug builds use Memora's bundled, test-only stable signing key and enable a debug-only
entitlement so UI development does not require a Play test purchase. This test key exists only so
GitHub debug APKs can update one another; Play Store release signing is separate and private.
Release builds never use the test key.

### Debug APK update chain

GitHub `assembleDebug` builds use the bundled test-only certificate with SHA-256
`77:2D:4A:04:10:F9:19:FD:0F:E2:77:DA:5E:DC:F4:92:10:25:DD:EC:3E:31:A0:71:D0:9A:79:DD:C8:17:FD:33`.
All debug APKs from 0.9.4 onward therefore share the same debug package ID and signing certificate.
An APK from 0.9.1–0.9.3 that was signed by GitHub's temporary default debug key may require one
final uninstall before 0.9.4 can be installed; after 0.9.4, later debug builds update in place.

A release bundle fails unless the following environment variables
are supplied:

- `MEMORA_KEYSTORE_PATH`
- `MEMORA_KEYSTORE_PASSWORD`
- `MEMORA_KEY_ALIAS`
- `MEMORA_KEY_PASSWORD`
- `MEMORA_BILLING_VERIFICATION_URL` (must be HTTPS)

No **production** signing key, password, service-account key or environment file belongs in Git. The bundled `memora-test-debug.jks` is intentionally non-production and exists only for debug update compatibility.
See `docs/PLAY_CONSOLE_SETUP.md`, `docs/PRODUCTION_AUDIT.md`, `docs/RELEASE_STEP2_SETUP.txt`, `docs/RELEASE_STEP3_PLAY_CONSOLE.txt`, `docs/STORE_LISTING_STEP3.md`, `docs/DATA_SAFETY_STEP3.md`, `docs/INTERNAL_TEST_MATRIX_STEP3.md`, and `backend/README.md`.
