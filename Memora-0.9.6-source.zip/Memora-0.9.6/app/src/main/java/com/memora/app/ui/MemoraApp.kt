package com.memora.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Surface
import androidx.compose.material3.rememberDrawerState
import androidx.compose.material3.DrawerValue
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.Density
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.memora.app.billing.EntitlementState
import com.memora.app.billing.SubscriptionPlan
import com.memora.app.data.local.NoteType
import com.memora.app.data.local.ReminderEntity
import com.memora.app.data.repository.MemoraRepository
import com.memora.app.export.ExportRequest
import com.memora.app.notifications.AlarmScheduler
import com.memora.app.prefs.ThemeMode
import com.memora.app.prefs.UserPreferences
import com.memora.app.prefs.UserSettings
import com.memora.app.ui.components.DrawerContent
import com.memora.app.ui.components.ExportDialog
import com.memora.app.ui.screens.EditorScreen
import com.memora.app.ui.screens.HomeScreen
import com.memora.app.ui.screens.LanguageScreen
import com.memora.app.ui.screens.NotesScreen
import com.memora.app.ui.screens.ReaderScreen
import com.memora.app.ui.screens.RemindersScreen
import com.memora.app.ui.screens.SearchScreen
import com.memora.app.ui.screens.SecurityScreen
import com.memora.app.ui.screens.StatisticsScreen
import com.memora.app.ui.screens.StatsSnapshot
import com.memora.app.ui.screens.SubscriptionScreen
import com.memora.app.ui.screens.ThemeScreen
import com.memora.app.ui.screens.TitlesScreen
import com.memora.app.util.TimeUtils
import kotlinx.coroutines.launch

private object Routes {
    const val HOME = "home"
    const val NOTES = "notes/{type}"
    const val EDITOR = "editor/{type}/{id}"
    const val READER = "reader/{id}"
    const val SEARCH = "search/{type}"
    const val TITLES = "titles"
    const val REMINDERS = "reminders"
    const val STATS = "statistics"
    const val LANGUAGE = "language"
    const val THEME = "theme"
    const val SECURITY = "security"
    const val SUBSCRIPTION = "subscription"

    fun notes(type: NoteType) = "notes/${type.name}"
    fun editor(type: NoteType, id: String?) = "editor/${type.name}/${id ?: "new"}"
    fun reader(id: String) = "reader/$id"
    fun search(type: NoteType) = "search/${type.name}"
}

@Composable
fun MemoraApp(
    repository: MemoraRepository,
    preferences: UserPreferences,
    settings: UserSettings,
    entitlement: EntitlementState,
    subscriptionPlans: List<SubscriptionPlan>,
    pendingEditorType: String?,
    onPendingEditorConsumed: () -> Unit,
    onExport: (ExportRequest) -> Unit,
    onImport: () -> Unit,
    onRequestNotifications: () -> Unit,
    onRequestExactTiming: () -> Unit,
    onPurchasePlan: (String) -> Unit,
    onRefreshSubscription: () -> Unit,
    onManageSubscription: () -> Unit
) {
    val navController = rememberNavController()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var showExportDialog by remember { mutableStateOf(false) }
    val backOne: () -> Unit = { navController.popBackStack() }

    fun openSingle(route: String) {
        navController.navigate(route) { launchSingleTop = true }
    }

    fun afterDrawerClosed(action: () -> Unit) {
        scope.launch {
            if (drawerState.isOpen) drawerState.close()
            action()
        }
    }

    val shortNotes by repository.observeNotes(NoteType.SHORT).collectAsStateWithLifecycle(emptyList())
    val longNotes by repository.observeNotes(NoteType.LONG).collectAsStateWithLifecycle(emptyList())
    val allNotes by repository.observeAllNotes().collectAsStateWithLifecycle(emptyList())
    val titles by repository.observeTitles().collectAsStateWithLifecycle(emptyList())
    val reminders by repository.observeReminders().collectAsStateWithLifecycle(emptyList())

    val allShort by repository.observeCount(NoteType.SHORT).collectAsStateWithLifecycle(0)
    val allLong by repository.observeCount(NoteType.LONG).collectAsStateWithLifecycle(0)

    val dayRange = remember { TimeUtils.currentDayRange() }
    val todayShort by repository.observeCountBetween(NoteType.SHORT, dayRange.start!!, dayRange.end!!)
        .collectAsStateWithLifecycle(0)
    val todayLong by repository.observeCountBetween(NoteType.LONG, dayRange.start!!, dayRange.end!!)
        .collectAsStateWithLifecycle(0)

    val monthRange = remember { TimeUtils.currentMonthRange() }
    val yearRange = remember { TimeUtils.currentYearRange() }
    val monthShort by repository.observeCountBetween(NoteType.SHORT, monthRange.start!!, monthRange.end!!)
        .collectAsStateWithLifecycle(0)
    val monthLong by repository.observeCountBetween(NoteType.LONG, monthRange.start!!, monthRange.end!!)
        .collectAsStateWithLifecycle(0)
    val yearShort by repository.observeCountBetween(NoteType.SHORT, yearRange.start!!, yearRange.end!!)
        .collectAsStateWithLifecycle(0)
    val yearLong by repository.observeCountBetween(NoteType.LONG, yearRange.start!!, yearRange.end!!)
        .collectAsStateWithLifecycle(0)

    val stats = StatsSnapshot(
        todayShort = todayShort,
        todayLong = todayLong,
        allShort = allShort,
        allLong = allLong,
        monthShort = monthShort,
        monthLong = monthLong,
        yearShort = yearShort,
        yearLong = yearLong
    )
    val isDark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val currentBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = currentBackStackEntry?.destination?.route

    // One central route-level Back handler prevents multiple screens from consuming the same press.
    // Nested screens (editor, note selection and calendar stages) register their own later handler and
    // therefore get the first chance to step back exactly one local level.
    BackHandler(enabled = drawerState.isOpen || currentRoute != Routes.HOME) {
        if (drawerState.isOpen) {
            scope.launch { drawerState.close() }
        } else {
            navController.popBackStack()
        }
    }

    LaunchedEffect(pendingEditorType, entitlement.canWrite) {
        val raw = pendingEditorType ?: return@LaunchedEffect
        val type = runCatching { NoteType.valueOf(raw) }.getOrNull() ?: return@LaunchedEffect
        val destination = if (entitlement.canWrite) Routes.editor(type, null) else Routes.SUBSCRIPTION
        navController.navigate(destination) {
            launchSingleTop = true
        }
        onPendingEditorConsumed()
    }

    val deviceDensity = LocalDensity.current
    val compactDensity = Density(
        density = deviceDensity.density * 0.80f * settings.uiScale,
        fontScale = deviceDensity.fontScale
    )

    CompositionLocalProvider(
        LocalDensity provides compactDensity,
        LocalLayoutDirection provides if (settings.language.rtl) LayoutDirection.Rtl else LayoutDirection.Ltr
    ) {
        ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = drawerState.isOpen,
        drawerContent = {
            DrawerContent(
                language = settings.language,
                isDark = isDark,
                onExport = {
                    afterDrawerClosed { showExportDialog = true }
                },
                onImport = {
                    afterDrawerClosed {
                        if (entitlement.canWrite) onImport()
                        else openSingle(Routes.SUBSCRIPTION)
                    }
                },
                onReminders = { afterDrawerClosed { openSingle(Routes.REMINDERS) } },
                onTitles = { afterDrawerClosed { openSingle(Routes.TITLES) } },
                onLanguage = { afterDrawerClosed { openSingle(Routes.LANGUAGE) } },
                onStatistics = { afterDrawerClosed { openSingle(Routes.STATS) } },
                onTheme = { afterDrawerClosed { openSingle(Routes.THEME) } },
                onSecurity = { afterDrawerClosed { openSingle(Routes.SECURITY) } },
                onSubscription = { afterDrawerClosed { openSingle(Routes.SUBSCRIPTION) } },
                onToggleDark = {
                    afterDrawerClosed {
                        scope.launch {
                            preferences.setThemeMode(if (isDark) ThemeMode.LIGHT else ThemeMode.DARK)
                        }
                    }
                }
            )
        }
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .windowInsetsPadding(WindowInsets.safeDrawing)
            ) {
                NavHost(
                    navController = navController,
                    startDestination = Routes.HOME,
                    modifier = Modifier.fillMaxSize()
                ) {
            composable(Routes.HOME) {
                HomeScreen(
                    language = settings.language,
                    shortCount = allShort,
                    longCount = allLong,
                    onMenu = { scope.launch { drawerState.open() } },
                    onShort = { openSingle(Routes.notes(NoteType.SHORT)) },
                    onLong = { openSingle(Routes.notes(NoteType.LONG)) }
                )
            }

            composable(
                route = Routes.NOTES,
                arguments = listOf(navArgument("type") { type = NavType.StringType })
            ) { entry ->
                val type = NoteType.valueOf(entry.arguments?.getString("type") ?: NoteType.SHORT.name)
                val notes = if (type == NoteType.SHORT) shortNotes else longNotes
                NotesScreen(
                    type = type,
                    notes = notes,
                    language = settings.language,
                    canWrite = entitlement.canWrite,
                    onBack = backOne,
                    onNew = { navController.navigate(Routes.editor(type, null)) },
                    onWriteRequired = { openSingle(Routes.SUBSCRIPTION) },
                    onOpen = { navController.navigate(Routes.reader(it)) },
                    onSearch = { navController.navigate(Routes.search(type)) },
                    onDelete = { ids ->
                        if (entitlement.canWrite) scope.launch { repository.deleteNotes(ids) }
                        else openSingle(Routes.SUBSCRIPTION)
                    }
                )
            }

            composable(
                route = Routes.EDITOR,
                arguments = listOf(
                    navArgument("type") { type = NavType.StringType },
                    navArgument("id") { type = NavType.StringType }
                )
            ) { entry ->
                if (!entitlement.canWrite) {
                    LaunchedEffect(Unit) {
                        navController.popBackStack()
                        navController.navigate(Routes.SUBSCRIPTION) { launchSingleTop = true }
                    }
                    return@composable
                }
                val type = NoteType.valueOf(entry.arguments?.getString("type") ?: NoteType.SHORT.name)
                val idArg = entry.arguments?.getString("id")
                val compact = LocalDensity.current
                CompositionLocalProvider(
                    LocalDensity provides Density(
                        density = compact.density * 1.125f,
                        fontScale = compact.fontScale
                    )
                ) {
                    EditorScreen(
                        noteId = idArg?.takeUnless { it == "new" },
                        type = type,
                        repository = repository,
                        savedTitles = titles,
                        language = settings.language,
                        writingFont = settings.writingFont,
                        uiScale = settings.uiScale,
                        onBack = backOne
                    )
                }
            }

            composable(
                route = Routes.READER,
                arguments = listOf(navArgument("id") { type = NavType.StringType })
            ) { entry ->
                val id = entry.arguments?.getString("id").orEmpty()
                val note by repository.observeNote(id).collectAsStateWithLifecycle(initialValue = null)
                ReaderScreen(
                    note = note,
                    language = settings.language,
                    writingFont = settings.writingFont,
                    canEdit = entitlement.canWrite,
                    onBack = backOne,
                    onEdit = {
                        note?.let {
                            navController.navigate(
                                Routes.editor(NoteType.valueOf(it.type), it.id)
                            )
                        }
                    },
                    onWriteRequired = { openSingle(Routes.SUBSCRIPTION) }
                )
            }

            composable(
                route = Routes.SEARCH,
                arguments = listOf(navArgument("type") { type = NavType.StringType })
            ) { entry ->
                val type = NoteType.valueOf(entry.arguments?.getString("type") ?: NoteType.SHORT.name)
                SearchScreen(
                    type = type,
                    notes = if (type == NoteType.SHORT) shortNotes else longNotes,
                    titles = titles,
                    language = settings.language,
                    onBack = backOne,
                    onOpen = { navController.navigate(Routes.reader(it)) }
                )
            }

            composable(Routes.TITLES) {
                TitlesScreen(
                    titles = titles,
                    language = settings.language,
                    onBack = backOne,
                    onAdd = { value -> scope.launch { repository.addTitle(value) } },
                    onDelete = { title -> scope.launch { repository.deleteTitle(title) } },
                    onEdit = { title, value, affect ->
                        if (affect && !entitlement.canWrite) {
                            openSingle(Routes.SUBSCRIPTION)
                        } else {
                            scope.launch { repository.renameTitle(title, value, affect) }
                        }
                    },
                    onPin = { title, pinned -> scope.launch { repository.setTitlePinned(title, pinned) } }
                )
            }

            composable(Routes.REMINDERS) {
                val context = androidx.compose.ui.platform.LocalContext.current
                RemindersScreen(
                    reminders = reminders,
                    language = settings.language,
                    exactTimingAvailable = AlarmScheduler(context).canScheduleExact(),
                    onBack = backOne,
                    onRequestNotifications = onRequestNotifications,
                    onRequestExactTiming = onRequestExactTiming,
                    onAdd = { hour, minute ->
                        scope.launch {
                            val id = repository.addReminder(hour, minute)
                            if (id != -1L) {
                                AlarmScheduler(context).scheduleReminder(
                                    ReminderEntity(id = id, hour = hour, minute = minute, enabled = true)
                                )
                            }
                        }
                    },
                    onToggle = { reminder, enabled ->
                        scope.launch {
                            val changed = reminder.copy(enabled = enabled)
                            repository.updateReminder(changed)
                            if (enabled) AlarmScheduler(context).scheduleReminder(changed)
                            else AlarmScheduler(context).cancelReminder(changed.id)
                        }
                    },
                    onDelete = { reminder ->
                        scope.launch {
                            AlarmScheduler(context).cancelReminder(reminder.id)
                            repository.deleteReminder(reminder)
                        }
                    }
                )
            }

            composable(Routes.STATS) {
                StatisticsScreen(
                    stats = stats,
                    allNotes = allNotes,
                    language = settings.language,
                    onBack = backOne,
                    onOpenNote = { navController.navigate(Routes.reader(it)) }
                )
            }

            composable(Routes.LANGUAGE) {
                LanguageScreen(
                    current = settings.language,
                    onBack = backOne,
                    onSelect = { scope.launch { preferences.setLanguage(it) } }
                )
            }

            composable(Routes.THEME) {
                ThemeScreen(
                    settings = settings,
                    onBack = backOne,
                    onPalette = { scope.launch { preferences.setPalette(it) } },
                    onUiFont = { scope.launch { preferences.setUiFont(it) } },
                    onWritingFont = { scope.launch { preferences.setWritingFont(it) } },
                    onUiScale = { scope.launch { preferences.setUiScale(it) } }
                )
            }

                composable(Routes.SUBSCRIPTION) {
                        SubscriptionScreen(
                        language = settings.language,
                        entitlement = entitlement,
                        plans = subscriptionPlans,
                        onBack = backOne,
                        onSubscribe = onPurchasePlan,
                        onRestore = onRefreshSubscription,
                        onManage = onManageSubscription
                    )
                }

                composable(Routes.SECURITY) {
                        SecurityScreen(
                        settings = settings,
                        onBack = backOne,
                        onEnabled = { scope.launch { preferences.setLockEnabled(it) } },
                        onInterval = { scope.launch { preferences.setLockInterval(it) } }
                    )
                }
                }
            }
        }
        }

        if (showExportDialog) {
            ExportDialog(
                language = settings.language,
                onDismiss = { showExportDialog = false },
                onExport = {
                    showExportDialog = false
                    onExport(it)
                }
            )
        }
    }
}
