package com.memora.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memora.app.i18n.L
import com.memora.app.i18n.S
import com.memora.app.prefs.AppLanguage

private val TiniqSage = Color(0xFF789786)
private val TiniqLavender = Color(0xFFE9E1F2)
private val TiniqMist = Color(0xFFDDEAF1)
private val TiniqInk = Color(0xFF202923)
private val TiniqMuted = Color(0xFF6F7973)

@Composable
fun HomeScreen(
    language: AppLanguage,
    shortCount: Int,
    longCount: Int,
    isDark: Boolean,
    onToggleDark: () -> Unit,
    onShort: () -> Unit,
    onLong: () -> Unit
) {
    val scroll = rememberScrollState()
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scroll)
                .padding(bottom = 96.dp)
        ) {
            HomeHeader(
                language = language,
                isDark = isDark,
                onToggleDark = onToggleDark
            )

            Column(Modifier.padding(horizontal = 24.dp)) {
                HomeNoteTypeCard(
                    title = L.t(language, S.SHORT_NOTES),
                    count = shortCount,
                    language = language,
                    icon = {
                        Icon(
                            Icons.Rounded.Description,
                            contentDescription = null,
                            tint = TiniqSage,
                            modifier = Modifier.size(32.dp)
                        )
                    },
                    tint = TiniqMist,
                    onClick = onShort
                )
                Spacer(Modifier.height(16.dp))
                HomeNoteTypeCard(
                    title = L.t(language, S.LONG_NOTES),
                    count = longCount,
                    language = language,
                    icon = {
                        Icon(
                            Icons.Rounded.MenuBook,
                            contentDescription = null,
                            tint = Color(0xFF7777A8),
                            modifier = Modifier.size(32.dp)
                        )
                    },
                    tint = TiniqLavender,
                    onClick = onLong
                )
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun HomeHeader(
    language: AppLanguage,
    isDark: Boolean,
    onToggleDark: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 28.dp, end = 28.dp, top = 28.dp, bottom = 22.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                "Memora",
                style = MaterialTheme.typography.displayMedium.copy(fontSize = 44.sp),
                fontWeight = FontWeight.SemiBold,
                color = if (isDark) MaterialTheme.colorScheme.onBackground else TiniqInk
            )
            Text(
                L.t(language, S.HOME_TAGLINE),
                style = MaterialTheme.typography.bodyLarge.copy(fontSize = 18.sp),
                color = if (isDark) MaterialTheme.colorScheme.onSurfaceVariant else TiniqMuted,
                modifier = Modifier.padding(top = 1.dp)
            )
        }

        Surface(
            shape = CircleShape,
            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.88f),
            shadowElevation = 2.dp
        ) {
            IconButton(onClick = onToggleDark, modifier = Modifier.size(52.dp)) {
                Icon(
                    if (isDark) Icons.Rounded.DarkMode else Icons.Rounded.LightMode,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

@Composable
private fun HomeNoteTypeCard(
    title: String,
    count: Int,
    language: AppLanguage,
    icon: @Composable () -> Unit,
    tint: Color,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(26.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.985f),
        shadowElevation = 1.dp
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 21.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = tint.copy(alpha = 0.66f),
                modifier = Modifier.size(68.dp)
            ) {
                Box(contentAlignment = Alignment.Center) { icon() }
            }
            Column(Modifier.weight(1f).padding(start = 20.dp)) {
                Text(
                    title,
                    style = MaterialTheme.typography.headlineSmall.copy(fontSize = 26.sp),
                    fontWeight = FontWeight.Medium
                )
                Text(
                    "$count ${L.t(language, S.NOTES)}",
                    style = MaterialTheme.typography.bodyLarge.copy(fontSize = 17.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 3.dp)
                )
            }
            Icon(
                Icons.Rounded.ArrowForward,
                contentDescription = null,
                modifier = Modifier.size(27.dp)
            )
        }
    }
}
