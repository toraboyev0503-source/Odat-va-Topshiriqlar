package com.memora.app.ui.components

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.memora.app.data.local.NoteEntity
import com.memora.app.i18n.L
import com.memora.app.i18n.S
import com.memora.app.media.MediaStorage
import com.memora.app.prefs.AppLanguage
import com.memora.app.util.TextUtils
import com.memora.app.util.TimeUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.File
import java.util.Locale
import kotlin.math.max

private data class NoteCardMedia(
    val imagePaths: List<String>,
    val imageCount: Int,
    val audioCount: Int
)

/**
 * List cards only need tiny thumbnails. Keep this cache intentionally small so opening the editor
 * never competes with a long scrolling session for tens of megabytes of bitmap memory.
 */
private object NoteListThumbnailCache {
    private const val MAX_CACHE_KB = 3 * 1024
    private const val TARGET_SIDE_PX = 128
    private val decodeGate = Semaphore(2)

    private val cache = object : LruCache<String, Bitmap>(MAX_CACHE_KB) {
        override fun sizeOf(key: String, value: Bitmap): Int =
            (value.byteCount / 1024).coerceAtLeast(1)
    }

    @Synchronized
    fun peek(key: String): Bitmap? = cache.get(key)

    suspend fun load(key: String, file: File): Bitmap? {
        peek(key)?.let { return it }
        return decodeGate.withPermit {
            peek(key)?.let { return@withPermit it }
            val decoded = decodeThumbnail(file, TARGET_SIDE_PX) ?: return@withPermit null
            synchronized(this) { cache.put(key, decoded) }
            decoded
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun NoteCard(
    note: NoteEntity,
    displayTitle: String,
    language: AppLanguage,
    selected: Boolean,
    previewLines: Int = 2,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onDeleteRequest: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val storage = remember(context) { MediaStorage(context.applicationContext) }
    val media = remember(note.blocksJson, note.hasImages, note.hasAudio) {
        parseMediaSummary(note.blocksJson, note.hasImages, note.hasAudio)
    }
    val imageFiles = remember(media.imagePaths, storage) {
        media.imagePaths.mapNotNull { relativePath ->
            runCatching { storage.resolve(relativePath) }.getOrNull()?.takeIf { it.isFile }
        }
    }
    val accent = remember(displayTitle) { titleAccentColor(displayTitle) }
    var menuExpanded by remember { mutableStateOf(false) }
    val cardShape = RoundedCornerShape(22.dp)
    val showMediaColumn = imageFiles.isNotEmpty() || media.imageCount > 0

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .combinedClickable(onClick = onClick, onLongClick = onLongClick),
        shape = cardShape,
        color = if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.10f)
        else MaterialTheme.colorScheme.surface,
        border = if (selected) BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)) else null,
        shadowElevation = if (selected) 1.dp else 0.35.dp,
        tonalElevation = 0.dp
    ) {
        Box(Modifier.fillMaxWidth()) {
            Box(Modifier.matchParentSize()) {
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterStart)
                        .width(5.dp)
                        .fillMaxHeight()
                        .background(accent)
                )
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 20.dp, end = 44.dp, top = 14.dp, bottom = 13.dp),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        text = displayTitle,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = TimeUtils.dateTime(note.createdAt, language),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(top = 2.dp)
                    )

                    if (note.plainText.isNotBlank()) {
                        Text(
                            text = TextUtils.preview(note.plainText),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = previewLines.coerceAtLeast(1),
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }

                    // With no image strip, keep the audio indicator compact and let text use the
                    // full card width. When images exist, media metadata belongs under thumbnails.
                    if (!showMediaColumn && media.audioCount > 0) {
                        Row(modifier = Modifier.padding(top = 8.dp)) {
                            AudioCountBadge(media.audioCount)
                        }
                    }
                }

                if (showMediaColumn) {
                    MediaSideColumn(
                        files = imageFiles,
                        imageCount = media.imageCount,
                        audioCount = media.audioCount,
                        modifier = Modifier.width(148.dp)
                    )
                }
            }

            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 6.dp, end = 4.dp)
            ) {
                IconButton(
                    onClick = { menuExpanded = true },
                    modifier = Modifier.size(34.dp)
                ) {
                    Icon(
                        Icons.Rounded.MoreVert,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                DropdownMenu(
                    expanded = menuExpanded,
                    onDismissRequest = { menuExpanded = false }
                ) {
                    DropdownMenuItem(
                        text = { Text(L.t(language, S.DELETE)) },
                        leadingIcon = {
                            Icon(Icons.Rounded.DeleteOutline, contentDescription = null)
                        },
                        onClick = {
                            menuExpanded = false
                            onDeleteRequest()
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun MediaSideColumn(
    files: List<File>,
    imageCount: Int,
    audioCount: Int,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.End
    ) {
        if (files.isNotEmpty()) {
            MediaPreviewStrip(
                files = files,
                totalCount = imageCount,
                width = 148.dp
            )
        } else {
            Spacer(Modifier.height(4.dp))
        }

        if (imageCount > 0 || audioCount > 0) {
            Row(
                modifier = Modifier
                    .padding(top = if (files.isNotEmpty()) 7.dp else 0.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (audioCount > 0) {
                    AudioCountBadge(audioCount)
                }
                if (imageCount > 0) {
                    ImageCountIndicator(imageCount)
                }
            }
        }
    }
}

@Composable
private fun AudioCountBadge(count: Int) {
    Surface(
        shape = RoundedCornerShape(50),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.62f)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Icon(
                Icons.Rounded.Mic,
                contentDescription = null,
                modifier = Modifier.size(17.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = count.toString(),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun ImageCountIndicator(count: Int) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Icon(
            Icons.Rounded.Image,
            contentDescription = null,
            modifier = Modifier.size(18.dp),
            tint = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = count.toString(),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun MediaPreviewStrip(
    files: List<File>,
    totalCount: Int,
    width: Dp
) {
    val shown = files.take(4)
    val gap = 3.dp
    val cellWidth = when (shown.size) {
        1 -> 62.dp
        2 -> 58.dp
        3 -> 47.dp
        else -> 35.dp
    }
    val cellHeight = 54.dp

    Row(
        modifier = Modifier.width(width),
        horizontalArrangement = Arrangement.spacedBy(gap, Alignment.End),
        verticalAlignment = Alignment.CenterVertically
    ) {
        shown.forEachIndexed { index, file ->
            Box(
                modifier = Modifier
                    .width(cellWidth)
                    .height(cellHeight)
                    .clip(RoundedCornerShape(9.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.30f))
            ) {
                ThumbnailCell(file, Modifier.fillMaxSize())
                if (index == 3 && totalCount > 4) {
                    Box(
                        Modifier
                            .fillMaxSize()
                            .background(Color(0x990E1720)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "+${totalCount - 4}",
                            color = Color.White,
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ThumbnailCell(
    file: File,
    modifier: Modifier = Modifier
) {
    val key = remember(file.absolutePath, file.lastModified(), file.length()) {
        "${file.absolutePath}:${file.lastModified()}:${file.length()}"
    }
    val bitmap by produceState<Bitmap?>(
        initialValue = NoteListThumbnailCache.peek(key),
        key1 = key
    ) {
        if (value == null) {
            value = withContext(Dispatchers.IO) {
                NoteListThumbnailCache.load(key, file)
            }
        }
    }

    Box(
        modifier = modifier.background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)),
        contentAlignment = Alignment.Center
    ) {
        bitmap?.let { loaded ->
            Image(
                bitmap = loaded.asImageBitmap(),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        }
    }
}

private fun parseMediaSummary(
    blocksJson: String,
    legacyHasImages: Boolean,
    legacyHasAudio: Boolean
): NoteCardMedia {
    if (blocksJson.isBlank()) {
        return NoteCardMedia(
            imagePaths = emptyList(),
            imageCount = if (legacyHasImages) 1 else 0,
            audioCount = if (legacyHasAudio) 1 else 0
        )
    }

    return runCatching {
        val array = JSONArray(blocksJson)
        val imagePaths = ArrayList<String>(4)
        var imageCount = 0
        var audioCount = 0
        for (index in 0 until array.length()) {
            val obj = array.optJSONObject(index) ?: continue
            when (obj.optString("type")) {
                "image" -> {
                    imageCount += 1
                    if (imagePaths.size < 4) {
                        obj.optString("path")
                            .takeIf { it.isNotBlank() }
                            ?.let(imagePaths::add)
                    }
                }
                "audio" -> audioCount += 1
            }
        }
        NoteCardMedia(
            imagePaths = imagePaths,
            imageCount = max(imageCount, if (legacyHasImages) 1 else 0),
            audioCount = max(audioCount, if (legacyHasAudio) 1 else 0)
        )
    }.getOrElse {
        NoteCardMedia(
            imagePaths = emptyList(),
            imageCount = if (legacyHasImages) 1 else 0,
            audioCount = if (legacyHasAudio) 1 else 0
        )
    }
}

private fun decodeThumbnail(file: File, targetSide: Int): Bitmap? = runCatching {
    if (!file.exists() || file.length() <= 0L) return@runCatching null
    val bounds = BitmapFactory.Options().also { options ->
        options.inJustDecodeBounds = true
        BitmapFactory.decodeFile(file.absolutePath, options)
    }
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return@runCatching null

    var sample = 1
    val maxSide = max(bounds.outWidth, bounds.outHeight)
    while (maxSide / sample > targetSide && sample <= Int.MAX_VALUE / 2) {
        sample *= 2
    }

    BitmapFactory.decodeFile(
        file.absolutePath,
        BitmapFactory.Options().apply {
            inSampleSize = sample.coerceAtLeast(1)
            inPreferredConfig = Bitmap.Config.RGB_565
            inDither = true
            inScaled = false
        }
    )
}.getOrNull()

private fun titleAccentColor(title: String): Color {
    val normalized = title
        .lowercase(Locale.ROOT)
        .replace('’', '\'')
        .trim()

    return when (normalized) {
        "kunim haqida" -> Color(0xFF4C9CF2)
        "o'zim haqimda" -> Color(0xFFF4AE2B)
        "kun savoli" -> Color(0xFF38CFA3)
        "kichik tikishlar" -> Color(0xFF8D68EB)
        else -> {
            val palette = listOf(
                Color(0xFF4C9CF2),
                Color(0xFFF4AE2B),
                Color(0xFF38CFA3),
                Color(0xFF8D68EB),
                Color(0xFFEF6680),
                Color(0xFF20BFC5),
                Color(0xFF7FA85B),
                Color(0xFFDA7B61)
            )
            palette[Math.floorMod(normalized.hashCode(), palette.size)]
        }
    }
}
