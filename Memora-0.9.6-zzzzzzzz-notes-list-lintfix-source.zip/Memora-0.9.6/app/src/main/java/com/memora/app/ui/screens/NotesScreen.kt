package com.memora.app.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.memora.app.data.local.NoteEntity
import com.memora.app.data.local.NoteType
import com.memora.app.i18n.L
import com.memora.app.i18n.S
import com.memora.app.prefs.AppLanguage
import com.memora.app.ui.components.MemoraTopBar
import com.memora.app.ui.components.NoteCard
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter

@Composable
fun NotesScreen(
    type: NoteType,
    notes: List<NoteEntity>,
    language: AppLanguage,
    canWrite: Boolean,
    onBack: () -> Unit,
    onNew: () -> Unit,
    onWriteRequired: () -> Unit,
    onOpen: (String) -> Unit,
    onSearch: () -> Unit,
    onDelete: (List<String>) -> Unit
) {
    var selected by remember { mutableStateOf(setOf<String>()) }
    var confirmDelete by remember { mutableStateOf(false) }

    val zone = remember { ZoneId.systemDefault() }
    val groupedNotes = remember(notes, zone) {
        notes.groupBy { note ->
            Instant.ofEpochMilli(note.createdAt).atZone(zone).toLocalDate()
        }
    }

    BackHandler {
        when {
            confirmDelete -> confirmDelete = false
            selected.isNotEmpty() -> selected = emptySet()
            else -> onBack()
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(Modifier.fillMaxSize()) {
            if (selected.isEmpty()) {
                MemoraTopBar(
                    title = L.t(language, if (type == NoteType.SHORT) S.SHORT_NOTES else S.LONG_NOTES),
                    navigation = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.Rounded.ArrowBack, contentDescription = null)
                        }
                    },
                    actions = {
                        IconButton(onClick = onSearch) {
                            Icon(Icons.Rounded.Search, contentDescription = L.t(language, S.SEARCH))
                        }
                    }
                )
            } else {
                MemoraTopBar(
                    title = selected.size.toString(),
                    navigation = {
                        IconButton(onClick = { selected = emptySet() }) {
                            Icon(Icons.Rounded.Close, contentDescription = null)
                        }
                    },
                    actions = {
                        IconButton(onClick = { if (canWrite) confirmDelete = true else onWriteRequired() }) {
                            Icon(
                                Icons.Rounded.DeleteOutline,
                                contentDescription = L.t(language, S.DELETE),
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                )
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(
                    start = 18.dp,
                    end = 18.dp,
                    top = 8.dp,
                    bottom = 34.dp
                )
            ) {
                item("new") {
                    NewNoteBanner(
                        text = L.t(language, S.NEW_NOTE),
                        onClick = { if (canWrite) onNew() else onWriteRequired() }
                    )
                    Spacer(Modifier.height(18.dp))
                }

                if (notes.isEmpty()) {
                    item("empty") {
                        Text(
                            L.t(language, S.NO_NOTES),
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 18.dp)
                        )
                    }
                }

                groupedNotes.entries.forEachIndexed { groupIndex, (date, dayNotes) ->
                    item("day-$date") {
                        if (groupIndex > 0) Spacer(Modifier.height(22.dp))
                        DayGroupHeader(
                            date = date,
                            count = dayNotes.size,
                            language = language
                        )
                        Spacer(Modifier.height(10.dp))
                    }

                    items(dayNotes, key = { it.id }) { note ->
                        val isSelected = note.id in selected
                        NoteCard(
                            note = note,
                            displayTitle = note.title.ifBlank { L.t(language, S.UNTITLED) },
                            language = language,
                            selected = isSelected,
                            previewLines = if (type == NoteType.SHORT) 2 else 3,
                            onClick = {
                                if (selected.isNotEmpty()) {
                                    selected = if (isSelected) selected - note.id else selected + note.id
                                } else {
                                    onOpen(note.id)
                                }
                            },
                            onLongClick = if (canWrite) ({
                                selected = if (isSelected) selected - note.id else selected + note.id
                            }) else ({ onWriteRequired() }),
                            onDeleteRequest = {
                                if (canWrite) {
                                    selected = setOf(note.id)
                                    confirmDelete = true
                                } else {
                                    onWriteRequired()
                                }
                            }
                        )
                        Spacer(Modifier.height(12.dp))
                    }
                }
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(L.t(language, S.DELETE_CONFIRM_TITLE)) },
            text = { Text(L.t(language, S.DELETE_CONFIRM_TEXT)) },
            confirmButton = {
                TextButton(onClick = {
                    onDelete(selected.toList())
                    selected = emptySet()
                    confirmDelete = false
                }) { Text(L.t(language, S.CONFIRM)) }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) {
                    Text(L.t(language, S.CANCEL))
                }
            }
        )
    }
}

@Composable
private fun NewNoteBanner(
    text: String,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(26.dp)
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(
                Brush.horizontalGradient(
                    colors = listOf(
                        MaterialTheme.colorScheme.primary.copy(alpha = 0.10f),
                        MaterialTheme.colorScheme.primary.copy(alpha = 0.04f)
                    )
                )
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Surface(
                modifier = Modifier.size(54.dp),
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primary
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        Icons.Rounded.Add,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.size(30.dp)
                    )
                }
            }
            Text(
                text = text,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
private fun DayGroupHeader(
    date: LocalDate,
    count: Int,
    language: AppLanguage
) {
    val formatter = remember(language) {
        DateTimeFormatter.ofPattern("d-MMM, yyyy", java.util.Locale.forLanguageTag(language.tag))
    }
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = date.format(formatter),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Text(
            text = noteCountText(count, language),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

private fun noteCountText(count: Int, language: AppLanguage): String = when (language) {
    AppLanguage.UZ -> "$count ta ${L.t(language, S.NOTES)}"
    else -> "$count ${L.t(language, S.NOTES)}"
}
