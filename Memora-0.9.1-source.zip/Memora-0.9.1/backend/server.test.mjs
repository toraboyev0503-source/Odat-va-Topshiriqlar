import assert from "node:assert/strict";
import test from "node:test";
import { evaluateSubscription } from "./server.mjs";

const NOW = Date.parse("2026-09-03T12:00:00Z");

function purchase(state, expiryTime, productId = "memora_premium") {
  return {
    subscriptionState: state,
    lineItems: [{ productId, expiryTime, offerDetails: { basePlanId: "monthly" } }],
  };
}

test("active and grace subscriptions remain entitled before expiry", () => {
  for (const state of ["SUBSCRIPTION_STATE_ACTIVE", "SUBSCRIPTION_STATE_IN_GRACE_PERIOD"]) {
    const result = evaluateSubscription(purchase(state, "2026-10-03T12:00:00Z"), NOW);
    assert.equal(result.active, true);
    assert.equal(result.basePlanId, "monthly");
  }
});

test("canceled subscription remains entitled only until its expiry", () => {
  assert.equal(
    evaluateSubscription(purchase("SUBSCRIPTION_STATE_CANCELED", "2026-10-03T12:00:00Z"), NOW).active,
    true,
  );
  assert.equal(
    evaluateSubscription(purchase("SUBSCRIPTION_STATE_CANCELED", "2026-08-03T12:00:00Z"), NOW).active,
    false,
  );
});

test("wrong products, pending, on-hold and expired purchases are read-only", () => {
  assert.equal(
    evaluateSubscription(purchase("SUBSCRIPTION_STATE_ACTIVE", "2026-10-03T12:00:00Z", "other"), NOW).active,
    false,
  );
  for (const state of [
    "SUBSCRIPTION_STATE_PENDING",
    "SUBSCRIPTION_STATE_ON_HOLD",
    "SUBSCRIPTION_STATE_EXPIRED",
  ]) {
    assert.equal(evaluateSubscription(purchase(state, "2026-10-03T12:00:00Z"), NOW).active, false);
  }
});
