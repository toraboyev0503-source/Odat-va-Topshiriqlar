# Memora billing verifier

This minimal Cloud Run service verifies only Google Play purchase tokens for
`com.memora.app` / `memora_premium`. It does not accept note text, titles, images,
audio, backups, device identifiers or analytics events, and it does not persist
request data.

## Endpoint

`POST /v1/google-play/subscriptions/verify`

Request fields: `packageName`, `productId`, `purchaseToken`.

Response fields: `active`, `expiryTimeMillis`, `serverTimeMillis`, `basePlanId`,
`state`.

The app sends the purchase token only after Google Play reports a completed
purchase. The service fetches a short-lived OAuth token from the Cloud Run
metadata server, then calls Android Publisher API v3
`purchases.subscriptionsv2.get`. No service-account JSON file is needed or
permitted in this repository.

## Deploy

1. Enable Cloud Run and Google Play Android Developer API in one Google Cloud project.
2. Create a dedicated runtime service account without a downloaded key.
3. Link that Cloud project/service account in Play Console and grant only the app-level permission needed to view financial/subscription order data.
4. Deploy this directory to Cloud Run with that service account attached and require HTTPS.
5. Put the final endpoint (ending in `/v1/google-play/subscriptions/verify`) in the GitHub repository variable `MEMORA_BILLING_VERIFICATION_URL`.

Run the dependency-free tests with `npm test` on Node.js 22 or newer.
