import http from "node:http";
import { pathToFileURL } from "node:url";

const PACKAGE_NAME = "com.memora.app";
const PRODUCT_ID = "memora_premium";
const ANDROID_PUBLISHER_SCOPE = "https://www.googleapis.com/auth/androidpublisher";
const METADATA_TOKEN_URL =
  "http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token";
const MAX_REQUEST_BYTES = 16 * 1024;

let cachedAccessToken;

function json(response, status, body) {
  response.writeHead(status, {
    "content-type": "application/json; charset=utf-8",
    "cache-control": "no-store",
    "x-content-type-options": "nosniff",
  });
  response.end(JSON.stringify(body));
}

async function readJson(request) {
  const chunks = [];
  let total = 0;
  for await (const chunk of request) {
    total += chunk.length;
    if (total > MAX_REQUEST_BYTES) throw new RequestError(413, "request_too_large");
    chunks.push(chunk);
  }
  try {
    return JSON.parse(Buffer.concat(chunks).toString("utf8"));
  } catch {
    throw new RequestError(400, "invalid_json");
  }
}

class RequestError extends Error {
  constructor(status, code) {
    super(code);
    this.status = status;
    this.code = code;
  }
}

async function getAccessToken(fetchImpl = fetch) {
  const now = Date.now();
  if (cachedAccessToken?.expiresAt > now + 60_000) return cachedAccessToken.value;

  const tokenUrl = `${METADATA_TOKEN_URL}?scopes=${encodeURIComponent(ANDROID_PUBLISHER_SCOPE)}`;
  const result = await fetchImpl(tokenUrl, {
    headers: { "Metadata-Flavor": "Google" },
    signal: AbortSignal.timeout(8_000),
  });
  if (!result.ok) throw new Error(`metadata_token_${result.status}`);
  const token = await result.json();
  if (!token.access_token || !token.expires_in) throw new Error("metadata_token_invalid");
  cachedAccessToken = {
    value: token.access_token,
    expiresAt: now + Number(token.expires_in) * 1000,
  };
  return cachedAccessToken.value;
}

export function evaluateSubscription(playPurchase, now = Date.now()) {
  const state = String(playPurchase?.subscriptionState ?? "SUBSCRIPTION_STATE_UNSPECIFIED");
  const matchingItems = (playPurchase?.lineItems ?? []).filter(
    (item) => item?.productId === PRODUCT_ID,
  );
  const expiryTimeMillis = matchingItems.reduce((latest, item) => {
    const parsed = Date.parse(item?.expiryTime ?? "");
    return Number.isFinite(parsed) ? Math.max(latest, parsed) : latest;
  }, 0);
  const entitledState = new Set([
    "SUBSCRIPTION_STATE_ACTIVE",
    "SUBSCRIPTION_STATE_IN_GRACE_PERIOD",
    "SUBSCRIPTION_STATE_CANCELED",
  ]).has(state);
  const active = entitledState && expiryTimeMillis > now && matchingItems.length > 0;
  const newestItem = matchingItems.reduce(
    (latest, item) => {
      if (!latest) return item;
      return Date.parse(item?.expiryTime ?? "") > Date.parse(latest?.expiryTime ?? "") ? item : latest;
    },
    undefined,
  );

  return {
    active,
    expiryTimeMillis,
    serverTimeMillis: now,
    basePlanId: newestItem?.offerDetails?.basePlanId ?? null,
    state,
  };
}

async function verifyWithGooglePlay(purchaseToken, fetchImpl = fetch) {
  const accessToken = await getAccessToken(fetchImpl);
  const url =
    `https://androidpublisher.googleapis.com/androidpublisher/v3/applications/${PACKAGE_NAME}` +
    `/purchases/subscriptionsv2/tokens/${encodeURIComponent(purchaseToken)}`;
  const result = await fetchImpl(url, {
    headers: {
      accept: "application/json",
      authorization: `Bearer ${accessToken}`,
    },
    signal: AbortSignal.timeout(10_000),
  });
  if (result.status === 404 || result.status === 410) return null;
  if (!result.ok) throw new Error(`android_publisher_${result.status}`);
  return result.json();
}

export function createHandler({ verify = verifyWithGooglePlay, now = Date.now } = {}) {
  return async (request, response) => {
    if (request.method === "GET" && request.url === "/healthz") {
      return json(response, 200, { ok: true });
    }
    if (request.method !== "POST" || request.url !== "/v1/google-play/subscriptions/verify") {
      return json(response, 404, { error: "not_found" });
    }

    try {
      const body = await readJson(request);
      if (body?.packageName !== PACKAGE_NAME || body?.productId !== PRODUCT_ID) {
        throw new RequestError(400, "invalid_product");
      }
      if (
        typeof body.purchaseToken !== "string" ||
        body.purchaseToken.length < 16 ||
        body.purchaseToken.length > 4096 ||
        /\s/.test(body.purchaseToken)
      ) {
        throw new RequestError(400, "invalid_purchase_token");
      }

      const purchase = await verify(body.purchaseToken);
      const serverNow = now();
      return json(
        response,
        200,
        purchase
          ? evaluateSubscription(purchase, serverNow)
          : {
              active: false,
              expiryTimeMillis: 0,
              serverTimeMillis: serverNow,
              basePlanId: null,
              state: "NOT_FOUND",
            },
      );
    } catch (error) {
      if (error instanceof RequestError) return json(response, error.status, { error: error.code });
      // Never log purchase tokens or request bodies. Platform error metrics are sufficient here.
      console.error("billing_verification_failed", error instanceof Error ? error.message : "unknown");
      return json(response, 503, { error: "verification_unavailable" });
    }
  };
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const port = Number(process.env.PORT || 8080);
  http.createServer(createHandler()).listen(port, "0.0.0.0", () => {
    console.log(`Memora billing verifier listening on ${port}`);
  });
}
