# Memora uses standard AndroidX/Compose/Room APIs.
# Keep rules can be added here if future releases introduce reflection-based libraries.
