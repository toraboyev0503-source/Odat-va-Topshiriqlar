package com.memora.app.prefs

import android.content.Context
import android.os.LocaleList
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.io.IOException
import java.util.Locale

private val Context.memoraDataStore by preferencesDataStore("memora_preferences")

enum class AppLanguage(val tag: String, val displayName: String, val rtl: Boolean = false) {
    AR("ar", "العربية", true),
    EN("en", "English"),
    FR("fr", "Français"),
    DE("de", "Deutsch"),
    HI("hi", "हिन्दी"),
    ID("id", "Bahasa Indonesia"),
    JA("ja", "日本語"),
    KO("ko", "한국어"),
    PT_BR("pt-BR", "Português (Brasil)"),
    RU("ru", "Русский"),
    ES("es", "Español"),
    TR("tr", "Türkçe"),
    UZ("uz", "O‘zbekcha");

    companion object {
        fun deviceDefault(): AppLanguage {
            val locales = LocaleList.getDefault()
            return fromLanguageTags((0 until locales.size()).map { locales[it].toLanguageTag() })
        }

        fun fromLanguageTags(tags: List<String>): AppLanguage {
            tags.forEach { tag ->
                val locale = Locale.forLanguageTag(tag)
                if (locale.language.equals("pt", ignoreCase = true) &&
                    locale.country.equals("BR", ignoreCase = true)
                ) return PT_BR
                entries.firstOrNull {
                    Locale.forLanguageTag(it.tag).language.equals(locale.language, ignoreCase = true)
                }?.let { return it }
            }
            return EN
        }
    }
}

enum class ThemeMode { LIGHT, DARK, SYSTEM }
enum class PaletteChoice { PAPER, IVORY, MIST, SAGE, SLATE }
enum class FontChoice { SANS, SERIF, MONO, CURSIVE }
enum class LockInterval { IMMEDIATELY, ONE_MINUTE, FIVE_MINUTES, FIFTEEN_MINUTES, THIRTY_MINUTES }

data class UserSettings(
    val language: AppLanguage = AppLanguage.EN,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val palette: PaletteChoice = PaletteChoice.PAPER,
    val uiFont: FontChoice = FontChoice.SANS,
    val writingFont: FontChoice = FontChoice.SERIF,
    val uiScale: Float = 1.0f,
    val lockEnabled: Boolean = true,
    val lockInterval: LockInterval = LockInterval.IMMEDIATELY
)

class UserPreferences(private val context: Context) {
    private object Keys {
        val language = stringPreferencesKey("language")
        val themeMode = stringPreferencesKey("theme_mode")
        val palette = stringPreferencesKey("palette")
        val uiFont = stringPreferencesKey("ui_font")
        val writingFont = stringPreferencesKey("writing_font")
        val uiScale = floatPreferencesKey("ui_scale")
        val lockEnabled = booleanPreferencesKey("lock_enabled")
        val lockInterval = stringPreferencesKey("lock_interval")
    }

    val settings: Flow<UserSettings> = context.memoraDataStore.data
        .catch { throwable ->
            if (throwable is IOException) emit(emptyPreferences()) else throw throwable
        }
        .map { p ->
        UserSettings(
            language = p.enumOr(Keys.language, AppLanguage.deviceDefault()),
            themeMode = p.enumOr(Keys.themeMode, ThemeMode.SYSTEM),
            palette = p.enumOr(Keys.palette, PaletteChoice.PAPER),
            uiFont = p.enumOr(Keys.uiFont, FontChoice.SANS),
            writingFont = p.enumOr(Keys.writingFont, FontChoice.SERIF),
            uiScale = (p[Keys.uiScale] ?: 1.0f).coerceIn(0.8f, 1.2f),
            lockEnabled = p[Keys.lockEnabled] ?: true,
            lockInterval = p.enumOr(Keys.lockInterval, LockInterval.IMMEDIATELY)
        )
        }

    suspend fun setLanguage(value: AppLanguage) = edit(Keys.language, value.name)
    suspend fun setThemeMode(value: ThemeMode) = edit(Keys.themeMode, value.name)
    suspend fun setPalette(value: PaletteChoice) = edit(Keys.palette, value.name)
    suspend fun setUiFont(value: FontChoice) = edit(Keys.uiFont, value.name)
    suspend fun setWritingFont(value: FontChoice) = edit(Keys.writingFont, value.name)
    suspend fun setUiScale(value: Float) {
        context.memoraDataStore.edit { it[Keys.uiScale] = value.coerceIn(0.8f, 1.2f) }
    }
    suspend fun setLockEnabled(value: Boolean) {
        context.memoraDataStore.edit { it[Keys.lockEnabled] = value }
    }
    suspend fun setLockInterval(value: LockInterval) = edit(Keys.lockInterval, value.name)

    private suspend fun edit(key: Preferences.Key<String>, value: String) {
        context.memoraDataStore.edit { it[key] = value }
    }

    private inline fun <reified E : Enum<E>> Preferences.enumOr(
        key: Preferences.Key<String>,
        default: E
    ): E {
        val raw = this[key] ?: return default
        return enumValues<E>().firstOrNull { it.name == raw } ?: default
    }
}
