package com.memora.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.memora.app.i18n.L
import com.memora.app.i18n.S
import com.memora.app.prefs.AppLanguage
import com.memora.app.ui.components.MemoraTopBar

@Composable
fun LanguageScreen(
    current: AppLanguage,
    onBack: () -> Unit,
    onSelect: (AppLanguage) -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        MemoraTopBar(
            title = L.t(current, S.LANGUAGE),
            navigation = {
                IconButton(onClick = onBack) {
                    Icon(Icons.Rounded.ArrowBack, contentDescription = null)
                }
            }
        )
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
        ) {
        val items = AppLanguage.entries.map { it to it.displayName }
        items.forEach { (lang, label) ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { onSelect(lang) }
                    .padding(horizontal = 20.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(selected = current == lang, onClick = { onSelect(lang) })
                Text(label, modifier = Modifier.padding(start = 8.dp))
            }
        }
        }
    }
}
