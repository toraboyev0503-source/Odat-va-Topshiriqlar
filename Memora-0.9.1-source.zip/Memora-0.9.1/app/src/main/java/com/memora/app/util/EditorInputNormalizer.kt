package com.memora.app.util

/**
 * Conservative IME helper. Paragraph creation is handled structurally by PlainTextEditor. Text is
 * never silently changed here: in particular, a period at the end of a sentence stays exactly as
 * the user typed it, which prevents an IME from turning the following Enter into a second line.
 */
object EditorInputNormalizer {
    data class Result(val text: String, val cursor: Int, val changed: Boolean)

    fun normalize(
        previousText: String,
        incomingText: String,
        incomingCursor: Int,
        hasComposition: Boolean
    ): Result {
        val safeCursor = incomingCursor.coerceIn(0, incomingText.length)
        return Result(incomingText, safeCursor, false)
    }

    /** Detects one real Enter insertion even when an IME is finishing composing text. */
    fun paragraphBreakCursor(
        previousText: String,
        incomingText: String,
        incomingCursor: Int
    ): Int? {
        if (incomingText.length != previousText.length + 1) return null
        val cursor = incomingCursor.coerceIn(0, incomingText.length)
        if (cursor == 0) return null
        val insertedIndex = cursor - 1
        if (incomingText.getOrNull(insertedIndex) != '\n') return null
        if (incomingText.removeRange(insertedIndex, insertedIndex + 1) != previousText) return null
        return insertedIndex.coerceIn(0, previousText.length)
    }

    fun numberedListPrefix(text: String, cursor: Int): String {
        val before = text.substring(0, cursor.coerceIn(0, text.length))
        val currentLine = before.substringAfterLast('\n')
        val match = Regex("^\\s*(\\d+)\\.\\s+\\S.*$").matchEntire(currentLine) ?: return ""
        val number = match.groupValues[1].toLongOrNull() ?: return ""
        if (number == Long.MAX_VALUE) return ""
        return "${number + 1}. "
    }
}
