package com.memora.app.media

import android.annotation.SuppressLint
import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import java.io.File

class AudioRecorderController(private val context: Context) {
    data class Session(
        val relativePath: String,
        val file: File,
        val startedAt: Long
    )

    private var recorder: MediaRecorder? = null
    private var session: Session? = null

    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    fun start(storage: MediaStorage): Session {
        check(recorder == null) { "Recording is already active" }
        val (relative, file) = storage.newAudioFile()
        val mediaRecorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            MediaRecorder(context)
        } else {
            MediaRecorder()
        }
        mediaRecorder.apply {
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setAudioEncodingBitRate(128_000)
            setAudioSamplingRate(44_100)
            setOutputFile(file.absolutePath)
            prepare()
            start()
        }
        val created = Session(relative, file, System.currentTimeMillis())
        recorder = mediaRecorder
        session = created
        return created
    }

    fun stop(): Long? {
        val current = session ?: return null
        val elapsed = (System.currentTimeMillis() - current.startedAt).coerceAtLeast(0L)
        val active = recorder
        recorder = null
        session = null
        var successful = false
        if (active != null) {
            try {
                active.stop()
                successful = true
            } catch (_: RuntimeException) {
                current.file.delete()
            } finally {
                runCatching { active.reset() }
                active.release()
            }
        }
        return elapsed.takeIf { successful }
    }

    fun cancel() {
        val current = session
        val active = recorder
        recorder = null
        session = null
        if (active != null) {
            runCatching { active.stop() }
            runCatching { active.reset() }
            runCatching { active.release() }
        }
        current?.file?.delete()
    }

    fun isRecording(): Boolean = recorder != null
}
