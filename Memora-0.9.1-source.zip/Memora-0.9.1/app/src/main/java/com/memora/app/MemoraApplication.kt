package com.memora.app

import android.app.Application
import com.memora.app.billing.SubscriptionManager
import com.memora.app.data.local.AppDatabase
import com.memora.app.data.repository.MemoraRepository
import com.memora.app.notifications.AlarmScheduler
import com.memora.app.notifications.NotificationChannels
import com.memora.app.notifications.StatsScheduler
import com.memora.app.prefs.UserPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class MemoraApplication : Application() {
    lateinit var repository: MemoraRepository
        private set
    lateinit var preferences: UserPreferences
        private set
    lateinit var subscriptions: SubscriptionManager
        private set

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        subscriptions = SubscriptionManager(this, appScope)
        repository = MemoraRepository(AppDatabase.get(this), subscriptions::canWriteNow)
        preferences = UserPreferences(this)
        NotificationChannels.create(this)
        StatsScheduler(this).scheduleAll()

        // Self-heal reminder schedules on every real app start. This covers app updates,
        // vendor battery management and cases where a previous alarm registration was lost.
        appScope.launch {
            val scheduler = AlarmScheduler(this@MemoraApplication)
            repository.enabledReminders().forEach(scheduler::scheduleReminder)
        }
    }
}
