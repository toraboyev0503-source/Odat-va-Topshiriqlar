package com.memora.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.memora.app.i18n.L
import com.memora.app.i18n.S
import com.memora.app.prefs.LockInterval
import com.memora.app.prefs.UserSettings
import com.memora.app.ui.components.MemoraTopBar

@Composable
fun SecurityScreen(
    settings: UserSettings,
    onBack: () -> Unit,
    onEnabled: (Boolean) -> Unit,
    onInterval: (LockInterval) -> Unit
) {
    val language = settings.language
    Column(Modifier.fillMaxSize()) {
        MemoraTopBar(
            title = L.t(language, S.SECURITY),
            navigation = {
                IconButton(onClick = onBack) {
                    Icon(Icons.Rounded.ArrowBack, contentDescription = null)
                }
            }
        )
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
        ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(L.t(language, S.APP_LOCK), style = MaterialTheme.typography.titleMedium)
                Text(
                    L.t(language, if (settings.lockEnabled) S.ENABLED else S.DISABLED),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Switch(checked = settings.lockEnabled, onCheckedChange = onEnabled)
        }
        if (settings.lockEnabled) {
            Text(
                L.t(language, S.LOCK_INTERVAL),
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp)
            )
            LockInterval.entries.forEach { interval ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { onInterval(interval) }
                        .padding(horizontal = 20.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = settings.lockInterval == interval,
                        onClick = { onInterval(interval) }
                    )
                    Text(
                        L.t(language, when (interval) {
                            LockInterval.IMMEDIATELY -> S.IMMEDIATELY
                            LockInterval.ONE_MINUTE -> S.ONE_MINUTE
                            LockInterval.FIVE_MINUTES -> S.FIVE_MINUTES
                            LockInterval.FIFTEEN_MINUTES -> S.FIFTEEN_MINUTES
                            LockInterval.THIRTY_MINUTES -> S.THIRTY_MINUTES
                        }),
                        modifier = Modifier.padding(start = 8.dp)
                    )
                }
            }
        }
        }
    }
}
