package com.memora.app.media

/** Shared, overflow-safe image limits for import and on-screen decoding. */
internal object ImageSampling {
    const val STORED_MAX_DIMENSION = 2_560
    const val STORED_MAX_PIXELS = 6_000_000L
    const val DISPLAY_MAX_DIMENSION = 2_048
    const val DISPLAY_MAX_PIXELS = 4_000_000L

    fun sampleSize(width: Int, height: Int, maxDimension: Int, maxPixels: Long): Int {
        require(width > 0 && height > 0)
        require(maxDimension > 0 && maxPixels > 0)
        var sample = 1
        while (true) {
            val sampledWidth = (width.toLong() / sample).coerceAtLeast(1L)
            val sampledHeight = (height.toLong() / sample).coerceAtLeast(1L)
            if (
                maxOf(sampledWidth, sampledHeight) <= maxDimension.toLong() &&
                sampledWidth * sampledHeight <= maxPixels
            ) {
                return sample
            }
            require(sample <= Int.MAX_VALUE / 2) { "Image dimensions are too large" }
            sample *= 2
        }
    }
}
