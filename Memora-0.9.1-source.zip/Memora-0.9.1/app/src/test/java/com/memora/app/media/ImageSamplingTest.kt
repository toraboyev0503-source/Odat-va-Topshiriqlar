package com.memora.app.media

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ImageSamplingTest {
    @Test
    fun modernCameraPhotoIsDecodedWithinStoredLimits() {
        val sample = ImageSampling.sampleSize(8_000, 6_000, 2_560, 6_000_000L)
        assertEquals(4, sample)
        assertTrue(8_000L / sample <= 2_560L)
        assertTrue((8_000L / sample) * (6_000L / sample) <= 6_000_000L)
    }

    @Test
    fun alreadySmallImageNeedsNoSampling() {
        assertEquals(1, ImageSampling.sampleSize(1_200, 800, 2_560, 6_000_000L))
    }

    @Test
    fun veryWideImageUsesDimensionLimitWithoutOverflow() {
        assertEquals(4, ImageSampling.sampleSize(10_000, 300, 2_560, 6_000_000L))
    }
}
