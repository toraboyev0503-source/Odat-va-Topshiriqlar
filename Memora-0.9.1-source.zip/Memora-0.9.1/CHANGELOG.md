# Changelog

## 0.9.1 — Stability and navigation bugfix

- Hardened gallery and camera image import with bounded staging, sampled decoding,
  safe cleanup and a user-visible failure message instead of an app exit.
- Limited displayed image decoding and removed decoded bitmap allocations when the
  image leaves the editor or reader.
- Made the launch artwork crop to the full edge-to-edge surface and aligned system
  bars so the lower strip keeps the same background.
- Removed Memora's duplicate copy/cut/paste/select-all toolbar; Android's native
  selection toolbar remains available.
- Enter after a numbered sentence ending in a period now creates exactly one next
  paragraph, without silently inserting a trailing space.
- Made every route use one-step back navigation, prevented rapid editor back races,
  and preserved nested statistics/search state when returning from a note.

## 0.9.0 — Play Release Candidate

- Added Google Play Billing Library 9.1.0 integration for the single
  `memora_premium` subscription and four base plans.
- Added Play-controlled offer selection for a one-month free trial; reinstalling
  the app does not reset Play account eligibility.
- Added backend purchase-token verification, encrypted seven-day offline
  entitlement caching, pending-purchase handling and post-verification acknowledgement.
- Added read-only behavior after expiry while preserving viewing, search,
  statistics, playback and every export format.
- Added automatic device-language selection with English fallback while retaining
  the existing manual choice and all 13 UI languages.
- Kept all journal content local and added no advertising, analytics or crash SDK.
- Separated release signing from debug signing and removed the bundled test key.
- Replaced the custom build bootstrap with the official checksum-pinned Gradle wrapper.
- Added bounded backup/media import and canonical private-storage path validation.
- Added a GitHub Actions test → lint → signed AAB pipeline.
- Retained the 0.5.7 editor/reader paragraph gap at exactly 60% of line-height.

## 0.5.7 baseline

- Structural paragraph blocks, 60% paragraph spacing, short/long notes, media,
  reminders, titles, statistics, search, app lock, 13 languages, HTML/Word export
  and `.memora` backup/import form the preserved functional baseline.
