# Memora Privacy Policy — publication template

Effective date: **[add date]**  
Contact: **[add support email]**

Memora is a local-first private journal. Journal text, titles, photographs, audio
recordings, statistics and Memora backup contents are stored on the user's device.
Memora does not upload, sell or share that journal content. Android system cloud and
device-transfer backup is disabled for Memora data.

Memora uses Google Play Billing to offer a subscription. To validate access, the app
sends the app package name, subscription product ID and Google Play purchase token
over HTTPS to Memora's minimal verification service. That service checks the token
with the Google Play Developer API, returns entitlement state and does not retain the
request. It is not designed to receive journal content or advertising identifiers.
Google processes purchase information under Google's own terms and privacy policy.

Memora contains no advertising SDK, analytics SDK or crash-tracking SDK. Network
access is used only for Google Play billing and purchase verification. A verified
entitlement status is stored locally in encrypted form for up to seven offline days,
and never beyond the subscription expiry reported by Google Play.

Users can export or back up their information from inside Memora. Uninstalling the
app removes its private local data unless the user has separately exported a copy.
For privacy questions, contact the address above.

This template must be reviewed, completed and hosted at a public HTTPS URL before
publishing. It is not legal advice.
