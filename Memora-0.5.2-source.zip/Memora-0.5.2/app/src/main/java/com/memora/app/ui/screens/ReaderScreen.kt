package com.memora.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.Hyphens
import androidx.compose.ui.text.style.LineBreak
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memora.app.data.local.NoteEntity
import com.memora.app.data.model.NoteBlock
import com.memora.app.data.model.NoteBlocksCodec
import com.memora.app.i18n.L
import com.memora.app.i18n.S
import com.memora.app.media.MediaStorage
import com.memora.app.prefs.AppLanguage
import com.memora.app.prefs.FontChoice
import com.memora.app.ui.components.AudioBlockView
import com.memora.app.ui.components.ImageBlockView
import com.memora.app.ui.components.MemoraTopBar
import com.memora.app.ui.theme.fontFamily
import com.memora.app.util.TimeUtils

@Composable
fun ReaderScreen(
    note: NoteEntity?,
    language: AppLanguage,
    writingFont: FontChoice,
    onBack: () -> Unit,
    onEdit: () -> Unit
) {
    if (note == null) {
        Column(Modifier.fillMaxSize()) {
            MemoraTopBar(
                title = "",
                navigation = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Rounded.ArrowBack, contentDescription = null)
                    }
                }
            )
        }
        return
    }

    val context = LocalContext.current
    val storage = remember { MediaStorage(context.applicationContext) }
    val blocks = remember(note.blocksJson, note.plainText) {
        NoteBlocksCodec.decode(note.blocksJson, note.plainText)
    }

    Column(Modifier.fillMaxSize()) {
        MemoraTopBar(
            title = "",
            navigation = {
                IconButton(onClick = onBack) {
                    Icon(Icons.Rounded.ArrowBack, contentDescription = null)
                }
            },
            actions = {
                IconButton(onClick = onEdit) {
                    Icon(Icons.Rounded.Edit, contentDescription = L.t(language, S.EDIT))
                }
            }
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 28.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = note.title.ifBlank { L.t(language, S.UNTITLED) },
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = TimeUtils.dateTime(note.createdAt, language),
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (note.updatedAt > note.createdAt) {
                Text(
                    text = L.format(language, S.EDITED, TimeUtils.dateTime(note.updatedAt, language)),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(Modifier.height(8.dp))

            blocks.forEach { block ->
                when (block) {
                    is NoteBlock.Text -> if (block.text.isNotBlank()) {
                        Text(
                            text = buildAnnotatedString {
                                append(block.text)
                                block.styles.forEach { span ->
                                    if (span.start >= 0 && span.end <= block.text.length && span.end > span.start) {
                                        addStyle(
                                            SpanStyle(
                                                fontWeight = if (span.bold) FontWeight.Bold else null,
                                                fontStyle = if (span.italic) FontStyle.Italic else null
                                            ),
                                            span.start,
                                            span.end
                                        )
                                    }
                                }
                                var index = block.text.indexOf("\n\n")
                                while (index >= 0) {
                                    val blankStart = index + 1
                                    val blankEnd = (index + 2).coerceAtMost(block.text.length)
                                    addStyle(
                                        SpanStyle(fontSize = 1.sp),
                                        blankStart,
                                        blankEnd
                                    )
                                    addStyle(
                                        androidx.compose.ui.text.ParagraphStyle(lineHeight = 21.sp),
                                        blankStart,
                                        blankEnd
                                    )
                                    index = block.text.indexOf("\n\n", index + 2)
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            style = TextStyle(
                                color = MaterialTheme.colorScheme.onBackground,
                                fontFamily = fontFamily(writingFont),
                                fontSize = 18.sp,
                                lineHeight = 28.sp,
                                hyphens = Hyphens.Auto,
                                lineBreak = LineBreak.Paragraph
                            )
                        )
                    }
                    is NoteBlock.Image -> ImageBlockView(
                        block = block,
                        file = storage.resolve(block.relativePath),
                        editable = false
                    )
                    is NoteBlock.Audio -> AudioBlockView(
                        block = block,
                        file = storage.resolve(block.relativePath),
                        editable = false,
                        language = language
                    )
                }
            }
            Spacer(Modifier.height(30.dp))
        }
    }
}
