# Memora 0.9.46 — Performance Foundation (21.11.2026)

O-01–O-09: yengil qayd proyeksiyalari, Room Paging 3, Reader bloklarini virtual ko‘rsatish,
Editor debouncing, SQLite FTS4 (Room 10), LRU bitmap kesh va sintetik tezlik sinovlari.
Mavjud yozuvlar, highlight, media, `.memora` backup va Obsidian sinxronlash saqlanadi.

**Yetkazish holati:** manba ZIP + GitHub Actions YAML. GitHub’ga bu bosqichda yuklanmagan;
Android APK hali yig‘ilmagan va qurilmada sinovdan o‘tmagan.

Manba audit: `docs/PERFORMANCE_0.9.46.md` va `TESTING_0.9.46.md`.

---

## Memora 0.9.45 — Android matn tanlash menyusi tuzatildi (21.11.2026)

- 0.9.44 dagi xato: Android «Nusxa olish / Geminidan so‘rash / …» kontekst menyusi Memora oynasi o‘rnida ochilgan.
- Sabab: avvalgi implementatsiya faqat `LocalTextToolbar`ni almashtirgan, ammo Compose Foundation 1.9+ yangi `LocalTextContextMenuToolbarProvider`/`DropdownProvider`dan foydalanadi.
- Yangi versiyada ikkala Compose API to‘sildi; Memora menyusi endi `TextFieldValue.selection` va `TextLayoutResult`dan mustaqil hisoblanadi.
- Tanlash dastagi (handles) saqlanadi; ko‘rinadigan panelda faqat **Nusxalash / Rasm / Marker** (oldingi bo‘yalgan matnda **X + 3 rang**).
- Qo‘shimcha o‘zgarish yo‘q: Room 9, backup, marker rangini saqlash va ulashish mexanizmi o‘z holida.
- Tekshiruv: manba regressiyasi / sintaksis; Android APK kompilyatsiya va telefonda sinov alohida GitHub build bosqichida bajariladi.

> **0.9.44 Selection & Mini Paper:** O‘qishda Memora’ning faqat «Nusxalash / Rasm / Marker» paneli, doimiy rang tanlash, markerga tegib rangni o‘zgartirish/olib tashlash, kichik matnga mos rasm va ikonli PNG/PDF footer. Qidiruv belgisi olib tashlangan. `CHANGELOG.md`ga qarang.

> **0.9.43 Memora Paper: Reader/Editor share a single scrolling card, dynamic status bar visibility, larger titles, bottom dates and quiet autosave. See `docs/RELEASE_0.9.43.md`.

> **0.9.41 Full Canvas:** Reader and Editor now scroll text to the physical top of the screen, using floating auto-hiding controls. Details: `docs/RELEASE_0.9.41.md`. Build only after a separate user command.

# Memora 0.9.44

Versiya: **0.9.44**, `versionCode 65` (Room 9). Yangilanish 0.9.40 debug paketining identifikatori va sinov imzosini saqlaydi.

Yangi asosiy menyu: Bosh sahifa, Yozuvlar, (+), Taqvim, Sozlamalar. Yangi **Kun izi** kamera+fotoalbom funksiyasi (+) orqali, **Eslatmalar** esa Sozlamalar orqali ishlaydi.

GitHub Actions: `.github/workflows/android-build.yml`. `tools/regression_0944.py` mahalliy strukturaviy tekshiruv; `MemoryRecallPlannerTest` Kotlin testlari mavjud.

**Eslatma:** ZIP va YAML tayyorlanishi GitHub'ga yuklandi yoki APK yaratildi degani emas. APK faqat alohida GitHub builddan keyin tayyor bo‘ladi.

# Memora 0.9.39 — Quiet Navigation fix

Android e-journal / Topilmalar app (Kotlin, Jetpack Compose, Room).

- `versionName`: **0.9.39**; `versionCode`: **60**.
- Debug application ID and signing key unchanged from 0.9.38.
- Room schema version **8**; note data, settings, media and backup format unchanged.

## Q-01–Q-11: video-observed navigation artifact remediation

- Root tabs switch immediately, without fading or sliding.
- Detail pages use a **170 ms / 12 dp** horizontal slide; Back reverses the movement.
- Every destination now owns a full-size opaque, theme-colored background. This prevents the previous screen's title or text appearing through a new screen.
- `NavHost` viewport never changes size when the bottom tab bar appears or disappears. Each root destination instead reserves its own tab bar space.
- The five-button bottom bar remains hidden until exiting details finish their transitions, and hides during keyboard entry. RTL reverses the horizontal slide.
- 19 navigation destinations are covered by the same wrapper; Topilmalar `CREATE` is treated as a detail.

See [`docs/RELEASE_0.9.39.md`](docs/RELEASE_0.9.39.md) for test scenarios, limitations and acceptance criteria.

## Build

Upload `Memora_0.9.39_GitHub.zip` to the GitHub repository root (keep it zipped). Place the companion `android-build.yml` in `.github/workflows/`, replacing the earlier version. The included `.github/workflows/android-build.yml` matches the companion file.

GitHub Actions runs static regression, Topilmalar checks, Billing backend tests, JVM tests, Android lint and debug APK assembly. Emulator Room migration test is optional via workflow dispatch.

**Status:** Static and pure Kotlin checks can run locally; Android build and actual device visual verification require GitHub/Android SDK and have not been performed by this package step.

## Earlier changes

0.9.38 U-01–U-06 design improvements are retained. See [`docs/RELEASE_0.9.38.md`](docs/RELEASE_0.9.38.md).

## Memora Performance Engineering 0.9.47

PerformanceProbe is a non-debuggable R8 test variant signed with the existing GitHub test key. Separate `:benchmark` Macrobenchmark tests collect startup/frame metrics and Perfetto traces. For full instructions see `docs/PERFORMANCE_ENGINEERING_0.9.47.md`. Never treat a passing CI build as proof of real-device speed.

## Memora Performance Engineering 0.9.47

PerformanceProbe is a non-debuggable R8 test variant signed with the existing GitHub test key. Separate `:benchmark` Macrobenchmark tests collect startup/frame metrics and Perfetto traces. For full instructions see `docs/PERFORMANCE_ENGINEERING_0.9.47.md`. Never treat a passing CI build as proof of real-device speed.
