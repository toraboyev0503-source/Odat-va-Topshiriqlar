#!/usr/bin/env python3
"""O-09: reproducible synthetic SQLite timings; these are NOT Android frame measurements.

    python3 tools/benchmark_0946.py [--quick]

No existing user database is read, written or copied. The database is in-memory.
"""
import argparse
import json
import sqlite3
import statistics
import time

parser = argparse.ArgumentParser()
parser.add_argument('--quick', action='store_true', help='Skip 5000/10000 sizes')
args = parser.parse_args()

SCHEMA = '''
CREATE TABLE notes(id TEXT PRIMARY KEY, type TEXT, title TEXT, plainText TEXT,
  createdAt INTEGER, updatedAt INTEGER, wordCount INTEGER,
  hasImages INTEGER, hasAudio INTEGER, mood TEXT, hashtagsJson TEXT);
CREATE INDEX notes_date ON notes(createdAt DESC, id DESC);
CREATE INDEX notes_type_date ON notes(type, createdAt DESC);
CREATE VIRTUAL TABLE notes_fts USING fts4(noteId,title,plainText,tokenize=unicode61);
CREATE TRIGGER notes_fts_insert AFTER INSERT ON notes BEGIN
  INSERT INTO notes_fts(noteId,title,plainText) VALUES(new.id,new.title,new.plainText);
END;
CREATE TRIGGER notes_fts_update AFTER UPDATE OF id,title,plainText ON notes BEGIN
  DELETE FROM notes_fts WHERE noteId=old.id;
  INSERT INTO notes_fts(noteId,title,plainText) VALUES(new.id,new.title,new.plainText);
END;
CREATE TRIGGER notes_fts_delete AFTER DELETE ON notes BEGIN
  DELETE FROM notes_fts WHERE noteId=old.id;
END;
'''

def measure(cursor, statement, params=(), repeat=7):
    times = []
    for _ in range(repeat):
        started = time.perf_counter()
        list(cursor.execute(statement, params))
        times.append((time.perf_counter()-started)*1000)
    return round(statistics.median(times), 3)

for count in ([140, 1000] if args.quick else [140,1000,5000,10000]):
    db = sqlite3.connect(':memory:')
    db.executescript(SCHEMA)
    with db:
        db.executemany('''INSERT INTO notes VALUES(?,?,?,?,?,?,?,?,?,?,?)''', [
            (f'n-{i}', 'LONG' if i % 3 else 'SHORT', f'Qayd {i}',
             f'Bu qidiruv uchun sinov matni, tezlik va optimallashtirish namuna {i}. ' * 8,
             1700000000000+i*1000,1700000000000+i*1000,72,0,0,None,'[]')
            for i in range(count)
        ])
    c=db.cursor()
    base = ('SELECT id,type,title,substr(plainText,1,360),createdAt,updatedAt,wordCount,'
            'hasImages,hasAudio,mood,hashtagsJson FROM notes ORDER BY createdAt DESC,id DESC LIMIT 32')
    filtered = ('SELECT id,title FROM notes WHERE id IN (SELECT noteId FROM notes_fts '
                'WHERE notes_fts MATCH ?) ORDER BY createdAt DESC,id DESC LIMIT 32')
    result = {'notes': count,
        'page_32_median_ms':measure(c,base),
        'fts_32_median_ms':measure(c,filtered,('tezlik*',)),
        'count_median_ms':measure(c,'SELECT COUNT(*) FROM notes'),
        'fts_matches':c.execute("SELECT COUNT(*) FROM notes_fts WHERE notes_fts MATCH 'tezlik*'").fetchone()[0]}
    # Sync integrity: update & delete are visible to the index immediately.
    with db:
        c.execute("UPDATE notes SET title = 'Yangilandi' WHERE id='n-0'")
        assert c.execute("SELECT count(*) FROM notes_fts WHERE notes_fts MATCH 'Yangilandi'").fetchone()[0]==1
        c.execute("DELETE FROM notes WHERE id='n-0'")
        assert c.execute("SELECT count(*) FROM notes_fts WHERE notes_fts MATCH 'Yangilandi'").fetchone()[0]==0
    print(json.dumps(result, ensure_ascii=False))
    db.close()
