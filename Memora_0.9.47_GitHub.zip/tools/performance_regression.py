#!/usr/bin/env python3
"""Static contracts and SHA checks; not a substitute for a device profile or build."""
from pathlib import Path
import hashlib,json,sys
R=Path(__file__).resolve().parents[1]
assertions=[]
def check(name, yes): assertions.append((name,bool(yes)))
def get(p):return (R/p).read_text(encoding='utf-8')
version = "0.9.47"
code_number = 68
build=get('app/build.gradle.kts')
check('version', f'versionName = "{version}"' in build and f'versionCode = {code_number}' in build)
check('test package stays compatible', 'applicationIdSuffix = ".debug"' in build)
check('stable test signer', 'memora-test-debug.jks' in build and 'signingConfig = signingConfigs.getByName("debug")' in build)
check('non-debuggable R8 probe', 'create("performanceProbe")' in build and 'isDebuggable = false' in build and 'isMinifyEnabled = true' in build)
check('stable Room schema 10', 'version = 10' in get('app/src/main/java/com/memora/app/data/local/AppDatabase.kt'))
check('JankStats performance-only', 'PERF_INSTRUMENTED' in get('app/src/main/java/com/memora/app/performance/MemoraPerformance.kt'))
check('profileable manifest', 'profileable android:shell="true"' in get('app/src/performanceProbe/AndroidManifest.xml'))
check('read-only three macrobenchmarks', all(x in get('benchmark/src/main/java/com/memora/benchmark/MemoraMacrobenchmark.kt') for x in ['coldStartup','tabNavigation','readerOpenAndScroll']))
check('Baseline Profile generator', 'BaselineProfileRule()' in get('benchmark/src/main/java/com/memora/benchmark/MemoraMacrobenchmark.kt'))
check('safe memory unchanged', 'onStop()' in get('app/src/main/java/com/memora/app/MainActivity.kt') and '.putLong(KEY_LAST_BACKGROUND_AT, now).commit()' in get('app/src/main/java/com/memora/app/MainActivity.kt'))
for file,expected in json.loads(get('tools/unchanged_code_sha256.json')).items():
 check('unchanged: '+file,hashlib.sha256((R/file).read_bytes()).hexdigest()==expected)
if version == '0.9.48':
 a=get('app/src/main/java/com/memora/app/ui/MemoraApp.kt')
 r=get('app/src/main/java/com/memora/app/ui/screens/ReaderScreen.kt')
 e=get('app/src/main/java/com/memora/app/ui/screens/EditorScreen.kt')
 check('no root global collectors', '    val titles by repository.observeTitles()' not in a and '    val albumPhotos by repository.observeMemoryAlbum()' not in a)
 check('per-destination collectors', a.count('val titles by remember(repository)')==2 and a.count('val albumPhotos by remember(repository)')==2)
 check('reader decode on Default', 'withContext(Dispatchers.Default)' in r and 'NoteBlocksCodec.decode(json, fallback)' in r)
 check('editor decode on Default', 'suspend fun parseBlocks' in e and 'withContext(Dispatchers.Default)' in e)
 check('editor recovery retained','recoveryStore.clear(' in e and 'saveMutex.withLock' in e)
for name,ok in assertions:
 if not ok: print('FAIL',name)
print(f'Performance source contracts {version}: {sum(ok for _,ok in assertions)}/{len(assertions)} passed')
if not all(ok for _,ok in assertions): sys.exit(1)
