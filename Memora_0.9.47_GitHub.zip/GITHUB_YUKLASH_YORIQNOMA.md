# Memora 0.9.46 — GitHub’ga yuklash va APK build

**Hozircha hech nima GitHub’ga yuklanmagan.** Bu paketdagi barcha ish mahalliy manba kodda bajarildi.

1. Alohida ruxsat kelganidan keyin repozitoriy ildiziga `Memora_0.9.46_GitHub.zip` ni qo‘ying.
2. `android-build_0.9.46.yml`ni `.github/workflows/android-build.yml`ga joylashtiring; ZIP ichidagi YAML bilan mazmuni aynan bir xil.
3. GitHub Actions JDK17, Android API36, `regression_0946.py`, `benchmark_0946.py`, Billing npm test, Kotlin unit test, lint, assembleDebug va assembleDebugAndroidTest bajaradi.
4. Debug APK artefakti `Memora-0.9.46-debug-apk` nomi bilan chiqariladi.
5. Room 3→10 instrumentatsion migratsiya testini qo‘shib sinash uchun `workflow_dispatch` kirishida `run_android_tests=true` ni tanlang (emulator uchun vaqt ko‘proq talab etiladi).
6. Haqiqiy qurilmadagi 140/1k/5k/10k va UI jank kuzatuv qoidalari `TESTING_0.9.46.md`da keltirilgan.

`versionCode=67`, `versionName=0.9.46`, `Room=10`, debug sinov kaliti va `.debug` applicationId suffix o‘zgarmagan.
