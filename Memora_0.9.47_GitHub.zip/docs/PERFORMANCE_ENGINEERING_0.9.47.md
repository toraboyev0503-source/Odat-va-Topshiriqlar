# Memora Performance Engineering — 0.9.47 (diagnostics only)

- No migration and no UI changes. Room schema remains **10**.
- `performanceProbe`: app ID `com.memora.app.debug` (same as GitHub debug APK), test certificate `app/keystore/memora-test-debug.jks`, minified **non-debuggable**; no uninstall/data reset required when updating an existing GitHub debug install.
- `release`: still requires its own signed production key and HTTPS billing endpoint; **not** replaced by test signing.
- `JankStats`: only active with `PERF_INSTRUMENTED=true` in `performanceProbe`; no note content or IDs logged or transferred over network.
- Collection on activity stop: adb logcat `MemoraPerf`, and app external-private `Android/data/com.memora.app.debug/files/performance/frames.jsonl`.
- `:benchmark`: Macrobenchmark read-only startup + four-tab navigation; generated Perfetto `.perfetto-trace` artifacts available via test output. Run on a **physical device** for comparisons; emulator results are diagnostic-only.
- `BaselineProfileRule`: generator is present; generated profile is *not* shipped automatically until measured and reviewed.

## Safety and rollout

1. Save a Memora backup before first performance experiment; do not uninstall the current app.
2. Install only a matching package/signature (`com.memora.app.debug`, same test signing certificate). VersionCode 68 updates v67.
3. Measure the **same** 140-note dataset and identical device conditions on debug and performanceProbe.
4. Do not trigger destructive application actions during benchmark journeys.
5. Release signing is separate; there is no insecure debug-key production release.
6. A successful compile is not proof of frame-rate improvements.
