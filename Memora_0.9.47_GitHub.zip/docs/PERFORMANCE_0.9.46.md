# O-01–O-09: Memora 0.9.46 arxitektura qarorlari

| Qoidalar | Kod yo‘li | Vazifa |
|---|---|---|
| O-01 | `NoteSummary`, `Daos.kt`, `MemoraApp.kt` | Global `SELECT *` kuzatuvi bekor. Faqat taqvimda tavsiflar, yozuvni ochganda bitta to‘liq entity. |
| O-02 | `NoteSearchQuery`, `NotesHubScreen` | Room PagingSource va Paging3 (32 yozuv/page, max 224 item) + qaydlar soni uchun mustaqil COUNT. |
| O-03 | `ReaderScreen`, `NoteStatusBarEffect`, `FullCanvasNoteChrome` | Bitta umumiy LazyColumn; har xatboshi faqat ko‘ringanda chiziladi, marker/nusxa/media mavjud. |
| O-04 | `NoteBlocksCodec.editText`, `EditorScreen` | Odatdagi harfda faqat o‘zgargan paragraf, statistikalar 180 ms, recovery 250 ms va saqlash 900 ms debounce. |
| O-05 | `AppDatabase` v10 | FTS4 yordamchi jadval, boshlang‘ich indeks + INSERT/UPDATE/DELETE triggerlar, parametrli qidiruv. |
| O-06 | `DisplayBitmapCache`, `MediaBlocks` | 24 MiB LRU va fonda sample/decode; ko‘rinmayotgan media hali yuklanmaydi. |
| O-07 | `EditorScreen`, `ReaderShareManager` | Debounced snapshot va avvaldan mavjud Mutex/IO eksportlar saqlanadi. |
| O-08 | `app/src/main/baseline-prof.txt`, R8 release | Qo‘lda tanlangan dastlabki profil qoidalari; non-debuggable release R8 allaqachon mavjud. Telefondagi profil test bilan tekshirish kerak. |
| O-09 | `tools/benchmark_0946.py`, testlar | 140/1k/5k/10k SQLite sintetik test; Kotlin unit, Room migration instrumentation (ixtiyoriy emulator). |

## Ma'lumotlar modeli

`notes` jadvali va media fayllar avvalgi kabi yagona haqiqat manbai. FTS qidiruvni tezlashtiradigan qo‘shimcha indeks xolos. `NoteSummary` faqat **ko‘rsatish** uchun yengil proyeksiya; u bilan o‘chirishdan boshqa yozish amali bajarilmaydi. O‘chirishda ham bazadan asl `NoteEntity` qayta olinadi.

## Qamrov va cheklovlar

* O‘qishda barcha paragraflarni bir paytda chizish kamaytirildi. Tahrirchida kursor va IME uzluksizligi uchun ko‘rinadigan matn editori `verticalScroll` ustida qoldi; oddiy yozish yo‘li tezlashtirildi.
* Taqvim bir vaqtning o‘zida faqat metadata va 360-belgili preview oladi, ammo 10k metadata hali xotirada bo‘lishi mumkin; yanada katta bazalar uchun keyingi bosqichda statistikani SQL aggregatlariga ko‘chirish mumkin.
* Obsidian `.md` eksporti/sinxronlash mexanizmi saqlangan; asosiy Room ma’lumotlar alohida `.md`larga o‘tkazilmadi.
* Kotlin unit, sintetik SQLite va manba regressiyasi haqiqiy Android ekran kadrlarini tasdiqlamaydi. APKni GitHub’da kompilyatsiya qilib, fizik qurilmada Profiling kerak.
