package com.memora.benchmark

import androidx.benchmark.macro.CompilationMode
import androidx.benchmark.macro.FrameTimingMetric
import androidx.benchmark.macro.StartupMode
import androidx.benchmark.macro.StartupTimingMetric
import androidx.benchmark.macro.junit4.MacrobenchmarkRule
import androidx.benchmark.macro.junit4.BaselineProfileRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.uiautomator.By
import androidx.test.uiautomator.Until
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/** Read-only journeys; no note import, mutation, or delete actions. */
@RunWith(AndroidJUnit4::class)
class MemoraMacrobenchmark {
    @get:Rule val benchmarkRule = MacrobenchmarkRule()
    private val app = "com.memora.app.debug"

    @Test fun coldStartup() = benchmarkRule.measureRepeated(
        packageName = app,
        metrics = listOf(StartupTimingMetric()),
        compilationMode = CompilationMode.Partial(),
        startupMode = StartupMode.COLD,
        iterations = 8,
        setupBlock = { pressHome() },
        measureBlock = { startActivityAndWait() }
    )

    @Test fun tabNavigation() = benchmarkRule.measureRepeated(
        packageName = app,
        metrics = listOf(FrameTimingMetric()),
        compilationMode = CompilationMode.Partial(),
        startupMode = StartupMode.WARM,
        iterations = 6,
        setupBlock = { pressHome(); startActivityAndWait() },
        measureBlock = {
            for (tag in listOf("memora_tab_notes", "memora_tab_calendar", "memora_tab_settings", "memora_tab_home")) {
                val tab = device.wait(Until.findObject(By.res(tag)), 8000L)
                    ?: error("Missing tab $tag: check testTagsAsResourceId")
                tab.click()
                device.waitForIdle()
            }
        }
    )

    /** Requires pre-existing notes. All operations are read-only. */
    @Test fun readerOpenAndScroll() = benchmarkRule.measureRepeated(
        packageName = app,
        metrics = listOf(FrameTimingMetric()),
        compilationMode = CompilationMode.Partial(),
        startupMode = StartupMode.WARM,
        iterations = 5,
        setupBlock = { pressHome(); startActivityAndWait() },
        measureBlock = {
            val notes = device.wait(Until.findObject(By.res("memora_tab_notes")), 8000L)
                ?: error("Notes tab is missing")
            notes.click()
            val first = device.wait(Until.findObject(By.res("memora_note_card")), 8000L)
                ?: error("Import or create a note before measuring reader performance")
            first.click()
            device.wait(Until.hasObject(By.res("memora_reader_content")), 8000L)
            val w = device.displayWidth
            val h = device.displayHeight
            device.swipe(w / 2, h * 3 / 4, w / 2, h / 3, 24)
            device.waitForIdle()
            device.pressBack()
        }
    )
}

/** Run separately: the generated text profile must be reviewed before shipping. */
@RunWith(AndroidJUnit4::class)
class MemoraBaselineProfileGenerator {
    @get:Rule val profile = BaselineProfileRule()
    @Test fun generate() = profile.collect(packageName = "com.memora.app.debug", maxIterations = 8) {
        pressHome()
        startActivityAndWait()
        val notes = device.wait(Until.findObject(By.res("memora_tab_notes")), 8000L)
            ?: error("Notes tab not found")
        notes.click()
        device.waitForIdle()
        device.pressBack()
    }
}
