# Memora 0.9.46 — Performance Foundation: qabul sinovlari

## Sinov matritsasi

1. 0.9.45 debug versiyasi ustiga yangilang: eski qaydlar, sarlavha, matn, highlight, rasm, audio, sana va sozlamalar yo‘qolmasin.
2. 140 qayd: Bosh sahifa → Yozuvlar → Taqvim → O‘qish → Tahrirlash; sahifa o‘zgarishida qotish va bo‘sh ekranlarni qayd qiling.
3. 1 000 / 5 000 / 10 000 sinov qaydi bilan (foydalanuvchining haqiqiy bazasida emas) Paging: pastga uzoq surish, eski yillarning yopiq/ochiq arxivlari, har bir natijaga o‘tish.
4. O‘qish: mingta xatboshi, ko‘p rasmlar, audiolar, highlight ustiga bosish, rang o‘zgartirish, 2–3 qatorli «Rasm» kartasi, oddiy nusxalash.
5. Tahrirlash: uzoq yozuvning o‘rtasida tez yozish, kursor, matnni bo‘lish/birlashtirish, media, avtomatik saqlash, ilova majburan yopilgandan keyin recovery.
6. Qidirish: kirill/lotin, maxsus belgilar, sarlavha va matn bo‘yicha FTS, sana turi/kayfiyat/media filtri; yangi qayd va tahrirdan so‘ng qidiruv darhol yangilansin.
7. Backup: .memora yaratish, toza sinov o‘rnatishga restore qilish, barcha qayd va media qaytishi, FTS qayta topishi.
8. Room 3→10 migratsiya instrumentatsion testi; eski ma’lumotlar saqlanishi va FTS insert/update/delete triggerlarini tekshirish.

## Tezlik tekshiruvi

* `python3 tools/benchmark_0946.py` — mahalliy, in-memory SQLite sun’iy test: 140/1 000/5 000/10 000 qayd uchun sahifalash va qidiruv vaqtini o‘lchaydi.
* Natijalar `docs/sqlite_performance_0946.jsonl`da. **Bu telefondagi Compose FPS yoki ilova yuklanish vaqti emas.**
* Telefonda `adb shell am force-stop com.memora.app.debug`, keyin `adb shell am start -W -n com.memora.app.debug/com.memora.app.MainActivity` bilan start vaqtini, Perfetto/JankStats bilan skroll kadrlarini o‘lchang.
* Testlarni debug bilan solishtirish natijalarini ehtiyotkor talqin qiling. Non-debuggable release profiling uchun ishlab chiqarish signing va HTTPS billing URL zarur.
* Baseline profile `app/src/main/baseline-prof.txt`da dastlabki (qo‘lda tanlangan) qoidalar; haqiqiy generatsiya qilingan profil va makrobenchmark natijalari GitHub build/device sinovlaridan keyin to‘ldiriladi.

## Axborot xavfsizligi va buzilmaslik

* Room 9→10: mavjud `notes` satrlari o‘zgarmaydi; faqat yordamchi FTS indeksi qo‘shiladi.
* `NoteSummary` hech qachon bazaga saqlanmaydi yoki eksport qilinmaydi; eksport faqat `NoteEntity`ning asl to‘liq qiymatini ishlatadi.
* Media o‘chirishdan oldin `repository.getNote(id)` bilan asl bloklar olinadi; eski backup sxemasi o‘zgarishsiz.
* Xatolik bo‘lsa APKni asosiy qurilmaga o‘rnatishdan oldin sinov bazasi/zaxira nusxasidan foydalaning.
