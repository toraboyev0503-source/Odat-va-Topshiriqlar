package com.memora.app.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.EditNote
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.RotateRight
import androidx.compose.material.icons.rounded.SelectAll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.exifinterface.media.ExifInterface
import com.memora.app.data.local.TopilmaSourceRow
import com.memora.app.share.TopilmaOcrManager
import com.memora.app.ui.theme.MemoraDesign
import java.io.File
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun TopilmaCreateModeScreen(
    sourceLabel: String = "Topilma",
    onBack: () -> Unit,
    onWrite: () -> Unit,
    onCopy: () -> Unit
) {
    BackHandler(onBack = onBack)
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 8.dp, end = 18.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, contentDescription = "Orqaga") }
            Column {
                Text(sourceLabel, style = MaterialTheme.typography.titleLarge)
                Text("Qanday qo‘shmoqchisiz?", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            CreateModeCard(
                icon = { Icon(Icons.Rounded.EditNote, contentDescription = null) },
                title = "Yozish",
                subtitle = "Topilmani klaviaturada yozish",
                onClick = onWrite
            )
            CreateModeCard(
                icon = { Icon(Icons.Rounded.CameraAlt, contentDescription = null) },
                title = "Nusxalash",
                subtitle = "Kitob yoki rasmdagi matnni belgilab olish",
                onClick = onCopy
            )
        }
    }
}

@Composable
private fun CreateModeCard(
    icon: @Composable () -> Unit,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(MemoraDesign.radiusMedium),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = MemoraDesign.shadowSubtle,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.padding(horizontal = 18.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(
                shape = RoundedCornerShape(MemoraDesign.radiusSmall),
                color = MaterialTheme.colorScheme.primary.copy(alpha = .11f)
            ) { Box(Modifier.padding(12.dp)) { icon() } }
            Column(Modifier.weight(1f).padding(start = 14.dp)) {
                Text(title, style = MaterialTheme.typography.titleLarge)
                Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text("›", style = MaterialTheme.typography.titleLarge)
        }
    }
}

@Composable
fun TopilmaCopyMethodScreen(
    source: TopilmaSourceRow,
    onBack: () -> Unit,
    onCamera: () -> Unit,
    onGalleryFile: (File) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var error by remember { mutableStateOf<String?>(null) }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) onCamera() else error = "Kameradan foydalanish uchun ruxsat kerak."
    }
    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                val file = withContext(Dispatchers.IO) { copyUriToOcrCache(context, uri) }
                if (file != null) onGalleryFile(file) else error = "Rasmni ochib bo‘lmadi."
            }
        }
    }

    BackHandler(onBack = onBack)
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 8.dp, end = 18.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, contentDescription = "Orqaga") }
            Column(Modifier.weight(1f)) {
                Text("Nusxalash", style = MaterialTheme.typography.titleLarge)
                Text(source.title, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Column(Modifier.padding(horizontal = 20.dp, vertical = 18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            CreateModeCard(
                icon = { Icon(Icons.Rounded.CameraAlt, contentDescription = null) },
                title = "Kamera",
                subtitle = "Sahifani hozir suratga olish",
                onClick = {
                    if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) onCamera()
                    else permissionLauncher.launch(Manifest.permission.CAMERA)
                }
            )
            CreateModeCard(
                icon = { Icon(Icons.Rounded.PhotoLibrary, contentDescription = null) },
                title = "Galereya",
                subtitle = "Telefondagi mavjud rasmni tanlash",
                onClick = { gallery.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
            )
            error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 4.dp)) }
        }
    }
}

@Composable
fun TopilmaCameraCaptureScreen(
    onBack: () -> Unit,
    onCaptured: (File) -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val previewView = remember {
        PreviewView(context).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
    }
    var imageCapture by remember { mutableStateOf<ImageCapture?>(null) }
    var captureInProgress by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    DisposableEffect(previewView, lifecycleOwner) {
        val providerFuture = ProcessCameraProvider.getInstance(context)
        val executor = ContextCompat.getMainExecutor(context)
        val listener = Runnable {
            runCatching {
                val provider = providerFuture.get()
                val preview = Preview.Builder().build()
                val capture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .build()
                val selector = if (provider.hasCamera(CameraSelector.DEFAULT_BACK_CAMERA)) {
                    CameraSelector.DEFAULT_BACK_CAMERA
                } else {
                    CameraSelector.DEFAULT_FRONT_CAMERA
                }
                provider.unbindAll()
                preview.setSurfaceProvider(previewView.surfaceProvider)
                provider.bindToLifecycle(lifecycleOwner, selector, preview, capture)
                imageCapture = capture
                error = null
            }.onFailure {
                imageCapture = null
                error = "Kamerani ishga tushirib bo‘lmadi."
            }
        }
        providerFuture.addListener(listener, executor)
        onDispose { runCatching { providerFuture.get().unbindAll() } }
    }

    BackHandler(onBack = onBack)
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())
        Row(
            Modifier.fillMaxWidth().align(Alignment.TopCenter).padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(shape = RoundedCornerShape(22.dp), color = Color.Black.copy(alpha = .46f)) {
                IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, contentDescription = "Orqaga", tint = Color.White) }
            }
            Text("Sahifani suratga oling", color = Color.White, modifier = Modifier.padding(start = 10.dp))
        }
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            error?.let {
                Surface(color = Color.Black.copy(alpha = .55f), shape = RoundedCornerShape(12.dp)) {
                    Text(it, color = Color.White, modifier = Modifier.padding(10.dp))
                }
                Spacer(Modifier.height(10.dp))
            }
            Button(
                enabled = imageCapture != null && !captureInProgress,
                onClick = {
                    val capture = imageCapture ?: return@Button
                    val file = createOcrCacheFile(context)
                    captureInProgress = true
                    val output = ImageCapture.OutputFileOptions.Builder(file).build()
                    capture.takePicture(
                        output,
                        ContextCompat.getMainExecutor(context),
                        object : ImageCapture.OnImageSavedCallback {
                            override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                                captureInProgress = false
                                onCaptured(file)
                            }
                            override fun onError(exception: ImageCaptureException) {
                                captureInProgress = false
                                file.delete()
                                error = "Rasmni saqlab bo‘lmadi. Qayta urinib ko‘ring."
                            }
                        }
                    )
                },
                shape = RoundedCornerShape(28.dp)
            ) {
                Icon(Icons.Rounded.CameraAlt, contentDescription = null)
                Text(if (captureInProgress) " Saqlanmoqda…" else " Suratga olish")
            }
        }
    }
}

@Composable
fun TopilmaOcrSelectionScreen(
    imageFile: File,
    onBack: () -> Unit,
    onRetryCamera: () -> Unit,
    onReplaceImage: (File) -> Unit,
    onConfirm: (String) -> Unit
) {
    var bitmap by remember(imageFile.absolutePath) { mutableStateOf(loadUprightBitmap(imageFile)) }
    var generation by remember { mutableIntStateOf(0) }
    var tokens by remember { mutableStateOf<List<TopilmaOcrManager.Token>>(emptyList()) }
    var selected by remember { mutableStateOf<Set<String>>(emptySet()) }
    var detecting by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var viewport by remember { mutableStateOf(IntSize.Zero) }
    var zoom by remember { mutableStateOf(1f) }
    var pan by remember { mutableStateOf(Offset.Zero) }
    val accent = MaterialTheme.colorScheme.primary
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val replacementGallery = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                val replacement = withContext(Dispatchers.IO) { copyUriToOcrCache(context, uri) }
                if (replacement != null) onReplaceImage(replacement)
            }
        }
    }

    LaunchedEffect(bitmap, generation) {
        val current = bitmap
        if (current == null) {
            error = "Rasmni ochib bo‘lmadi."
            tokens = emptyList()
            return@LaunchedEffect
        }
        detecting = true
        error = null
        selected = emptySet()
        val result = withContext(Dispatchers.Default) { TopilmaOcrManager.recognize(current) }
        detecting = false
        result.onSuccess { found ->
            tokens = found
            if (found.isEmpty()) error = "Matn topilmadi"
        }.onFailure {
            tokens = emptyList()
            error = "Matnni aniqlab bo‘lmadi."
        }
    }

    BackHandler(onBack = onBack)
    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Row(
            Modifier.fillMaxWidth().background(Color.Black.copy(alpha = .82f)).padding(horizontal = 6.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, contentDescription = "Orqaga", tint = Color.White) }
            Column(Modifier.weight(1f)) {
                Text("Matnni belgilang", color = Color.White, style = MaterialTheme.typography.titleMedium)
                Text("1 barmoq: belgilash · 2 barmoq: surish/yaqinlashtirish", color = Color.White.copy(alpha = .72f), style = MaterialTheme.typography.labelSmall)
            }
            IconButton(
                onClick = {
                    bitmap = bitmap?.let { rotateBitmap(it, 90f) }
                    zoom = 1f
                    pan = Offset.Zero
                    generation++
                },
                enabled = bitmap != null && !detecting
            ) { Icon(Icons.Rounded.RotateRight, contentDescription = "90° aylantirish", tint = Color.White) }
        }

        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .onSizeChanged { viewport = it }
                .pointerInput(bitmap, tokens) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        var multiTouch = false
                        var dragged = false
                        var lastSingle = down.position
                        val downPosition = down.position
                        while (true) {
                            val event = awaitPointerEvent()
                            val active = event.changes.filter { it.pressed }
                            if (active.isEmpty()) {
                                if (!multiTouch && !dragged) {
                                    tokenAt(downPosition, viewport, bitmap, zoom, pan, tokens)?.let { token ->
                                        selected = if (token.key in selected) selected - token.key else selected + token.key
                                    }
                                }
                                break
                            }
                            if (active.size >= 2) {
                                multiTouch = true
                                val first = active[0]
                                val second = active[1]
                                val previousCentroid = Offset(
                                    (first.previousPosition.x + second.previousPosition.x) / 2f,
                                    (first.previousPosition.y + second.previousPosition.y) / 2f
                                )
                                val currentCentroid = Offset(
                                    (first.position.x + second.position.x) / 2f,
                                    (first.position.y + second.position.y) / 2f
                                )
                                val previousDistance = (first.previousPosition - second.previousPosition).getDistance()
                                val currentDistance = (first.position - second.position).getDistance()
                                val factor = if (previousDistance > 1f) currentDistance / previousDistance else 1f
                                val nextZoom = (zoom * factor).coerceIn(1f, 6f)
                                zoom = nextZoom
                                pan = clampPan(pan + (currentCentroid - previousCentroid), viewport, bitmap, nextZoom)
                            } else if (!multiTouch) {
                                val change = active.first()
                                val movement = change.position - lastSingle
                                if (movement.getDistance() > 3f) dragged = true
                                if (dragged) {
                                    tokenAt(change.position, viewport, bitmap, zoom, pan, tokens)?.let { token ->
                                        if (token.key !in selected) selected = selected + token.key
                                    }
                                }
                                lastSingle = change.position
                            }
                        }
                    }
                }
        ) {
            val current = bitmap
            if (current != null) {
                Canvas(Modifier.fillMaxSize()) {
                    drawOcrImage(current, zoom, pan)
                    tokens.filter { it.key in selected }.forEach { token ->
                        drawTokenHighlight(current, token, zoom, pan, accent.copy(alpha = .34f))
                    }
                }
            }
            if (detecting) {
                Surface(
                    modifier = Modifier.align(Alignment.Center),
                    shape = RoundedCornerShape(14.dp),
                    color = Color.Black.copy(alpha = .62f)
                ) {
                    Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp, color = Color.White)
                        Text("Matn aniqlanmoqda…", color = Color.White, modifier = Modifier.padding(start = 10.dp))
                    }
                }
            } else if (error != null && tokens.isEmpty()) {
                Surface(
                    modifier = Modifier.align(Alignment.Center).padding(22.dp),
                    shape = RoundedCornerShape(16.dp),
                    color = Color.Black.copy(alpha = .68f)
                ) {
                    Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(error ?: "Matn topilmadi", color = Color.White)
                        Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = onRetryCamera) { Text("Qayta olish") }
                            OutlinedButton(onClick = { replacementGallery.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) { Text("Boshqa rasm") }
                        }
                    }
                }
            }
        }

        Surface(color = MaterialTheme.colorScheme.surface) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { selected = emptySet() }, enabled = selected.isNotEmpty()) {
                    Icon(Icons.Rounded.DeleteSweep, contentDescription = "Tozalash")
                }
                IconButton(onClick = { selected = tokens.mapTo(linkedSetOf()) { it.key } }, enabled = tokens.isNotEmpty()) {
                    Icon(Icons.Rounded.SelectAll, contentDescription = "Barchasini tanlash")
                }
                Text("${selected.size} tanlandi", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Button(
                    onClick = {
                        val text = TopilmaOcrManager.selectedText(tokens, selected)
                        if (text.isNotBlank()) onConfirm(text)
                    },
                    enabled = selected.isNotEmpty()
                ) {
                    Icon(Icons.Rounded.Check, contentDescription = null)
                    Text(" Tasdiqlash")
                }
            }
        }
    }
}

private data class ImagePlacement(val left: Float, val top: Float, val scale: Float)

private fun placement(viewport: IntSize, bitmap: Bitmap?, zoom: Float, pan: Offset): ImagePlacement? {
    if (bitmap == null || viewport.width <= 0 || viewport.height <= 0 || bitmap.width <= 0 || bitmap.height <= 0) return null
    val base = min(viewport.width.toFloat() / bitmap.width, viewport.height.toFloat() / bitmap.height)
    val scale = base * zoom
    val width = bitmap.width * scale
    val height = bitmap.height * scale
    return ImagePlacement(
        left = (viewport.width - width) / 2f + pan.x,
        top = (viewport.height - height) / 2f + pan.y,
        scale = scale
    )
}

private fun tokenAt(
    position: Offset,
    viewport: IntSize,
    bitmap: Bitmap?,
    zoom: Float,
    pan: Offset,
    tokens: List<TopilmaOcrManager.Token>
): TopilmaOcrManager.Token? {
    val p = placement(viewport, bitmap, zoom, pan) ?: return null
    val x = (position.x - p.left) / p.scale
    val y = (position.y - p.top) / p.scale
    return tokens.firstOrNull { token ->
        val padding = max(3f, 5f / p.scale)
        x >= token.bounds.left - padding && x <= token.bounds.right + padding &&
            y >= token.bounds.top - padding && y <= token.bounds.bottom + padding
    }
}

private fun clampPan(candidate: Offset, viewport: IntSize, bitmap: Bitmap?, zoom: Float): Offset {
    if (bitmap == null || viewport == IntSize.Zero) return Offset.Zero
    val base = min(viewport.width.toFloat() / bitmap.width, viewport.height.toFloat() / bitmap.height)
    val width = bitmap.width * base * zoom
    val height = bitmap.height * base * zoom
    val maxX = max(0f, (width - viewport.width) / 2f + viewport.width * .18f)
    val maxY = max(0f, (height - viewport.height) / 2f + viewport.height * .18f)
    return Offset(candidate.x.coerceIn(-maxX, maxX), candidate.y.coerceIn(-maxY, maxY))
}

private fun DrawScope.drawOcrImage(bitmap: Bitmap, zoom: Float, pan: Offset) {
    val viewport = IntSize(size.width.toInt(), size.height.toInt())
    val p = placement(viewport, bitmap, zoom, pan) ?: return
    val width = (bitmap.width * p.scale).toInt().coerceAtLeast(1)
    val height = (bitmap.height * p.scale).toInt().coerceAtLeast(1)
    drawImage(
        image = bitmap.asImageBitmap(),
        srcOffset = IntOffset.Zero,
        srcSize = IntSize(bitmap.width, bitmap.height),
        dstOffset = IntOffset(p.left.toInt(), p.top.toInt()),
        dstSize = IntSize(width, height)
    )
}

private fun DrawScope.drawTokenHighlight(
    bitmap: Bitmap,
    token: TopilmaOcrManager.Token,
    zoom: Float,
    pan: Offset,
    color: Color
) {
    val viewport = IntSize(size.width.toInt(), size.height.toInt())
    val p = placement(viewport, bitmap, zoom, pan) ?: return
    val left = p.left + token.bounds.left * p.scale
    val top = p.top + token.bounds.top * p.scale
    val right = p.left + token.bounds.right * p.scale
    val bottom = p.top + token.bounds.bottom * p.scale
    drawRoundRect(
        color = color,
        topLeft = Offset(left - 2f, top - 1f),
        size = Size((right - left) + 4f, (bottom - top) + 2f),
        cornerRadius = androidx.compose.ui.geometry.CornerRadius(5f, 5f)
    )
}

private fun createOcrCacheFile(context: android.content.Context): File {
    val dir = File(context.cacheDir, "topilma-ocr").apply { mkdirs() }
    return File(dir, "ocr-${UUID.randomUUID()}.jpg")
}

private fun copyUriToOcrCache(context: android.content.Context, uri: android.net.Uri): File? = runCatching {
    val target = createOcrCacheFile(context)
    context.contentResolver.openInputStream(uri)?.use { input ->
        target.outputStream().use { output -> input.copyTo(output) }
    } ?: return null
    target
}.getOrNull()

private fun loadUprightBitmap(file: File, maxDimension: Int = 2600): Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(file.absolutePath, bounds)
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    var sample = 1
    while (max(bounds.outWidth / sample, bounds.outHeight / sample) > maxDimension * 2) sample *= 2
    val decoded = BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample }) ?: return null
    val rotation = runCatching { ExifInterface(file).rotationDegrees }.getOrDefault(0)
    return if (rotation == 0) decoded else rotateBitmap(decoded, rotation.toFloat())
}

private fun rotateBitmap(source: Bitmap, degrees: Float): Bitmap {
    if (abs(degrees) < .1f) return source
    val matrix = Matrix().apply { postRotate(degrees) }
    val rotated = Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
    return rotated
}
