package com.memora.app.ui.components

import androidx.compose.ui.unit.dp

/**
 * Single visual source of truth for Topilma cards.
 * The bitmap exporter mirrors these proportions instead of maintaining a second design.
 */
object TopilmaCardVisualSpec {
    val radius = 24.dp
    val horizontalPadding = 18.dp
    val verticalPadding = 16.dp
    val coverWidth = 58.dp
    val coverHeight = 82.dp
    val coverRadius = 7.dp
    val coverBorder = 1.dp
    val coverToText = 14.dp
    val headerToBody = 18.dp
    val bodyToTags = 14.dp
    val tagsToActions = 16.dp
    val actionHeight = 52.dp

    // High-resolution PNG export. Outer canvas is transparent; only the card + subtle shadow is shared.
    const val EXPORT_WIDTH = 1440
    const val EXPORT_OUTER = 30f
    const val EXPORT_RADIUS = 60f
    const val EXPORT_INNER = 58f
    const val EXPORT_COVER_W = 154f
    const val EXPORT_COVER_H = 218f
    const val EXPORT_COVER_RADIUS = 18f
    const val EXPORT_COVER_BORDER = 2.5f
    const val EXPORT_HEADER_TO_BODY = 46f
    const val EXPORT_ACTION_HEIGHT = 132f
}
