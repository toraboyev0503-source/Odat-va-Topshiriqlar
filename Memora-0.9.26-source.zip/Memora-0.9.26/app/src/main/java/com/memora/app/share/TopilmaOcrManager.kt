package com.memora.app.share

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Rect
import androidx.core.content.FileProvider
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import kotlin.coroutines.resume
import kotlinx.coroutines.suspendCancellableCoroutine

/**
 * Topilma OCR support.
 *
 * The main capture flow uses bundled ML Kit Latin text recognition, which runs on-device.
 * [open] is retained for the legacy image-detail action so older UI paths keep working.
 */
object TopilmaOcrManager {
    data class Token(
        val blockIndex: Int,
        val lineIndex: Int,
        val tokenIndex: Int,
        val text: String,
        val bounds: Rect
    ) {
        val key: String get() = "$blockIndex:$lineIndex:$tokenIndex"
    }

    suspend fun recognize(bitmap: Bitmap): Result<List<Token>> = suspendCancellableCoroutine { continuation ->
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val task = recognizer.process(InputImage.fromBitmap(bitmap, 0))
        task
            .addOnSuccessListener { result ->
                val tokens = buildList {
                    result.textBlocks.forEachIndexed { blockIndex, block ->
                        block.lines.forEachIndexed { lineIndex, line ->
                            line.elements.forEachIndexed { tokenIndex, element ->
                                val box = element.boundingBox ?: return@forEachIndexed
                                val text = element.text.trim()
                                if (text.isNotBlank()) {
                                    add(Token(blockIndex, lineIndex, tokenIndex, text, Rect(box)))
                                }
                            }
                        }
                    }
                }
                if (continuation.isActive) continuation.resume(Result.success(tokens))
                recognizer.close()
            }
            .addOnFailureListener { error ->
                if (continuation.isActive) continuation.resume(Result.failure(error))
                recognizer.close()
            }
        continuation.invokeOnCancellation { recognizer.close() }
    }

    fun selectedText(tokens: List<Token>, selectedKeys: Set<String>): String {
        val selected = tokens
            .filter { it.key in selectedKeys }
            .sortedWith(compareBy<Token> { it.blockIndex }.thenBy { it.lineIndex }.thenBy { it.tokenIndex })
        if (selected.isEmpty()) return ""

        return selected
            .groupBy { it.blockIndex }
            .toSortedMap()
            .values
            .joinToString("\n\n") { blockTokens ->
                blockTokens
                    .groupBy { it.lineIndex }
                    .toSortedMap()
                    .values
                    .joinToString(" ") { lineTokens ->
                        lineTokens.sortedBy { it.tokenIndex }.joinToString(" ") { it.text }
                    }
                    .replace(Regex("\\s+"), " ")
                    .trim()
            }
            .trim()
    }

    fun open(context: Context, image: File, mimeType: String) {
        val directory = File(context.cacheDir, "shares").apply { mkdirs() }
        val shared = File(directory, "ocr-${image.name}")
        image.inputStream().use { input -> shared.outputStream().use { input.copyTo(it) } }
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", shared)
        val base = Intent(Intent.ACTION_SEND).apply {
            type = mimeType.ifBlank { "image/*" }
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val lens = Intent(base).setPackage("com.google.ar.lens")
        val target = if (lens.resolveActivity(context.packageManager) != null) lens else Intent.createChooser(base, "Matnni aniqlash")
        context.startActivity(target)
    }
}
