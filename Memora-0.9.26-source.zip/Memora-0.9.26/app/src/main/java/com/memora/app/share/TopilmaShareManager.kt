package com.memora.app.share

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.FileProvider
import com.memora.app.data.local.TopilmaCardRow
import com.memora.app.media.TopilmalarMediaStorage
import com.memora.app.ui.components.TopilmaCardVisualSpec
import com.memora.app.ui.components.presentation
import java.io.File
import java.io.FileOutputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object TopilmaShareManager {
    fun shareText(context: Context, card: TopilmaCardRow, includeSource: Boolean) {
        val presentation = card.presentation()
        val text = buildString {
            append(presentation.body)
            if (includeSource && presentation.title.isNotBlank()) {
                append("\n\n— ").append(presentation.title)
                if (presentation.author.isNotBlank()) append(", ").append(presentation.author)
            }
            if (presentation.tags.isNotEmpty()) append("\n\n").append(presentation.tags.joinToString(" ") { "#$it" })
        }
        context.startActivity(
            Intent.createChooser(
                Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, text)
                },
                "Topilmani ulashish"
            )
        )
    }

    /** Export always renders the complete card, never the 2-line list state. */
    suspend fun shareCardImage(context: Context, card: TopilmaCardRow) {
        val uri = withContext(Dispatchers.IO) {
            val bitmap = renderCardBitmap(context, card)
            val directory = File(context.cacheDir, "shares").apply { mkdirs() }
            val file = File(directory, humanReadableShareName(card))
            FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            bitmap.recycle()
            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        }
        withContext(Dispatchers.Main) {
            context.startActivity(
                Intent.createChooser(
                    Intent(Intent.ACTION_SEND).apply {
                        type = "image/png"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    },
                    "Kartochka rasmini ulashish"
                )
            )
        }
    }

    /** Reused by Obsidian sync so shared and synced cards are pixel-identical. */
    fun renderCardBitmap(context: Context, card: TopilmaCardRow): Bitmap {
        val spec = TopilmaCardVisualSpec
        val presentation = card.presentation()
        val width = spec.EXPORT_WIDTH
        val outer = spec.EXPORT_OUTER
        val cardLeft = outer
        val cardRight = width - outer
        val innerLeft = cardLeft + spec.EXPORT_INNER
        val innerRight = cardRight - spec.EXPORT_INNER
        val contentWidth = (innerRight - innerLeft).toInt()

        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(37, 38, 38)
            textSize = 54f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        val authorPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(112, 112, 112)
            textSize = 40f
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        }
        val bodyPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(35, 35, 34)
            textSize = when {
                presentation.body.length < 170 -> 62f
                presentation.body.length < 430 -> 56f
                presentation.body.length < 900 -> 49f
                else -> 44f
            }
            typeface = Typeface.create(Typeface.SERIF, Typeface.NORMAL)
        }

        val coverW = spec.EXPORT_COVER_W
        val coverH = spec.EXPORT_COVER_H
        val headerTextWidth = (contentWidth - coverW - 42f - 78f).toInt().coerceAtLeast(380)
        val titleLayout = StaticLayout.Builder.obtain(presentation.title, 0, presentation.title.length, titlePaint, headerTextWidth)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setMaxLines(2)
            .setEllipsize(android.text.TextUtils.TruncateAt.END)
            .setLineSpacing(2f, 1f)
            .build()
        val authorLayout = presentation.author.takeIf { it.isNotBlank() }?.let { author ->
            StaticLayout.Builder.obtain(author, 0, author.length, authorPaint, headerTextWidth)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setMaxLines(1)
                .setEllipsize(android.text.TextUtils.TruncateAt.END)
                .build()
        }
        val bodyLayout = StaticLayout.Builder.obtain(presentation.body, 0, presentation.body.length, bodyPaint, contentWidth)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setLineSpacing(13f, 1f)
            .build()

        val cardTop = outer
        val headerTop = cardTop + 58f
        val headerHeight = maxOf(coverH, titleLayout.height.toFloat() + (authorLayout?.height ?: 0) + 13f)
        val bodyTop = headerTop + headerHeight + spec.EXPORT_HEADER_TO_BODY
        val tagRows = layoutTagRows(presentation.tags, contentWidth)
        val tagsHeight = if (tagRows == 0) 0f else 59f * tagRows + 18f
        val bodyBottom = bodyTop + bodyLayout.height
        val actionTop = bodyBottom + 48f + tagsHeight
        val cardBottom = maxOf(actionTop + spec.EXPORT_ACTION_HEIGHT + 24f, cardTop + 820f)
        val bitmapHeight = (cardBottom + outer).toInt()

        val bitmap = Bitmap.createBitmap(width, bitmapHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.TRANSPARENT)

        val cardPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            setShadowLayer(14f, 0f, 5f, Color.argb(28, 0, 0, 0))
        }
        canvas.drawRoundRect(cardLeft, cardTop, cardRight, cardBottom, spec.EXPORT_RADIUS, spec.EXPORT_RADIUS, cardPaint)

        drawCover(context, canvas, card, innerLeft, headerTop, coverW, coverH)

        val textLeft = innerLeft + coverW + 38f
        canvas.save(); canvas.translate(textLeft, headerTop + 2f); titleLayout.draw(canvas); canvas.restore()
        authorLayout?.let {
            canvas.save(); canvas.translate(textLeft, headerTop + titleLayout.height + 11f); it.draw(canvas); canvas.restore()
        }

        // Same light horizontal three-dot affordance as the in-app master card.
        val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(119, 119, 118) }
        val dotY = headerTop + 31f
        val dotX = innerRight - 28f
        listOf(-19f, 0f, 19f).forEach { offset -> canvas.drawCircle(dotX + offset, dotY, 5.2f, dotPaint) }

        canvas.save(); canvas.translate(innerLeft, bodyTop); bodyLayout.draw(canvas); canvas.restore()

        var tagY = bodyBottom + 34f
        if (presentation.tags.isNotEmpty()) {
            val tagTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(88, 102, 161)
                textSize = 31f
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            }
            val tagBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(242, 242, 249) }
            var x = innerLeft
            presentation.tags.forEach { tag ->
                val label = "#$tag"
                val w = tagTextPaint.measureText(label) + 42f
                if (x + w > innerRight) { x = innerLeft; tagY += 59f }
                canvas.drawRoundRect(x, tagY, x + w, tagY + 46f, 23f, 23f, tagBg)
                canvas.drawText(label, x + 21f, tagY + 32f, tagTextPaint)
                x += w + 16f
            }
        }

        drawActions(canvas, card, innerLeft, innerRight, actionTop)
        return bitmap
    }

    private fun drawCover(context: Context, canvas: Canvas, card: TopilmaCardRow, left: Float, top: Float, width: Float, height: Float) {
        val spec = TopilmaCardVisualSpec
        val rect = RectF(left, top, left + width, top + height)
        val framePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.FILL
            setShadowLayer(2f, 0f, 1f, Color.argb(25, 0, 0, 0))
        }
        canvas.drawRoundRect(rect, spec.EXPORT_COVER_RADIUS, spec.EXPORT_COVER_RADIUS, framePaint)
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(222, 222, 222)
            style = Paint.Style.STROKE
            strokeWidth = spec.EXPORT_COVER_BORDER
        }
        canvas.drawRoundRect(rect, spec.EXPORT_COVER_RADIUS, spec.EXPORT_COVER_RADIUS, borderPaint)

        val thumbnail = card.sourceCoverPath?.let { relativePath ->
            runCatching { decodeThumbnail(TopilmalarMediaStorage(context).resolve(relativePath), 520) }.getOrNull()
        }
        if (thumbnail != null) {
            val inset = 3f
            val available = RectF(rect.left + inset, rect.top + inset, rect.right - inset, rect.bottom - inset)
            val scale = minOf(available.width() / thumbnail.width, available.height() / thumbnail.height)
            val drawW = thumbnail.width * scale
            val drawH = thumbnail.height * scale
            val dst = RectF(
                available.centerX() - drawW / 2f,
                available.centerY() - drawH / 2f,
                available.centerX() + drawW / 2f,
                available.centerY() + drawH / 2f
            )
            canvas.save()
            val clip = Path().apply { addRoundRect(available, spec.EXPORT_COVER_RADIUS - 2f, spec.EXPORT_COVER_RADIUS - 2f, Path.Direction.CW) }
            canvas.clipPath(clip)
            canvas.drawBitmap(thumbnail, null, dst, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
            canvas.restore()
            thumbnail.recycle()
        } else {
            val fallback = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(236, 241, 238) }
            canvas.drawRoundRect(rect, spec.EXPORT_COVER_RADIUS, spec.EXPORT_COVER_RADIUS, fallback)
            canvas.drawText("M", rect.centerX() - 22f, rect.centerY() + 20f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(64, 100, 84); textSize = 58f; typeface = Typeface.DEFAULT_BOLD
            })
        }
    }

    private fun drawActions(canvas: Canvas, card: TopilmaCardRow, innerLeft: Float, innerRight: Float, actionTop: Float) {
        val actionY = actionTop + 62f
        val iconColor = Color.rgb(56, 58, 57)
        val muted = Color.rgb(96, 98, 97)
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = iconColor; strokeWidth = 6f; style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        }
        val countPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = muted; textSize = 34f; typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        }
        val third = (innerRight - innerLeft) / 3f
        val shareX = innerLeft + third / 2f
        val heartX = innerLeft + third * 1.5f
        val commentX = innerLeft + third * 2.5f

        // Material-style Share: three connected nodes, matching the in-app Icons.Rounded.Share glyph.
        val sharePath = Path().apply {
            moveTo(shareX - 18f, actionY)
            lineTo(shareX + 20f, actionY - 24f)
            moveTo(shareX - 18f, actionY)
            lineTo(shareX + 20f, actionY + 24f)
        }
        canvas.drawPath(sharePath, stroke)
        val nodeFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = iconColor; style = Paint.Style.FILL }
        canvas.drawCircle(shareX - 24f, actionY, 10f, nodeFill)
        canvas.drawCircle(shareX + 27f, actionY - 29f, 10f, nodeFill)
        canvas.drawCircle(shareX + 27f, actionY + 29f, 10f, nodeFill)

        val heartPath = Path().apply {
            moveTo(heartX, actionY + 38f)
            cubicTo(heartX - 62f, actionY - 2f, heartX - 43f, actionY - 47f, heartX - 17f, actionY - 34f)
            cubicTo(heartX - 6f, actionY - 29f, heartX, actionY - 16f, heartX, actionY - 16f)
            cubicTo(heartX, actionY - 16f, heartX + 6f, actionY - 29f, heartX + 17f, actionY - 34f)
            cubicTo(heartX + 43f, actionY - 47f, heartX + 62f, actionY - 2f, heartX, actionY + 38f)
            close()
        }
        val heartPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (card.likeCount > 0) Color.rgb(219, 104, 113) else iconColor
            style = if (card.likeCount > 0) Paint.Style.FILL else Paint.Style.STROKE
            strokeWidth = 6f
        }
        canvas.drawPath(heartPath, heartPaint)
        if (card.likeCount > 0) canvas.drawText(card.likeCount.toString(), heartX + 57f, actionY + 12f, countPaint)

        val bubble = RectF(commentX - 34f, actionY - 32f, commentX + 34f, actionY + 24f)
        canvas.drawRoundRect(bubble, 14f, 14f, stroke)
        val tail = Path().apply {
            moveTo(commentX - 9f, actionY + 24f); lineTo(commentX - 20f, actionY + 43f); lineTo(commentX + 4f, actionY + 25f)
        }
        canvas.drawPath(tail, stroke)
        if (card.commentCount > 0) canvas.drawText(card.commentCount.toString(), commentX + 51f, actionY + 12f, countPaint)
    }

    private fun layoutTagRows(tags: List<String>, contentWidth: Int): Int {
        if (tags.isEmpty()) return 0
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 31f }
        var rows = 1
        var used = 0f
        for (tag in tags) {
            val width = paint.measureText("#$tag") + 58f
            if (used > 0f && used + width > contentWidth) { rows++; used = 0f }
            used += width
        }
        return rows
    }

    private fun humanReadableShareName(card: TopilmaCardRow): String {
        val p = card.presentation()
        val raw = buildString {
            append("Topilma - ").append(p.title)
            if (p.author.isNotBlank()) append(" - ").append(p.author)
        }
        val safe = raw.replace(Regex("[\\/:*?\"<>|]"), "-").replace(Regex("\\s+"), " ").trim().take(110)
        return "$safe.png"
    }

    private fun decodeThumbnail(file: File, target: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (bounds.outWidth / sample > target * 2 || bounds.outHeight / sample > target * 2) sample *= 2
        return BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
    }
}
