package com.memora.app.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memora.app.i18n.L
import com.memora.app.i18n.S
import com.memora.app.prefs.AppLanguage
import com.memora.app.reflections.HomeReflection
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first

private val TiniqSage = Color(0xFF789786)
private val TiniqLavender = Color(0xFFE9E1F2)
private val TiniqMist = Color(0xFFDDEAF1)
private val TiniqInk = Color(0xFF202923)
private val TiniqMuted = Color(0xFF6F7973)

@Composable
fun HomeScreen(
    language: AppLanguage,
    shortCount: Int,
    longCount: Int,
    isDark: Boolean,
    reflection: HomeReflection?,
    onReflectionSeen: (HomeReflection) -> Unit,
    onToggleDark: () -> Unit,
    onShort: () -> Unit,
    onLong: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            HomeHeader(
                language = language,
                isDark = isDark,
                onToggleDark = onToggleDark
            )

            Column(Modifier.padding(horizontal = 24.dp)) {
                HomeNoteTypeCard(
                    title = L.t(language, S.SHORT_NOTES),
                    count = shortCount,
                    language = language,
                    icon = {
                        Icon(
                            Icons.Rounded.Description,
                            contentDescription = null,
                            tint = TiniqSage,
                            modifier = Modifier.size(32.dp)
                        )
                    },
                    tint = TiniqMist,
                    onClick = onShort
                )
                Spacer(Modifier.height(16.dp))
                HomeNoteTypeCard(
                    title = L.t(language, S.LONG_NOTES),
                    count = longCount,
                    language = language,
                    icon = {
                        Icon(
                            Icons.Rounded.MenuBook,
                            contentDescription = null,
                            tint = Color(0xFF7777A8),
                            modifier = Modifier.size(32.dp)
                        )
                    },
                    tint = TiniqLavender,
                    onClick = onLong
                )
            }

            // The reflection owns the entire remaining viewport above the bottom navigation.
            // When it fits, it is centered with exactly the same breathing room above and below.
            // If a larger UI scale or a longer translation needs more room, only this region scrolls
            // instead of shrinking or clipping the text/frame.
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                val reflectionScroll = rememberScrollState()
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = maxHeight)
                        .verticalScroll(reflectionScroll)
                        .padding(horizontal = 24.dp),
                    verticalArrangement = Arrangement.Center
                ) {
                    Spacer(Modifier.height(24.dp))
                    HomeReflectionStage(
                        reflection = reflection,
                        isDark = isDark,
                        onSeen = onReflectionSeen
                    )
                    Spacer(Modifier.height(24.dp))
                }
            }
        }
    }
}

@Composable
private fun HomeHeader(
    language: AppLanguage,
    isDark: Boolean,
    onToggleDark: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 28.dp, end = 28.dp, top = 28.dp, bottom = 22.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                "Memora",
                style = MaterialTheme.typography.displayMedium.copy(fontSize = 44.sp),
                fontWeight = FontWeight.SemiBold,
                color = if (isDark) MaterialTheme.colorScheme.onBackground else TiniqInk
            )
            Text(
                L.t(language, S.HOME_TAGLINE),
                style = MaterialTheme.typography.bodyLarge.copy(fontSize = 18.sp),
                color = if (isDark) MaterialTheme.colorScheme.onSurfaceVariant else TiniqMuted,
                modifier = Modifier.padding(top = 1.dp)
            )
        }

        Surface(
            shape = CircleShape,
            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.88f),
            shadowElevation = 2.dp
        ) {
            IconButton(onClick = onToggleDark, modifier = Modifier.size(52.dp)) {
                Icon(
                    if (isDark) Icons.Rounded.DarkMode else Icons.Rounded.LightMode,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

@Composable
private fun HomeNoteTypeCard(
    title: String,
    count: Int,
    language: AppLanguage,
    icon: @Composable () -> Unit,
    tint: Color,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(26.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.985f),
        shadowElevation = 1.dp
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 21.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = tint.copy(alpha = 0.66f),
                modifier = Modifier.size(68.dp)
            ) {
                Box(contentAlignment = Alignment.Center) { icon() }
            }
            Column(Modifier.weight(1f).padding(start = 20.dp)) {
                Text(
                    title,
                    style = MaterialTheme.typography.headlineSmall.copy(fontSize = 26.sp),
                    fontWeight = FontWeight.Medium
                )
                Text(
                    "$count ${L.t(language, S.NOTES)}",
                    style = MaterialTheme.typography.bodyLarge.copy(fontSize = 17.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 3.dp)
                )
            }
            Icon(
                Icons.Rounded.ArrowForward,
                contentDescription = null,
                modifier = Modifier.size(27.dp)
            )
        }
    }
}

@Composable
private fun HomeReflectionStage(
    reflection: HomeReflection?,
    isDark: Boolean,
    onSeen: (HomeReflection) -> Unit
) {
    val frameProgress = remember(reflection?.id) { Animatable(0f) }
    val quoteProgress = remember(reflection?.id) { Animatable(0f) }
    val lineProgress = remember(reflection?.id) { Animatable(0f) }
    var visibleLines by remember(reflection?.id) { mutableIntStateOf(0) }
    var textLayout by remember(reflection?.id) { mutableStateOf<TextLayoutResult?>(null) }
    var seenCommitted by remember(reflection?.id) { mutableStateOf(false) }

    LaunchedEffect(reflection?.id) {
        val item = reflection ?: return@LaunchedEffect
        // The stage deliberately stays empty for the first five seconds on Home.
        delay(5_000)
        frameProgress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 850, easing = FastOutSlowInEasing)
        )
        quoteProgress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 280, easing = FastOutSlowInEasing)
        )
        lineProgress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 430, easing = FastOutSlowInEasing)
        )

        val count = snapshotFlow { textLayout?.lineCount ?: 0 }.first { it > 0 }
        for (line in 1..count) {
            visibleLines = line
            // Deliberately unhurried: each line materialises before the next begins.
            delay(250)
        }

        // A reflection counts as seen only after the complete text has been visible for one second.
        delay(1_000)
        if (!seenCommitted) {
            seenCommitted = true
            onSeen(item)
        }
    }

    val layout = textLayout
    val revealBottomTarget = when {
        visibleLines <= 0 || layout == null -> 0f
        else -> layout.getLineBottom((visibleLines - 1).coerceAtMost(layout.lineCount - 1))
    }
    val revealBottom by animateFloatAsState(
        targetValue = revealBottomTarget,
        animationSpec = tween(durationMillis = 300, easing = FastOutSlowInEasing),
        label = "reflectionTextReveal"
    )

    val frameColor = if (isDark) {
        MaterialTheme.colorScheme.primary.copy(alpha = 0.58f)
    } else {
        TiniqSage.copy(alpha = 0.62f)
    }
    val textColor = if (isDark) MaterialTheme.colorScheme.onSurface else TiniqInk

    // No fixed height: the final text is laid out first (while still visually hidden),
    // so the frame always wraps the real content at the current UI scale and language.
    // This prevents clipping for longer translations and when the user increases scale.
    Box(
        modifier = Modifier.fillMaxWidth(),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.matchParentSize()) {
            if (frameProgress.value <= 0f) return@Canvas
            val p = frameProgress.value
            val inset = 2.dp.toPx()
            val stroke = 1.25.dp.toPx()
            val radius = 28.dp.toPx()
            val w = size.width - inset * 2f
            val h = size.height - inset * 2f
            val left = inset
            val top = inset
            val right = inset + w
            val bottom = inset + h
            val horizontal = (w - radius * 2f).coerceAtLeast(0f)
            val vertical = (h - radius * 2f).coerceAtLeast(0f)

            // Two origins: top-left grows right/down; bottom-right grows left/up.
            drawLine(
                color = frameColor,
                start = Offset(left + radius, top),
                end = Offset(left + radius + horizontal * p, top),
                strokeWidth = stroke,
                cap = StrokeCap.Round
            )
            drawLine(
                color = frameColor,
                start = Offset(left, top + radius),
                end = Offset(left, top + radius + vertical * p),
                strokeWidth = stroke,
                cap = StrokeCap.Round
            )
            drawLine(
                color = frameColor,
                start = Offset(right - radius, bottom),
                end = Offset(right - radius - horizontal * p, bottom),
                strokeWidth = stroke,
                cap = StrokeCap.Round
            )
            drawLine(
                color = frameColor,
                start = Offset(right, bottom - radius),
                end = Offset(right, bottom - radius - vertical * p),
                strokeWidth = stroke,
                cap = StrokeCap.Round
            )

            drawArc(
                color = frameColor,
                startAngle = 180f,
                sweepAngle = 90f,
                useCenter = false,
                topLeft = Offset(left, top),
                size = androidx.compose.ui.geometry.Size(radius * 2f, radius * 2f),
                style = Stroke(stroke, cap = StrokeCap.Round)
            )
            drawArc(
                color = frameColor,
                startAngle = 0f,
                sweepAngle = 90f,
                useCenter = false,
                topLeft = Offset(right - radius * 2f, bottom - radius * 2f),
                size = androidx.compose.ui.geometry.Size(radius * 2f, radius * 2f),
                style = Stroke(stroke, cap = StrokeCap.Round)
            )

            val finish = ((p - 0.88f) / 0.12f).coerceIn(0f, 1f)
            if (finish > 0f) {
                drawArc(
                    color = frameColor.copy(alpha = frameColor.alpha * finish),
                    startAngle = 270f,
                    sweepAngle = 90f,
                    useCenter = false,
                    topLeft = Offset(right - radius * 2f, top),
                    size = androidx.compose.ui.geometry.Size(radius * 2f, radius * 2f),
                    style = Stroke(stroke, cap = StrokeCap.Round)
                )
                drawArc(
                    color = frameColor.copy(alpha = frameColor.alpha * finish),
                    startAngle = 90f,
                    sweepAngle = 90f,
                    useCenter = false,
                    topLeft = Offset(left, bottom - radius * 2f),
                    size = androidx.compose.ui.geometry.Size(radius * 2f, radius * 2f),
                    style = Stroke(stroke, cap = StrokeCap.Round)
                )
            }
        }

        if (reflection != null) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 26.dp, vertical = 22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(58.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(Modifier.fillMaxSize()) {
                        val p = lineProgress.value
                        if (p > 0f) {
                            val y = size.height * 0.54f
                            val gap = 34.dp.toPx()
                            val edge = 18.dp.toPx()
                            val cx = size.width / 2f
                            val leftTarget = cx - gap
                            val rightTarget = cx + gap
                            drawLine(
                                color = frameColor.copy(alpha = 0.72f),
                                start = Offset(edge, y),
                                end = Offset(edge + (leftTarget - edge) * p, y),
                                strokeWidth = 1.1.dp.toPx(),
                                cap = StrokeCap.Round
                            )
                            drawLine(
                                color = frameColor.copy(alpha = 0.72f),
                                start = Offset(size.width - edge, y),
                                end = Offset(size.width - edge - (size.width - edge - rightTarget) * p, y),
                                strokeWidth = 1.1.dp.toPx(),
                                cap = StrokeCap.Round
                            )
                        }
                    }
                    Text(
                        text = "“",
                        fontSize = 48.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = frameColor.copy(alpha = quoteProgress.value),
                        modifier = Modifier.padding(top = 10.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp)
                ) {
                    Text(
                        text = reflection.text,
                        style = MaterialTheme.typography.bodyLarge.copy(
                            fontSize = 19.sp,
                            lineHeight = 27.sp,
                            fontStyle = FontStyle.Normal
                        ),
                        color = textColor,
                        textAlign = TextAlign.Center,
                        onTextLayout = { textLayout = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .drawWithContent {
                                if (revealBottom > 0f) {
                                    clipRect(
                                        left = 0f,
                                        top = 0f,
                                        right = size.width,
                                        bottom = revealBottom.coerceAtMost(size.height)
                                    ) {
                                        this@drawWithContent.drawContent()
                                    }
                                }
                            }
                    )
                }
            }
        }
    }
}
