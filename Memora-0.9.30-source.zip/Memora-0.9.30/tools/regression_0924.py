#!/usr/bin/env python3
"""Static acceptance gate for Memora 0.9.24 / Kotlin compile-fix + Obsidian + master Topilma card.

The Android build, unit tests and lint remain separate Gradle steps in CI. This
gate catches removed-content regressions, migration/schema mistakes and missing
frozen Topilmalar integration points before Gradle starts.
"""

from pathlib import Path
import re
import sqlite3
import sys
import xml.etree.ElementTree as ET


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app/src/main"
SRC = APP / "java/com/memora/app"
checks: list[tuple[str, bool, str]] = []
failures: list[str] = []


def read(relative: str) -> str:
    path = ROOT / relative
    if not path.is_file():
        failures.append(f"missing file: {relative}")
        return ""
    return path.read_text(encoding="utf-8", errors="replace")


def require(name: str, condition: bool, detail: str = "") -> None:
    checks.append((name, bool(condition), detail))
    if not condition:
        failures.append(name + (f": {detail}" if detail else ""))


def kotlin_delimiters(path: Path) -> tuple[bool, str]:
    """Balance code delimiters while ignoring comments and string/char bodies."""
    source = path.read_text(encoding="utf-8", errors="replace")
    stack: list[tuple[str, int]] = []
    pairs = {")": "(", "]": "[", "}": "{"}
    i = 0
    line = 1
    block_depth = 0
    while i < len(source):
        if source[i] == "\n":
            line += 1
        if block_depth:
            if source.startswith("/*", i):
                block_depth += 1
                i += 2
                continue
            if source.startswith("*/", i):
                block_depth -= 1
                i += 2
                continue
            i += 1
            continue
        if source.startswith("//", i):
            end = source.find("\n", i + 2)
            i = len(source) if end < 0 else end
            continue
        if source.startswith("/*", i):
            block_depth = 1
            i += 2
            continue
        if source.startswith('"""', i):
            end = source.find('"""', i + 3)
            if end < 0:
                return False, f"unterminated triple string near line {line}"
            line += source[i:end + 3].count("\n")
            i = end + 3
            continue
        if source[i] in {'"', "'"}:
            quote = source[i]
            i += 1
            while i < len(source):
                if source[i] == "\n":
                    line += 1
                if source[i] == "\\":
                    i += 2
                    continue
                if source[i] == quote:
                    i += 1
                    break
                i += 1
            else:
                return False, f"unterminated literal near line {line}"
            continue
        char = source[i]
        if char in "([{":
            stack.append((char, line))
        elif char in ")]}":
            if not stack or stack[-1][0] != pairs[char]:
                return False, f"unmatched {char} at line {line}"
            stack.pop()
        i += 1
    if block_depth:
        return False, "unterminated block comment"
    if stack:
        return False, f"unclosed {stack[-1][0]} from line {stack[-1][1]}"
    return True, ""


gradle = read("app/build.gradle.kts")
manifest = read("app/src/main/AndroidManifest.xml")
entities = read("app/src/main/java/com/memora/app/data/local/Entities.kt")
daos = read("app/src/main/java/com/memora/app/data/local/TopilmalarDaos.kt")
database = read("app/src/main/java/com/memora/app/data/local/AppDatabase.kt")
repository = read("app/src/main/java/com/memora/app/data/repository/TopilmalarRepository.kt")
policy = read("app/src/main/java/com/memora/app/data/repository/TopilmaReviewPolicy.kt")
policy_test = read("app/src/test/java/com/memora/app/data/repository/TopilmaReviewPolicyTest.kt")
screen = read("app/src/main/java/com/memora/app/ui/screens/TopilmalarScreen.kt")
card_component = read("app/src/main/java/com/memora/app/ui/components/TopilmaCard.kt")
comments_screen = read("app/src/main/java/com/memora/app/ui/screens/TopilmaCommentsScreen.kt")
create_flow = read("app/src/main/java/com/memora/app/ui/screens/TopilmaCreateFlow.kt")
new_note_sheet = read("app/src/main/java/com/memora/app/ui/components/NewNoteSheet.kt")
navigation = read("app/src/main/java/com/memora/app/ui/MemoraApp.kt")
bottom_bar = read("app/src/main/java/com/memora/app/ui/components/MemoraBottomBar.kt")
home = read("app/src/main/java/com/memora/app/ui/screens/HomeScreen.kt")
share_activity = read("app/src/main/java/com/memora/app/share/TopilmalarShareActivity.kt")
metadata_worker = read("app/src/main/java/com/memora/app/share/TopilmalarMetadataWorker.kt")
share_manager = read("app/src/main/java/com/memora/app/share/TopilmaShareManager.kt")
ocr = read("app/src/main/java/com/memora/app/share/TopilmaOcrManager.kt")
preferences = read("app/src/main/java/com/memora/app/prefs/UserPreferences.kt")
notifications = read("app/src/main/java/com/memora/app/notifications/TopilmalarReviewScheduler.kt")
export_manager = read("app/src/main/java/com/memora/app/export/ExportManager.kt")
backup_codec = read("app/src/main/java/com/memora/app/export/TopilmalarBackupCodec.kt")
document_writer = read("app/src/main/java/com/memora/app/export/TopilmalarDocumentWriter.kt")
reader = read("app/src/main/java/com/memora/app/ui/screens/ReaderScreen.kt")
editor = read("app/src/main/java/com/memora/app/ui/screens/EditorScreen.kt")
media = read("app/src/main/java/com/memora/app/ui/components/MediaBlocks.kt")
time_trace = read("app/src/main/java/com/memora/app/ui/screens/TimeTraceScreen.kt")
main_activity = read("app/src/main/java/com/memora/app/MainActivity.kt")
workflow = read(".github/workflows/main.yml")
obsidian = read("app/src/main/java/com/memora/app/obsidian/ObsidianSyncManager.kt")
obsidian_screen = read("app/src/main/java/com/memora/app/ui/screens/ObsidianScreen.kt")
settings_hub = read("app/src/main/java/com/memora/app/ui/screens/SettingsHubV2Screen.kt")
main_app = read("app/src/main/java/com/memora/app/MemoraApplication.kt")
memora_repo = read("app/src/main/java/com/memora/app/data/repository/MemoraRepository.kt")
hashtags = read("app/src/main/java/com/memora/app/util/HashtagUtils.kt")
hashtag_chips = read("app/src/main/java/com/memora/app/ui/components/HashtagChips.kt")
hashtag_transform = read("app/src/main/java/com/memora/app/ui/components/HashtagVisualTransformation.kt")
visual_spec = read("app/src/main/java/com/memora/app/ui/components/TopilmaCardVisualSpec.kt")
rich_editor = read("app/src/main/java/com/memora/app/ui/components/RichTextEditor.kt")
note_card = read("app/src/main/java/com/memora/app/ui/components/NoteCard.kt")

# Release identity and baseline safety.
require("versionName 0.9.24", 'versionName = "0.9.24"' in gradle)
require("versionCode 44+", bool(re.search(r"versionCode\s*=\s*(?:4[3-9]|[5-9]\d|\d{3,})", gradle)))
require("package name preserved", 'applicationId = "com.memora.app"' in gradle)
require("stable debug signing preserved", "keystore/memora-test-debug.jks" in gradle)
require("billing/backend preserved", (SRC / "billing/SubscriptionManager.kt").is_file() and (ROOT / "backend").is_dir())

# Old daily-question feature must be gone, including runtime content.
reflection_assets = APP / "assets/reflections"
require("old reflection manager removed", not (SRC / "reflections/HomeReflectionManager.kt").exists())
require("old reflection runtime dataset removed", not reflection_assets.exists() or not any(reflection_assets.iterdir()))
require("Home no daily-question manager", "HomeReflectionManager" not in navigation + home)

# Data model, migration and performance foundations.
tables = [
    "topilma_sources", "topilma_cards", "topilma_comments", "topilma_images",
    "topilma_tags", "topilma_card_tags", "topilma_source_tags",
    "topilma_review_events", "topilma_review_sessions", "topilma_review_session_items",
]
require("all Topilmalar Room entities declared", all(f'tableName = "{name}"' in entities for name in tables))
require("Room database version 8", "version = 8" in database)
require("non-destructive 5→6→7→8 migrations", all(token in database for token in ["Migration(5, 6)", "MIGRATION_5_6", "Migration(6, 7)", "MIGRATION_6_7", "ADD COLUMN likeCount", "Migration(7, 8)", "MIGRATION_7_8", "ADD COLUMN hashtagsJson", "obsidian_sync_records"]) and "fallbackToDestructiveMigration" not in database)
require("Topilmalar indexes present", all(token in database for token in ["nextReviewAt", "contentFingerprint", "normalizedTitle_normalizedAuthor", "cardId_createdAt"]))
require("manual paging limit present", "LIMIT :limit" in daos and "Ko‘proq yuklash" in screen)
require("search covers cards/comments/tags/sources", all(token in daos for token in ["c.text LIKE", "s.title LIKE", "s.author LIKE", "topilma_comments", "topilma_card_tags"]))

# Execute migration SQL against SQLite to catch malformed statements and names.
migration = database[database.find("MIGRATION_5_6"):database.find("@Volatile")]
sql_statements = []
for triple_plain, triple_trimmed, quoted in re.findall(r'db\.execSQL\(\s*(?:"""(.*?)"""|"""(.*?)"""\.trimIndent\(\)|"([^"]*)")\s*\)', migration, re.S):
    sql_statements.append(triple_plain or triple_trimmed or quoted)
try:
    connection = sqlite3.connect(":memory:")
    # v7→v8 adds a column to the pre-existing notes table; seed its minimal v7 shape.
    connection.execute("CREATE TABLE notes (id TEXT PRIMARY KEY)")
    for statement in sql_statements:
        connection.execute(statement)
    found_tables = {row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    sql_ok = all(name in found_tables for name in tables)
    sql_detail = f"{len(sql_statements)} SQL statements; {len(found_tables)} tables"
except Exception as exc:  # pragma: no cover - diagnostic path
    sql_ok = False
    sql_detail = str(exc)
finally:
    if "connection" in locals():
        connection.close()
require("migration SQL smoke test", sql_ok, sql_detail)

# Android Share capture and metadata behavior.
require("share target label", "Memora — Topilmalarga saqlash" in read("app/src/main/res/values/strings.xml"))
require("SEND and SEND_MULTIPLE target", all(token in manifest for token in ["TopilmalarShareActivity", "android.intent.action.SEND", "android.intent.action.SEND_MULTIPLE", 'android:mimeType="text/*"', 'android:mimeType="image/*"']))
require("quick save is immediate/local", "saveImmediately(intent)" in share_activity and "topilmalarRepository.capture" in share_activity)
require("quick actions preserved", all(token in share_activity for token in ["Topilmalarga saqlandi ✓", "Izoh", "Manba", "Bekor qilish"]))
require("origin app name/icon captured", all(token in share_activity for token in ["originAppPackage", "originAppName", "originAppIconPath", "storeAppIcon"]))
require("duplicate keep/cancel flow", all(token in share_activity for token in ["duplicateOf", "Baribir saqlash", "Bu Topilma avval saqlangan"]))
require("metadata enrichment is deferred", "OneTimeWorkRequestBuilder<TopilmalarMetadataWorker>" in metadata_worker and "NetworkType.CONNECTED" in metadata_worker)
require("enrichment respects user edit", "userEdited = 0" in daos and "applyEnrichment" in metadata_worker)
require("no card/comment upload endpoint", "BILLING_VERIFICATION_URL" not in repository + share_activity + backup_codec)

# Source/card management and main UI.
require("three frozen Topilmalar tabs", all(token in screen for token in ["Manbalar", "Barcha topilmalar", "Qayta ko‘rish"]))
require("dedicated bottom destination", "RootTab.TOPILMALAR" in bottom_bar and "onTopilmalar" in bottom_bar)
require("source sorting and type filters", all(token in screen for token in ["SourceSort.RECENT", "SourceSort.AZ", "SourceSort.MOST", "SourceSort.NEWEST", "TopilmaSourceType.entries"]))
require("source matching priority", all(token in repository for token in ["findByUri", "findByTitleAuthor", "findByTitleOrigin", "findByTitle(normalizedTitle).singleOrNull"]))
require("source merge/archive/source-less", all(token in repository + screen for token in ["mergeSources", "setSourceArchived", "Manbasiz", "deleteSourceKeepCards"]))
require("manual source and card creation", "createSource(" in repository and "Yangi Topilma" in screen and "Clipboarddan joylash" in screen)
require("comments thread supports edit/delete", all(token in screen + repository for token in ["Yangi izoh", "tahrirlandi", "editComment", "deleteComment"]))
require("card/source tags and global management", all(token in screen + repository for token in ["addTagToCard", "addTagToSource", "mergeTags", "renameTag", "deleteTag"]))
require("favorite and source-less filters", 'Text("Sevimli")' in screen and 'Text("Manbasiz")' in screen)
require("bulk actions and delete confirmation", all(token in screen for token in ["tanlandi", "Ko‘chirish", "Teg qo‘shish", "Tanlangan Topilmalar o‘chirilsinmi?"]))
require("long cards expand by tapping text without arrow control", "hasVisualOverflow" in card_component and "expanded = true" in card_component and "KeyboardArrowDown" not in card_component and "KeyboardArrowUp" not in card_component)
require("copy copies main text", "clipboard.setText(AnnotatedString(row.text))" in screen)
require("card dates/edit state stored", all(token in entities for token in ["originalSourceDate", "lastEditedAt", "createdAt"]))

# T-168–T-183: 0.9.22 card interaction/create-flow acceptance guards.
require("universal TopilmaCard used across surfaces", (SRC / "ui/components/TopilmaCard.kt").is_file() and screen.count("TopilmaCard(") >= 2 and "TopilmaCard(" in comments_screen)
require("collapsed card is two lines and text-tap expands", all(token in card_component for token in ["maxLines = if (expanded || forceExpanded) Int.MAX_VALUE else 2", "hasVisualOverflow", "expanded = true"]) and "KeyboardArrowDown" not in card_component)
require("card footer limited to share like comment actions", all(token in card_component for token in ["Icons.Rounded.Share", "Icons.Rounded.Favorite", "Icons.Rounded.ChatBubbleOutline", "TopilmaAction("]) and "Icons.Rounded.Tag" not in card_component)
require("secondary favorite preserved in overflow", "onToggleFavorite" in card_component and "Sevimlidan olib tashlash" in card_component)
require("cumulative like persisted and backed up", all(token in entities + daos + repository + backup_codec for token in ["likeCount", "incrementLike"]) and 'put("likeCount"' in backup_codec and 'optLong("likeCount", 0L)' in backup_codec)
require("shared image always renders full card", all(token in share_manager for token in ["renderCardBitmap", "bodyLayout", "commentCount", "likeCount", "TopilmaCardVisualSpec.EXPORT_OUTER"]) and ".setMaxLines" not in share_manager[share_manager.find("val bodyLayout"):share_manager.find("val bodyBottom")])
require("comments are full-screen keyboard-safe and five-line", all(token in comments_screen for token in ["Scaffold(", "imePadding()", "maxLines = 5", "TopilmaCard(", "commentDateTime", "HH:mm"]))
require("global plus order is short Topilma long", new_note_sheet.find("onClick = onShort") < new_note_sheet.find("onClick = onTopilma") < new_note_sheet.find("onClick = onLong"))
require("source picker is recent-first searchable with count and add", all(token in create_flow for token in ["sortedByDescending { it.lastAddedAt }", "source.cardCount.toString()", "Manba yoki muallifni qidiring", "Yangi manba", "PhotoLibrary"]))
require("quick Topilma editor is text-only autosave", all(token in create_flow for token in ["TopilmaQuickEditorScreen", "delay(700)", "createManualCard", "updateCard", "Topilmangizni yozing", "saveMutex", "NonCancellable"]))
require("manual cards keep live source linkage", "sourceId = source.id" in repository and all(token in daos for token in ["s.title AS sourceTitle", "s.author AS sourceAuthor", "s.coverPath AS sourceCoverPath"]))
require("CREATE route exits cleanly to restore root navigation", "onCreateFlowExit" in screen + navigation and 'mode == "CREATE"' in navigation and "navController.popBackStack()" in navigation)


# T-184–T-205: Obsidian bridge and hashtag acceptance guards.
require("Obsidian settings destination wired", all(token in navigation + settings_hub for token in ["Routes.OBSIDIAN", "ObsidianScreen", "Tashqi dasturlar", "Obsidian"]))
require("SAF vault picker with persistent permission", all(token in obsidian_screen for token in ["OpenDocumentTree", "takePersistableUriPermission", "FLAG_GRANT_WRITE_URI_PERMISSION"]))
require("Obsidian folder structure exactly three Memora sections", all(token in obsidian for token in ["Memora", "Qisqa matn", "Topilmalar", "Uzun matn", "_assets"]))
require("one-way Memora to Obsidian model", "Memora → Obsidian" in obsidian_screen and "syncPending" in obsidian and "DocumentFile.fromTreeUri" in obsidian)
require("first-connect existing-or-future choice", all(token in obsidian_screen + preferences for token in ["Barcha mavjud yozuvlarni ham ko‘chirish", "Faqat bundan keyingilar", "obsidianExportExisting"]))
require("short and long Markdown headings/body", all(token in obsidian for token in ["# ", "NoteBlocksCodec.decode", "Qisqa matn", "Uzun matn"]))
require("Topilma title author colon source title", 'append(author).append(": ")' in obsidian and 'row.sourceTitle' in obsidian)
require("Topilma Obsidian card reuses share renderer", "TopilmaShareManager.renderCardBitmap" in obsidian and "topilma-" in obsidian and "image/png" in obsidian)
require("Topilma searchable collapsed text block", all(token in obsidian for token in ["<details>", "<summary>Matn</summary>", "row.text"]))
require("hashtag parser supports unicode slash dash underscore", all(token in hashtags for token in [r"\p{L}", r"\p{N}", "/", "_", r"\-"]) and "JSONArray" in hashtags)
require("hashtag chips and inline editor highlighting", "CircleShape" in hashtag_chips and "HashtagUtils.ranges" in hashtag_transform and "HashtagUtils.ranges" in rich_editor)
require("note hashtags stored separately", "hashtagsJson" in entities + memora_repo and "HashtagUtils.encode" in memora_repo)
require("Topilma hashtags use tag relation and render on card", "tagNamesCsv" in daos and "tagNames()" in card_component and "addHashtags" in repository)
require("Obsidian writes real hashtags", "HashtagUtils.markdown" in obsidian and '"#${it.removePrefix' in hashtags)
require("stable memora id avoids duplicates", all(token in obsidian for token in ["memora_id", "--${id.take(8)}.md", "resolveOrCreateMarkdown"]))
require("managed block protects Obsidian additions", all(token in obsidian for token in ["<!-- MEMORA:START -->", "<!-- MEMORA:END -->", "existing.substring(0, start)", "existing.substring(end)"]))
require("Obsidian debounce and forced final sync", "DEBOUNCE_MS = 1500L" in obsidian and "syncNoteToObsidianNow" in editor + memora_repo and "syncTopilmaToObsidianNow" in create_flow + repository)
require("failed external sync stays pending without harming Memora", 'state = "PENDING"' in obsidian and "lastError" in obsidian and "try" in obsidian)
require("Obsidian control screen exposes status and repair actions", all(token in obsidian_screen for token in ["Oxirgi sinxronlash", "Kutilayotganlar", "Hozir sinxronlash", "Papkani almashtirish", "Qayta"]))
require("Memora deletion preserves Obsidian copy", "intentionally leaves the already-exported Obsidian file intact" in obsidian and "sync.delete(key(type, id))" in obsidian)
require("note media copied to Obsidian assets", all(token in obsidian for token in ["writeAsset", "NoteBlock.Image", "NoteBlock.Audio", "![["]))
require("7→8 adds hashtags and sync state", all(token in database for token in ["Migration(7, 8)", "ADD COLUMN hashtagsJson", "obsidian_sync_records"]))
require("Obsidian manager injected into both repositories", "ObsidianSyncManager" in main_app and "MemoraRepository(database, subscriptions::canWriteNow, obsidianSync)" in main_app and "TopilmalarRepository(database, subscriptions::canWriteNow, obsidianSync)" in main_app)

# T-206–T-215: preferred master card visual acceptance guards.
require("master visual spec shared by app and export", "TopilmaCardVisualSpec" in card_component and "TopilmaCardVisualSpec" in share_manager and "EXPORT_WIDTH" in visual_spec)
require("preferred fixed larger cover geometry", all(token in visual_spec for token in ["coverWidth = 54.dp", "coverHeight = 72.dp", "coverRadius = 8.dp"]))
require("refined title author typography", all(token in card_component for token in ["fontSize = 20.sp", "FontWeight.SemiBold", "fontSize = 15.sp", "onSurfaceVariant"]))
require("horizontal ellipsis menu", "Icons.Rounded.MoreHoriz" in card_component and "MoreVert" not in card_component)
require("refined serif body typography", "FontFamily.Serif" in card_component and "fontSize = 20.sp" in card_component and "lineHeight = 29.sp" in card_component)
require("no expand button; multiple cards may expand independently", "KeyboardArrowDown" not in card_component and "KeyboardArrowUp" not in card_component and "expanded = true" in card_component)
require("three equal footer zones", card_component.count("Modifier.weight(1f)") >= 3 and all(token in card_component for token in ["Icons.Rounded.Share", "Icons.Rounded.Favorite", "Icons.Rounded.ChatBubbleOutline"]))
require("consistent action icon family", card_component.count("Icons.Rounded.") >= 4)
require("share card has rounded outer canvas", all(token in share_manager + visual_spec for token in ["EXPORT_OUTER", "EXPORT_RADIUS", "drawRoundRect"]))
require("share renderer always full text", "renderCardBitmap" in share_manager and ".setMaxLines" not in share_manager[share_manager.find("val bodyLayout"):share_manager.find("val bodyBottom")])

# Review algorithm, session stability, notifications and Home integration.
require("daily counts include frozen options/default", "listOf(3, 5, 10, 15, 20)" in screen and "topilmalarDailyCount: Int = 5" in preferences)
require("first review 1–3 days", "firstDelayDays" in policy and "% 3" in policy and "firstReviewAlwaysFallsWithinOneToThreeDays" in policy_test)
require("adaptive three-rating policy", all(token in policy for token in ["SOONER", "NORMAL", "LATER", "1.5", "1.8"]))
require("balanced review weighting", all(token in repository for token in ["overdueDays", "unseenBoost", "favoriteBoost", "commentBoost", "usedSources", "favoriteLimit"]))
require("stable daily session", 'id = "daily-$dayKey"' in repository and "getSession(dayKey)" in repository)
require("review eligibility excludes inactive content", all(token in daos for token in ["deletedAt IS NULL", "excludedFromReview = 0", "s.archived = 0", "s.excludedFromReview = 0"]))
require("rating/progress/comment controls", all(token in screen for token in ["Tezroq", "Odatiy", "Keyinroq", "Izoh qo‘shish", "currentSession.items.size"]))
require("review row avoids delegated smart cast", "val reviewRow = currentRow" in screen)
require("random and manual source review", "randomEligibleCard" in repository and "createSourceReviewSession" in repository)
require("optional independent reminder", all(token in preferences + notifications for token in ["topilmalarReminderEnabled", "topilmalarReminderHour", "topilmalarReminderMinute", "EXTRA_OPEN_TOPILMALAR_REVIEW"]))
require("Home review card replaces old frame", "Bugungi qayta ko‘rish" in home and "reviewReadyCount" in home and "HomeReflection" not in home)

# Images, OCR, external sharing, backup and export.
require("multiple images and zoom viewer", "GetMultipleContents" in screen and "ImageBlockView" in screen and "detectTransformGestures" in media)
require("OCR is explicit", "Matnni aniqlash" in screen and "TopilmaOcrManager.open" in screen and "ACTION_SEND" in ocr)
require("three external share forms", all(token in screen + share_manager + visual_spec for token in ["Faqat matn", "Matn + manba", "Kartochka rasmi", "EXPORT_WIDTH = 1080", "bodyLayout"]))
require("share-card work off main thread", "suspend fun shareCardImage" in share_manager and "withContext(Dispatchers.IO)" in share_manager)
require("full Topilmalar backup model", all(token in backup_codec for token in ["sources", "cards", "comments", "images", "tags", "reviewEvents", "reviewSessions", "reviewSessionItems"]))
require("backup v6 and old backup compatibility", 'put("schemaVersion", 6)' in export_manager and "in 1..6" in export_manager and 'optJSONObject("topilmalar")' in export_manager and "hashtagsJson" in export_manager)
require("separate HTML and Word export", "TopilmalarDocumentWriter.html" in export_manager and "TopilmalarDocumentWriter.docx" in export_manager and "includeComments" in document_writer)
require("note-to-Topilmalar action", "Topilmalarga qo‘shish" in reader and "onAddToTopilmalar" in reader)

# Whole-screen crossfade and protected existing functionality.
require("whole-screen fade transitions", navigation.count("fadeIn(") >= 2 and navigation.count("fadeOut(") >= 2 and "durationMillis = 200" in navigation and "durationMillis = 180" in navigation)
require("no navigation slide offsets", not re.search(r"slide(?:In|Out)|initialOffset|targetOffset", navigation))
require("autosave/recovery preserved", "EditorRecoveryStore" in editor and (SRC / "recovery/EditorRecoveryStore.kt").is_file())
require("audio controls preserved", all(token in media for token in ["onPauseRecording", "onResumeRecording", "onStopRecording"]))
require("CameraX Vaqt izi preserved", "androidx.camera." in time_trace)
require("App Lock remains global", "BiometricPrompt" in main_activity and "BiometricManager" in main_activity)
require("Search/Calendar/Statistics preserved", all((SRC / "ui/screens" / name).is_file() for name in ["SearchScreen.kt", "CalendarHubScreen.kt", "StatisticsScreen.kt"]))
require("workflow runs new gate/build/tests/lint", all(token in workflow for token in ["regression_0924.py", "clean compileDebugKotlin", "testDebugUnitTest", "lintDebug", "assembleDebug"]))

# Basic parsers catch malformed resources and common accidental Kotlin truncation.
xml_errors = []
for path in [APP / "AndroidManifest.xml", *(APP / "res").rglob("*.xml")]:
    try:
        ET.parse(path)
    except Exception as exc:
        xml_errors.append(f"{path.relative_to(ROOT)}: {exc}")
require("all Android XML parses", not xml_errors, "; ".join(xml_errors[:3]))

kotlin_errors = []
for path in SRC.rglob("*.kt"):
    ok, detail = kotlin_delimiters(path)
    if not ok:
        kotlin_errors.append(f"{path.relative_to(ROOT)}: {detail}")
require("Kotlin delimiter smoke test", not kotlin_errors, "; ".join(kotlin_errors[:3]))

passed = sum(1 for _, ok, _ in checks if ok)
for name, ok, detail in checks:
    print(("OK   " if ok else "FAIL ") + name + (f" — {detail}" if detail else ""))
print(f"\nRegression checks: {passed}/{len(checks)} passed")
if failures:
    print("\nFailures:")
    for failure in failures:
        print(" -", failure)
    sys.exit(1)
print("Memora 0.9.24 static regression audit PASSED")
