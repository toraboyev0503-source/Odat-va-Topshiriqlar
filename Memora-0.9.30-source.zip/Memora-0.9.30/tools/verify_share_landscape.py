#!/usr/bin/env python3
from pathlib import Path
import json
import re

ROOT = Path(__file__).resolve().parents[1]
spec_file = ROOT / "tools/topilma_share_landscape_spec.json"
kt_file = ROOT / "app/src/main/java/com/memora/app/share/TopilmaShareVisualSpec.kt"
manager_file = ROOT / "app/src/main/java/com/memora/app/share/TopilmaShareManager.kt"
obsidian_file = ROOT / "app/src/main/java/com/memora/app/obsidian/ObsidianSyncManager.kt"

spec = json.loads(spec_file.read_text())
kt = kt_file.read_text()
manager = manager_file.read_text()
obsidian = obsidian_file.read_text()

expected = {
    "CANVAS_WIDTH": spec["canvasPx"]["width"],
    "CANVAS_HEIGHT": spec["canvasPx"]["height"],
    "CARD_LEFT": spec["cardPx"]["left"],
    "CARD_TOP": spec["cardPx"]["top"],
    "CARD_RIGHT": spec["cardPx"]["right"],
    "CARD_BOTTOM": spec["cardPx"]["bottom"],
    "CARD_RADIUS": spec["cardPx"]["radius"],
    "COVER_LEFT": spec["coverPx"]["left"],
    "COVER_TOP": spec["coverPx"]["top"],
    "COVER_WIDTH": spec["coverPx"]["width"],
    "COVER_HEIGHT": spec["coverPx"]["height"],
    "TITLE_LEFT": spec["titlePx"]["left"],
    "TITLE_TOP": spec["titlePx"]["top"],
    "TITLE_RIGHT": spec["titlePx"]["right"],
    "TITLE_TEXT_SIZE": spec["titlePx"]["size"],
    "AUTHOR_TEXT_SIZE": spec["authorPx"]["size"],
    "BODY_LEFT": spec["bodyPx"]["left"],
    "BODY_TOP": spec["bodyPx"]["top"],
    "BODY_RIGHT": spec["bodyPx"]["right"],
    "BODY_TEXT_SIZE": spec["bodyPx"]["preferredSize"],
    "MENU_CENTER_X": spec["menuPx"]["centerX"],
    "MENU_CENTER_Y": spec["menuPx"]["centerY"],
    "ACTION_CENTER_Y": spec["actionsPx"]["centerY"],
    "SHARE_CENTER_X": spec["actionsPx"]["shareX"],
    "LIKE_CENTER_X": spec["actionsPx"]["likeX"],
    "COMMENT_CENTER_X": spec["actionsPx"]["commentX"],
}

fail = []
for name, value in expected.items():
    pattern = rf"const val {name}\s*=\s*{value}(?:f)?\b"
    if not re.search(pattern, kt):
        fail.append(f"{name} != frozen {value}")

if spec["canvasPx"]["width"] <= spec["canvasPx"]["height"]:
    fail.append("canvas is not landscape")
if spec["transparentRootAllowed"]:
    fail.append("transparent root unexpectedly allowed")
if "0xFFFDECE5L" not in kt:
    fail.append("opaque #FDECE5 outer background missing")
if "Bitmap.createBitmap(s.CANVAS_WIDTH, s.CANVAS_HEIGHT" not in manager:
    fail.append("renderer is not locked to frozen canvas")
if "TopilmaCardVisualSpec" in manager:
    fail.append("share renderer still depends on feed visual spec")
if "fitBodyLayout" not in manager:
    fail.append("long-text fitting guard missing")
if "TopilmaShareManager.renderCardBitmap(appContext, row)" not in obsidian:
    fail.append("Obsidian does not reuse the same share renderer")
if "Color.TRANSPARENT" in manager:
    fail.append("transparent export path detected")

if fail:
    print("LOCKED LANDSCAPE SHARE SPEC FAILED")
    for item in fail:
        print(" -", item)
    raise SystemExit(1)

print("LOCKED LANDSCAPE SHARE SPEC PASS")
print(f"canvas={spec['canvasPx']['width']}x{spec['canvasPx']['height']} ratio={spec['canvasPx']['width']/spec['canvasPx']['height']:.3f}")
print("outer=#FDECE5 opaque; Android Share and Obsidian share one renderer")
