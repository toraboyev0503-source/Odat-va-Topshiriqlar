#!/usr/bin/env python3
from pathlib import Path
import json
import re

ROOT = Path(__file__).resolve().parents[1]
spec = json.loads((ROOT / "tools/topilma_card_0930_spec.json").read_text())
visual = (ROOT / "app/src/main/java/com/memora/app/ui/components/TopilmaCardVisualSpec.kt").read_text()
renderer = (ROOT / "app/src/main/java/com/memora/app/share/TopilmaShareManager.kt").read_text()
live = (ROOT / "app/src/main/java/com/memora/app/ui/components/TopilmaCard.kt").read_text()
obsidian = (ROOT / "app/src/main/java/com/memora/app/obsidian/ObsidianSyncManager.kt").read_text()

expected = {
    "CANVAS_WIDTH": spec["referenceCanvasPx"]["width"],
    "MIN_CANVAS_HEIGHT": spec["referenceCanvasPx"]["minimumHeight"],
    "CARD_LEFT": spec["cardPx"]["left"],
    "CARD_TOP": spec["cardPx"]["top"],
    "CARD_RIGHT": spec["cardPx"]["right"],
    "CARD_RADIUS": spec["cardPx"]["radius"],
    "COVER_LEFT": spec["coverPx"]["left"],
    "COVER_TOP": spec["coverPx"]["top"],
    "COVER_WIDTH": spec["coverPx"]["width"],
    "COVER_HEIGHT": spec["coverPx"]["height"],
    "TITLE_LEFT": spec["titlePx"]["left"],
    "TITLE_TOP": spec["titlePx"]["top"],
    "TITLE_RIGHT": spec["titlePx"]["right"],
    "TITLE_TEXT_SIZE": spec["titlePx"]["size"],
    "BODY_LEFT": spec["bodyPx"]["left"],
    "BODY_TOP": spec["bodyPx"]["top"],
    "BODY_RIGHT": spec["bodyPx"]["right"],
    "BODY_TEXT_SIZE": spec["bodyPx"]["size"],
    "BODY_LINE_HEIGHT": spec["bodyPx"]["lineHeight"],
    "BASE_ACTION_CENTER_Y": spec["actionsPx"]["baseCenterY"],
    "SHARE_CENTER_X": spec["actionsPx"]["shareX"],
    "LIKE_CENTER_X": spec["actionsPx"]["likeX"],
    "COMMENT_CENTER_X": spec["actionsPx"]["commentX"],
}

fail = []
for name, value in expected.items():
    if not re.search(rf"const val {name}\s*=\s*{value}(?:f)?\b", visual):
        fail.append(f"{name} != frozen {value}")

requirements = {
    "opaque approved outer color": "0xFFFEF0E5L" in visual,
    "height grows from body layout": "bodyBottom" in renderer and "desiredActionCenter" in renderer and "canvasHeight" in renderer,
    "no text shrinking": "fitBodyLayout" not in renderer and "BODY_MIN_TEXT_SIZE" not in visual,
    "no pagination": "pageIndex" not in renderer and "splitAcrossCards" not in renderer,
    "app displays canonical bitmap": "TopilmaShareManager.renderCardBitmap" in live and "current.asImageBitmap()" in live,
    "app has transparent action targets": "TopilmaHitTarget" in live and "indication = null" in live,
    "Obsidian displays canonical bitmap": "TopilmaShareManager.renderCardBitmap" in obsidian,
}
for label, ok in requirements.items():
    if not ok:
        fail.append(label)

if fail:
    print("TOPILMA 0.9.30 CANONICAL CARD VERIFY FAILED")
    for item in fail:
        print(" -", item)
    raise SystemExit(1)

print("TOPILMA 0.9.30 CANONICAL CARD VERIFY PASS")
print("one renderer; fixed width; minimum 1536x1199; dynamic downward growth; no shrink/pagination")
