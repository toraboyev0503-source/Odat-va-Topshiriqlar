#!/usr/bin/env python3
"""Static safety gate for Memora 0.9.30.

Gradle unit tests, Kotlin compilation and Android Lint run separately. This gate
protects the existing Memora/Topilmalar baseline plus the canonical card and
continuous OCR contracts before Gradle starts.
"""
from pathlib import Path
import re
import sqlite3
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "app/src/main/java/com/memora/app"
failures: list[str] = []
checks = 0


def read(path: str) -> str:
    file = ROOT / path
    if not file.is_file():
        failures.append(f"missing file: {path}")
        return ""
    return file.read_text(encoding="utf-8", errors="replace")


def require(label: str, condition: bool) -> None:
    global checks
    checks += 1
    if not condition:
        failures.append(label)


gradle = read("app/build.gradle.kts")
manifest = read("app/src/main/AndroidManifest.xml")
database = read("app/src/main/java/com/memora/app/data/local/AppDatabase.kt")
entities = read("app/src/main/java/com/memora/app/data/local/Entities.kt")
repository = read("app/src/main/java/com/memora/app/data/repository/TopilmalarRepository.kt")
screen = read("app/src/main/java/com/memora/app/ui/screens/TopilmalarScreen.kt")
card = read("app/src/main/java/com/memora/app/ui/components/TopilmaCard.kt")
visual = read("app/src/main/java/com/memora/app/ui/components/TopilmaCardVisualSpec.kt")
renderer = read("app/src/main/java/com/memora/app/share/TopilmaShareManager.kt")
ocr = read("app/src/main/java/com/memora/app/share/TopilmaOcrManager.kt")
ocr_screen = read("app/src/main/java/com/memora/app/ui/screens/TopilmaOcrCaptureScreen.kt")
ocr_test = read("app/src/test/java/com/memora/app/share/TopilmaOcrManagerTest.kt")
obsidian = read("app/src/main/java/com/memora/app/obsidian/ObsidianSyncManager.kt")
backup = read("app/src/main/java/com/memora/app/export/TopilmalarBackupCodec.kt")
workflow = read(".github/workflows/main.yml")

# Release and upgrade safety.
require("versionName 0.9.30", 'versionName = "0.9.30"' in gradle)
require("versionCode 50+", bool(re.search(r"versionCode\s*=\s*(?:5\d|[6-9]\d|\d{3,})", gradle)))
require("package id preserved", 'applicationId = "com.memora.app"' in gradle)
require("stable debug signing preserved", "keystore/memora-test-debug.jks" in gradle)
require("Room schema stays 8", "version = 8" in database)
require("non-destructive migrations stay present", all(x in database for x in ["MIGRATION_5_6", "MIGRATION_6_7", "MIGRATION_7_8"]) and "fallbackToDestructiveMigration" not in database)
require("Topilmalar tables preserved", all(x in entities for x in ["topilma_sources", "topilma_cards", "topilma_comments", "topilma_tags", "topilma_review_events"]))
require("backup keeps likes/comments/tags", all(x in backup for x in ["likeCount", "comments", "tags", "sourceId"]))
require("billing/backend preserved", (SRC / "billing/SubscriptionManager.kt").is_file() and (ROOT / "backend/server.mjs").is_file())

# Existing Topilmalar product surface.
require("three Topilmalar tabs", all(x in screen for x in ["Manbalar", "Barcha topilmalar", "Qayta ko‘rish"]))
require("source/card operations preserved", all(x in repository for x in ["createSource", "createManualCard", "incrementLike", "addComment", "syncTopilmaToObsidianNow"]))
require("multi-select and filters preserved", all(x in screen for x in ["Tanlangan Topilmalar o‘chirilsinmi?", "Sevimli", "Manbasiz", "Ko‘chirish"]))
require("SEND targets preserved", all(x in manifest for x in ["TopilmalarShareActivity", "android.intent.action.SEND", "android.intent.action.SEND_MULTIPLE"]))

# One canonical dynamic-height card.
require("one canonical visual spec", "object TopilmaCardVisualSpec" in visual and not (SRC / "share/TopilmaShareVisualSpec.kt").exists())
require("approved warm background", "0xFFFEF0E5L" in visual)
require("fixed reference width and minimum height", "CANVAS_WIDTH = 1536" in visual and "MIN_CANVAS_HEIGHT = 1199" in visual)
require("renderer grows down from full body", all(x in renderer for x in ["bodyLayout", "bodyBottom", "desiredActionCenter", "canvasHeight", "cardBottom"]))
require("renderer never shrinks quote", all(x not in renderer + visual for x in ["fitBodyLayout", "BODY_MIN_TEXT_SIZE", "emergencySize"]))
require("renderer never paginates quote", all(x not in renderer for x in ["pageIndex", "pageCount", "splitAcrossCards"]))
require("app uses exact renderer output", "TopilmaShareManager.renderCardBitmap" in card and "current.asImageBitmap()" in card)
require("app contains no second card typography", all(x not in card for x in ["FontFamily.Serif", "TITLE_SP.sp", "BODY_SP.sp", "Icons.Rounded.Share", "ChatBubbleOutline"]))
require("transparent interactive hit targets", "TopilmaHitTarget" in card and "indication = null" in card and "contentDescription = label" in card)
require("Obsidian reuses exact renderer", "TopilmaShareManager.renderCardBitmap" in obsidian)
require("share remains opaque PNG", "Bitmap.Config.ARGB_8888" in renderer and "canvas.drawColor" in renderer and "image/png" in renderer)

# OCR reading order and continuous selection.
require("bundled on-device ML Kit retained", all(x in ocr for x in ["TextRecognition", "TextRecognizerOptions.DEFAULT_OPTIONS", "InputImage.fromBitmap"]))
require("pure geometric bounds", "data class Bounds" in ocr and "centerY" in ocr)
require("detector indexes are not sort order", "readingLines" in ocr and "lineAffinity" in ocr and ".sortedBy { it.bounds.left }" in ocr)
require("inclusive reversible range", "rangeKeys" in ocr and "min(anchor, extent)" in ocr and "max(anchor, extent)" in ocr)
require("punctuation/paragraph assembly", "joinTokens" in ocr and "paragraphBreak" in ocr)
require("range gesture replaces paint trail", "OcrSelectionRange" in ocr_screen and "nearestTokenAt" in ocr_screen and "rangeKeys" in ocr_screen)
require("smooth line highlights", "drawSelectionHighlights" in ocr_screen and "readingLines(tokens)" in ocr_screen)
require("live preview and add passage", "Tanlangan matn" in ocr_screen and "Yana parcha" in ocr_screen and "selectedPreview" in ocr_screen)
require("rotation/pinch/pan retained", all(x in ocr_screen for x in ["rotateBitmap(it, 90f)", "active.size >= 2", "currentDistance / previousDistance", "clampPan"]))
require("OCR regression tests present", all(x in ocr_test for x in ["geometricOrderIgnoresShuffledMlKitIndices", "continuousRangeWorksForwardAndBackward", "punctuationAndParagraphsAreReconstructedWithoutRewritingWords"]))

# Workflow and resources.
require("0.9.30 verification in workflow", "verify_topilma_card_0930.py" in workflow and "regression_0930.py" in workflow)
require("workflow compiles/tests/lints/builds", all(x in workflow for x in ["compileDebugKotlin", "testDebugUnitTest", "lintDebug", "assembleDebug"]))
for xml in (ROOT / "app/src/main/res").rglob("*.xml"):
    try:
        ET.parse(xml)
    except Exception as exc:
        failures.append(f"invalid XML {xml.relative_to(ROOT)}: {exc}")

# Execute migration statements against SQLite as a syntax smoke test.
migration = database[database.find("MIGRATION_5_6"):database.find("@Volatile")]
sql = []
for plain, trimmed, quoted in re.findall(r'db\.execSQL\(\s*(?:"""(.*?)"""|"""(.*?)"""\.trimIndent\(\)|"([^"]*)")\s*\)', migration, re.S):
    sql.append(plain or trimmed or quoted)
try:
    connection = sqlite3.connect(":memory:")
    connection.execute("CREATE TABLE notes (id TEXT PRIMARY KEY)")
    for statement in sql:
        connection.execute(statement)
except Exception as exc:
    failures.append(f"migration SQL: {exc}")
finally:
    if "connection" in locals():
        connection.close()

if failures:
    print("Memora 0.9.30 regression FAILED")
    for item in failures:
        print(" -", item)
    raise SystemExit(1)

print(f"Memora 0.9.30 regression PASS ({checks} checks)")
