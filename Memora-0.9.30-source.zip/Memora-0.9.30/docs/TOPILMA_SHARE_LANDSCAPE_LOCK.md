# Topilma Share Landscape Lock — SUPERSEDED BY 0.9.30

> Historical 0.9.29 contract. `TOPILMA_CARD_OCR_0930_FROZEN.md` is authoritative.

Frozen decisions: **T-256–T-262**.

The in-app Topilma feed card and the exported share card are intentionally separate presentation modes. The share/export mode is a locked reference template and must not inherit layout values from the feed card.

## Non-negotiable export contract

- Canvas: **1536 × 1199 px**, landscape.
- Root canvas: fully opaque warm peach **#FDECE5**. Transparent/black receiver edges are forbidden.
- Card frame: fixed **(78,84)–(1452,1112)** with **72 px** radius.
- Cover: fixed **138 × 198 px** at **(145,154)**; aspect ratio is preserved with fit, never crop/stretch.
- Header, menu, body zone and three footer centers are frozen in `TopilmaShareVisualSpec.kt`.
- Android Share and Obsidian must both call `TopilmaShareManager.renderCardBitmap()`.
- The export must never switch to content-driven portrait geometry.
- Long quotes keep the full text; only body font size may reduce to stay inside the locked canvas.
- App-feed changes must not change export geometry.

Run before build:

```bash
python3 tools/verify_share_landscape.py
python3 tools/regression_0929.py
```
