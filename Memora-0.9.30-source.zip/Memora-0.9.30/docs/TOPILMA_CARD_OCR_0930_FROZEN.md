# Memora 0.9.30 — Topilma card and OCR contract (FROZEN)

## Supersession

This contract supersedes the 0.9.29 rule that the in-app feed card and the
Share/Obsidian card must have independent visual implementations. The former
landscape-only height lock is also superseded. Opaque export, fixed width,
complete text, preserved source metadata and the single Share/Obsidian output
remain required.

## One canonical card

- `TopilmaShareManager.renderCardBitmap()` is the only visible Topilma card renderer.
- The live app card displays that bitmap and adds transparent accessible hit targets.
- Android Share and Obsidian call the same renderer.
- The approved 1016×793 reference is represented by a 1536×1199 minimum canvas.
- Width is always 1536 px. Height is content-driven and may exceed 1199 px.
- Quote font size, line height and width never change because of quote length.
- A long quote is never split into multiple cards. The card grows only downward.
- The outer background is opaque `#FEF0E5`; transparent/black receiver edges are forbidden.
- Cover aspect ratio is preserved with Fit; it is never cropped or stretched.
- Title/author, horizontal menu and Share/Like/Comment glyphs use the canonical scene.
- Tags extend the same card below the quote and above the action row.

## OCR selection and reconstruction

- ML Kit remains bundled/on-device and no page image is uploaded.
- Detector `blockIndex`, `lineIndex` and `tokenIndex` are identity only, never reading order.
- Reading order is reconstructed from token bounding boxes: line clustering by vertical
  overlap, lines top-to-bottom, tokens left-to-right.
- One-finger drag selects the inclusive anchor-to-extent range, including every word
  between the first and last word. Reverse drag is equivalent.
- A finger crossing whitespace maps to the nearest token instead of creating holes.
- Selected words render as continuous per-line highlight strips.
- The last range can be adjusted from either endpoint; “Yana parcha” adds a disjoint range.
- A live text preview appears before confirmation; Clear and Select all remain.
- Punctuation spacing and paragraph gaps are reconstructed without paraphrasing,
  spell-correcting or silently changing recognized words.
- Two-finger pan/zoom, 90° rotation, camera/gallery input and the normal autosave editor remain.

## Acceptance

1. One card record has identical visible output in-app, Android Share and Obsidian.
2. A 100–150-word quote keeps the approved width/font and produces one taller card.
3. No renderer contains quote-length font shrinking or pagination.
4. The supplied reversed OCR scenario produces top-to-bottom text.
5. Forward and reverse drag select the same inclusive word range.
6. Existing Room schema 8 data and update-over-old-APK signing remain intact.
