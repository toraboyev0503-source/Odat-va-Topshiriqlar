# Memora approved visual references — 0.9.18

These images are the user-approved visual references for this design pass. The Compose implementation should match their hierarchy, spacing, card language and visual rhythm as closely as practical across real Android screen sizes.

1. `final-design-reference/01-home-approved.png` — Home.
2. `final-design-reference/02-notes-approved.png` — unified Notes list.
3. `final-design-reference/03-new-note-editor-approved.png` — New Note sheet + Editor.
4. `final-design-reference/04-reader-approved.png` — Reader. Use only Memora's custom mood stickers, not system emoji.
5. `final-design-reference/05-memories-approved.png` — Calendar + Statistics. Final decision: same background family as the other approved screens; no decorative leaves and no quote/citation copy.
6. `final-design-reference/06-settings-approved.png` — Settings with icon tiles, subtitles and section hierarchy.

Functional behavior from 0.9.17 remains authoritative where the mockups are purely visual: autosave/recovery, media zoom, audio pause/resume, corrected created/edited timestamps, Time Trace guided camera, backup/export, app lock and billing behavior must not regress.
