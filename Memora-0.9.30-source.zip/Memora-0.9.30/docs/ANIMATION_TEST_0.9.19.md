# Memora 0.9.19 on-device motion test

This build intentionally changes interactive motion without changing note/database formats.

Check these flows on a real phone:

1. Bottom navigation: Home ↔ Notes ↔ Calendar ↔ Settings. It should feel immediate, not abrupt.
2. Reader/Editor: open a note, edit it, go back. The direction should be understandable without feeling like a long page slide.
3. Center `+`: press feedback should be subtle and immediate.
4. Settings subpages and Back: no “waiting for the previous screen to finish” feeling.
5. Vaqt izi slideshow: Medium should feel calm enough to inspect each frame; Slow/Fast should remain clearly distinct.
6. Home reflection: its five-second quiet start and reveal ceremony should still feel calm; it was not globally sped up.

If root navigation feels too fast/too slow, tune only the shared values in `MemoraMotion.kt` rather than changing each screen separately.
