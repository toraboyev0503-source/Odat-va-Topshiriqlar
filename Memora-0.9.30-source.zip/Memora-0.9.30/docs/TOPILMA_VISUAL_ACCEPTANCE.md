# Topilma visual parity acceptance — SUPERSEDED BY 0.9.30

> Historical parity checklist. `TOPILMA_CARD_OCR_0930_FROZEN.md` is authoritative.

This document freezes T-246–T-255 into measurable build acceptance criteria.

## One geometry system

The live Compose card and the Share/Obsidian bitmap must derive geometry from
`TopilmaCardVisualSpec`. The exporter uses exactly 4 px for every canonical dp/sp
unit; it must not contain an independent dynamic font-size or cover-size system.

Canonical values:

- card radius: 24 dp
- inner horizontal padding: 18 dp
- inner vertical padding: 16 dp
- cover frame: 46 × 66 dp, 6 dp radius, 1 dp border, 2 dp image inset
- cover → title gap: 14 dp
- header → body: 18 dp
- title: 20 sp / 24 sp line
- author: 15 sp / 19 sp line
- body: 20 sp / 29 sp line
- action row: 52 dp
- export canvas: 360 dp × content height at 4 px/dp = 1440 px wide
- outer export margin: 12 dp
- outer export background: opaque warm `#F8F3EF`
- card background: opaque white

## Required checks before calling a build visually ready

1. In-app and Share card use the same title, author, cleaned body and tag list.
2. Cover aspect is preserved (`Fit`), never cropped or stretched.
3. Cover frame proportions are the same in-app and in exported PNG.
4. Export body font size never changes because quote length changes.
5. Share PNG contains no transparent pixel in the root/background region.
6. Telegram/Honor share preview therefore cannot substitute a black alpha background.
7. Android Share and Obsidian use the exact same `renderCardBitmap()` output.
8. Raw `#tags` do not remain inside the quote body; they appear once as chips in the card.
9. Obsidian visible notes contain no Memora START/END markers, UUID suffixes, instructions or visible sync metadata.
10. `app/src/debug/.../TopilmaVisualParityPreview.kt` can show the live card and exported bitmap together for diagnostics.
