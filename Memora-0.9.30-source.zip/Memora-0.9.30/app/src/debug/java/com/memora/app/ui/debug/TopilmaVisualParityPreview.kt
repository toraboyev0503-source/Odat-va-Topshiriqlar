package com.memora.app.ui.debug

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.memora.app.data.local.TopilmaCardRow
import com.memora.app.share.TopilmaShareManager
import com.memora.app.ui.components.TopilmaCard

/**
 * Internal debug-only parity probe (T-253).
 * It intentionally renders the live card and the exact Share/Obsidian bitmap together.
 * This is not wired into release navigation.
 */
@Composable
internal fun TopilmaVisualParityPreview(row: TopilmaCardRow) {
    val context = LocalContext.current
    val exported = remember(
        row.id,
        row.text,
        row.sourceTitle,
        row.sourceAuthor,
        row.sourceCoverPath,
        row.tagNamesCsv,
        row.likeCount,
        row.commentCount
    ) { TopilmaShareManager.renderCardBitmap(context, row) }

    DisposableEffect(exported) {
        onDispose { if (!exported.isRecycled) exported.recycle() }
    }

    Column(
        modifier = Modifier.fillMaxWidth().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("In-app master card", style = MaterialTheme.typography.labelLarge)
        TopilmaCard(
            row = row,
            canEdit = false,
            forceExpanded = true,
            onShare = {},
            onLike = {},
            onComments = {},
            onEdit = {}
        )
        Text("Share / Obsidian controlled render", style = MaterialTheme.typography.labelLarge)
        Image(
            bitmap = exported.asImageBitmap(),
            contentDescription = null,
            modifier = Modifier.fillMaxWidth(),
            contentScale = ContentScale.FillWidth
        )
    }
}
