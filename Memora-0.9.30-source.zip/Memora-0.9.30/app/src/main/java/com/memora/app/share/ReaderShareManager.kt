package com.memora.app.share

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.net.Uri
import android.text.Layout
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.StaticLayout
import android.text.TextPaint
import android.text.style.StyleSpan
import androidx.core.content.FileProvider
import com.memora.app.R
import com.memora.app.data.local.NoteEntity
import com.memora.app.prefs.AppLanguage
import com.memora.app.util.TimeUtils
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Reader-only sharing. Generated files live in cache and are never added to the Gallery. */
class ReaderShareManager(private val context: Context) {
    private val shareDir = File(context.cacheDir, "shares").apply { mkdirs() }

    fun shareText(note: NoteEntity, chooserTitle: String) {
        val title = note.title.ifBlank { "Memora" }
        val body = SpannableStringBuilder().apply {
            val start = length
            append(title)
            setSpan(StyleSpan(Typeface.BOLD), start, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            if (note.plainText.isNotBlank()) append("\n\n").append(note.plainText.trim())
        }
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, body)
        }
        context.startActivity(Intent.createChooser(intent, chooserTitle))
    }

    suspend fun shareImages(note: NoteEntity, language: AppLanguage, chooserTitle: String) {
        val intent = withContext(Dispatchers.IO) {
            clearOld("reader-", ".png")
            val pages = renderImagePages(note, language)
            val uris = ArrayList<Uri>(pages.size)
            pages.forEach { file -> uris += uriFor(file) }
            if (uris.size == 1) {
                Intent(Intent.ACTION_SEND).apply {
                    type = "image/png"
                    putExtra(Intent.EXTRA_STREAM, uris.first())
                }
            } else {
                Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                    type = "image/png"
                    putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                }
            }.apply {
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }
        withContext(Dispatchers.Main) {
            context.startActivity(Intent.createChooser(intent, chooserTitle))
        }
    }

    suspend fun shareHtml(note: NoteEntity, language: AppLanguage, chooserTitle: String) {
        val intent = withContext(Dispatchers.IO) {
            clearOld("reader-", ".html")
            val safeId = note.id.replace(Regex("[^A-Za-z0-9_-]"), "_")
            val file = File(shareDir, "reader-$safeId.html")
            file.writeText(buildHtml(note, language), Charsets.UTF_8)
            Intent(Intent.ACTION_SEND).apply {
                type = "text/html"
                putExtra(Intent.EXTRA_STREAM, uriFor(file))
                putExtra(Intent.EXTRA_TEXT, note.plainText)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }
        withContext(Dispatchers.Main) {
            context.startActivity(Intent.createChooser(intent, chooserTitle))
        }
    }

    private fun renderImagePages(note: NoteEntity, language: AppLanguage): List<File> {
        val width = 1080
        val height = 1350
        val left = 92f
        val right = 92f
        val top = 92f
        val footerTop = 1240f
        val bodyWidth = (width - left - right).toInt()
        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(32, 40, 43)
            textSize = 58f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
        val metaPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(104, 119, 124)
            textSize = 27f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        }
        val bodyPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(32, 40, 43)
            textSize = 37f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        }

        val title = note.title.ifBlank { if (language == AppLanguage.UZ) "Sarlavhasiz" else "Untitled" }
        val titleLayout = staticLayout(title, titlePaint, bodyWidth, 1.04f)
        val meta = TimeUtils.dateTime(note.createdAt, language)
        val metaLayout = staticLayout(meta, metaPaint, bodyWidth, 1f)
        val firstBodyTop = top + titleLayout.height + 30f + metaLayout.height + 48f
        val continuationHeaderLayout = staticLayout("$title · 650/650", metaPaint, bodyWidth, 1f)
        val nextBodyTop = top + continuationHeaderLayout.height + 34f
        val body = note.plainText.trim().ifBlank { " " }
        val chunks = paginate(body, bodyPaint, bodyWidth, firstBodyTop, nextBodyTop, footerTop - 48f)
        val total = chunks.size.coerceAtLeast(1)
        val icon = BitmapFactory.decodeResource(context.resources, R.drawable.memora_brand_symbol_exact)

        return chunks.mapIndexed { index, chunk ->
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            canvas.drawColor(Color.rgb(251, 252, 253))
            var y = if (index == 0) top else nextBodyTop
            if (index == 0) {
                canvas.save(); canvas.translate(left, y); titleLayout.draw(canvas); canvas.restore()
                y += titleLayout.height + 30f
                canvas.save(); canvas.translate(left, y); metaLayout.draw(canvas); canvas.restore()
                y += metaLayout.height + 48f
            } else {
                val pageHeader = "$title · ${index + 1}/$total"
                val headerLayout = staticLayout(pageHeader, metaPaint, bodyWidth, 1f)
                canvas.save(); canvas.translate(left, top); headerLayout.draw(canvas); canvas.restore()
                y = top + headerLayout.height + 34f
            }
            val bodyLayout = staticLayout(chunk, bodyPaint, bodyWidth, 1.34f)
            canvas.save(); canvas.translate(left, y); bodyLayout.draw(canvas); canvas.restore()
            drawBrandFooter(canvas, icon, width, footerTop)

            val safeId = note.id.replace(Regex("[^A-Za-z0-9_-]"), "_")
            val file = File(shareDir, "reader-$safeId-${index + 1}.png")
            FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            bitmap.recycle()
            file
        }.also { icon?.recycle() }
    }

    private fun paginate(
        text: String,
        paint: TextPaint,
        width: Int,
        firstTop: Float,
        nextTop: Float,
        bottom: Float
    ): List<String> {
        val pages = mutableListOf<String>()
        var start = 0
        var page = 0
        while (start < text.length) {
            val available = (bottom - if (page == 0) firstTop else nextTop).toInt().coerceAtLeast(200)
            val layout = staticLayout(text.substring(start), paint, width, 1.34f)
            var fit = layout.lineCount
            while (fit > 1 && layout.getLineBottom(fit - 1) > available) fit--
            val endOffset = if (fit <= 0) 1 else layout.getLineEnd((fit - 1).coerceAtLeast(0))
            val end = (start + endOffset).coerceAtMost(text.length)
            if (end <= start) break
            pages += text.substring(start, end).trim()
            start = end
            while (start < text.length && text[start].isWhitespace()) start++
            page++
        }
        if (pages.isEmpty()) pages += " "
        return pages
    }

    private fun drawBrandFooter(canvas: Canvas, icon: Bitmap?, width: Int, y: Float) {
        val center = width / 2f
        val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(70, 95, 105)
            textSize = 26f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
        val sloganPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(104, 119, 124)
            textSize = 21f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        }
        val brandText = "Memora"
        val iconSize = 30f
        val gap = 10f
        val brandWidth = labelPaint.measureText(brandText) + if (icon != null) iconSize + gap else 0f
        var x = center - brandWidth / 2f
        if (icon != null) {
            canvas.drawBitmap(icon, null, android.graphics.RectF(x, y, x + iconSize, y + iconSize), Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
            x += iconSize + gap
        }
        canvas.drawText(brandText, x, y + 25f, labelPaint)
        val slogan = "Har bir kuningizdan bir iz qoldiring."
        canvas.drawText(slogan, center - sloganPaint.measureText(slogan) / 2f, y + 60f, sloganPaint)
    }

    private fun staticLayout(text: String, paint: TextPaint, width: Int, spacing: Float): StaticLayout =
        StaticLayout.Builder.obtain(text, 0, text.length, paint, width)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setIncludePad(false)
            .setLineSpacing(0f, spacing)
            .build()

    private fun buildHtml(note: NoteEntity, language: AppLanguage): String {
        val iconData = runCatching {
            val bitmap = BitmapFactory.decodeResource(context.resources, R.drawable.memora_brand_symbol_exact)
                ?: error("Memora brand icon could not be decoded")
            try {
                ByteArrayOutputStream().use { output ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, output)
                    android.util.Base64.encodeToString(output.toByteArray(), android.util.Base64.NO_WRAP)
                }
            } finally {
                bitmap.recycle()
            }
        }.getOrDefault("")
        val title = htmlEscape(note.title.ifBlank { if (language == AppLanguage.UZ) "Sarlavhasiz" else "Untitled" })
        val body = note.plainText.trim().split(Regex("\\n\\s*\\n")).joinToString("\n") { p ->
            "<p>${htmlEscape(p).replace("\n", "<br>")}</p>"
        }
        val date = htmlEscape(TimeUtils.dateTime(note.createdAt, language))
        val slogan = "Har bir kuningizdan bir iz qoldiring."
        val logo = if (iconData.isBlank()) "" else "<img src=\"data:image/png;base64,$iconData\" alt=\"Memora\">"
        return """<!doctype html>
<html lang="${language.tag}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>$title</title><style>
body{margin:0;background:#f0f4f5;color:#20282b;font-family:system-ui,-apple-system,Segoe UI,sans-serif}.page{max-width:760px;margin:0 auto;padding:52px 30px 34px}.card{background:#fbfcfd;border:1px solid #e3eaec;border-radius:24px;padding:42px 38px;box-shadow:0 8px 26px rgba(20,35,40,.06)}h1{font-size:2rem;margin:0 0 12px;line-height:1.2}.date{color:#68777c;font-size:.92rem;margin-bottom:32px}p{font-size:1.08rem;line-height:1.75;margin:0 0 1.25em;white-space:normal}.brand{display:flex;flex-direction:column;align-items:center;gap:5px;color:#68777c;margin-top:34px;font-size:.82rem}.brandline{display:flex;align-items:center;gap:8px;color:#465f69;font-weight:650;font-size:.95rem}.brand img{width:24px;height:24px;object-fit:contain}</style></head>
<body><main class="page"><article class="card"><h1>$title</h1><div class="date">$date</div>$body</article><footer class="brand"><div class="brandline">$logo<span>Memora</span></div><div>${htmlEscape(slogan)}</div></footer></main></body></html>"""
    }

    private fun htmlEscape(value: String): String = value
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")

    private fun uriFor(file: File): Uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)

    private fun clearOld(prefix: String, suffix: String) {
        shareDir.listFiles()?.filter { it.name.startsWith(prefix) && it.name.endsWith(suffix) }?.forEach { it.delete() }
    }
}
