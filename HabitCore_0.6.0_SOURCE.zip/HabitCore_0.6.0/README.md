# HabitCore 0.6.0

## Navigation simplification

- The separate Home screen is removed.
- The app opens directly in Habits.
- Main Habits and Tasks screens no longer show a back arrow.
- A single section switch control is used in the top bar:
  - Habits → tap once → Tasks
  - Tasks → tap once → Habits
- Habit directions/categories are removed from the user interface.
- Existing direction data is NOT deleted. All existing habits are now shown together.
- New habits are stored under the safe default category internally, while the category system stays hidden for backward compatibility.

## Habit monitoring drill-down

- Month and week day cells are now tappable.
- Selecting a day opens a dedicated day detail screen.
- Top bar shows numeric date (dd.MM.yyyy) and that day's percentage.
- The detail list shows every habit scheduled for that day.
- Each habit shows:
  - completed ✓
  - unfinished/failed ×
  - measurable partial percentage when applicable
  - note text when a note exists
- A compact top icon switches between:
  - all habits
  - unfinished habits only

## Task monitoring drill-down

- Month calendar day cells are now tappable.
- Selecting a day opens only tasks completed for that day.
- Layout follows the archive style.
- The top result area shows the number of completed tasks for the selected day.

## Existing functionality preserved

- Today-first five-day habit grid
- Hide DONE/FAILED habits for today
- Manual habit ordering
- Habit editing
- Carry-over task scoring
- 10 visual themes × 4 accent palettes
- Daily / weekly / monthly notifications
- Archive, scheduling, task priorities and task completion reversal

## Data safety

- Room schema remains version 4.
- No destructive migration is used.
- Existing habits, old hidden category values, tasks, task plans, history, monitoring and settings remain intact.
- Same bundled TEST signing key as 0.4.x / 0.5.0 is retained.
- 0.5.0 → 0.6.0 can be installed as a normal update.

## GitHub

Upload `HabitCore_0.6.0_SOURCE.zip` to the repository root.

Replace `.github/workflows/main.yml` with the supplied `main_0.6.0.yml`.

Artifact:
`HabitCore-0.6.0-debug-apk`
