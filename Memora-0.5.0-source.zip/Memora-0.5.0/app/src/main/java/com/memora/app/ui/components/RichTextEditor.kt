package com.memora.app.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.ContentPaste
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.SelectAll
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.ParagraphStyle
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memora.app.data.model.TextInlineStyle
import com.memora.app.i18n.L
import com.memora.app.i18n.S
import com.memora.app.prefs.AppLanguage
import com.memora.app.prefs.FontChoice
import com.memora.app.ui.theme.fontFamily
import com.memora.app.util.EditorInputNormalizer

/**
 * IME-safe editor: underlying text always stays plain. Bold/italic are rendered through a
 * same-length VisualTransformation, so SwiftKey/Gboard composing spans never become Memora data.
 * The platform selection menu remains available; Memora adds a small contextual row when a range
 * is selected, with extra formatting under the three-dot menu.
 */
@Composable
fun PlainTextEditor(
    text: String,
    styles: List<TextInlineStyle> = emptyList(),
    onValueChanged: (String, List<TextInlineStyle>) -> Unit,
    fontChoice: FontChoice,
    ink: Color,
    language: AppLanguage,
    uiScale: Float = 1.0f,
    onFocused: () -> Unit = {},
    onCursorChanged: (Int) -> Unit = {},
    requestFocus: Boolean = false,
    requestCursorPosition: Int? = null,
    modifier: Modifier = Modifier
) {
    val focusRequester = remember { FocusRequester() }
    val clipboard = LocalClipboardManager.current
    var moreOpen by remember { mutableStateOf(false) }
    var localStyles by remember(styles) { mutableStateOf(styles.sanitize(text.length)) }
    var fieldValue by remember {
        mutableStateOf(TextFieldValue(text = text, selection = TextRange(text.length)))
    }

    LaunchedEffect(text) {
        if (text != fieldValue.text) {
            fieldValue = fieldValue.copy(
                text = text,
                selection = TextRange(fieldValue.selection.start.coerceAtMost(text.length)),
                composition = null
            )
            localStyles = styles.sanitize(text.length)
        }
    }
    LaunchedEffect(styles) { localStyles = styles.sanitize(fieldValue.text.length) }

    LaunchedEffect(requestFocus, requestCursorPosition) {
        if (requestFocus) {
            val cursor = (requestCursorPosition ?: fieldValue.text.length).coerceIn(0, fieldValue.text.length)
            fieldValue = fieldValue.copy(selection = TextRange(cursor), composition = null)
            onCursorChanged(cursor)
            focusRequester.requestFocus()
        }
    }

    val selection = fieldValue.selection
    val hasSelection = !selection.collapsed && selection.min < selection.max

    androidx.compose.foundation.layout.Column(modifier) {
        if (hasSelection) {
            Surface(
                shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.82f),
                modifier = Modifier.padding(bottom = 4.dp)
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(1.dp),
                    modifier = Modifier.padding(horizontal = 3.dp, vertical = 1.dp)
                ) {
                    IconButton(onClick = {
                        clipboard.setText(AnnotatedString(fieldValue.text.substring(selection.min, selection.max)))
                    }) { Icon(Icons.Rounded.ContentCopy, contentDescription = L.t(language, S.COPY)) }
                    IconButton(onClick = {
                        clipboard.setText(AnnotatedString(fieldValue.text.substring(selection.min, selection.max)))
                        replaceSelection(fieldValue, "") { next ->
                            val adjusted = adjustStylesForEdit(fieldValue.text, next.text, localStyles)
                            fieldValue = next
                            localStyles = adjusted
                            onValueChanged(next.text, adjusted)
                        }
                    }) { Icon(Icons.Rounded.ContentCut, contentDescription = L.t(language, S.CUT)) }
                    IconButton(onClick = {
                        val pasted = clipboard.getText()?.text.orEmpty()
                        if (pasted.isNotEmpty()) replaceSelection(fieldValue, pasted) { next ->
                            val adjusted = adjustStylesForEdit(fieldValue.text, next.text, localStyles)
                            fieldValue = next
                            localStyles = adjusted
                            onValueChanged(next.text, adjusted)
                        }
                    }) { Icon(Icons.Rounded.ContentPaste, contentDescription = L.t(language, S.PASTE)) }
                    IconButton(onClick = { fieldValue = fieldValue.copy(selection = TextRange(0, fieldValue.text.length)) }) {
                        Icon(Icons.Rounded.SelectAll, contentDescription = L.t(language, S.SELECT_ALL))
                    }
                    androidx.compose.foundation.layout.Box {
                        IconButton(onClick = { moreOpen = true }) { Icon(Icons.Rounded.MoreVert, contentDescription = L.t(language, S.MORE)) }
                        DropdownMenu(expanded = moreOpen, onDismissRequest = { moreOpen = false }) {
                            DropdownMenuItem(
                                text = { Text(L.t(language, S.BOLD)) },
                                onClick = {
                                    localStyles = toggleStyle(localStyles, selection.min, selection.max, bold = true).sanitize(fieldValue.text.length)
                                    onValueChanged(fieldValue.text, localStyles)
                                    moreOpen = false
                                }
                            )
                            DropdownMenuItem(
                                text = { Text(L.t(language, S.ITALIC)) },
                                onClick = {
                                    localStyles = toggleStyle(localStyles, selection.min, selection.max, italic = true).sanitize(fieldValue.text.length)
                                    onValueChanged(fieldValue.text, localStyles)
                                    moreOpen = false
                                }
                            )
                            DropdownMenuItem(
                                text = { Text(L.t(language, S.NUMBERED_LIST)) },
                                onClick = {
                                    val next = applyNumberedList(fieldValue)
                                    val adjusted = adjustStylesForEdit(fieldValue.text, next.text, localStyles)
                                    fieldValue = next
                                    localStyles = adjusted
                                    onValueChanged(next.text, adjusted)
                                    moreOpen = false
                                }
                            )
                        }
                    }
                }
            }
        }

        BasicTextField(
            value = fieldValue,
            onValueChange = { incoming ->
                val normalized = EditorInputNormalizer.normalize(
                    previousText = fieldValue.text,
                    incomingText = incoming.text,
                    incomingCursor = incoming.selection.start,
                    hasComposition = incoming.composition != null
                )
                val next = if (normalized.changed) incoming.copy(
                    text = normalized.text,
                    selection = TextRange(normalized.cursor),
                    composition = null
                ) else incoming
                val nextStyles = if (next.text != fieldValue.text) adjustStylesForEdit(fieldValue.text, next.text, localStyles) else localStyles
                fieldValue = next
                localStyles = nextStyles
                onCursorChanged(next.selection.start)
                if (next.text != text || nextStyles != styles) onValueChanged(next.text, nextStyles)
            },
            modifier = Modifier
                .fillMaxWidth()
                .focusRequester(focusRequester)
                .onFocusChanged {
                    if (it.isFocused) {
                        onFocused()
                        onCursorChanged(fieldValue.selection.start)
                    }
                },
            textStyle = TextStyle(
                color = ink,
                fontFamily = fontFamily(fontChoice),
                fontSize = (16.2f * uiScale).sp,
                lineHeight = (24.0f * uiScale).sp
            ),
            keyboardOptions = KeyboardOptions(
                capitalization = KeyboardCapitalization.Sentences,
                keyboardType = KeyboardType.Text
            ),
            cursorBrush = SolidColor(ink),
            visualTransformation = MemoraVisualTransformation(localStyles, uiScale)
        )
    }
}

private class MemoraVisualTransformation(
    private val styles: List<TextInlineStyle>,
    private val uiScale: Float
) : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val transformed = buildAnnotatedString {
            append(text.text)
            styles.forEach { span ->
                if (span.end > span.start && span.start >= 0 && span.end <= text.length) {
                    addStyle(
                        SpanStyle(
                            fontWeight = if (span.bold) FontWeight.Bold else null,
                            fontStyle = if (span.italic) FontStyle.Italic else null
                        ),
                        span.start,
                        span.end
                    )
                }
            }
            // Existing Memora paragraph model stores a blank line as "\n\n". Compress that
            // blank paragraph to 75% of the normal line height without altering stored text.
            var index = text.text.indexOf("\n\n")
            while (index >= 0) {
                addStyle(ParagraphStyle(lineHeight = (18f * uiScale).sp), index + 1, (index + 2).coerceAtMost(text.length))
                index = text.text.indexOf("\n\n", index + 2)
            }
        }
        return TransformedText(transformed, OffsetMapping.Identity)
    }
}

private fun List<TextInlineStyle>.sanitize(length: Int): List<TextInlineStyle> = mapNotNull { span ->
    val start = span.start.coerceIn(0, length)
    val end = span.end.coerceIn(start, length)
    if (end > start && (span.bold || span.italic)) span.copy(start = start, end = end) else null
}

private fun toggleStyle(
    styles: List<TextInlineStyle>,
    start: Int,
    end: Int,
    bold: Boolean = false,
    italic: Boolean = false
): List<TextInlineStyle> {
    if (end <= start) return styles
    val fullyCovered = styles.any { it.start <= start && it.end >= end && (!bold || it.bold) && (!italic || it.italic) }
    return if (fullyCovered) {
        styles.flatMap { span ->
            if (span.end <= start || span.start >= end) listOf(span)
            else {
                val out = mutableListOf<TextInlineStyle>()
                if (span.start < start) out += span.copy(end = start)
                val middleStart = maxOf(span.start, start)
                val middleEnd = minOf(span.end, end)
                val middle = span.copy(
                    start = middleStart,
                    end = middleEnd,
                    bold = if (bold) false else span.bold,
                    italic = if (italic) false else span.italic
                )
                if (middle.bold || middle.italic) out += middle
                if (span.end > end) out += span.copy(start = end)
                out
            }
        }
    } else {
        styles + TextInlineStyle(start = start, end = end, bold = bold, italic = italic)
    }
}

private fun adjustStylesForEdit(oldText: String, newText: String, styles: List<TextInlineStyle>): List<TextInlineStyle> {
    if (oldText == newText || styles.isEmpty()) return styles
    var prefix = 0
    val min = minOf(oldText.length, newText.length)
    while (prefix < min && oldText[prefix] == newText[prefix]) prefix++
    var suffix = 0
    while (suffix < min - prefix && oldText[oldText.length - 1 - suffix] == newText[newText.length - 1 - suffix]) suffix++
    val oldEnd = oldText.length - suffix
    val newEnd = newText.length - suffix
    val delta = (newEnd - prefix) - (oldEnd - prefix)
    return styles.mapNotNull { span ->
        when {
            span.end <= prefix -> span
            span.start >= oldEnd -> span.copy(start = span.start + delta, end = span.end + delta)
            else -> {
                val newStart = minOf(span.start, prefix)
                val newSpanEnd = if (span.end >= oldEnd) span.end + delta else newEnd
                if (newSpanEnd > newStart) span.copy(start = newStart, end = newSpanEnd) else null
            }
        }
    }.sanitize(newText.length)
}

private fun replaceSelection(value: TextFieldValue, replacement: String, commit: (TextFieldValue) -> Unit) {
    val start = value.selection.min
    val end = value.selection.max
    val newText = value.text.replaceRange(start, end, replacement)
    val cursor = start + replacement.length
    commit(value.copy(text = newText, selection = TextRange(cursor), composition = null))
}

private fun applyNumberedList(value: TextFieldValue): TextFieldValue {
    val start = value.selection.min
    val end = value.selection.max
    val lineStart = value.text.lastIndexOf('\n', (start - 1).coerceAtLeast(0)).let { if (it < 0) 0 else it + 1 }
    val lineEndRaw = value.text.indexOf('\n', end)
    val lineEnd = if (lineEndRaw < 0) value.text.length else lineEndRaw
    val selected = value.text.substring(lineStart, lineEnd)
    val numbered = selected.split('\n').mapIndexed { index, line ->
        val cleaned = line.replace(Regex("^\\s*\\d+\\.\\s*"), "")
        "${index + 1}. $cleaned"
    }.joinToString("\n")
    val nextText = value.text.replaceRange(lineStart, lineEnd, numbered)
    return value.copy(text = nextText, selection = TextRange(lineStart, lineStart + numbered.length), composition = null)
}
