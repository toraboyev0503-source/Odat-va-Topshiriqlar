# Memora 0.9.42 — GitHub yuklash yo‘riqnomasi

**Hozircha GitHub’ga hech narsa yuklanmaydi.** Faqat foydalanuvchining alohida buyrug‘idan keyin GitHub orqali build qilinadi.

1. `Memora_0.9.42_GitHub.zip` faylini repozitoriy asosiy katalogiga arxiv sifatida yuklash mumkin — GitHub’da alohida yuzlab faylni ochish shart emas.
2. `.github/workflows/main.yml` faylini hamroh `android-build_0.9.42.yml` mazmuni bilan almashtirish kerak. ZIP ichida shu workflow `.github/workflows/android-build.yml` bo‘lib turadi; **ikkita bir xil workflow’ni bir vaqtda faol qilish shart emas.**
3. `Actions` → `Memora 0.9.42 Android Build` jarayonida Kotlin unit tests, lint, regressiya va APK artefaktini tekshirish kerak.
4. Build muvaffaqiyatli bo‘lgach `Memora-0.9.42-debug-apk` artefakti olinadi.

Versiya: **0.9.42**, `versionCode 63`. Debug paket identifikatori va test imzosi o‘zgarmagan. Room v9 o‘zgarmaydi.

**F-09 bo‘yicha qurilma sinovi shart:** turli Android versiyalari, gesture navigatsiya, tez skroll, status bar yopilishi va qaytishi, klaviatura va tahrirlash, Reader → Editor → Back yo‘li tekshiriladi. `statusBarsIgnoringVisibility` ishlashi qurilmada tasdiqlanmaguncha vizual xatosiz deb baholanmaydi.
