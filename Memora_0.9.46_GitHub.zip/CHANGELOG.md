## 0.9.46 — Performance Foundation (2026-11-21)

- O-01: Asosiy navigatsiyada barcha to‘liq qaydlarni doimiy kuzatish bekor; yengil `NoteSummary` proyeksiya.
- O-02: Room Paging3 (32/page), filtrlar va FTS qidiruv, ortiqcha ro‘yxat xotirasi cheklangan.
- O-03: Reader ekrani bir hujjat ko‘rinishidagi virtual blokli LazyColumn; highlight va media saqlanadi.
- O-04: Editor tez matn tahririda bitta paragrafni qayta hisoblaydi, saqlash snapshotlari debounce’dan keyin yig‘iladi.
- O-05: Room 9→10 migratsiya, FTS4 + uchta trigger. Asl qaydlar jadvalining matni o‘zgartirilmaydi.
- O-06: 24 MiB media bitmap LRU; resurslar fon oqimida ochiladi.
- O-07: mutex, recovery va avtomatik saqlash semantikasi saqlandi; og‘ir preview ortiqcha qayta hisoblanmaydi.
- O-08: Dastlabki baseline profile qoidalari va release R8 sozlamalari.
- O-09: Sintetik 140/1k/5k/10k SQL benchmark, Kotlin/JUnit, migratsiya testlari va yangi 209+ regresiya shartlari.
- versionCode 67, versionName 0.9.46, Room 10. Debug signing, app ID, backup schema 7 saqlandi.
- **Cheklov:** Android kompilyatsiyasi/telefon fps sinovi bu bosqichda bajarilmadi.

## Memora 0.9.45 — Android matn tanlash menyusi tuzatildi (21.11.2026)

- 0.9.44 dagi xato: Android «Nusxa olish / Geminidan so‘rash / …» kontekst menyusi Memora oynasi o‘rnida ochilgan.
- Sabab: avvalgi implementatsiya faqat `LocalTextToolbar`ni almashtirgan, ammo Compose Foundation 1.9+ yangi `LocalTextContextMenuToolbarProvider`/`DropdownProvider`dan foydalanadi.
- Yangi versiyada ikkala Compose API to‘sildi; Memora menyusi endi `TextFieldValue.selection` va `TextLayoutResult`dan mustaqil hisoblanadi.
- Tanlash dastagi (handles) saqlanadi; ko‘rinadigan panelda faqat **Nusxalash / Rasm / Marker** (oldingi bo‘yalgan matnda **X + 3 rang**).
- Qo‘shimcha o‘zgarish yo‘q: Room 9, backup, marker rangini saqlash va ulashish mexanizmi o‘z holida.
- Tekshiruv: manba regressiyasi / sintaksis; Android APK kompilyatsiya va telefonda sinov alohida GitHub build bosqichida bajariladi.

# Memora 0.9.44 — Tanlash paneli va ixcham Memora Paper kartalari

## Tasdiqlangan H-01–H-09

- **H-01/H-02:** O‘qish rejimida Android’ning standart nusxalash oynasi o‘rniga Memora’ning o‘z uch amalli, matn ustida chiqadigan tanlash paneli qo‘shildi: Nusxalash, Rasm, Marker. Matnni uzun bosib tanlashning odatiy usuli va tutqichlari saqlanadi.
- **H-03/H-04:** Markerga bir marta bosish tanlangan parchaga joriy rangni qo‘llaydi. Marker ustida uzoq bosish sariq/yashil/pushti rang tanlashni ochadi. Tanlangan rang keyingi markerlashlar uchun qurilma sozlamasida saqlanadi.
- **H-05/H-06:** Avval ranglangan matn ustiga bir marta bosilganda bir xil rangdagi uzluksiz qism tanlanadi. X belgisi marker rangini olib tashlaydi, uch rangli tugma esa o‘sha qism rangini bir urinishda almashtiradi. Matn mazmuni hamda qalin/kursiv uslublar o‘zgarmaydi.
- **H-07:** Butun yozuvning PNG/PDF sahifalarida ham, tanlangan parchadan olingan mini-kartalarda ham past chapdagi «Memora» matni yonida o‘rnatilgan ilovaning haqiqiy launcher ikonchasi chiziladi; sahifa raqami o‘ngda qoladi.
- **H-08/H-09:** O‘qish oynasining yuqorisidan lupa va qidiruv oynasi olib tashlandi. O‘ngda bitta muallaq qalam, chapda ortga qaytish tugmasi qoladi.

## H-02 aniqligi — Rasm dinamik balandlikda

- Tanlangan parchadagi satrlar Android `StaticLayout` orqali haqiqiy o‘lchanadi; PNG balandligi matnning o‘sha balandligi, yuqori/pastki oraliq va kichik brend footeriga mos tuziladi. Qisqa uch qatorlik matn to‘liq 1080×1528 sahifaga majburlanmaydi.
- Uzoq parchalar 2300 piksel matn balandligi chegarasida sahifalanadi. Oldindan ko‘rishda sahifalar o‘rtasida o‘tish mumkin; «Ulashish» PNG(lar)ni yuboradi; «Saqlash» bittada PNG, ko‘p sahifada rasmlar to‘plangan ZIP uchun tizimning fayl tanlash oynasini ochadi.
- Mini-kartalar asl matnning o‘zidan yaratiladi; alohida sarlavha yoki yaratish sanasi majburiy qo‘shilmaydi.

## Moslik va tekshiruv chegarasi

- `versionName = "0.9.44"`, `versionCode = 65`, Room **9** o‘zgarmaydi.
- Oldingi qaydlar, highlightlar, backup/restore, media va debug imzo ishlashiga tegilmagan. Markerning faqat default rangi oddiy local SharedPreferences orqali saqlanadi.
- 13 tilga tegishli kontekst menyusi va rasmni ulashish/saqlash yozuvlari mavjud.
- Mahalliy tekshiruv: `python3 tools/regression_0944.py`; Android unit test, lint, APK build va qurilma sinovi GitHub’da keyingi alohida buyruq bilan bajariladi.

---

# Memora 0.9.43 — Reader and Memora Paper sharing

## Approved P-01–P-09 implementation
- P-01: Reading and editing titles changed to 39sp / 48sp line height (15% above 34sp baseline); full text size unchanged.
- P-02: Replaced the previous ReaderShareManager legacy layouts with a common Memora Paper renderer. PNG and PDF share one paginated renderer, and HTML shares the same warm paper typography, white card, images, styled text and dates at the end.
- P-03: PNG pagination, PDF sharing, HTML layout, plain text, and a Paper preview in the share sheet. PDF pages are raster-based; they are not selectable text. Audio content has a placeholder, not an embedded playable audio attachment.
- P-04: Removed redundant top-right three-dot Delete action; the bottom Delete action and confirmation remain.
- P-05: Each reader paragraph can be selected, copied and shared via the read-only text selection. A separate bottom action copies the entire note across paragraphs.
- P-06: Yellow, green and rose marker spans are stored independently of note text using NoteBlocksCodec's inline style metadata. No new Room table or destructive migration: old text, current note ID and dates are unchanged. Editor offset tracking, paragraph split/merge and the existing .memora blocksJson backup work with these spans.
- P-07: Selected paragraph snippets can be shared as plain text or a Paper PNG card.
- P-08: Reader can search within the note, show match counts, highlight occurrences and navigate previous/next results.
- P-09: 13 language action labels and existing 5 palette/Room 9 behavior retained. Regression tests added for the policy, UI wiring and exports.

## Compatibility and limitations
- versionName: 0.9.43; versionCode: 64; Room: 9 (unchanged).
- Debug signing config, package ID and the 0.9.42 recovery, memory and camera subsystems remain unchanged.
- Existing highlight operations apply to the selected *paragraph*. Cross-paragraph arbitrary selection is not implemented; the bottom Copy command copies the complete note.
- Share sheet preview renders the page hierarchy and text excerpt, not an image of every exported page.
- No Android SDK was available in the local environment; Gradle compilation and actual on-device UI verification still need GitHub Actions and a device.

# Memora 0.9.42 — Paper + Dynamic Status Bar (F-09–F-15)

- **F-09:** Reader and Editor share the same scroll-sensitive Android status-bar visibility behavior. Icons hide once the document reaches the system-bar region and reappear only when returning to the top. A hysteresis boundary prevents flashing; hidden status bar does not change the stable top inset. Status bar visibility is restored on leaving a document.
- **F-10:** Removed routine “Saving” / “Saved” chrome text without altering automatic Room saves, recovery snapshots or error feedback.
- **F-11:** Reintroduced a single rounded, palette-aware paper surface around title, body, images, audio, tags and dates in *both* Reader and Editor. The paper is inside the original viewport scroll; no nested scroll and no fixed top bar.
- **F-12:** Both title variants use 34sp / 41sp line height, with a matching editor placeholder.
- **F-13:** Created and edited timestamps moved from below the title to a compact, muted footer inside the paper. The edited date is omitted when unchanged.
- **F-14:** Kept independent floating Back / Edit / Done controls. Controls now use statusBarsIgnoringVisibility so they do not shift when the Android status bar is hidden.
- **F-15:** Removed editor title animateContentSize jitter; preserved existing keyboard-aware viewport and scroll position persistence. Existing save failures continue to display explicit feedback.
- Debug version 0.9.42 / versionCode 63; Room v9, ID and signing key unchanged.

**Validation:** `tools/regression_0942.py` static source checks and existing backend tests completed locally. Actual APK build, emulator, edge-to-edge presentation and device/keyboard testing remain pending the user's separate build approval.

---

# Memora 0.9.41 — Full Canvas Reading & Editing

- **F-01:** Reader/Editor have destination-local edge-to-edge layouts; other screens retain `safeDrawing`.
- **F-02/F-03:** Title, metadata, and document content scroll behind the status bar to the physical screen edge; no fixed top app bar or 52dp stop.
- **F-04:** Floating circular Back, Pencil (read) and Done (edit) actions with theme-aware opaque backgrounds; menu retained.
- **F-05:** At 16dp of upward text movement, controls hide; reverse scroll or one unconsumed tap reveals them. 140ms hide / 170ms reveal.
- **F-06:** Reader's body Surface and editor's short-note card removed; text is continuous on the full canvas.
- **F-07:** Approximate reader scroll position handed to editor (single-use normalized fraction); keyboard, cursor, media and existing autosave retained.
- **F-08:** Tests include directional scroll JVM policy and static code contract; all palettes/RTL/debug signing unchanged.

`versionCode 62` · `versionName 0.9.41` · Room schema stays **9**; no database migration needed.

**Release status:** Source prepared; not uploaded to GitHub, APK compilation and device-level visual verification pending.

---

# Memora 0.9.40 — yangi Eslatmalar va Kun izi albomi

## O‘zgarishlar
- Pastki navigatsiyadagi Topilmalar o‘rniga Taqvim; Sozlamalar ichida ikkita mustaqil Eslatmalar sozlamasi.
- Yozuv eslatmalari: 7 kundan eski qaydlar, 1/3/5 ta tanlov, og‘irliklangan eski-yangi tasodifiy saralash, 30 kunlik takrorni cheklash, asl yozilgan soat, ilova ichidagi xotira kartasi va Android bildirishnomalari. O‘tkazish, o‘qish, bir soatdan keyin eslatish.
- Kun izi: kamera, odatiy va yana 4 ta nostaljik foto effekti, 20 so‘zli izoh, qo‘lyozma ko‘rinishidagi Polaroid karta, raqamlangan fotoalbom va sahifa varaqlash.
- Kun izi eslatmalari: mustaqil 1/3/5 miqdor, tasodifiy yoki belgilangan boshlanish vaqti, vaqt oralig‘i, bildirishnomadan kamerani ochish.
- Editor: tepaga suriladigan matn va nozik dumaloq ortga qaytish tugmasi.
- Room 8→9 qo‘shimcha migratsiya; eski Topilma va Vaqt izi ma’lumotlari yo‘q qilinmaydi. `.memora` zaxirasiga yangi fotoalbom ham qo‘shildi.
- 13 ta til uchun eslatma bildirishnomalari sarlavhasi, boshqaruv tugmalari va yozilgan vaqt iboralari.

## Cheklovlar va tekshirish
- Bu manba kod kompilyatsiyasi mahalliy Android SDK yo‘qligi sabab hali tasdiqlanmagan. APK natijasi faqat keyingi GitHub builddan so‘ng aniqlanadi.
- Android bildirishnomalari ruxsatlar, fon rejimi va qurilma energiya sozlamalariga bog‘liq ravishda kechikishi mumkin. Absolyut aynan daqiqada kelish kafolatlanmaydi.
- Kitob varaqlash yumshoq 3D pager sifatida amalga oshirilgan; jismoniy qog‘oz sahifasining real deformatsiya simulyatsiyasi emas.
- Eski Topilma kodi va jadvallari yangilash/backup mosligi uchun saqlanadi, asosiy interfeys va eski bildirishnoma oqimlari o‘chirildi.
- Eslatmalar sukut bo‘yicha o‘chiq; foydalanuvchi sozlamalardan yoqadi.

---

# Memora 0.9.39 — Quiet Navigation / overlap fix

- Removed detail-screen fadeIn/fadeOut; root-tab switches are immediate.
- Detail navigation enters by a quiet 12 dp slide over 170 ms; Back slides the outgoing detail out over 170 ms.
- Wrapped all 19 Navigation Compose destinations in opaque, palette-aware full-screen Surfaces to prevent text ghosting.
- Made NavHost full-size and stable; moved bottom-bar padding inside the root destinations.
- Kept five-button bottom navigation hidden through the entire detail exit transition and during keyboard entry.
- Added pure Kotlin navigation policy and JUnit tests; made the slide RTL-aware.
- `versionName = 0.9.39`, `versionCode = 60`; Room schema, signing key and debug package ID unchanged.
- Static and pure Kotlin tests are not a substitute for GitHub build and device visual verification.

---

# Memora 0.9.38 — Harmony UI (U-01–U-06)

- **U-01 Navigation:** removed whole-screen simultaneous fade on root tabs; details use subtle horizontal motion and shorter transitions.
- **U-02 Notes archive:** current-year notes remain expanded by day; completed years become a single collapsible year folder, without month folders; search shows all matching notes directly.
- **U-03 Overlays and keyboard:** unified palette-aware Material 3 tonal surface roles, shared `MemoraSheet` / `MemoraDialog`, compact new-note sheet and search filters, themed date picker; hide the five-button bottom bar and its reserved space when the IME opens.
- **U-04 Language:** compact theme-aligned selectable language cards, supporting all 13 existing language choices and RTL.
- **U-05 Theme:** light/dark/system previews, five live palette samples, font previews, scale slider and localized reset/mode names.
- **U-06 Security:** coherent app-lock header and clear selection cards for existing lock intervals.
- **Compatibility:** `versionName = 0.9.38`, `versionCode = 59`; same debug application identity/signing certificate, Room schema 8, existing settings, content and exports preserved.
- **Validation:** 185 static regression checks, two Topilma visual checks, 5 backend tests and a pure Kotlin archive policy smoke test passed locally. Android Gradle compile, instrumentation, lint, device test and in-place APK upgrade remain unverified until CI/device runs.

---

# Memora 0.9.37 — audit fixes M-01–M-12

- Single, up-to-date GitHub Actions workflow with lint, unit tests, APK build, backend tests and optional emulator migration check.
- Preserve note data and attached media when save fails; enforce required title and recover drafts.
- Separate local save from Obsidian sync errors; improve Topilmalar selection count.
- Transactional database import, staged media restoration and rollback cleanup on error.
- Bounded OCR image staging; Topilmalar integration preference now drives source suggestions.
- Targeted integration UI localization/theming, migration test coverage, backend throttling and limited refactoring.
- Version updated to `0.9.37` / `58`, with Room schema kept at `8`.

See `docs/RELEASE_0.9.37.md` for test status and remaining device/build verification.

# Memora 0.9.36 — external Topilma source chooser

- “Topilmaga saqlash” now opens a compact bottom source chooser before saving.
- The last-used source is the primary large option with cover/title.
- The next five recently used sources appear as compact horizontal cover tiles with short titles.
- Tapping any source saves immediately; no second confirmation is required.
- “Barcha manbalar” opens a searchable full source list.
- Current-source metadata is surfaced as a separate suggestion only when usable title/author/URL metadata is available.
- Detected new sources are created only after the user explicitly selects the suggestion.
- Detected source contexts are remembered and mapped back to the selected existing source on later captures.
- External app names are fallback metadata only, not the preferred source.
- Browser URL metadata continues to be enriched asynchronously into article/site title, author and image/favicon where available.
- Back/outside tap dismisses the chooser without saving.
- Canonical Topilma card visuals remain unchanged.
- Version bumped to `0.9.36` / code `57`.

# Memora 0.9.35 — Topilma scanner + external app integrations + Back fix

## 0.9.35.1
- Installation compatibility build: Accessibility Service component temporarily removed from the APK.
- Explicit Android “Topilmaga saqlash” PROCESS_TEXT integration remains available.
- Scanner/OCR and Topilma creation/back-navigation improvements remain unchanged.

- Topilma copy icon is now a scanner icon.
- Camera copy flow now uses Google ML Kit Document Scanner FULL mode with automatic page detection, perspective correction, crop and cleanup.
- The old custom perspective transform is no longer applied to OCR input, avoiding bent/skewed page rendering.
- OCR keeps line/paragraph-aware reading order, adds full-line tap selection, range dragging and editable review before insertion.
- Settings now includes “Topilmalar integratsiyasi”.
- Users can add/remove launchable apps such as ChatGPT, Chrome and eReader from the allowed-app list.
- Android PROCESS_TEXT integration adds “Topilmaga saqlash” to compatible text-selection menus.
- Optional quick monitoring uses an Accessibility Service for selected apps and offers a small save prompt after copied text is detected.
- External captures create/reuse Topilma sources automatically and use app metadata as fallback.
- Browser captures attempt to detect the current URL; network enrichment fetches page title, author, Open Graph image or favicon when available.
- ChatGPT-like apps map to a Chat source; eReader/book apps map to a Book source with available metadata.
- Topilma editor Back now waits only for safe local save; it no longer forces synchronous Obsidian sync before navigating back.
- Toolbar Back and system Back share the same guarded exit path; local sheets/dialogs close first; repeated taps are ignored.
- Save failures are shown in the editor instead of leaving the screen apparently frozen.
- Canonical Topilma card visual renderer/spec remains unchanged.
- Version bumped to `0.9.35` / code `55`.

CI test correction: QuietNavigationPolicyTest now checks Calendar as the primary tab in 0.9.40.
