package com.memora.app.util

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class EditorInputNormalizerTest {
    @Test
    fun commaDoesNotCreateParagraph() {
        val result = EditorInputNormalizer.normalize("Salom", "Salom,", 6, false)
        assertEquals("Salom,", result.text)
        assertFalse(result.changed)
    }

    @Test
    fun normalLetterDoesNotCreateParagraph() {
        val result = EditorInputNormalizer.normalize("salo", "salom", 5, false)
        assertEquals("salom", result.text)
        assertFalse(result.changed)
    }

    @Test
    fun composingUpdateIsNeverTransformed() {
        val result = EditorInputNormalizer.normalize("haqi", "haqida", 6, true)
        assertEquals("haqida", result.text)
        assertFalse(result.changed)
    }

    @Test
    fun enterCreatesSingleBlankLine() {
        val result = EditorInputNormalizer.normalize("Birinchi", "Birinchi\n", 9, false)
        assertEquals("Birinchi\n\n", result.text)
        assertEquals(10, result.cursor)
        assertTrue(result.changed)
    }

    @Test
    fun periodAtSentenceEndGetsOneSpace() {
        val result = EditorInputNormalizer.normalize("Salom", "Salom.", 6, false)
        assertEquals("Salom. ", result.text)
        assertEquals(7, result.cursor)
        assertTrue(result.changed)
    }

    @Test
    fun decimalPeriodIsNotChanged() {
        val result = EditorInputNormalizer.normalize("12", "12.", 3, false)
        assertEquals("12.", result.text)
        assertFalse(result.changed)
    }
    @Test
    fun numberedListContinuesAfterEnter() {
        val result = EditorInputNormalizer.normalize("1. Birinchi", "1. Birinchi\n", 12, false)
        assertEquals("1. Birinchi\n2. ", result.text)
        assertEquals(15, result.cursor)
        assertTrue(result.changed)
    }

}
