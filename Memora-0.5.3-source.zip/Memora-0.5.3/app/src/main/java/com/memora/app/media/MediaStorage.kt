package com.memora.app.media

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.core.content.FileProvider
import com.memora.app.data.model.NoteBlock
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

class MediaStorage(private val context: Context) {
    data class CameraCapture(val uri: Uri, val file: File)
    private val root: File get() = context.filesDir

    fun importImage(uri: Uri): NoteBlock.Image {
        val bitmap = context.contentResolver.openInputStream(uri)?.use(BitmapFactory::decodeStream)
            ?: error("Unable to read image")
        val relative = "media/images/${UUID.randomUUID()}.jpg"
        val target = resolve(relative)
        target.parentFile?.mkdirs()
        FileOutputStream(target).use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)
        }
        bitmap.recycle()
        return NoteBlock.Image(relativePath = relative, mimeType = "image/jpeg")
    }

    fun createCameraCapture(): CameraCapture {
        val dir = File(context.cacheDir, "camera").apply { mkdirs() }
        val file = File(dir, "${UUID.randomUUID()}.jpg")
        if (!file.exists()) file.createNewFile()
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        return CameraCapture(uri, file)
    }

    fun importCameraImage(capture: CameraCapture): NoteBlock.Image =
        try {
            importImage(capture.uri)
        } finally {
            runCatching { capture.file.delete() }
        }

    fun discardCameraCapture(capture: CameraCapture) {
        runCatching { capture.file.delete() }
    }

    fun newAudioFile(): Pair<String, File> {
        val relative = "media/audio/${UUID.randomUUID()}.m4a"
        val target = resolve(relative)
        target.parentFile?.mkdirs()
        return relative to target
    }

    fun resolve(relativePath: String): File = File(root, relativePath)

    fun delete(relativePath: String) {
        runCatching { resolve(relativePath).delete() }
    }

    fun storeImported(relativeFolder: String, extension: String, bytes: ByteArray): String {
        val cleanExt = extension.trimStart('.').ifBlank { "bin" }
        val relative = "media/$relativeFolder/${UUID.randomUUID()}.$cleanExt"
        val target = resolve(relative)
        target.parentFile?.mkdirs()
        target.writeBytes(bytes)
        return relative
    }
}
