package com.memora.app

import android.Manifest
import android.app.KeyguardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import com.memora.app.export.ExportFormat
import com.memora.app.export.ExportManager
import com.memora.app.export.ExportRequest
import com.memora.app.i18n.L
import com.memora.app.i18n.S
import com.memora.app.notifications.AlarmScheduler
import com.memora.app.prefs.LockInterval
import com.memora.app.prefs.UserSettings
import com.memora.app.ui.MemoraApp
import com.memora.app.ui.screens.BrandLaunchScreen
import com.memora.app.ui.screens.LockedScreen
import com.memora.app.ui.theme.MemoraTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : FragmentActivity() {

    private lateinit var app: MemoraApplication
    private lateinit var exportManager: ExportManager
    private lateinit var folderLauncher: ActivityResultLauncher<Uri?>
    private lateinit var backupLauncher: ActivityResultLauncher<String>
    private lateinit var importLauncher: ActivityResultLauncher<Array<String>>
    private lateinit var notificationPermissionLauncher: ActivityResultLauncher<String>

    private var pendingExportRequest: ExportRequest? = null
    private val pendingEditorType = mutableStateOf<String?>(null)
    private val unlocked = mutableStateOf(false)
    private var brandSplashFinished = false
    private var backgroundAt: Long? = null
    private var authenticating = false
    private val lockRuntimePrefs by lazy {
        getSharedPreferences("memora_lock_runtime", MODE_PRIVATE)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)

        unlocked.value = sessionUnlocked
        backgroundAt = sessionBackgroundAt

        app = application as MemoraApplication
        exportManager = ExportManager(this, contentResolver, app.repository, app.preferences)
        registerLaunchers()
        handleIntent(intent)

        setContent {
            val settings by app.preferences.settings.collectAsStateWithLifecycle(initialValue = UserSettings())
            MemoraTheme(settings) { _, _ ->
                var showBrandSplash by remember { mutableStateOf(true) }

                LaunchedEffect(Unit) {
                    delay(900)
                    showBrandSplash = false
                    brandSplashFinished = true
                    authenticateIfNeeded(force = false)
                }

                when {
                    showBrandSplash -> BrandLaunchScreen()
                    !settings.lockEnabled || unlocked.value -> MemoraApp(
                        repository = app.repository,
                        preferences = app.preferences,
                        settings = settings,
                        pendingEditorType = pendingEditorType.value,
                        onPendingEditorConsumed = { pendingEditorType.value = null },
                        onExport = ::beginExport,
                        onImport = { importLauncher.launch(arrayOf("*/*")) },
                        onRequestNotifications = ::requestNotificationPermission,
                        onRequestExactTiming = ::requestExactAlarmAccess
                    )
                    else -> LockedScreen(
                        language = settings.language,
                        onUnlock = { authenticateIfNeeded(force = true) }
                    )
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        if (brandSplashFinished) {
            authenticateIfNeeded(force = false)
        }
        if (::app.isInitialized) {
            lifecycleScope.launch(Dispatchers.IO) {
                val scheduler = AlarmScheduler(this@MainActivity)
                app.repository.enabledReminders().forEach(scheduler::scheduleReminder)
            }
        }
    }

    override fun onStop() {
        if (!isChangingConfigurations && !authenticating) {
            val now = System.currentTimeMillis()
            backgroundAt = now
            sessionBackgroundAt = now
            sessionUnlocked = unlocked.value
            lockRuntimePrefs.edit().putLong(KEY_LAST_BACKGROUND_AT, now).commit()
        }
        super.onStop()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun registerLaunchers() {
        folderLauncher = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            if (uri != null) finishFolderExport(uri)
        }

        backupLauncher = registerForActivityResult(
            ActivityResultContracts.CreateDocument("application/octet-stream")
        ) { uri ->
            if (uri != null) finishExport(uri)
        }

        importLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri == null) return@registerForActivityResult
            lifecycleScope.launch(Dispatchers.IO) {
                try {
                    val result = exportManager.importBackup(uri)
                    val scheduler = AlarmScheduler(this@MainActivity)
                    app.repository.enabledReminders().forEach(scheduler::scheduleReminder)
                    val language = app.preferences.settings.first().language
                    withContext(Dispatchers.Main) {
                        Toast.makeText(
                            this@MainActivity,
                            L.format(language, S.IMPORT_SUMMARY, result.imported, result.duplicatesSkipped),
                            Toast.LENGTH_LONG
                        ).show()
                    }
                } catch (t: Throwable) {
                    val language = app.preferences.settings.first().language
                    withContext(Dispatchers.Main) {
                        Toast.makeText(
                            this@MainActivity,
                            "${L.t(language, S.IMPORT_FAILED)}: ${t.message ?: "—"}",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }
        }

        notificationPermissionLauncher = registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { /* The reminder screen stays usable even if permission is denied. */ }
    }

    private fun beginExport(request: ExportRequest) {
        pendingExportRequest = request
        if (request.format == ExportFormat.BACKUP) {
            backupLauncher.launch(ExportManager.suggestedFileName(request))
        } else {
            folderLauncher.launch(null)
        }
    }

    private fun finishFolderExport(treeUri: Uri) {
        val request = pendingExportRequest ?: return
        pendingExportRequest = null
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val language = app.preferences.settings.first().language
                exportManager.writeFolder(request, treeUri, language)
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, L.t(language, S.SAVED), Toast.LENGTH_SHORT).show()
                }
            } catch (t: Throwable) {
                val language = app.preferences.settings.first().language
                withContext(Dispatchers.Main) {
                    Toast.makeText(
                        this@MainActivity,
                        "${L.t(language, S.EXPORT_FAILED)}: ${t.message ?: "—"}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    private fun finishExport(uri: android.net.Uri) {
        val request = pendingExportRequest ?: return
        pendingExportRequest = null
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val language = app.preferences.settings.first().language
                exportManager.write(request, uri, language)
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, L.t(language, S.SAVED), Toast.LENGTH_SHORT).show()
                }
            } catch (t: Throwable) {
                val language = app.preferences.settings.first().language
                withContext(Dispatchers.Main) {
                    Toast.makeText(
                        this@MainActivity,
                        "${L.t(language, S.EXPORT_FAILED)}: ${t.message ?: "—"}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }


    private fun requestExactAlarmAccess() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return
        val scheduler = AlarmScheduler(this)
        if (scheduler.canScheduleExact()) return
        runCatching {
            startActivity(
                Intent(
                    Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                    Uri.parse("package:$packageName")
                )
            )
        }.onFailure {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    private fun handleIntent(intent: Intent?) {
        pendingEditorType.value = intent?.getStringExtra(EXTRA_OPEN_EDITOR)
        val notificationId = intent?.getIntExtra(EXTRA_NOTIFICATION_ID, -1) ?: -1
        if (notificationId >= 0) {
            NotificationManagerCompat.from(this).cancel(notificationId)
            intent?.removeExtra(EXTRA_NOTIFICATION_ID)
        }
    }

    private fun authenticateIfNeeded(force: Boolean) {
        if (authenticating) return
        lifecycleScope.launch {
            val settings = app.preferences.settings.first()
            if (!settings.lockEnabled) {
                unlocked.value = true
                sessionUnlocked = true
                return@launch
            }
            if (!force && !intervalElapsed(settings)) {
                unlocked.value = true
                sessionUnlocked = true
                return@launch
            }

            val authenticators = BiometricManager.Authenticators.BIOMETRIC_WEAK or
                BiometricManager.Authenticators.DEVICE_CREDENTIAL
            val canAuthenticate = BiometricManager.from(this@MainActivity)
                .canAuthenticate(authenticators)

            if (canAuthenticate != BiometricManager.BIOMETRIC_SUCCESS) {
                val keyguard = getSystemService(KeyguardManager::class.java)
                if (keyguard?.isDeviceSecure != true) {
                    unlocked.value = true
                    sessionUnlocked = true
                    Toast.makeText(
                        this@MainActivity,
                        L.t(settings.language, S.NO_DEVICE_SECURITY),
                        Toast.LENGTH_LONG
                    ).show()
                    return@launch
                }
            }

            authenticating = true
            unlocked.value = false
            sessionUnlocked = false
            val prompt = BiometricPrompt(
                this@MainActivity,
                ContextCompat.getMainExecutor(this@MainActivity),
                object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                        authenticating = false
                        unlocked.value = true
                        sessionUnlocked = true
                        backgroundAt = null
                        sessionBackgroundAt = null
                        lockRuntimePrefs.edit().remove(KEY_LAST_BACKGROUND_AT).apply()
                    }

                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                        authenticating = false
                        unlocked.value = false
                        sessionUnlocked = false
                    }

                    override fun onAuthenticationFailed() {
                        unlocked.value = false
                        sessionUnlocked = false
                    }
                }
            )
            val promptInfo = BiometricPrompt.PromptInfo.Builder()
                .setTitle(L.t(settings.language, S.AUTH_TITLE))
                .setSubtitle(L.t(settings.language, S.AUTH_SUBTITLE))
                .setAllowedAuthenticators(authenticators)
                .build()
            prompt.authenticate(promptInfo)
        }
    }

    private fun intervalElapsed(settings: UserSettings): Boolean {
        val background = backgroundAt
            ?: sessionBackgroundAt
            ?: lockRuntimePrefs.getLong(KEY_LAST_BACKGROUND_AT, 0L).takeIf { it > 0L }
            ?: return !unlocked.value
        val elapsed = (System.currentTimeMillis() - background).coerceAtLeast(0L)
        val threshold = when (settings.lockInterval) {
            LockInterval.IMMEDIATELY -> 0L
            LockInterval.ONE_MINUTE -> 60_000L
            LockInterval.FIVE_MINUTES -> 5 * 60_000L
            LockInterval.FIFTEEN_MINUTES -> 15 * 60_000L
            LockInterval.THIRTY_MINUTES -> 30 * 60_000L
        }
        return elapsed >= threshold
    }

    companion object {
        private const val KEY_LAST_BACKGROUND_AT = "last_background_at"
        private var sessionUnlocked: Boolean = false
        private var sessionBackgroundAt: Long? = null
        const val EXTRA_OPEN_EDITOR = "open_editor_type"
        const val EXTRA_NOTIFICATION_ID = "notification_id"
    }
}
