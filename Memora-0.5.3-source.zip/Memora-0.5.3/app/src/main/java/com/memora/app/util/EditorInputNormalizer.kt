package com.memora.app.util

/**
 * Conservative IME normalizer. It only reacts to a genuine single-character insertion after
 * verifying that removing that character reproduces the previous text exactly. This prevents
 * SwiftKey/Gboard composing updates, commas and autocorrect replacements from becoming paragraphs.
 */
object EditorInputNormalizer {
    data class Result(val text: String, val cursor: Int, val changed: Boolean)

    fun normalize(
        previousText: String,
        incomingText: String,
        incomingCursor: Int,
        hasComposition: Boolean
    ): Result {
        val safeCursor = incomingCursor.coerceIn(0, incomingText.length)
        if (hasComposition || incomingText.length != previousText.length + 1 || safeCursor == 0) {
            return Result(incomingText, safeCursor, false)
        }
        val insertedIndex = safeCursor - 1
        if (insertedIndex !in incomingText.indices) return Result(incomingText, safeCursor, false)
        if (incomingText.removeRange(insertedIndex, insertedIndex + 1) != previousText) {
            return Result(incomingText, safeCursor, false)
        }
        return when (incomingText[insertedIndex]) {
            '\n' -> normalizeEnter(previousText, incomingText, insertedIndex, safeCursor)
            '.' -> normalizePeriod(incomingText, insertedIndex, safeCursor)
            else -> Result(incomingText, safeCursor, false)
        }
    }

    private fun normalizeEnter(previousText: String, incomingText: String, index: Int, cursor: Int): Result {
        val beforeCursor = previousText.substring(0, index.coerceAtMost(previousText.length))
        val currentLine = beforeCursor.substringAfterLast('\n')
        val match = Regex("^\\s*(\\d+)\\.\\s+.*$").matchEntire(currentLine)
        if (match != null) {
            val next = (match.groupValues[1].toIntOrNull() ?: 0) + 1
            val suffix = "$next. "
            val adjusted = incomingText.substring(0, cursor) + suffix + incomingText.substring(cursor)
            return Result(adjusted, cursor + suffix.length, true)
        }

        // Memora paragraphs use a blank paragraph. The editor renders that blank line at 30%
        // height, so the stored format remains portable and export-friendly.
        if (incomingText.getOrNull(index - 1) == '\n' || incomingText.getOrNull(index + 1) == '\n') {
            return Result(incomingText, cursor, false)
        }
        val adjusted = incomingText.substring(0, cursor) + "\n" + incomingText.substring(cursor)
        return Result(adjusted, cursor + 1, true)
    }

    private fun normalizePeriod(text: String, index: Int, cursor: Int): Result {
        if (cursor != text.length) return Result(text, cursor, false)
        val previous = text.getOrNull(index - 1) ?: return Result(text, cursor, false)
        if (previous.isWhitespace() || previous.isDigit() || previous == '.') return Result(text, cursor, false)
        return Result(text + " ", cursor + 1, true)
    }
}
