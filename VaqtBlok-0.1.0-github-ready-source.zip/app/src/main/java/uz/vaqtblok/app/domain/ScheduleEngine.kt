package uz.vaqtblok.app.domain

import java.util.Calendar

object ScheduleEngine {
    private const val MINUTES_PER_DAY = 24 * 60

    fun isActive(schedule: BlockSchedule, calendar: Calendar = Calendar.getInstance()): Boolean {
        val minute = calendar.get(Calendar.HOUR_OF_DAY) * 60 + calendar.get(Calendar.MINUTE)
        val day = calendar.get(Calendar.DAY_OF_WEEK)
        return isActive(schedule, day, minute)
    }

    fun isActive(schedule: BlockSchedule, dayOfWeek: Int, minuteOfDay: Int): Boolean {
        if (!schedule.enabled || schedule.days.isEmpty()) return false
        if (minuteOfDay !in 0 until MINUTES_PER_DAY) return false
        if (schedule.startMinute !in 0 until MINUTES_PER_DAY) return false
        if (schedule.endMinute !in 0 until MINUTES_PER_DAY) return false

        val start = schedule.startMinute
        val end = schedule.endMinute

        // Equal start/end is treated as invalid and therefore fail-open.
        // A dedicated 24-hour mode can be added later without ambiguous semantics.
        if (start == end) return false

        return when {
            start < end -> dayOfWeek in schedule.days && minuteOfDay in start until end
            else -> {
                // Cross-midnight, e.g. Mon 22:00 -> Tue 07:00.
                if (minuteOfDay >= start) {
                    dayOfWeek in schedule.days
                } else if (minuteOfDay < end) {
                    previousDay(dayOfWeek) in schedule.days
                } else {
                    false
                }
            }
        }
    }

    fun nextEndEpochMillis(schedule: BlockSchedule, now: Calendar = Calendar.getInstance()): Long {
        val minute = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
        val result = now.clone() as Calendar
        result.set(Calendar.SECOND, 0)
        result.set(Calendar.MILLISECOND, 0)

        val endHour = schedule.endMinute / 60
        val endMin = schedule.endMinute % 60
        result.set(Calendar.HOUR_OF_DAY, endHour)
        result.set(Calendar.MINUTE, endMin)

        when {
            schedule.startMinute == schedule.endMinute -> return now.timeInMillis
            schedule.startMinute < schedule.endMinute -> {
                if (minute >= schedule.endMinute) result.add(Calendar.DAY_OF_YEAR, 1)
            }
            else -> {
                // If currently in the late-night part, end is tomorrow.
                if (minute >= schedule.startMinute) result.add(Calendar.DAY_OF_YEAR, 1)
            }
        }
        return result.timeInMillis
    }

    fun remainingMillis(schedule: BlockSchedule, now: Calendar = Calendar.getInstance()): Long {
        if (!isActive(schedule, now)) return 0L
        return (nextEndEpochMillis(schedule, now) - now.timeInMillis).coerceAtLeast(0L)
    }

    private fun previousDay(day: Int): Int = when (day) {
        Calendar.SUNDAY -> Calendar.SATURDAY
        else -> day - 1
    }
}
