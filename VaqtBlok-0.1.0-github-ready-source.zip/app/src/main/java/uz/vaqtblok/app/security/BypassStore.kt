package uz.vaqtblok.app.security

import android.content.Context

class BypassStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Atomically persists bypasses for all currently active profiles of one app. */
    fun grantAll(packageName: String, expiryByScheduleId: Map<String, Long>): Boolean {
        if (packageName.isBlank() || expiryByScheduleId.isEmpty()) return false
        val editor = prefs.edit()
        expiryByScheduleId.forEach { (scheduleId, untilEpochMillis) ->
            editor.putLong(key(scheduleId, packageName), untilEpochMillis)
        }
        // Correct-PIN unlock should not continue until bypass state is durably written.
        return editor.commit()
    }

    fun isGranted(scheduleId: String, packageName: String, nowMillis: Long = System.currentTimeMillis()): Boolean {
        val k = key(scheduleId, packageName)
        val expiry = prefs.getLong(k, 0L)
        if (expiry <= nowMillis) {
            if (expiry != 0L) prefs.edit().remove(k).apply()
            return false
        }
        return true
    }

    fun clearExpired(nowMillis: Long = System.currentTimeMillis()) {
        val editor = prefs.edit()
        prefs.all.forEach { (k, v) ->
            if (v is Long && v <= nowMillis) editor.remove(k)
        }
        editor.apply()
    }

    private fun key(scheduleId: String, packageName: String) = "$scheduleId|$packageName"

    companion object {
        private const val PREFS = "bypass_v1"
    }
}
