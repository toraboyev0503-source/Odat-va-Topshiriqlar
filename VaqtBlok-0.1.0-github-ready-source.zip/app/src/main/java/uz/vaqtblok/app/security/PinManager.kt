package uz.vaqtblok.app.security

import android.content.Context

class PinManager(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /**
     * True only when a complete, integrity-checked credential can be decoded.
     * If both stored copies are damaged, callers fail open instead of trapping the owner.
     */
    fun hasPin(): Boolean = loadCredential() != null

    fun setPin(pin: String): Boolean {
        if (!isValidFormat(pin)) return false
        val salt = PinCrypto.createSalt()
        val hash = PinCrypto.hash(pin.toCharArray(), salt)
        val record = PinCredentialCodec.encode(salt, hash)

        // commit() is intentional: PIN creation is not reported as successful until it is on disk.
        return prefs.edit()
            .putString(KEY_PRIMARY, record)
            .putString(KEY_BACKUP, record)
            .remove(LEGACY_SALT)
            .remove(LEGACY_HASH)
            .commit()
    }

    fun verify(pin: String): Boolean {
        if (!isValidFormat(pin)) return false
        val credential = loadCredential() ?: return false
        return PinCrypto.verify(pin.toCharArray(), credential.salt, credential.hash)
    }

    fun isValidFormat(pin: String): Boolean = pin.matches(Regex("^[0-9]{6,12}$"))

    private fun loadCredential(): PinCredentialCodec.Credential? {
        val primaryText = prefs.getString(KEY_PRIMARY, null)
        PinCredentialCodec.decode(primaryText)?.let { return it }

        val backupText = prefs.getString(KEY_BACKUP, null)
        val backup = PinCredentialCodec.decode(backupText) ?: return null

        // Self-heal a damaged/missing primary copy when the backup is valid.
        if (backupText != null) {
            prefs.edit().putString(KEY_PRIMARY, backupText).commit()
        }
        return backup
    }

    companion object {
        private const val PREFS = "security_v2"
        private const val KEY_PRIMARY = "pin_record_primary"
        private const val KEY_BACKUP = "pin_record_backup"
        private const val LEGACY_SALT = "pin_salt"
        private const val LEGACY_HASH = "pin_hash"
    }
}
