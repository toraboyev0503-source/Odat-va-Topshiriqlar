package uz.vaqtblok.app.domain

import java.util.Calendar

/**
 * A local, offline block profile.
 * days uses Calendar.SUNDAY..Calendar.SATURDAY constants.
 */
data class BlockSchedule(
    val id: String,
    val name: String,
    val packages: Set<String>,
    val startMinute: Int,
    val endMinute: Int,
    val days: Set<Int>,
    val enabled: Boolean,
    val pinProtected: Boolean,
) {
    companion object {
        fun defaultDays(): Set<Int> = setOf(
            Calendar.MONDAY,
            Calendar.TUESDAY,
            Calendar.WEDNESDAY,
            Calendar.THURSDAY,
            Calendar.FRIDAY,
            Calendar.SATURDAY,
            Calendar.SUNDAY,
        )
    }
}
