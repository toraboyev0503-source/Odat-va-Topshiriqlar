package uz.vaqtblok.app.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import uz.vaqtblok.app.security.BypassStore

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED) {
            BypassStore(context).clearExpired()
        }
    }
}
