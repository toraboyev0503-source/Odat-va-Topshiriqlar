package uz.vaqtblok.app.ui

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.accessibility.AccessibilityManager
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import uz.vaqtblok.app.R
import uz.vaqtblok.app.data.ScheduleRepository
import uz.vaqtblok.app.domain.BlockSchedule
import uz.vaqtblok.app.service.AppBlockAccessibilityService

class MainActivity : AppCompatActivity() {
    private lateinit var repository: ScheduleRepository
    private lateinit var adapter: ScheduleAdapter
    private lateinit var emptyText: TextView
    private lateinit var accessibilityStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        repository = ScheduleRepository(this)
        emptyText = findViewById(R.id.emptyText)
        accessibilityStatus = findViewById(R.id.accessibilityStatus)

        adapter = ScheduleAdapter(
            onToggle = { schedule, enabled -> handleProtected(schedule, "Blok holatini o‘zgartirish") {
                if (!repository.setEnabled(schedule.id, enabled)) {
                    Toast.makeText(this, "Blok holatini saqlab bo‘lmadi", Toast.LENGTH_SHORT).show()
                }
                refresh()
            } },
            onEdit = { schedule -> handleProtected(schedule, "Blokni tahrirlash") {
                startActivity(Intent(this, ScheduleEditorActivity::class.java).putExtra(ScheduleEditorActivity.EXTRA_ID, schedule.id))
            } },
            onDelete = { schedule -> handleProtected(schedule, "Blokni o‘chirish") {
                MaterialAlertDialogBuilder(this)
                    .setTitle("Blok o‘chirilsinmi?")
                    .setMessage("${schedule.name} butunlay o‘chiriladi.")
                    .setNegativeButton("Yo‘q", null)
                    .setPositiveButton("O‘chirish") { _, _ ->
                        if (!repository.delete(schedule.id)) {
                            Toast.makeText(this, "Blokni o‘chirib bo‘lmadi", Toast.LENGTH_SHORT).show()
                        }
                        refresh()
                    }
                    .show()
            } },
        )

        findViewById<RecyclerView>(R.id.scheduleList).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }

        findViewById<MaterialButton>(R.id.addButton).setOnClickListener {
            startActivity(Intent(this, ScheduleEditorActivity::class.java))
        }
        findViewById<MaterialButton>(R.id.accessibilityButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val items = repository.getAll()
        adapter.submit(items)
        emptyText.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE

        val enabled = isBlockingServiceEnabled()
        accessibilityStatus.text = if (enabled) {
            "Bloklash xizmati: YOQILGAN"
        } else {
            "Bloklash xizmati: O‘CHIQ"
        }
    }

    private fun handleProtected(schedule: BlockSchedule, title: String, action: () -> Unit) {
        if (!schedule.pinProtected) {
            action()
            return
        }
        PinDialogs.requestPin(
            context = this,
            title = title,
            onSuccess = action,
            onCancelled = { refresh() },
        )
    }

    private fun isBlockingServiceEnabled(): Boolean {
        val manager = getSystemService(AccessibilityManager::class.java) ?: return false
        val expected = ComponentName(this, AppBlockAccessibilityService::class.java)
        return manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { info ->
                val service = info.resolveInfo?.serviceInfo ?: return@any false
                ComponentName(service.packageName, service.name) == expected
            }
    }
}
