package uz.vaqtblok.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import uz.vaqtblok.app.domain.BlockSchedule
import java.util.UUID

class ScheduleRepository(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun getAll(): List<BlockSchedule> {
        val primary = prefs.getString(KEY_JSON, null)
        parse(primary)?.let { return it }

        val backupText = prefs.getString(KEY_BACKUP, null)
        val backup = parse(backupText) ?: return emptyList()
        if (backupText != null) prefs.edit().putString(KEY_JSON, backupText).commit()
        return backup
    }

    fun getById(id: String): BlockSchedule? = getAll().firstOrNull { it.id == id }

    fun save(schedule: BlockSchedule): Boolean {
        val items = getAll().toMutableList()
        val index = items.indexOfFirst { it.id == schedule.id }
        if (index >= 0) items[index] = schedule else items.add(schedule)
        return persist(items)
    }

    fun delete(id: String): Boolean = persist(getAll().filterNot { it.id == id })

    fun setEnabled(id: String, enabled: Boolean): Boolean {
        val items = getAll().map { if (it.id == id) it.copy(enabled = enabled) else it }
        return persist(items)
    }

    fun newId(): String = UUID.randomUUID().toString()

    private fun parse(raw: String?): List<BlockSchedule>? {
        if (raw == null) return null
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) add(fromJson(array.getJSONObject(i)))
            }
        }.getOrNull()
    }

    private fun persist(items: List<BlockSchedule>): Boolean {
        val array = JSONArray()
        items.forEach { array.put(toJson(it)) }
        val encoded = array.toString()
        // Synchronous persistence for configuration that immediately controls blocking behavior.
        return prefs.edit()
            .putString(KEY_JSON, encoded)
            .putString(KEY_BACKUP, encoded)
            .commit()
    }

    private fun toJson(s: BlockSchedule): JSONObject = JSONObject().apply {
        put("id", s.id)
        put("name", s.name)
        put("startMinute", s.startMinute)
        put("endMinute", s.endMinute)
        put("enabled", s.enabled)
        put("pinProtected", s.pinProtected)
        put("packages", JSONArray(s.packages.toList()))
        put("days", JSONArray(s.days.toList()))
    }

    private fun fromJson(o: JSONObject): BlockSchedule {
        val packages = mutableSetOf<String>()
        val p = o.optJSONArray("packages") ?: JSONArray()
        for (i in 0 until p.length()) packages.add(p.getString(i))

        val days = mutableSetOf<Int>()
        val d = o.optJSONArray("days") ?: JSONArray()
        for (i in 0 until d.length()) days.add(d.getInt(i))

        return BlockSchedule(
            id = o.getString("id"),
            name = o.optString("name", "Blok"),
            packages = packages,
            startMinute = o.optInt("startMinute", -1),
            endMinute = o.optInt("endMinute", -1),
            days = days,
            enabled = o.optBoolean("enabled", false),
            pinProtected = o.optBoolean("pinProtected", false),
        )
    }

    companion object {
        private const val PREFS = "schedules_v2"
        private const val KEY_JSON = "schedules_json_primary"
        private const val KEY_BACKUP = "schedules_json_backup"
    }
}
