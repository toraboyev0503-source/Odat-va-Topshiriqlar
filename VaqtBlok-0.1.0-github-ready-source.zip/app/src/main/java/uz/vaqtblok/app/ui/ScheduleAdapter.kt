package uz.vaqtblok.app.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch
import uz.vaqtblok.app.R
import uz.vaqtblok.app.domain.BlockSchedule
import java.util.Locale

class ScheduleAdapter(
    private val onToggle: (BlockSchedule, Boolean) -> Unit,
    private val onEdit: (BlockSchedule) -> Unit,
    private val onDelete: (BlockSchedule) -> Unit,
) : RecyclerView.Adapter<ScheduleAdapter.Holder>() {
    private var items: List<BlockSchedule> = emptyList()

    fun submit(items: List<BlockSchedule>) {
        this.items = items
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_schedule, parent, false)
        return Holder(view)
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val item = items[position]
        holder.name.text = if (item.pinProtected) "${item.name}  🔒" else item.name
        holder.time.text = "${formatTime(item.startMinute)} → ${formatTime(item.endMinute)}"
        holder.apps.text = "${item.packages.size} ta ilova"
        holder.enabled.setOnCheckedChangeListener(null)
        holder.enabled.isChecked = item.enabled
        holder.enabled.setOnCheckedChangeListener { _, checked -> onToggle(item, checked) }
        holder.edit.setOnClickListener { onEdit(item) }
        holder.delete.setOnClickListener { onDelete(item) }
    }

    override fun getItemCount(): Int = items.size

    private fun formatTime(minute: Int): String = String.format(
        Locale.US,
        "%02d:%02d",
        minute / 60,
        minute % 60,
    )

    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val name: TextView = view.findViewById(R.id.nameText)
        val time: TextView = view.findViewById(R.id.timeText)
        val apps: TextView = view.findViewById(R.id.appsText)
        val enabled: MaterialSwitch = view.findViewById(R.id.enabledSwitch)
        val edit: MaterialButton = view.findViewById(R.id.editButton)
        val delete: MaterialButton = view.findViewById(R.id.deleteButton)
    }
}
