package uz.vaqtblok.app.ui

import android.app.TimePickerDialog
import android.content.pm.PackageManager
import android.content.Intent
import android.os.Bundle
import android.telecom.TelecomManager
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.textfield.TextInputEditText
import uz.vaqtblok.app.R
import uz.vaqtblok.app.data.ScheduleRepository
import uz.vaqtblok.app.domain.BlockSchedule
import uz.vaqtblok.app.security.PinManager
import java.util.Calendar
import java.util.Locale

class ScheduleEditorActivity : AppCompatActivity() {
    private lateinit var repository: ScheduleRepository
    private lateinit var pickerAdapter: AppPickerAdapter
    private lateinit var selectionCount: TextView
    private lateinit var nameInput: TextInputEditText
    private lateinit var pinSwitch: MaterialSwitch
    private lateinit var startButton: MaterialButton
    private lateinit var endButton: MaterialButton

    private val selectedPackages = mutableSetOf<String>()
    private val selectedDays = mutableSetOf<Int>()
    private var startMinute = 22 * 60
    private var endMinute = 7 * 60
    private var existing: BlockSchedule? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_schedule_editor)

        repository = ScheduleRepository(this)
        val id = intent.getStringExtra(EXTRA_ID)
        existing = id?.let(repository::getById)

        nameInput = findViewById(R.id.nameInput)
        pinSwitch = findViewById(R.id.pinProtectionSwitch)
        startButton = findViewById(R.id.startTimeButton)
        endButton = findViewById(R.id.endTimeButton)
        selectionCount = findViewById(R.id.selectionCount)

        existing?.let { schedule ->
            findViewById<TextView>(R.id.titleText).text = "Blokni tahrirlash"
            nameInput.setText(schedule.name)
            selectedPackages.addAll(schedule.packages)
            selectedDays.addAll(schedule.days)
            startMinute = schedule.startMinute
            endMinute = schedule.endMinute
            pinSwitch.isChecked = schedule.pinProtected
        } ?: run {
            selectedDays.addAll(BlockSchedule.defaultDays())
        }

        pickerAdapter = AppPickerAdapter(selectedPackages) { count -> updateSelectionCount(count) }
        findViewById<RecyclerView>(R.id.appList).apply {
            layoutManager = LinearLayoutManager(this@ScheduleEditorActivity)
            adapter = pickerAdapter
        }

        findViewById<TextInputEditText>(R.id.searchInput).doAfterTextChanged {
            pickerAdapter.filter(it?.toString().orEmpty())
        }

        buildDayCheckboxes()
        updateTimeButtons()
        updateSelectionCount(selectedPackages.size)

        startButton.setOnClickListener { pickTime(startMinute) { startMinute = it; updateTimeButtons() } }
        endButton.setOnClickListener { pickTime(endMinute) { endMinute = it; updateTimeButtons() } }
        findViewById<MaterialButton>(R.id.saveButton).setOnClickListener { saveRequested() }

        loadInstalledApps()
    }

    private fun loadInstalledApps() {
        Thread {
            val pm = packageManager
            val critical = criticalPackages()
            val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            @Suppress("DEPRECATION")
            val launchable = pm.queryIntentActivities(launcherIntent, 0)

            val items = launchable.asSequence()
                .mapNotNull { it.activityInfo?.applicationInfo }
                .distinctBy { it.packageName }
                .filter { it.packageName !in critical }
                .mapNotNull { info ->
                    runCatching {
                        InstalledApp(
                            label = pm.getApplicationLabel(info).toString(),
                            packageName = info.packageName,
                            icon = pm.getApplicationIcon(info),
                        )
                    }.getOrNull()
                }
                .sortedBy { it.label.lowercase(Locale.getDefault()) }
                .toList()

            runOnUiThread { pickerAdapter.submit(items) }
        }.start()
    }

    private fun criticalPackages(): Set<String> {
        val result = mutableSetOf(
            packageName,
            "com.android.settings",
            "com.android.systemui",
            "com.android.permissioncontroller",
            "com.google.android.permissioncontroller",
            "com.android.packageinstaller",
            "com.google.android.packageinstaller",
        )

        val homeIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        packageManager.resolveActivity(homeIntent, PackageManager.MATCH_DEFAULT_ONLY)
            ?.activityInfo?.packageName?.let(result::add)

        getSystemService(TelecomManager::class.java)?.defaultDialerPackage?.let(result::add)
        return result
    }

    private fun buildDayCheckboxes() {
        val container = findViewById<LinearLayout>(R.id.dayContainer)
        val days = listOf(
            Calendar.MONDAY to "Du",
            Calendar.TUESDAY to "Se",
            Calendar.WEDNESDAY to "Cho",
            Calendar.THURSDAY to "Pa",
            Calendar.FRIDAY to "Ju",
            Calendar.SATURDAY to "Sha",
            Calendar.SUNDAY to "Yak",
        )
        days.forEach { (day, label) ->
            val box = CheckBox(this).apply {
                text = label
                isChecked = day in selectedDays
                setOnCheckedChangeListener { _, checked ->
                    if (checked) selectedDays.add(day) else selectedDays.remove(day)
                }
            }
            container.addView(box)
        }
    }

    private fun pickTime(currentMinute: Int, onPicked: (Int) -> Unit) {
        TimePickerDialog(
            this,
            { _, hour, minute -> onPicked(hour * 60 + minute) },
            currentMinute / 60,
            currentMinute % 60,
            true,
        ).show()
    }

    private fun updateTimeButtons() {
        startButton.text = "Boshlanish: ${formatTime(startMinute)}"
        endButton.text = "Tugash: ${formatTime(endMinute)}"
    }

    private fun updateSelectionCount(count: Int) {
        selectionCount.text = "$count ta ilova tanlandi"
    }

    private fun saveRequested() {
        if (selectedPackages.isEmpty()) {
            toast("Kamida bitta ilovani tanlang")
            return
        }
        if (selectedDays.isEmpty()) {
            toast("Kamida bitta kunni tanlang")
            return
        }
        if (startMinute == endMinute) {
            toast("Boshlanish va tugash vaqti bir xil bo‘lishi mumkin emas")
            return
        }

        if (pinSwitch.isChecked && !PinManager(this).hasPin()) {
            PinDialogs.createPin(this) { persistAndFinish() }
        } else {
            persistAndFinish()
        }
    }

    private fun persistAndFinish() {
        // Final guard: a protected schedule is never persisted without a usable PIN.
        if (pinSwitch.isChecked && !PinManager(this).hasPin()) {
            toast("PIN yaratilmagan. Blok saqlanmadi.")
            return
        }

        val previous = existing
        val schedule = BlockSchedule(
            id = previous?.id ?: repository.newId(),
            name = nameInput.text?.toString()?.trim().orEmpty().ifBlank { "Blok" },
            packages = selectedPackages.toSet(),
            startMinute = startMinute,
            endMinute = endMinute,
            days = selectedDays.toSet(),
            enabled = previous?.enabled ?: true,
            pinProtected = pinSwitch.isChecked,
        )
        if (!repository.save(schedule)) {
            toast("Blokni saqlashda xato yuz berdi")
            return
        }
        finish()
    }

    private fun formatTime(minute: Int): String = String.format(
        Locale.US,
        "%02d:%02d",
        minute / 60,
        minute % 60,
    )

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()

    companion object {
        const val EXTRA_ID = "schedule_id"
    }
}
