package uz.vaqtblok.app.ui

import android.content.Context
import android.text.InputType
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import uz.vaqtblok.app.security.PinManager

object PinDialogs {
    fun requestPin(
        context: Context,
        title: String,
        onSuccess: () -> Unit,
        onCancelled: (() -> Unit)? = null,
    ) {
        val manager = PinManager(context)
        if (!manager.hasPin()) {
            // Fail-open for inconsistent security state; never trap the owner.
            onSuccess()
            return
        }

        val input = pinInput(context)
        val dialog = MaterialAlertDialogBuilder(context)
            .setTitle(title)
            .setMessage("6–12 xonali administrator PINini kiriting.")
            .setView(input)
            .setNegativeButton("Bekor qilish") { _, _ -> onCancelled?.invoke() }
            .setPositiveButton("Tasdiqlash", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val pin = input.text?.toString().orEmpty()
                if (manager.verify(pin)) {
                    input.error = null
                    dialog.dismiss()
                    onSuccess()
                } else {
                    input.error = "PIN noto‘g‘ri"
                }
            }
        }
        dialog.setOnCancelListener { onCancelled?.invoke() }
        dialog.show()
        input.requestFocus()
    }

    fun createPin(context: Context, onCreated: () -> Unit) {
        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            val p = (20 * resources.displayMetrics.density).toInt()
            setPadding(p, 0, p, 0)
        }
        val hintText = TextView(context).apply {
            text = "PIN blokni to‘xtatish, o‘chirish va tahrirlash uchun ishlatiladi. 6–12 raqam kiriting."
        }
        val first = pinInput(context).apply { this.hint = "Yangi PIN" }
        val second = pinInput(context).apply { this.hint = "PINni takrorlang" }
        container.addView(hintText)
        container.addView(first, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        container.addView(second, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        val dialog = MaterialAlertDialogBuilder(context)
            .setTitle("Administrator PIN yaratish")
            .setView(container)
            .setNegativeButton("Bekor qilish", null)
            .setPositiveButton("Saqlash", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val p1 = first.text?.toString().orEmpty()
                val p2 = second.text?.toString().orEmpty()
                val manager = PinManager(context)
                when {
                    !manager.isValidFormat(p1) -> first.error = "6–12 ta raqam kiriting"
                    p1 != p2 -> second.error = "PINlar bir xil emas"
                    !manager.setPin(p1) -> first.error = "PINni saqlab bo‘lmadi"
                    else -> {
                        dialog.dismiss()
                        onCreated()
                    }
                }
            }
        }
        dialog.show()
    }

    private fun pinInput(context: Context): EditText = EditText(context).apply {
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        maxLines = 1
        setSingleLine(true)
    }
}
