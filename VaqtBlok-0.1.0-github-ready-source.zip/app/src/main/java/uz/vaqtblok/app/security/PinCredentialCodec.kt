package uz.vaqtblok.app.security

import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.util.Base64

object PinCredentialCodec {
    private const val VERSION = "v1"
    private const val SALT_BYTES = 16
    private const val HASH_BYTES = 32
    private const val CHECKSUM_BYTES = 32

    data class Credential(val salt: ByteArray, val hash: ByteArray)

    fun encode(salt: ByteArray, hash: ByteArray): String {
        require(salt.size == SALT_BYTES)
        require(hash.size == HASH_BYTES)

        val encoder = Base64.getUrlEncoder().withoutPadding()
        val saltText = encoder.encodeToString(salt)
        val hashText = encoder.encodeToString(hash)
        val payload = "$VERSION.$saltText.$hashText"
        val checksum = MessageDigest.getInstance("SHA-256")
            .digest(payload.toByteArray(StandardCharsets.UTF_8))
        return "$payload.${encoder.encodeToString(checksum)}"
    }

    fun decode(record: String?): Credential? = runCatching {
        if (record.isNullOrBlank()) return null
        val parts = record.split('.')
        if (parts.size != 4 || parts[0] != VERSION) return null

        val decoder = Base64.getUrlDecoder()
        val salt = decoder.decode(parts[1])
        val hash = decoder.decode(parts[2])
        val checksum = decoder.decode(parts[3])
        if (salt.size != SALT_BYTES || hash.size != HASH_BYTES || checksum.size != CHECKSUM_BYTES) return null

        val payload = "${parts[0]}.${parts[1]}.${parts[2]}"
        val expected = MessageDigest.getInstance("SHA-256")
            .digest(payload.toByteArray(StandardCharsets.UTF_8))
        if (!MessageDigest.isEqual(expected, checksum)) return null

        Credential(salt, hash)
    }.getOrNull()
}
