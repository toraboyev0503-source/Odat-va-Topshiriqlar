package uz.vaqtblok.app.domain

import android.content.Context
import uz.vaqtblok.app.data.ScheduleRepository
import uz.vaqtblok.app.security.BypassStore
import uz.vaqtblok.app.security.PinManager
import java.util.Calendar

class AppBlockCoordinator(context: Context) {
    private val repository = ScheduleRepository(context)
    private val bypassStore = BypassStore(context)
    private val pinManager = PinManager(context)

    fun activeBlockFor(packageName: String, now: Calendar = Calendar.getInstance()): BlockSchedule? =
        activeBlocksFor(packageName, now).firstOrNull()

    fun activeBlocksFor(packageName: String, now: Calendar = Calendar.getInstance()): List<BlockSchedule> {
        if (packageName.isBlank()) return emptyList()
        val nowMillis = now.timeInMillis

        return repository.getAll().filter { schedule ->
            if (!schedule.enabled) return@filter false
            if (packageName !in schedule.packages) return@filter false

            // Fail-open safety: a PIN-protected profile is never enforced when
            // its integrity-checked PIN credential is unavailable/corrupt.
            if (schedule.pinProtected && !pinManager.hasPin()) return@filter false

            ScheduleEngine.isActive(schedule, now) &&
                !bypassStore.isGranted(schedule.id, packageName, nowMillis)
        }
    }
}
