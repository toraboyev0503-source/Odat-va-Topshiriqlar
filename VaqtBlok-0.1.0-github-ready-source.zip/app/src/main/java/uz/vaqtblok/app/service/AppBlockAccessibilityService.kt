package uz.vaqtblok.app.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import uz.vaqtblok.app.domain.AppBlockCoordinator
import uz.vaqtblok.app.ui.BlockActivity

class AppBlockAccessibilityService : AccessibilityService() {
    private lateinit var coordinator: AppBlockCoordinator
    private val handler = Handler(Looper.getMainLooper())
    private var foregroundPackage: String = ""

    private val minuteRecheck = object : Runnable {
        override fun run() {
            if (foregroundPackage.isNotBlank()) evaluate(foregroundPackage)
            scheduleNextMinuteCheck()
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        coordinator = AppBlockCoordinator(applicationContext)
        scheduleNextMinuteCheck()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val packageName = event.packageName?.toString().orEmpty()
        if (packageName.isBlank()) return

        // Do not replace the remembered target with our own blocking UI.
        if (packageName == applicationContext.packageName) return

        foregroundPackage = packageName
        evaluate(packageName)
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        handler.removeCallbacks(minuteRecheck)
        super.onDestroy()
    }

    private fun evaluate(packageName: String) {
        if (!::coordinator.isInitialized) return
        val schedule = coordinator.activeBlockFor(packageName) ?: return
        val intent = Intent(this, BlockActivity::class.java).apply {
            addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP or
                    Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS,
            )
            putExtra(BlockActivity.EXTRA_PACKAGE, packageName)
            putExtra(BlockActivity.EXTRA_SCHEDULE_ID, schedule.id)
        }
        startActivity(intent)
    }

    private fun scheduleNextMinuteCheck() {
        handler.removeCallbacks(minuteRecheck)
        val now = System.currentTimeMillis()
        val delay = 60_000L - (now % 60_000L) + 150L
        handler.postDelayed(minuteRecheck, delay)
    }
}
