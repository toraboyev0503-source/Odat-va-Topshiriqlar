package uz.vaqtblok.app.ui

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import uz.vaqtblok.app.R
import uz.vaqtblok.app.domain.AppBlockCoordinator
import uz.vaqtblok.app.domain.BlockSchedule
import uz.vaqtblok.app.domain.ScheduleEngine
import uz.vaqtblok.app.security.BypassStore
import uz.vaqtblok.app.security.PinManager
import java.util.Calendar
import java.util.Locale

class BlockActivity : AppCompatActivity() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var coordinator: AppBlockCoordinator
    private lateinit var pinManager: PinManager
    private lateinit var bypassStore: BypassStore

    private var blockedPackage: String = ""
    private var activeBlocks: List<BlockSchedule> = emptyList()

    private lateinit var remainingText: TextView
    private lateinit var blockNameText: TextView
    private lateinit var pinLayout: TextInputLayout
    private lateinit var pinInput: TextInputEditText
    private lateinit var unlockButton: MaterialButton

    private val tick = object : Runnable {
        override fun run() {
            refreshState()
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_block)
        coordinator = AppBlockCoordinator(this)
        pinManager = PinManager(this)
        bypassStore = BypassStore(this)

        remainingText = findViewById(R.id.remainingText)
        blockNameText = findViewById(R.id.blockName)
        pinLayout = findViewById(R.id.pinLayout)
        pinInput = findViewById(R.id.pinInput)
        unlockButton = findViewById(R.id.unlockButton)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                goHome()
            }
        })

        findViewById<MaterialButton>(R.id.homeButton).setOnClickListener { goHome() }
        unlockButton.setOnClickListener { tryUnlock() }

        applyIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        applyIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        super.onPause()
    }

    private fun applyIntent(intent: Intent) {
        blockedPackage = intent.getStringExtra(EXTRA_PACKAGE).orEmpty()

        val appLabel = runCatching {
            val info = packageManager.getApplicationInfo(blockedPackage, 0)
            packageManager.getApplicationLabel(info).toString()
        }.getOrElse { "Ilova" }

        findViewById<TextView>(R.id.blockedTitle).text = "$appLabel bloklangan"
        refreshState()
    }

    private fun configurePinUi() {
        // If any currently effective profile is PIN-protected, the valid admin PIN
        // may bypass all profiles that are active for this app at this moment.
        val protected = activeBlocks.any { it.pinProtected } && pinManager.hasPin()
        pinLayout.visibility = if (protected) View.VISIBLE else View.GONE
        unlockButton.visibility = if (protected) View.VISIBLE else View.GONE
        if (!protected) {
            pinLayout.error = null
            pinInput.text?.clear()
        }
    }

    private fun refreshState() {
        if (blockedPackage.isBlank()) {
            finish()
            return
        }

        val now = Calendar.getInstance()
        activeBlocks = coordinator.activeBlocksFor(blockedPackage, now)
        if (activeBlocks.isEmpty()) {
            finish()
            return
        }

        blockNameText.text = if (activeBlocks.size == 1) {
            activeBlocks.first().name
        } else {
            "${activeBlocks.size} ta faol blok"
        }
        configurePinUi()

        val remaining = activeBlocks.maxOf { ScheduleEngine.remainingMillis(it, now) }
        val totalSeconds = remaining / 1000L
        val hours = totalSeconds / 3600L
        val minutes = (totalSeconds % 3600L) / 60L
        val seconds = totalSeconds % 60L
        remainingText.text = String.format(Locale.US, "Qolgan vaqt: %02d:%02d:%02d", hours, minutes, seconds)
    }

    private fun tryUnlock() {
        val now = Calendar.getInstance()
        val blocks = coordinator.activeBlocksFor(blockedPackage, now)
        if (blocks.isEmpty()) {
            finish()
            return
        }
        if (blocks.none { it.pinProtected } || !pinManager.hasPin()) {
            Toast.makeText(this, "Bu blok uchun PIN orqali ochish mavjud emas", Toast.LENGTH_SHORT).show()
            return
        }

        val pin = pinInput.text?.toString().orEmpty()
        if (!pinManager.verify(pin)) {
            pinLayout.error = "PIN noto‘g‘ri"
            return
        }

        pinLayout.error = null
        // Grant every profile that is active now for this package in one durable write.
        // This prevents overlapping schedules from immediately re-blocking after a valid PIN.
        val expiries = blocks.associate { active ->
            active.id to ScheduleEngine.nextEndEpochMillis(active, now)
        }
        if (!bypassStore.grantAll(blockedPackage, expiries)) {
            Toast.makeText(this, "PIN tasdiqlandi, lekin ochish ruxsatini saqlab bo‘lmadi", Toast.LENGTH_SHORT).show()
            return
        }

        val launch = packageManager.getLaunchIntentForPackage(blockedPackage)
        if (launch == null) {
            Toast.makeText(this, "Ilovani qayta ochib bo‘lmadi", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        finish()
        startActivity(launch)
    }

    private fun goHome() {
        val home = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        startActivity(home)
        finish()
    }

    companion object {
        const val EXTRA_PACKAGE = "blocked_package"
        const val EXTRA_SCHEDULE_ID = "schedule_id"
    }
}
