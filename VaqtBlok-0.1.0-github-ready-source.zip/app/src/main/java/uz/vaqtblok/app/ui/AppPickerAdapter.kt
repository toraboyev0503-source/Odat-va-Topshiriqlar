package uz.vaqtblok.app.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import uz.vaqtblok.app.R

class AppPickerAdapter(
    private val selected: MutableSet<String>,
    private val onSelectionChanged: (Int) -> Unit,
) : RecyclerView.Adapter<AppPickerAdapter.Holder>() {
    private var allItems: List<InstalledApp> = emptyList()
    private var shownItems: List<InstalledApp> = emptyList()

    fun submit(items: List<InstalledApp>) {
        allItems = items
        shownItems = items
        notifyDataSetChanged()
    }

    fun filter(query: String) {
        val q = query.trim().lowercase()
        shownItems = if (q.isBlank()) allItems else allItems.filter {
            it.label.lowercase().contains(q) || it.packageName.lowercase().contains(q)
        }
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false)
        return Holder(view)
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val item = shownItems[position]
        holder.name.text = item.label
        holder.icon.setImageDrawable(item.icon)
        holder.check.setOnCheckedChangeListener(null)
        holder.check.isChecked = item.packageName in selected

        val toggle = {
            if (item.packageName in selected) selected.remove(item.packageName)
            else selected.add(item.packageName)
            holder.check.setOnCheckedChangeListener(null)
            holder.check.isChecked = item.packageName in selected
            onSelectionChanged(selected.size)
        }

        holder.itemView.setOnClickListener { toggle() }
        holder.check.setOnClickListener { toggle() }
    }

    override fun getItemCount(): Int = shownItems.size

    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.appIcon)
        val name: TextView = view.findViewById(R.id.appName)
        val check: CheckBox = view.findViewById(R.id.appCheck)
    }
}
