package uz.vaqtblok.app.security

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertNotNull
import org.junit.Test

class PinCredentialCodecTest {
    @Test
    fun validRecordRoundTrips() {
        val salt = ByteArray(16) { it.toByte() }
        val hash = ByteArray(32) { (it * 3).toByte() }
        val record = PinCredentialCodec.encode(salt, hash)
        val decoded = PinCredentialCodec.decode(record)
        assertNotNull(decoded)
        assertArrayEquals(salt, decoded!!.salt)
        assertArrayEquals(hash, decoded.hash)
    }

    @Test
    fun corruptedRecordIsRejected() {
        val salt = ByteArray(16) { it.toByte() }
        val hash = ByteArray(32) { it.toByte() }
        val record = PinCredentialCodec.encode(salt, hash)
        val broken = record.dropLast(1) + if (record.last() == 'A') 'B' else 'A'
        assertNull(PinCredentialCodec.decode(broken))
    }
}
