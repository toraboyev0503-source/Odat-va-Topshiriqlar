package uz.vaqtblok.app.security

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PinCryptoTest {
    @Test
    fun correctPinVerifiesAndWrongPinDoesNot() {
        val salt = PinCrypto.createSalt()
        val expected = PinCrypto.hash("123456".toCharArray(), salt)

        assertTrue(PinCrypto.verify("123456".toCharArray(), salt, expected))
        assertFalse(PinCrypto.verify("654321".toCharArray(), salt, expected))
    }

    @Test
    fun differentSaltProducesDifferentCredential() {
        val saltA = PinCrypto.createSalt()
        val saltB = PinCrypto.createSalt()
        val expected = PinCrypto.hash("123456".toCharArray(), saltA)

        assertFalse(PinCrypto.verify("123456".toCharArray(), saltB, expected))
    }
}
