package uz.vaqtblok.app.domain

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar

class ScheduleEngineTest {
    private fun schedule(
        start: Int,
        end: Int,
        days: Set<Int> = setOf(Calendar.MONDAY),
    ) = BlockSchedule(
        id = "1",
        name = "Test",
        packages = setOf("example.app"),
        startMinute = start,
        endMinute = end,
        days = days,
        enabled = true,
        pinProtected = false,
    )

    @Test
    fun normalRangeWorks() {
        val s = schedule(9 * 60, 17 * 60)
        assertTrue(ScheduleEngine.isActive(s, Calendar.MONDAY, 9 * 60))
        assertTrue(ScheduleEngine.isActive(s, Calendar.MONDAY, 16 * 60 + 59))
        assertFalse(ScheduleEngine.isActive(s, Calendar.MONDAY, 17 * 60))
        assertFalse(ScheduleEngine.isActive(s, Calendar.TUESDAY, 10 * 60))
    }

    @Test
    fun crossMidnightRangeUsesPreviousSelectedDay() {
        val s = schedule(22 * 60, 7 * 60)
        assertTrue(ScheduleEngine.isActive(s, Calendar.MONDAY, 23 * 60))
        assertTrue(ScheduleEngine.isActive(s, Calendar.TUESDAY, 6 * 60 + 59))
        assertFalse(ScheduleEngine.isActive(s, Calendar.TUESDAY, 7 * 60))
        assertFalse(ScheduleEngine.isActive(s, Calendar.SUNDAY, 23 * 60))
    }

    @Test
    fun equalTimesFailOpen() {
        val s = schedule(0, 0)
        assertFalse(ScheduleEngine.isActive(s, Calendar.MONDAY, 0))
        assertFalse(ScheduleEngine.isActive(s, Calendar.MONDAY, 23 * 60 + 59))
    }

    @Test
    fun saturdayCrossMidnightWrapsIntoSunday() {
        val s = schedule(22 * 60, 7 * 60, setOf(Calendar.SATURDAY))
        assertTrue(ScheduleEngine.isActive(s, Calendar.SATURDAY, 23 * 60))
        assertTrue(ScheduleEngine.isActive(s, Calendar.SUNDAY, 6 * 60 + 59))
        assertFalse(ScheduleEngine.isActive(s, Calendar.SUNDAY, 7 * 60))
    }

    @Test
    fun invalidMinutesFailOpen() {
        assertFalse(ScheduleEngine.isActive(schedule(-1, 60), Calendar.MONDAY, 0))
        assertFalse(ScheduleEngine.isActive(schedule(0, 24 * 60), Calendar.MONDAY, 0))
        assertFalse(ScheduleEngine.isActive(schedule(0, 60), Calendar.MONDAY, -1))
        assertFalse(ScheduleEngine.isActive(schedule(0, 60), Calendar.MONDAY, 24 * 60))
    }

    @Test
    fun disabledScheduleNeverBlocks() {
        val s = schedule(9 * 60, 17 * 60).copy(enabled = false)
        assertFalse(ScheduleEngine.isActive(s, Calendar.MONDAY, 10 * 60))
    }
}
