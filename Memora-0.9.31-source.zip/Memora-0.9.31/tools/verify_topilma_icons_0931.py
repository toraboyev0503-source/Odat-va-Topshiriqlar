#!/usr/bin/env python3
"""Freeze the user-approved Topilma VectorDrawable assets byte-for-byte."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from xml.etree import ElementTree


ROOT = Path(__file__).resolve().parents[1]
DRAWABLES = ROOT / "app/src/main/res/drawable"
HASHES = json.loads((ROOT / "tools/topilma_icons_0931_sha256.json").read_text())
ANDROID = "{http://schemas.android.com/apk/res/android}"
failures: list[str] = []


for name, expected_hash in HASHES.items():
    path = DRAWABLES / name
    if not path.is_file():
        failures.append(f"missing approved drawable: {name}")
        continue
    actual_hash = hashlib.sha256(path.read_bytes()).hexdigest()
    if actual_hash != expected_hash:
        failures.append(f"approved drawable changed: {name}")
    try:
        root = ElementTree.parse(path).getroot()
    except Exception as exc:
        failures.append(f"invalid XML {name}: {exc}")
        continue
    if root.attrib.get(ANDROID + "viewportWidth") != "96" or root.attrib.get(ANDROID + "viewportHeight") != "96":
        failures.append(f"master viewport changed: {name}")
    if not list(root.iter("path")):
        failures.append(f"drawable has no path: {name}")

renderer = (ROOT / "app/src/main/java/com/memora/app/share/TopilmaShareManager.kt").read_text()
for name in HASHES:
    resource = name.removesuffix(".xml")
    if f"R.drawable.{resource}" not in renderer:
        failures.append(f"renderer does not use approved resource: {resource}")
for forbidden in ("drawReferenceShareIcon", "drawReferenceThoughtIcon", "private fun drawHeart"):
    if forbidden in renderer:
        failures.append(f"forbidden duplicate icon renderer: {forbidden}")

if failures:
    print("TOPILMA 0.9.31 ICON FREEZE FAILED")
    for failure in failures:
        print(" -", failure)
    raise SystemExit(1)

print("TOPILMA 0.9.31 ICON FREEZE PASS (4 approved VectorDrawables)")
