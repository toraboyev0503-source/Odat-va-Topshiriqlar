# Memora 0.9.31 — Topilma card icons and background contract (FROZEN)

## Approved visual source

- The approved card is the supplied 1016 × 793 Mark Manson reference.
- Frozen reference: `docs/final-design-reference/07-topilma-card-approved.png`.
- Approved comparison sheet: `docs/final-design-reference/08-topilma-icons-approved.png`.
- Editable SVG masters: `docs/topilma-icon-masters/`.
- Card geometry, cover, title/author, serif quote, menu and footer positions remain derived from that reference.
- The former 0.9.30 fixed pink outer background is superseded.

## Frozen action resources

- `ic_topilma_share.xml`
- `ic_topilma_heart.xml`
- `ic_topilma_heart_filled.xml`
- `ic_topilma_note.xml`

These Android VectorDrawables are the only action-glyph geometry. The live app,
Android Share and Obsidian must load the same resources. Reconstructing the icons
with ad-hoc `Canvas` paths or substituting Material/emoji/font glyphs is forbidden.

The canonical 1536 px renderer draws each 96 × 96 master inside a 136 px box at
the frozen action centers. Transparent interactive hit targets may be larger than
the visible glyph but must not alter its pixels.

## Active background

- The card surface remains white.
- The outer canvas is opaque and equals the active Memora `background` color.
- The app passes `MaterialTheme.colorScheme.background`.
- Android Share receives the same captured active color.
- Obsidian resolves the saved palette plus LIGHT/DARK/SYSTEM mode.
- Fixed peach/pink, transparent and black fallback edges are forbidden.

## Preserved card behavior

- Width stays fixed and height grows downward with complete text.
- Text is never shrunk or split into multiple cards.
- Like/comment counts appear beside their approved glyph only when non-zero.
- OCR selection and reconstruction remain the frozen 0.9.30 implementation.
