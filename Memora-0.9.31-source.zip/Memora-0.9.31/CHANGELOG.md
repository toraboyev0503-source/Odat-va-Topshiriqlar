# Memora 0.9.31 — approved Topilma icons + active Memora background

- Replaced all hand-drawn Topilma footer glyphs with the four user-approved Android VectorDrawable resources: Share, outline heart, filled heart and notebook/pencil.
- The live app card, Android Share and Obsidian now load those same drawable resources through one renderer; no parallel Canvas icon implementation remains.
- Removed the fixed peach `#FEF0E5` outer canvas. In-app cards use the current Material background; Share captures that same active color; Obsidian resolves the saved palette and light/dark mode.
- Preserved the approved 1016×793-derived geometry, fixed width, complete quote, and content-driven downward height without shrinking or pagination.
- Preserved continuous geometric OCR selection, Room schema 8, existing cards/comments/likes, backup data and stable update signing.
- Version bumped to `0.9.31` / code `51`.

# Memora 0.9.30 — canonical Topilma card + continuous OCR selection

- Replaced the two independent Topilma card implementations with one canonical bitmap renderer. The live app card, Android Share and Obsidian now display the same pixels, typography, cover frame, menu and three action glyphs.
- Recalibrated the card to the approved 1016×793 reference: warm `#FEF0E5` outer surface, reference header/body offsets and fixed reference width.
- Removed quote shrinking and card pagination. The reference height is a minimum; normally 100–150-word quotes keep the width and extend the card/canvas downward until every word fits at the approved body size.
- Kept live interaction through transparent accessible hit targets over the rendered Share / Like / Comment / overflow controls.
- Replaced ML Kit detector-index ordering with deterministic geometric line reconstruction, so selected page text is emitted top-to-bottom and left-to-right even when OCR blocks arrive shuffled.
- Replaced paint-over-word selection with inclusive anchor-to-extent range selection. Dragging forward or backward automatically selects every intervening word; whitespace between rows no longer creates holes.
- Added smooth per-line highlights, adjustable end tokens, optional “Yana parcha”, live extracted-text preview, Select all and Clear.
- Added punctuation/paragraph reconstruction without paraphrasing or silently correcting the quotation.
- Added JVM regressions for shuffled OCR blocks, reverse drag ranges, punctuation and paragraph preservation.
- Room remains schema 8; existing cards, comments, likes, source links, backups and Obsidian mappings require no migration. Version bumped to `0.9.30` / code `50`.

# Memora 0.9.29 — locked landscape Topilma share template

- Replaced the parity-driven share renderer with a deliberately separate, frozen landscape export template (T-256–T-262).
- Share/Obsidian Topilma cards now render on a fixed 1536×1199 px canvas and can no longer become portrait because of quote length.
- Locked card frame, cover, title/author, body zone, menu and three footer action positions to the approved reference geometry.
- Restored an opaque warm peach outer background (`#FDECE5`); transparent/black receiver edges are forbidden.
- Preserved complete quote text by adapting only body font size when a long quote would overflow the fixed landscape body zone.
- Android Share and Obsidian continue to use the exact same `TopilmaShareManager.renderCardBitmap()` output.
- The in-app feed card is now intentionally independent, so future feed refinements cannot silently alter the share template.
- Added `tools/topilma_share_landscape_spec.json`, `verify_share_landscape.py`, and a frozen export contract document.
- Room remains schema 8; no migration is required. Version bumped to `0.9.29` / code `49`.

## 0.9.28 — Topilma visual parity hardening

- Replaced export-only card geometry with canonical dp/sp geometry shared with the in-app Topilma card.
- Share/Obsidian PNG now uses a fully opaque warm outer canvas (`#F8F3EF`), eliminating black alpha edges in receivers.
- Removed dynamic export font sizing by quote length; title/author/body now scale exactly from the live-card typography spec.
- Matched cover frame/inset proportions between live card and export, using a compact 46×66 dp book cover.
- Removed export minimum-height padding hack; height is now content-driven like the live card.
- Added debug visual-parity probe, golden geometry specification, and frozen acceptance checklist.

# Memora 0.9.27 — Obsidian compile fix

- Restored the three Obsidian SAF helpers accidentally omitted from 0.9.26: `currentTreeUri()`, `DocumentFile.ensureDirectory()`, and `writeAsset()`.
- This resolves the GitHub Kotlin compiler cascade in `ObsidianSyncManager.kt` (`currentTreeUri`, `ensureDirectory`, `writeAsset`, inferred `uri` access).
- No frozen product behavior changed; T-235–T-245 remain exactly as approved.
- Added a 0.9.27 regression guard that verifies the helper definitions exist, not only their call sites.
- Room remains schema 8; no migration is required.
- Version bumped to `0.9.27` / code `47`.

# Memora 0.9.26 — Topilma card parity + clean Obsidian

- Unified Topilma presentation data across the in-app card and PNG renderer so title, author, cleaned body and tags cannot drift independently.
- Refined source cover presentation to a fixed 58×82 dp framed book-cover slot with preserved aspect ratio instead of crop/stretch; mirrored the geometry in the PNG exporter.
- Removed raw hashtag tokens from displayed Topilma prose; tags remain as the approved chips and still export as real Obsidian `#tags`.
- Reworked shared-card PNGs to a 1440 px high-resolution transparent canvas with a tight outer margin, matching Share/Like/Comment semantics and human-readable share filenames.
- Removed visible Obsidian YAML properties, `MEMORA:START/END` markers, instructional comments and technical UUID suffixes from user-facing Markdown filenames.
- Moved Memora sync snapshots/identity metadata into hidden vault-level `.memora/managed` and `.memora/index` storage so user-authored Obsidian suffix content remains protected without visible markers.
- Existing 0.9.25 Obsidian notes migrate to the clean layout on their next sync; legacy technical filenames are renamed safely with readable `(2)`, `(3)` collision handling when needed.
- Explicit `_assets/...` embeds are used for note media and Topilma card PNGs.
- Room remains schema 8; no data migration is required.
- Added `tools/regression_0926.py`; static acceptance gate passes 143/143 checks and billing verifier tests pass 3/3.
- Version bumped to `0.9.26` / code `46`.

# Memora 0.9.25 — Topilma OCR / Nusxalash

- Added `+ → Topilma → Yozish / Nusxalash`; both paths preserve source selection and manual source creation before editing/capture.
- Added CameraX page capture and Android native photo selection for Topilma copy capture.
- Added bundled on-device ML Kit Latin OCR; page images are processed locally and are not sent to a Memora server.
- Added full-screen OCR selection with Memora-accent word highlighting, multiple separate selections, tap-to-remove, Clear, Select all and Confirm.
- Added two-finger pan/zoom plus 90° rotation; OCR is re-run after rotation so highlights stay aligned.
- Selected text is reconstructed in reading order with line-break/whitespace normalization only; Memora does not paraphrase or silently correct the quotation.
- Confirmed OCR text opens in the existing title-free Topilma editor with the keyboard initially closed, then uses normal hashtag parsing, autosave and Obsidian synchronization.
- Added empty/error OCR states with retry/another-image paths and background recognition progress feedback.
- Added temporary `topilma-ocr` cache cleanup after the capture flow; page photos are not persisted into the Topilma record.
- Room remains schema 8; no migration was required for the OCR flow.
- Added `tools/regression_0925.py` with 129 static frozen-feature/regression checks.
- Version bumped to `0.9.25` / code `45`.

# Memora 0.9.24

- Fixed Kotlin compilation in `ObsidianScreen.kt`: corrected Compose `drawLine` argument order using named arguments.
- Fixed `ReaderScreen.kt`: added the missing `HashtagUtils` import used by hashtag decoding.
- No frozen feature behavior was changed; this is a build-fix release over 0.9.23.

# Memora 0.9.23 — Obsidian bridge, hashtags and master Topilma card

- Added Settings → External apps → Obsidian with a persistent Android SAF vault picker, enable/disable state, sync status, pending count, manual sync, full resync and folder replacement.
- Added one-way Memora → Obsidian Markdown synchronization with stable `memora_id` mapping, 1.5 s debounce, editor-exit flush, resumable pending state, and managed blocks that preserve user-written Obsidian content outside the Memora block.
- Creates `Memora/Qisqa matn`, `Memora/Topilmalar`, and `Memora/Uzun matn`, with `_assets` subfolders for note media and Topilma card PNGs. First connection can export all existing content or future content only.
- Short/Long notes export with their title as the Markdown heading, original body/media order, and real Obsidian hashtags. Topilmalar use `Muallif: Karta sarlavhasi`, embed the full-card PNG, add a collapsed searchable text block, and write real hashtags below the card.
- Added Unicode hashtag parsing/highlighting to Short, Long and Topilma editors; hashtags are stored separately, displayed as Memora-accent chips and included in shared Topilma cards.
- Refined the approved Topilma master card: larger fixed cover, tighter title/author geometry, horizontal three-dot menu, refined serif body spacing, and three equal Share / Like / Comment action zones.
- Removed the expand/collapse button. Collapsed cards show two lines; tapping the text expands that individual card until the current section is left, and multiple cards can remain open at once.
- Share and Obsidian use the same full-text card renderer and visual constants, regardless of the current in-app collapsed state.
- Added Room 7 → 8 migration for note hashtag metadata and Obsidian sync state; preserved 6 → 7 → 8 upgrade safety, existing Topilmalar/comments/likes, stable debug signing and update-over-old-APK behavior.
- Backup schema advanced to 6 while preserving import compatibility with schemas 1–6.
- Added `tools/regression_0923.py`; static acceptance gate passes 111/111 checks and billing verifier tests pass 3/3.
- Version bumped to `0.9.23` / code `43`.

# Memora 0.9.22 — Topilmalar card interaction upgrade

- Rebuilt Topilma cards around the approved source-cover/title/author layout with a two-line collapsed body and a circular expand/collapse control.
- Simplified each card footer to exactly three primary actions: Share, cumulative Like, and Comments; secondary actions remain in the top-right overflow menu.
- Added unlimited per-card `likeCount` with a soft-red heart state, subtle pulse feedback, Room 6 → 7 migration, and backup/restore preservation.
- Share now always exports a full-text card PNG, independent of the current collapsed/expanded state, with the card corners visible inside a small outer crop margin.
- Replaced the old comments dialog with a dedicated full-screen comments experience: the complete Memora card stays above the thread, comments show date + time, and the composer grows to five lines while staying above the keyboard.
- Added `Topilma` between Short and Long in the global `+` sheet. The flow opens a recent-first searchable source picker, supports creating a source with metadata/cover, then opens a title-free full-screen autosaving Topilma editor.
- New manually entered cards reference their source live, so later source title/author/cover edits propagate to every related card.
- Unified Topilma list/source/review/comments rendering around one reusable `TopilmaCard` component.
- Preserved existing Topilmalar data, review history, comments, exports, billing, stable debug signing and update-over-old-APK behavior.
- Version bumped to `0.9.22` / code `42`.

# Memora 0.9.21 — Topilmalar

- Added the local-first **Topilmalar** module with dedicated bottom navigation and the frozen Manbalar / Barcha topilmalar / Qayta ko‘rish structure.
- Added Android Share capture for text, URL, one or multiple images, origin-app metadata, duplicate handling and a compact post-save surface.
- Added Room schema version 6 and a non-destructive 5 → 6 migration for sources, cards, comments, images, tags and persistent review sessions/history.
- Added source matching, source-less cards, editable metadata/covers, archive/restore, source merge, card move, global search, tags, Favorites and multi-select actions.
- Added stable daily review sessions, 1–3 day first review, adaptive Tezroq / Odatiy / Keyinroq intervals, source diversification, Favorite caps, comment priority, Random Topilma and optional independent notifications.
- Added Home **Bugungi qayta ko‘rish**, note-to-Topilmalar capture, explicit OCR hand-off, image zoom, text/source/card-image sharing and dedicated HTML/Word export with optional comments.
- Extended full Memora backup/restore to include all Topilmalar records, media, Favorites, review history/state and settings while retaining compatibility with schema 1–4 backups.
- Fully removed the old Home daily-question UI, manager, validator and bundled 13-language reflection datasets.
- Replaced section navigation slides with consistent whole-screen 200/180 ms fade transitions.
- Added `tools/regression_0921.py`; preserved notes, autosave/recovery, media controls, Vaqt izi, App Lock, billing/backend, signing and build infrastructure.
- Version bumped to `0.9.21` / code `41`.

# Memora 0.9.20 — approved UX completion pass

- Fixed Back navigation so pop entry uses the same shallow right-origin motion as normal entry; the left-side slide/clipping shown in the supplied video is removed.
- Shortened interactive motion tokens by about 30% while keeping ambient motion calm.
- Added Reader sharing as **Matn / Rasm / HTML**: bold-capable text title, 1080×1350 paginated image cards, self-contained HTML, and subtle Memora icon/name/tagline branding. Heavy image/HTML generation runs off the main UI thread.
- Standardized the five custom Memora mood stickers and changed image insertion to a Camera/Gallery bottom sheet.
- Added a shared Memora destructive confirmation surface for notes, note media, saved titles, reminders and Time Trace photos.
- Preserved HTML-folder, Word-folder and full Memora backup export; added backup validation/preview before restore confirmation.
- Added camera/microphone explanation dialogs and app-settings recovery when Android no longer offers the permission prompt.
- Added shared Memora empty states and loading/success/error/info feedback surfaces.
- Added real Time Trace MP4 export percentage and cooperative cancellation.
- Kept approved Paper/Slate dark palettes and replaced Calendar/Notes purple selection styling with palette-driven slate/sage tones.
- Removed technical exception text from user-facing error paths.
- Home now uses the audited 13 × 650 reflection assets with six fully-seen reflections per day and sequence continuity across languages.
- Added `tools/regression_0920.py` and wired it into GitHub Actions before Kotlin compilation.
- Preserved autosave/recovery, image zoom, audio Pause/Resume/Stop, CameraX Time Trace, note-date logic, App Lock, Room migrations, notifications, billing/backend, backup/export and stable debug update signing.
- Version bumped to `0.9.20` / code `40`.

# Memora 0.9.19 — motion test + 13-language reflection pack

- Added the animation test pass: interactive screen navigation now uses a faster ~210 ms fade + very small slide, with enter/exit running together so navigation feels responsive without losing Memora’s calm character.
- Added responsive press feedback and fast selected-state transitions to the shared bottom navigation and center `+` button.
- Kept Home reflection/splash motion atmospheric rather than globally speeding it up.
- Rebalanced Vaqt izi slideshow timing for deliberate viewing: Slow 4.2 s, Medium 2.8 s, Fast 1.6 s, with a 520 ms soft crossfade.
- Added the audited 650-item Home reflection/question pack in all 13 supported languages: O‘zbekcha, English, العربية, Français, Deutsch, हिन्दी, Bahasa Indonesia, 日本語, 한국어, Português (Brasil), Русский, Español and Türkçe.
- All language packs share ids 1..650, so language switching preserves the user’s place in the sequence; no fallback language is substituted when a pack is unavailable.
- Added in-memory reflection-pack caching to avoid repeated asset parsing during Home use.
- Added `tools/validate_reflections.py` and the audited source workbook under `docs/content/` for content-pack validation and traceability.
- No Room schema, note data format, media storage, backup format, app-lock behavior, billing configuration or stable debug signing certificate changed.
- Version bumped to `0.9.19` / code `39`.

# Memora 0.9.18 — approved visual system pass

- Applied the user-approved final visual direction to Home, Notes, New Note sheet, Editor, Reader, Memories (Calendar + Statistics), Settings and shared bottom navigation.
- Home now uses a calmer header hierarchy, roomier Short/Long cards, refined Time Trace status card, softer shared backdrop and a more compact reflection stage.
- Notes now uses the approved large title hierarchy, lavender selected chips, refined search field, stronger day headers and quieter editorial note cards.
- New Note sheet gains the approved two premium note-type cards and an explicit Cancel action.
- Editor aligns metadata and media controls on one calm row, uses the approved title hint, retains custom Memora mood stickers and adds a small note-type footer while preserving autosave/recovery and the Short/Long editor behavior.
- Reader now matches the approved layout with metadata chips, custom Memora mood badge, rounded reading surface, media/mood summary chips, edit action and bottom favorite/share/delete actions.
- Memories keeps the approved leaf/quote-free background, lavender tab/period selection, two-column statistic cards and the custom five-state Memora sticker distribution.
- Settings now uses the approved section hierarchy, icon tiles, explanatory subtitles and right-side security state.
- Preserved Time Trace camera fix, media zoom, audio pause/resume, corrected written/edited timestamps, editor stability hardening, database schema, backup formats and stable debug signing.
- Version bumped to `0.9.18` / code `38`.

# 0.9.12 — Compile diagnostic

- Keeps the 0.9.11 UX architecture preview unchanged.
- Adds a dedicated GitHub Actions Kotlin compile diagnostic step.
- Prints concise Kotlin compiler source errors before the long Gradle stacktrace.
- Uploads the complete compile log as `memora-compile-log` even when compilation fails.

# Memora 0.9.11 — UX architecture + Vaqt izi integration preview

- Replaced the old root Search tab with a unified **Yozuvlar / Notes** hub: All/Short/Long filters, live title/body search, mood/date/media filters, grouped day headers and preserved list position.
- Rebuilt Home around compact Short/Long archive cards, the approved reflection stage and a new compact **Vaqt izi** status card showing today's capture state and streak.
- Rebuilt Calendar as a direct current-month view with swipe/month picker/Today actions, day sheets and an integrated Statistics mode with period filters and custom Memora mood stickers.
- Reorganized Settings into Writing, Appearance, Data & Privacy and Memora groups; moved statistics out of Settings, folded dark mode into Theme, and combined backup/export/import into one data screen.
- Refined Editor/Reader: true 50-word Short-note cap, autosave state, title-required exit guard, private recovery, compact media controls, custom Memora mood stickers, safe media deletion and quiet borderless Long writing.
- Added the full **Vaqt izi** local module: onboarding, one final photo per day, private app storage, camera/gallery input, historical import, calm guide, local face-geometry alignment with centered-crop fallback, streak/history, 1/3/6/12-month slideshow, Before/After, date overlay, MP4 export, storage summary, daily reminder and milestone notifications.
- Vaqt izi never beautifies or scores appearance; face geometry is used only on-device to stabilise crop position for the time-lapse and no biometric identity/template is stored.
- Added Vaqt izi photos/settings to Memora backup/restore with an explicit include-photos toggle; exported videos are regenerated rather than embedded in backups.
- Added the approved warm-editorial five-state Memora mood sticker family: Zo‘r / Yaxshi / O‘rtacha / Yomon / Juda yomon.
- Replaced the launcher artwork with the approved premium open-page + bookmark Memora mark, including adaptive and Android 13+ monochrome resources.
- Preserved the slower brand-motion splash rhythm and stable test-only debug signing certificate.
- Version bumped to `0.9.11` / code `31`.

# Memora 0.9.10 — splash rhythm preview

- Rebalanced the approved Memora brand splash timing after on-device video review.
- Added a short 280 ms calm ivory pause before motion so the launch canvas registers without feeling stalled.
- Slowed the page assembly and bookmark reveal, then separated the `Memora` wordmark and tagline into distinct beats so both are readable.
- Added a brief breathing hold before the shared Home curves emerge, preserving the approved splash → Home visual connection.
- Extended the final splash-to-Home cross-fade from 240 ms to 340 ms for a softer transition.
- Total branded launch experience is now about 2.8 seconds including the final fade, while all notes, editor, database, billing, backup, and signing behavior remain unchanged.
- Version bumped to `0.9.10` / code `30`.

# Memora 0.9.9 — GitHub build fix

- Fixed the Kotlin compile error in `MainActivity.kt` where the purchase callback resolved `this` to Compose `BoxScope` instead of the required Android `Activity`.
- The billing purchase callback now explicitly passes `this@MainActivity`, preserving the existing Google Play purchase flow.
- No UI, animation, database, note/editor, backup, or signing behavior changed from the approved 0.9.8 brand-motion preview.
- Version bumped to `0.9.9` / code `29` so GitHub's newest-source selection chooses this fixed build over 0.9.8.

# Memora 0.9.8 — brand motion preview

- Replaced the static full-screen launch artwork with a lightweight Compose/vector brand animation: two pages come together, the sage bookmark appears, the Memora wordmark settles, and soft curves emerge before Home is revealed.
- Connected splash and Home with the same quiet curved-background motif and a 240 ms cross-fade so launch no longer feels like a separate illustration.
- Replaced the generic notebook/pencil launcher artwork with the new Memora mark (M + open pages + bookmark) in ivory / slate / sage brand colors.
- Removed the old 1.5 MB splash bitmap and 700 KB launcher foreground bitmap; the new brand assets are vector-drawn for sharper rendering and lighter startup resources.
- Preserved the stable test-only debug signing key and all note/editor/data behavior. No Room schema or backup format changes.
- Version bumped to `0.9.8` / code `28`.

# Memora 0.9.6 — final regression bug-fix

- Replaced the editor gallery action from the generic document picker with Android's photo-focused system picker (`PickVisualMedia`), so **Gallery** opens the device photo/gallery experience instead of the Files browser. Selected images are still copied immediately into Memora private storage.
- Hardened the Home navigation drawer after returning from notes/editor: removed the competing Home-level Back handler, made drawer actions wait for the drawer to close before navigating, and gave the drawer a deterministic half-screen width. This prevents the reported blank-background drawer state.
- No database schema or user-data format changes; Room remains at schema version 4 and existing 0.9.5 data is preserved.
- Version bumped to `0.9.6` / code `26`. Feature freeze remains in force; this build contains bug fixes only.

# Memora 0.9.5 — Final functional stabilization

- Stage 3 Play-policy hardening: subscription plan cards now explicitly disclose automatic renewal and, when a 1-month trial is available, explain the post-trial charge and how to cancel in Google Play before the trial ends. The disclosure is localized in all 13 supported UI languages and covered by a localization regression test.
- Added optional per-note mood metadata with five values: 😄 / 🙂 / 😐 / 🙁 / 😞.
- Simplified the editor mood picker to emoji-only choices; translated mood names remain available to accessibility semantics and search filters, but are no longer displayed under the five rating emojis.
- Added safe Room migration 3 → 4; existing notes and media remain intact.
- Mood is preserved by Memora backup/restore and can be used as a search filter.
- Reader view shows the selected mood beside the note date.
- Editor title field now grows naturally to multiple wrapped lines instead of scrolling horizontally.
- Reworked editor persistence into a 900 ms debounced, mutex-serialized autosave pipeline; Back/background still flush immediately.
- Added app-private recovery snapshots so recent edits can be recovered after an abnormal process exit.
- Added app-private local crash diagnostics containing stack locations only; note text, titles and media are never logged or uploaded.
- Added editor stress tests for repeated paragraph split/merge, large paste, IME punctuation/Enter, and numbered-list overflow.
- Kept the stable test-only debug signing certificate and version-independent GitHub debug workflow.
- Feature freeze begins after this stabilization build; subsequent work is bug-fix and Play testing only.

# Changelog

## 0.9.5 — final bug-fix gate before Play setup

- Removed the five built-in/system titles that Memora used to force into the Titles screen and title picker. Only titles created by the user are now shown, pinnable, editable and searchable; existing notes keep their stored title text unchanged.
- Fixed the custom-title edit dialog: the primary action now says **Save** instead of reusing the
  destructive **Delete** confirmation label. Added a dedicated `SAVE` translation in all 13 UI
  languages so the fix is correct regardless of the selected language.
- Kept the approved 60% paragraph spacing, structural numbered-list continuation, safe image import,
  single-level Back behavior, full-screen branded launch artwork and suppressed duplicate Compose
  selection toolbar unchanged.
- Preserved the stable bundled test-only debug signing certificate introduced in 0.9.4 so 0.9.5 and
  later GitHub debug APKs can update 0.9.4 in place.
- Replaced the version-hardcoded debug workflow with a universal workflow that automatically selects
  the newest `Memora-*-source.zip`, runs unit tests and lint, builds the APK, and verifies the expected
  debug signing certificate before upload. This prevents old `0.9.x-source.zip not found` workflow
  failures when the app version changes.
- Added a localization regression test for the Save action and corrected the paragraph-gap test name
  to match the established 60% metric.
- Version bumped to `0.9.5` / code `25`. This is the code-freeze bug-fix gate; new feature work is
  deferred until the Play release infrastructure steps.

## 0.9.4 — launch cleanup, numbered paragraphs, stable test updates

- Removed the separate small-logo Android system splash introduced in 0.9.3: the mandatory
  platform splash now uses a transparent icon and blends directly into the existing full-screen
  Memora launch artwork.
- Restored numbered-paragraph continuation in the structural paragraph editor. Soft keyboards that
  commit punctuation and Enter in one callback now preserve the punctuation and create exactly one
  next marker (`1.` → `2.` → `3.`).
- Removed the cross-paragraph timing debounce that could swallow a legitimate Enter and leave
  automatic numbering inactive; duplicate OEM callbacks remain guarded per editor instance.
- Reintroduced the established bundled **test-only** signing certificate for debug builds. Debug
  APKs from 0.9.4 onward use the same package ID and certificate, so later GitHub APKs install as
  updates instead of requiring uninstall/reinstall. Production Play signing remains separate.
- Version bumped to `0.9.4` / code `24`; the 60% paragraph spacing and all 0.9.3 fixes are retained.

## 0.9.3 — GitHub lint/build fix + stability hardening

- Fixed all six blocking Android Lint `NewApi` errors introduced by splash/system-bar XML: API 27/29-only navigation-bar attributes are no longer declared in unqualified `values` resources. Runtime system-bar behavior remains handled safely by `WindowCompat` and existing SDK guards.
- Moved image display decoding off the Compose UI thread and reduced peak bitmap memory with
  bounded RGB_565 sampling; gallery import now uses a document URI with persistable read access.
- Added graceful handling for oversized/corrupt images so image insertion reports a failure instead
  of terminating the app process.
- Shortened the platform splash transition, made the native first frame show the Memora mark
  instead of a blank cream screen, moved nonessential startup scheduling off the main thread, and
  matched the navigation/gesture area to the lower edge of the launch artwork.
- Hardened structural Enter handling for numbered lists: hardware Enter is consumed directly,
  duplicate OEM-IME newline callbacks collapse to one paragraph break, and a cross-field debounce
  prevents the next number from being created twice after terminal punctuation.
- Replaced per-route Back handlers with one central route-level handler while keeping nested editor,
  note-selection and calendar Back behavior; each Back action now removes exactly one level.
- Suppressed Memora's Compose text-selection toolbar in the note editor while leaving text selection
  enabled for device/OEM-native actions.
- Version bumped to `0.9.3` / code `23`; the existing 60% paragraph spacing and 0.9.1 production
  billing/privacy architecture are unchanged.

## 0.9.1 — Stability and navigation bugfix

- Hardened gallery and camera image import with bounded staging, sampled decoding,
  safe cleanup and a user-visible failure message instead of an app exit.
- Limited displayed image decoding and removed decoded bitmap allocations when the
  image leaves the editor or reader.
- Made the launch artwork crop to the full edge-to-edge surface and aligned system
  bars so the lower strip keeps the same background.
- Removed Memora's duplicate copy/cut/paste/select-all toolbar; Android's native
  selection toolbar remains available.
- Enter after a numbered sentence ending in a period now creates exactly one next
  paragraph, without silently inserting a trailing space.
- Made every route use one-step back navigation, prevented rapid editor back races,
  and preserved nested statistics/search state when returning from a note.

## 0.9.0 — Play Release Candidate

- Added Google Play Billing Library 9.1.0 integration for the single
  `memora_premium` subscription and four base plans.
- Added Play-controlled offer selection for a one-month free trial; reinstalling
  the app does not reset Play account eligibility.
- Added backend purchase-token verification, encrypted seven-day offline
  entitlement caching, pending-purchase handling and post-verification acknowledgement.
- Added read-only behavior after expiry while preserving viewing, search,
  statistics, playback and every export format.
- Added automatic device-language selection with English fallback while retaining
  the existing manual choice and all 13 UI languages.
- Kept all journal content local and added no advertising, analytics or crash SDK.
- Separated release signing from debug signing and removed the bundled test key.
- Replaced the custom build bootstrap with the official checksum-pinned Gradle wrapper.
- Added bounded backup/media import and canonical private-storage path validation.
- Added a GitHub Actions test → lint → signed AAB pipeline.
- Retained the 0.5.7 editor/reader paragraph gap at exactly 60% of line-height.

## 0.5.7 baseline

- Structural paragraph blocks, 60% paragraph spacing, short/long notes, media,
  reminders, titles, statistics, search, app lock, 13 languages, HTML/Word export
  and `.memora` backup/import form the preserved functional baseline.

## 0.9.7 — Tiniq Xotira design-system preview
- Unified corner radii/elevation tokens across Compose UI.
- Home colors now follow the selected palette instead of fixed Sage/Lavender/Mist values.
- Quieter bottom navigation with a smaller central action and subtler selected state.
- Refined compact note cards and note-list spacing.
- Editor chrome aligned with the shared design system while preserving the borderless Long editor.
- Settings reorganized into logical groups.
# 0.9.21 — Topilmalar

- Added the device-local Topilmalar module with sources, cards, comments, tags, favorites, images and source management.
- Added Android Share quick capture with immediate local save and post-save actions.
- Added balanced offline Qayta ko‘rish sessions, adaptive intervals, random review, reminders and Home integration.
- Added Room 5→6 migration without destructive recreation.
- Added Topilmalar backup/restore and separate HTML/Word exports.
- Replaced directional navigation slides with a fast whole-screen crossfade.
- Removed the old bundled daily-reflection system and its datasets.
