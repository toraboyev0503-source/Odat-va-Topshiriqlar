package com.memora.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.TextSnippet
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.Hyphens
import androidx.compose.ui.text.style.LineBreak
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memora.app.data.local.NoteEntity
import com.memora.app.data.model.NoteBlock
import com.memora.app.data.model.NoteBlocksCodec
import com.memora.app.data.model.NoteMood
import com.memora.app.i18n.L
import com.memora.app.i18n.S
import com.memora.app.media.MediaStorage
import com.memora.app.prefs.AppLanguage
import com.memora.app.prefs.FontChoice
import com.memora.app.ui.components.AudioBlockView
import com.memora.app.ui.components.ImageBlockView
import com.memora.app.ui.components.MemoraTopBar
import com.memora.app.ui.components.MemoraConfirmationDialog
import com.memora.app.ui.components.MoodSticker
import com.memora.app.ui.theme.MemoraDesign
import com.memora.app.ui.theme.ParagraphMetrics
import com.memora.app.ui.theme.fontFamily
import com.memora.app.util.TimeUtils
import com.memora.app.share.ReaderShareManager
import kotlinx.coroutines.launch

@Composable
fun ReaderScreen(
    note: NoteEntity?,
    language: AppLanguage,
    writingFont: FontChoice,
    canEdit: Boolean,
    onBack: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onWriteRequired: () -> Unit
) {
    if (note == null) {
        Column(Modifier.fillMaxSize()) {
            MemoraTopBar(
                title = "",
                navigation = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Rounded.ArrowBack, contentDescription = null)
                    }
                }
            )
        }
        return
    }

    val context = LocalContext.current
    val storage = remember { MediaStorage(context.applicationContext) }
    val blocks = remember(note.blocksJson, note.plainText) {
        NoteBlocksCodec.decode(note.blocksJson, note.plainText)
    }
    val noteMood = remember(note.mood) { NoteMood.fromStored(note.mood) }
    val density = LocalDensity.current
    val paragraphGap = with(density) { (ParagraphMetrics.READER_LINE_HEIGHT_SP * ParagraphMetrics.GAP_RATIO).sp.toDp() }
    var menuExpanded by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var showShareSheet by remember { mutableStateOf(false) }
    val shareManager = remember(context) { ReaderShareManager(context) }
    val shareScope = rememberCoroutineScope()

    val favoritePrefs = remember(context) {
        context.getSharedPreferences("memora_reader_favorites", 0)
    }
    var favorite by remember(note.id) { mutableStateOf(favoritePrefs.getBoolean(note.id, false)) }
    val imageCount = remember(blocks) { blocks.count { it is NoteBlock.Image } }
    val audioCount = remember(blocks) { blocks.count { it is NoteBlock.Audio } }

    Column(Modifier.fillMaxSize()) {
        MemoraTopBar(
            title = "",
            navigation = {
                IconButton(onClick = onBack) {
                    Icon(Icons.Rounded.ArrowBack, contentDescription = null)
                }
            },
            actions = {
                Surface(
                    onClick = { if (canEdit) onEdit() else onWriteRequired() },
                    shape = RoundedCornerShape(MemoraDesign.radiusMedium),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .42f)
                ) {
                    Row(
                        Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Rounded.Edit, contentDescription = null, modifier = Modifier.size(18.dp))
                        Text(
                            readerEditLabel(language),
                            style = MaterialTheme.typography.labelLarge,
                            modifier = Modifier.padding(start = 6.dp)
                        )
                    }
                }
                Box {
                    IconButton(onClick = { menuExpanded = true }) {
                        Icon(Icons.Rounded.MoreVert, contentDescription = null)
                    }
                    DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
                        DropdownMenuItem(
                            text = { Text(L.t(language, S.DELETE)) },
                            leadingIcon = { Icon(Icons.Rounded.DeleteOutline, contentDescription = null) },
                            onClick = {
                                menuExpanded = false
                                if (canEdit) confirmDelete = true else onWriteRequired()
                            }
                        )
                    }
                }
            }
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 8.dp)
        ) {
            Row(verticalAlignment = Alignment.Top) {
                Column(Modifier.weight(1f)) {
                    Text(
                        text = note.title.ifBlank { L.t(language, S.UNTITLED) },
                        style = MaterialTheme.typography.headlineLarge.copy(fontSize = 35.sp),
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(10.dp))
                    ReaderMetaChip(
                        icon = Icons.Rounded.CalendarMonth,
                        text = readerWrittenText(language, note.createdAt),
                        tintAlpha = .10f
                    )
                    if (note.updatedAt > note.createdAt) {
                        Spacer(Modifier.height(6.dp))
                        ReaderMetaChip(
                            icon = Icons.Rounded.History,
                            text = readerEditedText(language, note.updatedAt),
                            tintAlpha = .08f
                        )
                    }
                }
                noteMood?.let { mood ->
                    Surface(
                        shape = RoundedCornerShape(MemoraDesign.radiusMedium),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .52f),
                        modifier = Modifier.padding(start = 12.dp)
                    ) {
                        Column(
                            Modifier.padding(horizontal = 13.dp, vertical = 11.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            MoodSticker(
                                mood = mood,
                                description = readerMoodName(language, mood),
                                modifier = Modifier.size(42.dp)
                            )
                            Text(
                                readerMoodName(language, mood),
                                style = MaterialTheme.typography.labelMedium,
                                modifier = Modifier.padding(top = 5.dp)
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(18.dp))

            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(MemoraDesign.radiusLarge),
                color = MaterialTheme.colorScheme.surface.copy(alpha = .985f),
                shadowElevation = MemoraDesign.shadowSubtle
            ) {
                Column(Modifier.padding(20.dp)) {
                    blocks.forEachIndexed { index, block ->
                        when (block) {
                            is NoteBlock.Text -> if (block.text.isNotBlank()) {
                                Text(
                                    text = buildAnnotatedString {
                                        append(block.text)
                                        block.styles.forEach { span ->
                                            if (span.start >= 0 && span.end <= block.text.length && span.end > span.start) {
                                                addStyle(
                                                    SpanStyle(
                                                        fontWeight = if (span.bold) FontWeight.Bold else null,
                                                        fontStyle = if (span.italic) FontStyle.Italic else null
                                                    ),
                                                    span.start,
                                                    span.end
                                                )
                                            }
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    style = TextStyle(
                                        color = MaterialTheme.colorScheme.onBackground,
                                        fontFamily = fontFamily(writingFont),
                                        fontSize = 18.sp,
                                        lineHeight = 28.sp,
                                        hyphens = Hyphens.Auto,
                                        lineBreak = LineBreak.Paragraph
                                    )
                                )
                            }
                            is NoteBlock.Image -> ImageBlockView(
                                block = block,
                                file = storage.resolve(block.relativePath),
                                editable = false
                            )
                            is NoteBlock.Audio -> AudioBlockView(
                                block = block,
                                file = storage.resolve(block.relativePath),
                                editable = false,
                                language = language
                            )
                        }

                        val next = blocks.getOrNull(index + 1)
                        if (next != null) {
                            val gap = if (block is NoteBlock.Text && next is NoteBlock.Text) paragraphGap else 14.dp
                            Spacer(Modifier.height(gap))
                        }
                    }

                    if (imageCount > 0 || audioCount > 0 || noteMood != null) {
                        HorizontalDivider(
                            modifier = Modifier.padding(top = 18.dp, bottom = 14.dp),
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = .08f)
                        )
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (imageCount > 0) {
                                ReaderSummaryChip(Icons.Rounded.Image, readerImageCount(language, imageCount), Modifier.weight(1f))
                            }
                            if (audioCount > 0) {
                                ReaderSummaryChip(Icons.Rounded.Mic, readerAudioCount(language, audioCount), Modifier.weight(1f))
                            }
                            noteMood?.let { mood ->
                                ReaderMoodSummaryChip(language, mood, Modifier.weight(1.35f))
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(18.dp))

            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(MemoraDesign.radiusLarge),
                color = MaterialTheme.colorScheme.surface.copy(alpha = .96f),
                shadowElevation = MemoraDesign.shadowSubtle
            ) {
                Row(Modifier.fillMaxWidth()) {
                    ReaderAction(
                        icon = if (favorite) Icons.Rounded.Star else Icons.Rounded.StarBorder,
                        label = readerFavoriteLabel(language),
                        onClick = {
                            favorite = !favorite
                            favoritePrefs.edit().putBoolean(note.id, favorite).apply()
                        },
                        modifier = Modifier.weight(1f)
                    )
                    ReaderAction(
                        icon = Icons.Rounded.Share,
                        label = readerShareLabel(language),
                        onClick = { showShareSheet = true },
                        modifier = Modifier.weight(1f)
                    )
                    ReaderAction(
                        icon = Icons.Rounded.DeleteOutline,
                        label = L.t(language, S.DELETE),
                        onClick = { if (canEdit) confirmDelete = true else onWriteRequired() },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
            Spacer(Modifier.height(28.dp))
        }
    }

    if (confirmDelete) {
        MemoraConfirmationDialog(
            language = language,
            title = if (language == AppLanguage.UZ) "Yozuvni o‘chirish" else "Delete note",
            text = if (language == AppLanguage.UZ) "Bu yozuv qayta tiklanmaydi. O‘chirishni tasdiqlaysizmi?" else "This note cannot be restored. Delete it?",
            onConfirm = { confirmDelete = false; onDelete() },
            onDismiss = { confirmDelete = false }
        )
    }

    if (showShareSheet) {
        ModalBottomSheet(onDismissRequest = { showShareSheet = false }) {
            Column(Modifier.fillMaxWidth().padding(start = 18.dp, end = 18.dp, bottom = 26.dp)) {
                Text(
                    readerShareLabel(language),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp)
                )
                ShareSheetAction(Icons.Rounded.TextSnippet, readerShareTextLabel(language)) {
                    showShareSheet = false
                    shareManager.shareText(note, readerShareLabel(language))
                }
                ShareSheetAction(Icons.Rounded.Image, readerShareImageLabel(language)) {
                    showShareSheet = false
                    shareScope.launch {
                        runCatching { shareManager.shareImages(note, language, readerShareLabel(language)) }
                    }
                }
                ShareSheetAction(Icons.Rounded.Code, "HTML") {
                    showShareSheet = false
                    shareScope.launch {
                        runCatching { shareManager.shareHtml(note, language, readerShareLabel(language)) }
                    }
                }
            }
        }
    }
}

@Composable
private fun ReaderMetaChip(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    text: String,
    tintAlpha: Float
) {
    Surface(
        shape = RoundedCornerShape(MemoraDesign.radiusMedium),
        color = MaterialTheme.colorScheme.primary.copy(alpha = tintAlpha)
    ) {
        Row(
            Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
            Text(
                text,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(start = 7.dp)
            )
        }
    }
}

@Composable
private fun ReaderSummaryChip(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    text: String,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(MemoraDesign.radiusMedium),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .50f)
    ) {
        Row(
            Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(19.dp))
            Text(text, style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(start = 7.dp))
        }
    }
}

@Composable
private fun ReaderMoodSummaryChip(language: AppLanguage, mood: NoteMood, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(MemoraDesign.radiusMedium),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .50f)
    ) {
        Row(
            Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            MoodSticker(mood, readerMoodName(language, mood), Modifier.size(24.dp))
            Text(
                "${readerMoodLabel(language)}: ${readerMoodName(language, mood)}",
                style = MaterialTheme.typography.labelLarge,
                modifier = Modifier.padding(start = 7.dp)
            )
        }
    }
}

@Composable
private fun ReaderAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clickable(onClick = onClick)
            .padding(vertical = 15.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = label, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
        Text(
            label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 5.dp)
        )
    }
}

@Composable
private fun ShareSheetAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        shape = RoundedCornerShape(MemoraDesign.radiusMedium),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .34f)
    ) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Text(label, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(start = 14.dp))
        }
    }
}

private fun readerShareTextLabel(l: AppLanguage) = if (l == AppLanguage.UZ) "Matn" else if (l == AppLanguage.RU) "Текст" else "Text"
private fun readerShareImageLabel(l: AppLanguage) = if (l == AppLanguage.UZ) "Rasm" else if (l == AppLanguage.RU) "Изображение" else "Image"

private fun readerEditLabel(l: AppLanguage) = if (l == AppLanguage.UZ) "Tahrirlash" else if (l == AppLanguage.RU) "Изменить" else "Edit"
private fun readerFavoriteLabel(l: AppLanguage) = if (l == AppLanguage.UZ) "Sevimlilarga" else if (l == AppLanguage.RU) "Избранное" else "Favorite"
private fun readerShareLabel(l: AppLanguage) = if (l == AppLanguage.UZ) "Ulashish" else if (l == AppLanguage.RU) "Поделиться" else "Share"
private fun readerMoodLabel(l: AppLanguage) = if (l == AppLanguage.UZ) "Kayfiyat" else if (l == AppLanguage.RU) "Настроение" else "Mood"
private fun readerImageCount(l: AppLanguage, n: Int) = if (l == AppLanguage.UZ) "$n rasm" else "$n images"
private fun readerAudioCount(l: AppLanguage, n: Int) = if (l == AppLanguage.UZ) "$n audio" else "$n audio"
private fun readerWrittenText(l: AppLanguage, time: Long) = when (l) {
    AppLanguage.UZ -> "Yozilgan: ${TimeUtils.dateTime(time, l)}"
    AppLanguage.RU -> "Создано: ${TimeUtils.dateTime(time, l)}"
    else -> "Written: ${TimeUtils.dateTime(time, l)}"
}
private fun readerEditedText(l: AppLanguage, time: Long) = when (l) {
    AppLanguage.UZ -> "Tahrirlandi: ${TimeUtils.dateTime(time, l)}"
    AppLanguage.RU -> "Изменено: ${TimeUtils.dateTime(time, l)}"
    else -> "Edited: ${TimeUtils.dateTime(time, l)}"
}
private fun readerMoodName(l: AppLanguage, mood: NoteMood): String = when (mood) {
    NoteMood.GREAT -> if (l == AppLanguage.UZ) "Zo‘r" else "Great"
    NoteMood.GOOD -> if (l == AppLanguage.UZ) "Yaxshi" else "Good"
    NoteMood.NEUTRAL -> if (l == AppLanguage.UZ) "O‘rtacha" else "Neutral"
    NoteMood.BAD -> if (l == AppLanguage.UZ) "Yomon" else "Bad"
    NoteMood.VERY_BAD -> if (l == AppLanguage.UZ) "Juda yomon" else "Very bad"
}
