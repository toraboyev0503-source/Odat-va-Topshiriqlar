package com.memora.app.share

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File

/**
 * Uses an installed on-device image-text recognizer (Google Lens or another OCR app).
 * No image is uploaded by Memora; the user explicitly chooses/opens the OCR provider.
 */
object TopilmaOcrManager {
    fun open(context: Context, image: File, mimeType: String) {
        val directory = File(context.cacheDir, "shares").apply { mkdirs() }
        val shared = File(directory, "ocr-${image.name}")
        image.inputStream().use { input -> shared.outputStream().use { input.copyTo(it) } }
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", shared)
        val base = Intent(Intent.ACTION_SEND).apply {
            type = mimeType.ifBlank { "image/*" }
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val lens = Intent(base).setPackage("com.google.ar.lens")
        val target = if (lens.resolveActivity(context.packageManager) != null) lens else Intent.createChooser(base, "Matnni aniqlash")
        context.startActivity(target)
    }
}
