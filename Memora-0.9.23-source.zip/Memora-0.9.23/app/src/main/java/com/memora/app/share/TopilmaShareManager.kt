package com.memora.app.share

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.FileProvider
import com.memora.app.data.local.TopilmaCardRow
import com.memora.app.media.TopilmalarMediaStorage
import com.memora.app.ui.components.TopilmaCardVisualSpec
import com.memora.app.ui.components.tagNames
import java.io.File
import java.io.FileOutputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object TopilmaShareManager {
    fun shareText(context: Context, card: TopilmaCardRow, includeSource: Boolean) {
        val text = buildString {
            append(card.text)
            if (includeSource && !card.sourceTitle.isNullOrBlank()) {
                append("\n\n— ").append(card.sourceTitle)
                if (!card.sourceAuthor.isNullOrBlank()) append(", ").append(card.sourceAuthor)
            }
            val tags = card.tagNames()
            if (tags.isNotEmpty()) append("\n\n").append(tags.joinToString(" ") { "#$it" })
        }
        context.startActivity(
            Intent.createChooser(
                Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, text)
                },
                "Topilmani ulashish"
            )
        )
    }

    /** T-171/T-206: export always renders the complete master card, never the 2-line list state. */
    suspend fun shareCardImage(context: Context, card: TopilmaCardRow) {
        val uri = withContext(Dispatchers.IO) {
            val bitmap = renderCardBitmap(context, card)
            val directory = File(context.cacheDir, "shares").apply { mkdirs() }
            val file = File(directory, "topilma-${card.id}.png")
            FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            bitmap.recycle()
            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        }
        withContext(Dispatchers.Main) {
            context.startActivity(
                Intent.createChooser(
                    Intent(Intent.ACTION_SEND).apply {
                        type = "image/png"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    },
                    "Kartochka rasmini ulashish"
                )
            )
        }
    }

    /** Reused by Obsidian sync so shared and synced cards are pixel-identical. Call from IO. */
    fun renderCardBitmap(context: Context, card: TopilmaCardRow): Bitmap {
        val width = TopilmaCardVisualSpec.EXPORT_WIDTH
        val outer = TopilmaCardVisualSpec.EXPORT_OUTER
        val cardLeft = outer
        val cardRight = width - outer
        val innerLeft = cardLeft + TopilmaCardVisualSpec.EXPORT_INNER
        val innerRight = cardRight - TopilmaCardVisualSpec.EXPORT_INNER
        val contentWidth = (innerRight - innerLeft).toInt()

        val title = card.sourceTitle?.takeIf { it.isNotBlank() } ?: "Manbasi aniqlanmagan"
        val author = card.sourceAuthor.orEmpty()
        val body = card.text.ifBlank { "Rasmli Topilma" }
        val tags = card.tagNames()

        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(37, 38, 38)
            textSize = 40f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        val authorPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(112, 112, 112)
            textSize = 30f
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        }
        val bodyPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(35, 35, 34)
            textSize = when {
                body.length < 170 -> 47f
                body.length < 430 -> 42f
                body.length < 900 -> 37f
                else -> 33f
            }
            typeface = Typeface.create(Typeface.SERIF, Typeface.NORMAL)
        }

        val coverW = TopilmaCardVisualSpec.EXPORT_COVER_W
        val coverH = TopilmaCardVisualSpec.EXPORT_COVER_H
        val headerTextWidth = (contentWidth - coverW - 34f - 58f).toInt().coerceAtLeast(300)
        val titleLayout = StaticLayout.Builder.obtain(title, 0, title.length, titlePaint, headerTextWidth)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setMaxLines(2)
            .setEllipsize(android.text.TextUtils.TruncateAt.END)
            .setLineSpacing(2f, 1f)
            .build()
        val authorLayout = if (author.isNotBlank()) {
            StaticLayout.Builder.obtain(author, 0, author.length, authorPaint, headerTextWidth)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setMaxLines(1)
                .setEllipsize(android.text.TextUtils.TruncateAt.END)
                .build()
        } else null
        val bodyLayout = StaticLayout.Builder.obtain(body, 0, body.length, bodyPaint, contentWidth)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setLineSpacing(10f, 1f)
            .build()

        val cardTop = outer
        val headerTop = cardTop + 44f
        val headerHeight = maxOf(coverH, titleLayout.height.toFloat() + (authorLayout?.height ?: 0) + 10f)
        val bodyTop = headerTop + headerHeight + TopilmaCardVisualSpec.EXPORT_HEADER_TO_BODY

        val tagRows = if (tags.isEmpty()) 0 else ((tags.size + 2) / 3).coerceAtLeast(1)
        val tagsHeight = if (tagRows == 0) 0f else 52f * tagRows + 14f
        val bodyBottom = bodyTop + bodyLayout.height
        val actionTop = bodyBottom + 40f + tagsHeight
        val cardBottom = maxOf(
            actionTop + TopilmaCardVisualSpec.EXPORT_ACTION_HEIGHT + 18f,
            cardTop + 650f
        )
        val bitmapHeight = (cardBottom + outer).toInt()

        val bitmap = Bitmap.createBitmap(width, bitmapHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.rgb(249, 245, 242))

        val cardPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            setShadowLayer(12f, 0f, 4f, Color.argb(30, 0, 0, 0))
        }
        canvas.drawRoundRect(
            cardLeft, cardTop, cardRight, cardBottom,
            TopilmaCardVisualSpec.EXPORT_RADIUS, TopilmaCardVisualSpec.EXPORT_RADIUS,
            cardPaint
        )

        val coverLeft = innerLeft
        val coverTop = headerTop
        val thumbnail = card.sourceCoverPath?.let { relativePath ->
            runCatching { decodeThumbnail(TopilmalarMediaStorage(context).resolve(relativePath), 360) }.getOrNull()
        }
        if (thumbnail != null) {
            canvas.save()
            val clip = Path().apply {
                addRoundRect(
                    RectF(coverLeft, coverTop, coverLeft + coverW, coverTop + coverH),
                    TopilmaCardVisualSpec.EXPORT_COVER_RADIUS,
                    TopilmaCardVisualSpec.EXPORT_COVER_RADIUS,
                    Path.Direction.CW
                )
            }
            canvas.clipPath(clip)
            canvas.drawBitmap(thumbnail, null, RectF(coverLeft, coverTop, coverLeft + coverW, coverTop + coverH), Paint(Paint.ANTI_ALIAS_FLAG))
            canvas.restore()
            thumbnail.recycle()
        } else {
            val fallback = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(236, 241, 238) }
            canvas.drawRoundRect(
                coverLeft, coverTop, coverLeft + coverW, coverTop + coverH,
                TopilmaCardVisualSpec.EXPORT_COVER_RADIUS,
                TopilmaCardVisualSpec.EXPORT_COVER_RADIUS,
                fallback
            )
            canvas.drawText("M", coverLeft + 33f, coverTop + 88f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(64, 100, 84)
                textSize = 52f
                typeface = Typeface.DEFAULT_BOLD
            })
        }

        val textLeft = coverLeft + coverW + 31f
        canvas.save(); canvas.translate(textLeft, headerTop + 2f); titleLayout.draw(canvas); canvas.restore()
        authorLayout?.let {
            canvas.save(); canvas.translate(textLeft, headerTop + titleLayout.height + 9f); it.draw(canvas); canvas.restore()
        }

        // Horizontal three-dot menu to match the master card.
        val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(119, 119, 118) }
        val dotY = headerTop + 23f
        val dotX = innerRight - 24f
        listOf(-17f, 0f, 17f).forEach { offset -> canvas.drawCircle(dotX + offset, dotY, 4.1f, dotPaint) }

        canvas.save(); canvas.translate(innerLeft, bodyTop); bodyLayout.draw(canvas); canvas.restore()

        var tagY = bodyBottom + 30f
        if (tags.isNotEmpty()) {
            val tagTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(78, 92, 160)
                textSize = 25f
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            }
            val tagBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(241, 240, 252) }
            var x = innerLeft
            tags.forEach { tag ->
                val label = "#$tag"
                val w = tagTextPaint.measureText(label) + 34f
                if (x + w > innerRight) {
                    x = innerLeft
                    tagY += 52f
                }
                canvas.drawRoundRect(x, tagY, x + w, tagY + 40f, 20f, 20f, tagBg)
                canvas.drawText(label, x + 17f, tagY + 28f, tagTextPaint)
                x += w + 14f
            }
        }

        val actionY = actionTop + 54f
        val iconColor = Color.rgb(56, 58, 57)
        val muted = Color.rgb(96, 98, 97)
        val actionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = iconColor
            strokeWidth = 5f
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        val countPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = muted
            textSize = 29f
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        }

        // Equal thirds: share / like / comment.
        val third = (innerRight - innerLeft) / 3f
        val shareX = innerLeft + third / 2f
        val heartX = innerLeft + third * 1.5f
        val commentX = innerLeft + third * 2.5f

        canvas.drawLine(shareX - 24f, actionY + 20f, shareX - 24f, actionY + 44f, actionPaint)
        canvas.drawLine(shareX - 24f, actionY + 44f, shareX + 24f, actionY + 44f, actionPaint)
        canvas.drawLine(shareX + 24f, actionY + 44f, shareX + 24f, actionY + 20f, actionPaint)
        canvas.drawLine(shareX, actionY + 29f, shareX, actionY - 26f, actionPaint)
        canvas.drawLine(shareX, actionY - 26f, shareX - 15f, actionY - 9f, actionPaint)
        canvas.drawLine(shareX, actionY - 26f, shareX + 15f, actionY - 9f, actionPaint)

        val heartPath = Path().apply {
            moveTo(heartX, actionY + 35f)
            cubicTo(heartX - 58f, actionY - 2f, heartX - 40f, actionY - 42f, heartX - 16f, actionY - 30f)
            cubicTo(heartX - 5f, actionY - 25f, heartX, actionY - 13f, heartX, actionY - 13f)
            cubicTo(heartX, actionY - 13f, heartX + 5f, actionY - 25f, heartX + 16f, actionY - 30f)
            cubicTo(heartX + 40f, actionY - 42f, heartX + 58f, actionY - 2f, heartX, actionY + 35f)
            close()
        }
        val heartPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (card.likeCount > 0) Color.rgb(219, 104, 113) else iconColor
            style = if (card.likeCount > 0) Paint.Style.FILL else Paint.Style.STROKE
            strokeWidth = 5f
        }
        canvas.drawPath(heartPath, heartPaint)
        if (card.likeCount > 0) canvas.drawText(card.likeCount.toString(), heartX + 51f, actionY + 10f, countPaint)

        val bubble = RectF(commentX - 31f, actionY - 29f, commentX + 31f, actionY + 21f)
        canvas.drawRoundRect(bubble, 13f, 13f, actionPaint)
        val tail = Path().apply {
            moveTo(commentX - 8f, actionY + 21f)
            lineTo(commentX - 18f, actionY + 38f)
            lineTo(commentX + 3f, actionY + 22f)
        }
        canvas.drawPath(tail, actionPaint)
        if (card.commentCount > 0) canvas.drawText(card.commentCount.toString(), commentX + 46f, actionY + 10f, countPaint)

        return bitmap
    }

    private fun decodeThumbnail(file: File, target: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (bounds.outWidth / sample > target * 2 || bounds.outHeight / sample > target * 2) sample *= 2
        return BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
    }
}
