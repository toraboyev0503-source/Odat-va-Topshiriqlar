package com.memora.app.obsidian

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import com.memora.app.data.local.AppDatabase
import com.memora.app.data.local.NoteEntity
import com.memora.app.data.local.NoteType
import com.memora.app.data.local.ObsidianSyncRecordEntity
import com.memora.app.data.local.TopilmaCardRow
import com.memora.app.data.model.NoteBlock
import com.memora.app.data.model.NoteBlocksCodec
import com.memora.app.media.MediaStorage
import com.memora.app.prefs.UserPreferences
import com.memora.app.share.TopilmaShareManager
import com.memora.app.ui.components.tagNames
import com.memora.app.util.HashtagUtils
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ObsidianSyncManager(
    context: Context,
    private val db: AppDatabase,
    private val preferences: UserPreferences,
    private val scope: CoroutineScope
) {
    private val appContext = context.applicationContext
    private val notes = db.noteDao()
    private val cards = db.topilmaCardDao()
    private val sync = db.obsidianSyncDao()
    private val mediaStorage = MediaStorage(appContext)
    private val debounceJobs = ConcurrentHashMap<String, Job>()

    val pendingCount: Flow<Int> = sync.observePendingCount()
    val lastSyncedAt: Flow<Long?> = sync.observeLastSyncedAt()
    val lastError: Flow<String?> = sync.observeLastError()

    companion object {
        const val TYPE_SHORT = "SHORT"
        const val TYPE_LONG = "LONG"
        const val TYPE_TOPILMA = "TOPILMA"
        private const val START = "<!-- MEMORA:START -->"
        private const val END = "<!-- MEMORA:END -->"
        private const val DEBOUNCE_MS = 1500L
    }

    suspend fun connect(treeUri: Uri, exportExisting: Boolean) {
        preferences.setObsidianTreeUri(treeUri.toString())
        preferences.setObsidianExportExisting(exportExisting)
        preferences.setObsidianEnabled(true)
        ensureStructure(treeUri)
        if (exportExisting) markAllExistingPending()
        // Existing pending writes (for example after a moved vault) resume immediately.
        syncPending()
    }

    suspend fun setEnabled(enabled: Boolean) {
        if (enabled) {
            val uri = currentTreeUri() ?: return
            ensureStructure(uri)
        }
        preferences.setObsidianEnabled(enabled)
        if (enabled) syncPending()
    }

    suspend fun clearConnection() {
        preferences.setObsidianEnabled(false)
        preferences.setObsidianTreeUri(null)
    }

    suspend fun noteChanged(noteId: String) {
        val settings = preferences.settings.first()
        if (!settings.obsidianEnabled || settings.obsidianTreeUri.isNullOrBlank()) return
        val note = notes.getById(noteId) ?: return
        val type = if (note.type == NoteType.SHORT.name) TYPE_SHORT else TYPE_LONG
        markPending(type, noteId)
        schedule(type, noteId)
    }

    suspend fun topilmaChanged(cardId: String) {
        val settings = preferences.settings.first()
        if (!settings.obsidianEnabled || settings.obsidianTreeUri.isNullOrBlank()) return
        if (cards.getById(cardId) == null) return
        markPending(TYPE_TOPILMA, cardId)
        schedule(TYPE_TOPILMA, cardId)
    }

    suspend fun sourceChanged(sourceId: String) {
        cards.idsForSource(sourceId).forEach { topilmaChanged(it) }
    }

    suspend fun forceNote(noteId: String) {
        val settings = preferences.settings.first()
        if (!settings.obsidianEnabled || settings.obsidianTreeUri.isNullOrBlank()) return
        debounceJobs.remove("note:$noteId")?.cancel()
        val note = notes.getById(noteId) ?: return
        val type = if (note.type == NoteType.SHORT.name) TYPE_SHORT else TYPE_LONG
        markPending(type, noteId)
        syncOne(type, noteId)
    }

    suspend fun forceTopilma(cardId: String) {
        val settings = preferences.settings.first()
        if (!settings.obsidianEnabled || settings.obsidianTreeUri.isNullOrBlank()) return
        debounceJobs.remove("topilma:$cardId")?.cancel()
        if (cards.getById(cardId) == null) return
        markPending(TYPE_TOPILMA, cardId)
        syncOne(TYPE_TOPILMA, cardId)
    }

    suspend fun markAllExistingPending() {
        notes.getForExport(null, null, null).forEach { note ->
            markPending(if (note.type == NoteType.SHORT.name) TYPE_SHORT else TYPE_LONG, note.id)
        }
        cards.getAll().forEach { card -> markPending(TYPE_TOPILMA, card.id) }
    }

    suspend fun resyncAll() {
        markAllExistingPending()
        syncPending()
    }

    suspend fun syncPending() {
        val settings = preferences.settings.first()
        if (!settings.obsidianEnabled || settings.obsidianTreeUri.isNullOrBlank()) return
        sync.pending().forEach { record -> syncOne(record.entityType, record.entityId) }
    }

    suspend fun ensureStructure(treeUri: Uri? = null) {
        val resolvedTreeUri = treeUri ?: currentTreeUri() ?: return
        withContext(Dispatchers.IO) {
        val root = DocumentFile.fromTreeUri(appContext, resolvedTreeUri) ?: error("Obsidian papkasini ochib bo‘lmadi")
        val memora = root.ensureDirectory("Memora")
        memora.ensureDirectory("Qisqa matn").ensureDirectory("_assets")
        memora.ensureDirectory("Topilmalar").ensureDirectory("_assets")
        memora.ensureDirectory("Uzun matn").ensureDirectory("_assets")
        }
    }

    fun kickPendingOnLaunch() {
        scope.launch(Dispatchers.IO) {
            runCatching { syncPending() }
        }
    }

    private suspend fun markPending(type: String, id: String) {
        val key = key(type, id)
        val existing = sync.get(key)
        sync.upsert(
            (existing ?: ObsidianSyncRecordEntity(key, type, id)).copy(
                state = "PENDING",
                lastError = null,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    private fun schedule(type: String, id: String) {
        val jobKey = if (type == TYPE_TOPILMA) "topilma:$id" else "note:$id"
        debounceJobs.remove(jobKey)?.cancel()
        debounceJobs[jobKey] = scope.launch(Dispatchers.IO) {
            delay(DEBOUNCE_MS)
            runCatching { syncOne(type, id) }
            debounceJobs.remove(jobKey)
        }
    }

    private suspend fun syncOne(type: String, id: String) = withContext(Dispatchers.IO) {
        val tree = currentTreeUri() ?: return@withContext
        val settings = preferences.settings.first()
        if (!settings.obsidianEnabled) return@withContext
        val now = System.currentTimeMillis()
        val record = sync.get(key(type, id)) ?: ObsidianSyncRecordEntity(key(type, id), type, id)
        try {
            val relative = when (type) {
                TYPE_SHORT, TYPE_LONG -> {
                    val note = notes.getById(id)
                    if (note == null) {
                        // Memora deletion intentionally leaves the already-exported Obsidian file intact.
                        sync.delete(key(type, id))
                        return@withContext
                    }
                    syncNote(tree, note, record)
                }
                TYPE_TOPILMA -> {
                    val row = cards.getRowById(id)
                    if (row == null) {
                        // Do not delete the Obsidian copy when its Memora source is gone.
                        sync.delete(key(type, id))
                        return@withContext
                    }
                    syncTopilma(tree, row, record)
                }
                else -> return@withContext
            }
            sync.upsert(
                record.copy(
                    relativePath = relative,
                    state = "SYNCED",
                    lastSyncedAt = now,
                    lastError = null,
                    updatedAt = now
                )
            )
        } catch (t: Throwable) {
            sync.upsert(
                record.copy(
                    state = "PENDING",
                    lastError = t.message ?: t.javaClass.simpleName,
                    updatedAt = now
                )
            )
        }
    }

    private fun syncNote(tree: Uri, note: NoteEntity, record: ObsidianSyncRecordEntity): String {
        val folderName = if (note.type == NoteType.SHORT.name) "Qisqa matn" else "Uzun matn"
        val folder = folder(tree, folderName)
        val assets = folder.ensureDirectory("_assets")
        val fileName = markdownFileName(note.title.ifBlank { "Sarlavhasiz" }, note.id)
        val file = resolveOrCreateMarkdown(folder, record.relativePath, fileName, note.id)
        val blocks = NoteBlocksCodec.decode(note.blocksJson, note.plainText)
        val body = buildString {
            append("# ").append(note.title.ifBlank { "Sarlavhasiz" }).append("\n\n")
            blocks.forEach { block ->
                when (block) {
                    is NoteBlock.Text -> if (block.text.isNotBlank()) append(block.text.trimEnd()).append("\n\n")
                    is NoteBlock.Image -> {
                        val source = mediaStorage.resolve(block.relativePath)
                        if (source.exists()) {
                            val ext = extensionFor(block.mimeType, source.extension.ifBlank { "jpg" })
                            val assetName = "${note.id.take(8)}-${block.id.take(8)}.$ext"
                            writeAsset(assets, assetName, block.mimeType, source)
                            append("![[").append(assetName).append("]]\n\n")
                        }
                    }
                    is NoteBlock.Audio -> {
                        val source = mediaStorage.resolve(block.relativePath)
                        if (source.exists()) {
                            val ext = extensionFor(block.mimeType, source.extension.ifBlank { "m4a" })
                            val assetName = "${note.id.take(8)}-${block.id.take(8)}.$ext"
                            writeAsset(assets, assetName, block.mimeType, source)
                            append("![[").append(assetName).append("]]\n\n")
                        }
                    }
                }
            }
            val tags = HashtagUtils.decode(note.hashtagsJson)
            if (tags.isNotEmpty()) append(HashtagUtils.markdown(tags)).append('\n')
        }.trimEnd()
        writeManagedMarkdown(file, note.id, note.type.lowercase(), body)
        return "Memora/$folderName/${file.name}"
    }

    private fun syncTopilma(tree: Uri, row: TopilmaCardRow, record: ObsidianSyncRecordEntity): String {
        val folder = folder(tree, "Topilmalar")
        val assets = folder.ensureDirectory("_assets")
        val displayTitle = buildString {
            val author = row.sourceAuthor?.trim().orEmpty()
            if (author.isNotBlank()) append(author).append(": ")
            append(row.sourceTitle?.takeIf { it.isNotBlank() } ?: "Topilma")
        }
        val fileName = markdownFileName(displayTitle, row.id)
        val file = resolveOrCreateMarkdown(folder, record.relativePath, fileName, row.id)

        val cardAssetName = "topilma-${row.id}.png"
        val cardBitmap = TopilmaShareManager.renderCardBitmap(appContext, row)
        val cardAsset = assets.findFile(cardAssetName) ?: assets.createFile("image/png", cardAssetName)
            ?: error("Topilma kartasi uchun rasm fayli yaratilmadi")
        appContext.contentResolver.openOutputStream(cardAsset.uri, "wt")?.use { stream ->
            cardBitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, stream)
        } ?: error("Topilma kartasi yozilmadi")
        cardBitmap.recycle()

        val tags = row.tagNames()
        val body = buildString {
            append("# ").append(displayTitle).append("\n\n")
            append("![[").append(cardAssetName).append("]]\n\n")
            append("<details>\n<summary>Matn</summary>\n\n")
            append(row.text).append("\n\n</details>\n")
            if (tags.isNotEmpty()) append("\n").append(HashtagUtils.markdown(tags)).append('\n')
        }.trimEnd()
        writeManagedMarkdown(file, row.id, "topilma", body)
        return "Memora/Topilmalar/${file.name}"
    }

    private fun folder(tree: Uri, child: String): DocumentFile {
        val root = DocumentFile.fromTreeUri(appContext, tree) ?: error("Obsidian vault topilmadi")
        return root.ensureDirectory("Memora").ensureDirectory(child)
    }

    private fun resolveOrCreateMarkdown(
        folder: DocumentFile,
        storedRelativePath: String?,
        desiredName: String,
        id: String
    ): DocumentFile {
        val storedName = storedRelativePath?.substringAfterLast('/')
        var file = storedName?.let(folder::findFile)
        if (file == null) {
            val suffix = "--${id.take(8)}.md"
            file = folder.listFiles().firstOrNull { it.name?.endsWith(suffix) == true }
        }
        if (file != null && file.name != desiredName) {
            file.renameTo(desiredName)
            file = folder.findFile(desiredName) ?: file
        }
        return file ?: folder.createFile("text/markdown", desiredName)
            ?: error("Markdown fayli yaratilmadi")
    }

    private fun writeManagedMarkdown(file: DocumentFile, id: String, type: String, managedBody: String) {
        val resolver = appContext.contentResolver
        val existing = runCatching {
            resolver.openInputStream(file.uri)?.bufferedReader()?.use { it.readText() }.orEmpty()
        }.getOrDefault("")

        val frontMatter = "---\nmemora_id: \"${yaml(id)}\"\nmemora_type: \"${yaml(type)}\"\n---\n"
        val managed = "$START\n$managedBody\n$END"
        val next = if (existing.contains(START) && existing.contains(END)) {
            val start = existing.indexOf(START)
            val end = existing.indexOf(END, start) + END.length
            existing.substring(0, start) + managed + existing.substring(end)
        } else {
            buildString {
                append(frontMatter).append(managed)
                if (existing.isNotBlank()) append("\n\n").append(existing)
                else append("\n\n<!-- Bu joydan pastga Obsidian ichida qo‘shimcha yozishingiz mumkin. Memora uni saqlab qoladi. -->\n")
            }
        }
        resolver.openOutputStream(file.uri, "wt")?.bufferedWriter()?.use { it.write(next) }
            ?: error("Markdown fayliga yozib bo‘lmadi")
    }

    private fun writeAsset(folder: DocumentFile, name: String, mime: String, source: File) {
        val file = folder.findFile(name) ?: folder.createFile(mime, name) ?: return
        appContext.contentResolver.openOutputStream(file.uri, "wt")?.use { output ->
            source.inputStream().use { input -> input.copyTo(output) }
        }
    }

    private suspend fun currentTreeUri(): Uri? = preferences.settings.first().obsidianTreeUri
        ?.takeIf { it.isNotBlank() }
        ?.let { Uri.parse(it) }

    private fun DocumentFile.ensureDirectory(name: String): DocumentFile =
        findFile(name)?.takeIf { it.isDirectory }
            ?: createDirectory(name)
            ?: error("$name papkasini yaratib bo‘lmadi")

    private fun markdownFileName(title: String, id: String): String {
        val safe = title
            .replace(Regex("[\\\\/:*?\"<>|]"), "-")
            .replace(Regex("\\s+"), " ")
            .trim()
            .take(90)
            .ifBlank { "Memora" }
        return "$safe --${id.take(8)}.md"
    }

    private fun extensionFor(mime: String, fallback: String): String = when {
        mime.contains("jpeg") -> "jpg"
        mime.contains("png") -> "png"
        mime.contains("webp") -> "webp"
        mime.contains("mp4") -> "m4a"
        mime.contains("mpeg") -> "mp3"
        mime.contains("wav") -> "wav"
        else -> fallback.ifBlank { "bin" }
    }

    private fun yaml(value: String): String = value.replace("\\", "\\\\").replace("\"", "\\\"")
    private fun key(type: String, id: String) = "$type:$id"
}
