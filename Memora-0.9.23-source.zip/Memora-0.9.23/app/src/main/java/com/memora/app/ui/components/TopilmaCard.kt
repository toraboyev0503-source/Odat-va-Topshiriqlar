package com.memora.app.ui.components

import android.graphics.BitmapFactory
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ChatBubbleOutline
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memora.app.data.local.TopilmaCardRow
import com.memora.app.data.local.TopilmaSourceType
import com.memora.app.media.TopilmalarMediaStorage
import com.memora.app.ui.theme.MemoraDesign
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

fun TopilmaCardRow.tagNames(): List<String> = tagNamesCsv
    ?.split(' ')
    ?.map { it.trim().removePrefix("#") }
    ?.filter { it.isNotBlank() }
    ?.distinct()
    .orEmpty()

@OptIn(ExperimentalFoundationApi::class, ExperimentalLayoutApi::class)
@Composable
fun TopilmaCard(
    row: TopilmaCardRow,
    canEdit: Boolean,
    onShare: () -> Unit,
    onLike: () -> Unit,
    onComments: () -> Unit,
    modifier: Modifier = Modifier,
    selected: Boolean = false,
    onOpen: (() -> Unit)? = null,
    onLongPress: (() -> Unit)? = null,
    onEdit: (() -> Unit)? = null,
    onToggleFavorite: (() -> Unit)? = null,
    onToggleReview: (() -> Unit)? = null,
    onDelete: (() -> Unit)? = null,
    onOpenSource: (() -> Unit)? = null,
    forceExpanded: Boolean = false,
    showExpandControl: Boolean = true // retained for source compatibility; T-211 removes the control itself.
) {
    var expanded by remember(row.id) { mutableStateOf(forceExpanded) }
    var canExpand by remember(row.id, row.text) { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var pulseLike by remember(row.id) { mutableStateOf(false) }
    var previousLikeCount by remember(row.id) { mutableStateOf(row.likeCount) }
    LaunchedEffect(row.likeCount) {
        if (row.likeCount > previousLikeCount) {
            pulseLike = true
            delay(120)
            pulseLike = false
        }
        previousLikeCount = row.likeCount
    }
    val likeScale by animateFloatAsState(if (pulseLike) 1.15f else 1f, label = "topilmaLikePulse")
    val cardGesture = onOpen != null || onLongPress != null
    val tags = remember(row.tagNamesCsv) { row.tagNames() }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .then(
                if (cardGesture) Modifier.combinedClickable(
                    onClick = { onOpen?.invoke() },
                    onLongClick = { onLongPress?.invoke() }
                ) else Modifier
            ),
        shape = RoundedCornerShape(TopilmaCardVisualSpec.radius),
        colors = CardDefaults.cardColors(
            containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = .38f)
            else MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = MemoraDesign.shadowSubtle)
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .animateContentSize()
                .padding(
                    horizontal = TopilmaCardVisualSpec.horizontalPadding,
                    vertical = TopilmaCardVisualSpec.verticalPadding
                )
        ) {
            Row(verticalAlignment = Alignment.Top) {
                TopilmaCardCover(
                    row,
                    Modifier.size(
                        width = TopilmaCardVisualSpec.coverWidth,
                        height = TopilmaCardVisualSpec.coverHeight
                    )
                )
                Column(
                    Modifier
                        .weight(1f)
                        .padding(start = TopilmaCardVisualSpec.coverToText, top = 2.dp)
                ) {
                    Text(
                        text = row.sourceTitle ?: "Manbasi aniqlanmagan",
                        fontSize = 20.sp,
                        lineHeight = 24.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    row.sourceAuthor?.takeIf { it.isNotBlank() }?.let { author ->
                        Text(
                            text = author,
                            fontSize = 15.sp,
                            lineHeight = 19.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = .82f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(top = 3.dp)
                        )
                    }
                }
                if (onEdit != null || onToggleFavorite != null || onToggleReview != null || onDelete != null || onOpenSource != null) {
                    Box {
                        IconButton(onClick = { menuOpen = true }, modifier = Modifier.size(38.dp)) {
                            Icon(
                                Icons.Rounded.MoreHoriz,
                                contentDescription = "Ko‘proq",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = .72f)
                            )
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            onOpenSource?.let { action ->
                                DropdownMenuItem(
                                    text = { Text("Manbaga o‘tish") },
                                    leadingIcon = { Icon(Icons.Rounded.OpenInNew, null) },
                                    onClick = { menuOpen = false; action() }
                                )
                            }
                            onEdit?.let { action ->
                                DropdownMenuItem(
                                    text = { Text("Tahrirlash") },
                                    leadingIcon = { Icon(Icons.Rounded.Edit, null) },
                                    enabled = canEdit,
                                    onClick = { menuOpen = false; action() }
                                )
                            }
                            onToggleFavorite?.let { action ->
                                DropdownMenuItem(
                                    text = { Text(if (row.favorite) "Sevimlidan olib tashlash" else "Sevimli") },
                                    leadingIcon = { Icon(if (row.favorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, null) },
                                    enabled = canEdit,
                                    onClick = { menuOpen = false; action() }
                                )
                            }
                            onToggleReview?.let { action ->
                                DropdownMenuItem(
                                    text = { Text(if (row.excludedFromReview) "Qayta ko‘rishga qo‘shish" else "Qayta ko‘rsatma") },
                                    leadingIcon = { Icon(if (row.excludedFromReview) Icons.Rounded.Visibility else Icons.Rounded.VisibilityOff, null) },
                                    enabled = canEdit,
                                    onClick = { menuOpen = false; action() }
                                )
                            }
                            onDelete?.let { action ->
                                DropdownMenuItem(
                                    text = { Text("O‘chirish") },
                                    leadingIcon = { Icon(Icons.Rounded.DeleteOutline, null) },
                                    enabled = canEdit,
                                    onClick = { menuOpen = false; action() }
                                )
                            }
                        }
                    }
                }
            }

            Text(
                text = row.text.ifBlank { "Rasmli Topilma" },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = TopilmaCardVisualSpec.headerToBody)
                    .clickable(enabled = canExpand && !expanded && !forceExpanded) { expanded = true },
                fontFamily = FontFamily.Serif,
                fontSize = 20.sp,
                lineHeight = 29.sp,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = if (expanded || forceExpanded) Int.MAX_VALUE else 2,
                overflow = if (expanded || forceExpanded) TextOverflow.Clip else TextOverflow.Ellipsis,
                onTextLayout = { result ->
                    if (!expanded && !forceExpanded) canExpand = result.hasVisualOverflow
                }
            )

            if (tags.isNotEmpty()) {
                FlowRow(
                    modifier = Modifier.padding(top = TopilmaCardVisualSpec.bodyToTags),
                    horizontalArrangement = Arrangement.spacedBy(7.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    tags.forEach { tag ->
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primary.copy(alpha = .10f)
                        ) {
                            Text(
                                text = "#$tag",
                                color = MaterialTheme.colorScheme.primary,
                                style = MaterialTheme.typography.labelMedium,
                                modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp)
                            )
                        }
                    }
                }
            }

            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = if (tags.isEmpty()) TopilmaCardVisualSpec.bodyToTags else TopilmaCardVisualSpec.tagsToActions)
                    .height(TopilmaCardVisualSpec.actionHeight),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TopilmaAction(modifier = Modifier.weight(1f), onClick = onShare) {
                    Icon(Icons.Rounded.Share, contentDescription = "Ulashish", modifier = Modifier.size(25.dp))
                }
                TopilmaAction(modifier = Modifier.weight(1f), onClick = onLike, enabled = canEdit) {
                    Icon(
                        imageVector = if (row.likeCount > 0) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        contentDescription = "Like",
                        modifier = Modifier.size(27.dp).graphicsLayer(scaleX = likeScale, scaleY = likeScale),
                        tint = if (row.likeCount > 0) MaterialTheme.colorScheme.error.copy(alpha = .68f)
                        else MaterialTheme.colorScheme.onSurface
                    )
                    if (row.likeCount > 0) {
                        Text(
                            row.likeCount.toString(),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(start = 6.dp)
                        )
                    }
                }
                TopilmaAction(modifier = Modifier.weight(1f), onClick = onComments) {
                    Icon(Icons.Rounded.ChatBubbleOutline, contentDescription = "Izohlar", modifier = Modifier.size(26.dp))
                    if (row.commentCount > 0) {
                        Text(
                            row.commentCount.toString(),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(start = 6.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TopilmaAction(
    modifier: Modifier,
    onClick: () -> Unit,
    enabled: Boolean = true,
    content: @Composable RowScope.() -> Unit
) {
    Surface(
        onClick = onClick,
        enabled = enabled,
        color = androidx.compose.ui.graphics.Color.Transparent,
        modifier = modifier.fillMaxSize()
    ) {
        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
            content = content
        )
    }
}

@Composable
private fun TopilmaCardCover(row: TopilmaCardRow, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val path = row.sourceCoverPath
    val bitmap by produceState<android.graphics.Bitmap?>(null, path) {
        value = path?.let { relativePath ->
            withContext(Dispatchers.IO) {
                runCatching { decodeTopilmaCardThumbnail(TopilmalarMediaStorage(context).resolve(relativePath), 320) }.getOrNull()
            }
        }
    }
    Surface(
        shape = RoundedCornerShape(TopilmaCardVisualSpec.coverRadius),
        color = MaterialTheme.colorScheme.primary.copy(alpha = .10f),
        modifier = modifier.clip(RoundedCornerShape(TopilmaCardVisualSpec.coverRadius))
    ) {
        val current = bitmap
        if (current != null) {
            Image(current.asImageBitmap(), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    text = when (row.sourceType) {
                        TopilmaSourceType.BOOK.name -> "B"
                        TopilmaSourceType.ARTICLE_WEBSITE.name -> "A"
                        TopilmaSourceType.CHAT.name -> "C"
                        TopilmaSourceType.SOCIAL.name -> "S"
                        TopilmaSourceType.DOCUMENT.name -> "D"
                        else -> "M"
                    },
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

private fun decodeTopilmaCardThumbnail(file: File, target: Int): android.graphics.Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(file.absolutePath, bounds)
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    var sample = 1
    while (bounds.outWidth / sample > target * 2 || bounds.outHeight / sample > target * 2) sample *= 2
    return BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
}
