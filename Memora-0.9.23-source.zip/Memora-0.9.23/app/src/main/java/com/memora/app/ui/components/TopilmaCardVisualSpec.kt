package com.memora.app.ui.components

import androidx.compose.ui.unit.dp

/** Single visual source of truth for Topilma cards in-app and exported PNGs. */
object TopilmaCardVisualSpec {
    val radius = 24.dp
    val horizontalPadding = 18.dp
    val verticalPadding = 16.dp
    val coverWidth = 54.dp
    val coverHeight = 72.dp
    val coverRadius = 8.dp
    val coverToText = 14.dp
    val headerToBody = 18.dp
    val bodyToTags = 14.dp
    val tagsToActions = 16.dp
    val actionHeight = 52.dp

    const val EXPORT_WIDTH = 1080
    const val EXPORT_OUTER = 46f
    const val EXPORT_RADIUS = 42f
    const val EXPORT_INNER = 44f
    const val EXPORT_COVER_W = 106f
    const val EXPORT_COVER_H = 140f
    const val EXPORT_COVER_RADIUS = 13f
    const val EXPORT_HEADER_TO_BODY = 42f
    const val EXPORT_ACTION_HEIGHT = 118f
}
