package com.memora.app.ui.components

import androidx.compose.ui.unit.dp

/**
 * Canonical Topilma visual geometry.
 *
 * App UI and bitmap export both derive from the SAME raw dp/sp constants below.
 * Export uses a fixed 4 px-per-dp canonical canvas; there is no export-only card geometry.
 */
object TopilmaCardVisualSpec {
    const val RADIUS_DP = 24f
    const val HORIZONTAL_PADDING_DP = 18f
    const val VERTICAL_PADDING_DP = 16f

    // Approved compact book-cover frame.
    const val COVER_WIDTH_DP = 46f
    const val COVER_HEIGHT_DP = 66f
    const val COVER_RADIUS_DP = 6f
    const val COVER_BORDER_DP = 1f
    const val COVER_INSET_DP = 2f
    const val COVER_TO_TEXT_DP = 14f

    const val HEADER_TO_BODY_DP = 18f
    const val BODY_TO_TAGS_DP = 14f
    const val TAGS_TO_ACTIONS_DP = 16f
    const val ACTION_HEIGHT_DP = 52f
    const val MENU_SIZE_DP = 38f

    // Compose-facing Dp values are derived only from the constants above.
    val radius = RADIUS_DP.dp
    val horizontalPadding = HORIZONTAL_PADDING_DP.dp
    val verticalPadding = VERTICAL_PADDING_DP.dp
    val coverWidth = COVER_WIDTH_DP.dp
    val coverHeight = COVER_HEIGHT_DP.dp
    val coverRadius = COVER_RADIUS_DP.dp
    val coverBorder = COVER_BORDER_DP.dp
    val coverInset = COVER_INSET_DP.dp
    val coverToText = COVER_TO_TEXT_DP.dp
    val headerToBody = HEADER_TO_BODY_DP.dp
    val bodyToTags = BODY_TO_TAGS_DP.dp
    val tagsToActions = TAGS_TO_ACTIONS_DP.dp
    val actionHeight = ACTION_HEIGHT_DP.dp
    val menuSize = MENU_SIZE_DP.dp

    // Typography: exporter mirrors these exact sizes/line heights.
    const val TITLE_SP = 20f
    const val TITLE_LINE_SP = 24f
    const val AUTHOR_SP = 15f
    const val AUTHOR_LINE_SP = 19f
    const val AUTHOR_TOP_DP = 3f
    const val BODY_SP = 20f
    const val BODY_LINE_SP = 29f
    const val TAG_SP = 12f

    const val TAG_HORIZONTAL_DP = 9f
    const val TAG_VERTICAL_DP = 5f
    const val TAG_GAP_X_DP = 7f
    const val TAG_GAP_Y_DP = 6f

    // Controlled off-screen export.
    const val EXPORT_CANONICAL_WIDTH_DP = 360f
    const val EXPORT_SCALE = 4f
    const val EXPORT_WIDTH = 1440
    const val EXPORT_OUTER_DP = 12f

    // Opaque warm outer canvas; no alpha/black receiver edge.
    const val EXPORT_BACKGROUND_ARGB: Long = 0xFFF8F3EFL
    const val EXPORT_CARD_ARGB: Long = 0xFFFFFFFFL

    fun px(dp: Float): Float = dp * EXPORT_SCALE
    fun sp(sp: Float): Float = sp * EXPORT_SCALE
}
