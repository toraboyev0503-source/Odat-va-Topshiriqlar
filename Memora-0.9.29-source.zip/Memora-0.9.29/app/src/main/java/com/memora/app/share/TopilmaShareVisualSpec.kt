package com.memora.app.share

/**
 * Frozen landscape-only Topilma share/export template (T-256..T-262).
 *
 * IMPORTANT: this geometry is intentionally independent from the in-app feed card.
 * Android Share and Obsidian MUST both render through TopilmaShareManager using this
 * exact template. Do not derive these values from screen density, Compose constraints,
 * or the live TopilmaCard geometry.
 *
 * Canonical reference canvas: 1536 x 1199 px.
 */
object TopilmaShareVisualSpec {
    const val CANVAS_WIDTH = 1536
    const val CANVAS_HEIGHT = 1199

    // Opaque reference-like warm peach outer canvas. Never transparent.
    const val OUTER_BACKGROUND_ARGB: Long = 0xFFFDECE5L
    const val CARD_BACKGROUND_ARGB: Long = 0xFFFFFFFFL

    // Locked card frame measured from the approved reference.
    const val CARD_LEFT = 78f
    const val CARD_TOP = 84f
    const val CARD_RIGHT = 1452f
    const val CARD_BOTTOM = 1112f
    const val CARD_RADIUS = 72f

    // Header / source cover.
    const val COVER_LEFT = 145f
    const val COVER_TOP = 154f
    const val COVER_WIDTH = 138f
    const val COVER_HEIGHT = 198f
    const val COVER_RADIUS = 10f
    const val COVER_BORDER = 2f
    const val COVER_INSET = 4f

    const val TITLE_LEFT = 344f
    const val TITLE_TOP = 151f
    const val TITLE_RIGHT = 1294f
    const val TITLE_TEXT_SIZE = 58f
    const val TITLE_LINE_HEIGHT = 67f
    const val AUTHOR_TEXT_SIZE = 47f
    const val AUTHOR_LINE_HEIGHT = 55f
    const val AUTHOR_TOP_GAP = 8f

    // Horizontal three-dot menu.
    const val MENU_CENTER_X = 1342f
    const val MENU_CENTER_Y = 205f
    const val MENU_DOT_RADIUS = 6f
    const val MENU_DOT_GAP = 20f

    // Quote block. Body text is the only adaptive visual property: it shrinks only
    // when required to keep the complete quote inside the locked landscape canvas.
    const val BODY_LEFT = 146f
    const val BODY_TOP = 435f
    const val BODY_RIGHT = 1388f
    const val BODY_TEXT_SIZE = 64f
    const val BODY_MIN_TEXT_SIZE = 28f
    const val BODY_LINE_HEIGHT_MULTIPLIER = 1.28f
    const val BODY_SIZE_STEP = 2f

    // Tags live in a reserved strip above actions and never alter canvas aspect ratio.
    const val TAG_AREA_TOP = 842f
    const val TAG_AREA_BOTTOM = 910f
    const val TAG_TEXT_SIZE = 23f
    const val TAG_HORIZONTAL_PADDING = 16f
    const val TAG_VERTICAL_PADDING = 8f
    const val TAG_GAP_X = 12f
    const val TAG_GAP_Y = 8f

    // Locked three-column footer centers.
    const val ACTION_CENTER_Y = 978f
    const val SHARE_CENTER_X = 258f
    const val LIKE_CENTER_X = 768f
    const val COMMENT_CENTER_X = 1264f
    const val ICON_STROKE = 7f
    const val COUNT_TEXT_SIZE = 32f

    // Body must stop before tags/actions. With no tags it may use more vertical room.
    const val BODY_BOTTOM_WITH_TAGS = 816f
    const val BODY_BOTTOM_NO_TAGS = 858f
}
