package com.memora.app.share

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.FileProvider
import com.memora.app.data.local.TopilmaCardRow
import com.memora.app.media.TopilmalarMediaStorage
import com.memora.app.ui.components.presentation
import java.io.File
import java.io.FileOutputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Dedicated landscape Topilma share renderer.
 *
 * T-256..T-262 deliberately separate this from the live feed card. Android Share
 * and Obsidian both call [renderCardBitmap], therefore there is exactly one export
 * appearance. The canvas is always the frozen 1536x1199 landscape reference size
 * and is completely opaque.
 */
object TopilmaShareManager {
    fun shareText(context: Context, card: TopilmaCardRow, includeSource: Boolean) {
        val presentation = card.presentation()
        val text = buildString {
            append(presentation.body)
            if (includeSource && presentation.title.isNotBlank()) {
                append("\n\n— ").append(presentation.title)
                if (presentation.author.isNotBlank()) append(", ").append(presentation.author)
            }
            if (presentation.tags.isNotEmpty()) {
                append("\n\n").append(presentation.tags.joinToString(" ") { "#$it" })
            }
        }
        context.startActivity(
            Intent.createChooser(
                Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, text)
                },
                "Topilmani ulashish"
            )
        )
    }

    /** Export always renders the complete quote; list collapse state is irrelevant. */
    suspend fun shareCardImage(context: Context, card: TopilmaCardRow) {
        val uri = withContext(Dispatchers.IO) {
            val bitmap = renderCardBitmap(context, card)
            val directory = File(context.cacheDir, "shares").apply { mkdirs() }
            val file = File(directory, humanReadableShareName(card))
            FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            bitmap.recycle()
            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        }
        withContext(Dispatchers.Main) {
            context.startActivity(
                Intent.createChooser(
                    Intent(Intent.ACTION_SEND).apply {
                        type = "image/png"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    },
                    "Kartochka rasmini ulashish"
                )
            )
        }
    }

    /**
     * Frozen landscape export. Do not derive geometry from TopilmaCard/Compose.
     * This exact bitmap is also written to Obsidian.
     */
    fun renderCardBitmap(context: Context, card: TopilmaCardRow): Bitmap {
        val s = TopilmaShareVisualSpec
        val p = card.presentation()
        val bitmap = Bitmap.createBitmap(s.CANVAS_WIDTH, s.CANVAS_HEIGHT, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Opaque warm canvas: prevents black/transparent receiver edges.
        canvas.drawColor(s.OUTER_BACKGROUND_ARGB.toInt())

        // Reference card + soft shadow.
        val cardRect = RectF(s.CARD_LEFT, s.CARD_TOP, s.CARD_RIGHT, s.CARD_BOTTOM)
        val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(18, 60, 42, 34)
            setShadowLayer(24f, 0f, 12f, Color.argb(38, 70, 45, 35))
        }
        canvas.drawRoundRect(cardRect, s.CARD_RADIUS, s.CARD_RADIUS, shadowPaint)
        val cardPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = s.CARD_BACKGROUND_ARGB.toInt() }
        canvas.drawRoundRect(cardRect, s.CARD_RADIUS, s.CARD_RADIUS, cardPaint)

        drawCover(context, canvas, card)
        drawHeader(canvas, p.title, p.author)
        drawMenu(canvas)

        val bodyMaxBottom = if (p.tags.isEmpty()) s.BODY_BOTTOM_NO_TAGS else s.BODY_BOTTOM_WITH_TAGS
        val bodyWidth = (s.BODY_RIGHT - s.BODY_LEFT).toInt()
        val bodyMaxHeight = (bodyMaxBottom - s.BODY_TOP).toInt()
        val bodyLayout = fitBodyLayout(p.body, bodyWidth, bodyMaxHeight)
        canvas.save()
        canvas.translate(s.BODY_LEFT, s.BODY_TOP)
        bodyLayout.layout.draw(canvas)
        canvas.restore()

        if (p.tags.isNotEmpty()) drawTags(canvas, p.tags)
        drawActions(canvas, card)
        return bitmap
    }

    private data class FittedBody(val paint: TextPaint, val layout: StaticLayout)

    /**
     * The reference body size is preferred. Only quote text size may shrink so the
     * COMPLETE quote stays inside the fixed landscape template. Canvas/card/header/
     * footer geometry never changes and the export can never turn portrait.
     */
    private fun fitBodyLayout(text: String, width: Int, maxHeight: Int): FittedBody {
        val s = TopilmaShareVisualSpec
        var size = s.BODY_TEXT_SIZE
        while (size >= s.BODY_MIN_TEXT_SIZE) {
            val paint = bodyPaint(size)
            val layout = staticLayout(text, paint, width, size * s.BODY_LINE_HEIGHT_MULTIPLIER, Int.MAX_VALUE)
            val fitted = FittedBody(paint, layout)
            if (layout.height <= maxHeight) return fitted
            size -= s.BODY_SIZE_STEP
        }

        // Extreme quote fallback: keep shrinking only the quote body until ALL text fits.
        // Header/card/footer geometry remains frozen and the canvas never turns portrait.
        var emergencySize = s.BODY_MIN_TEXT_SIZE - 1f
        while (emergencySize >= 4f) {
            val paint = bodyPaint(emergencySize)
            val layout = staticLayout(text, paint, width, emergencySize * s.BODY_LINE_HEIGHT_MULTIPLIER, Int.MAX_VALUE)
            if (layout.height <= maxHeight) return FittedBody(paint, layout)
            emergencySize -= 1f
        }
        val paint = bodyPaint(4f)
        return FittedBody(paint, staticLayout(text, paint, width, 4f * s.BODY_LINE_HEIGHT_MULTIPLIER, Int.MAX_VALUE))
    }

    private fun bodyPaint(size: Float) = TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
        color = Color.rgb(31, 31, 30)
        textSize = size
        typeface = Typeface.create(Typeface.SERIF, Typeface.NORMAL)
    }

    private fun drawHeader(canvas: Canvas, title: String, author: String) {
        val s = TopilmaShareVisualSpec
        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            color = Color.rgb(31, 31, 31)
            textSize = s.TITLE_TEXT_SIZE
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        val authorPaint = TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            color = Color.rgb(111, 111, 111)
            textSize = s.AUTHOR_TEXT_SIZE
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        }
        val headerWidth = (s.TITLE_RIGHT - s.TITLE_LEFT).toInt()
        val titleLayout = staticLayout(title, titlePaint, headerWidth, s.TITLE_LINE_HEIGHT, 2)
        canvas.save()
        canvas.translate(s.TITLE_LEFT, s.TITLE_TOP)
        titleLayout.draw(canvas)
        canvas.restore()

        if (author.isNotBlank()) {
            val authorLayout = staticLayout(author, authorPaint, headerWidth, s.AUTHOR_LINE_HEIGHT, 1)
            canvas.save()
            canvas.translate(s.TITLE_LEFT, s.TITLE_TOP + titleLayout.height + s.AUTHOR_TOP_GAP)
            authorLayout.draw(canvas)
            canvas.restore()
        }
    }

    private fun drawMenu(canvas: Canvas) {
        val s = TopilmaShareVisualSpec
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(108, 108, 108) }
        canvas.drawCircle(s.MENU_CENTER_X - s.MENU_DOT_GAP, s.MENU_CENTER_Y, s.MENU_DOT_RADIUS, paint)
        canvas.drawCircle(s.MENU_CENTER_X, s.MENU_CENTER_Y, s.MENU_DOT_RADIUS, paint)
        canvas.drawCircle(s.MENU_CENTER_X + s.MENU_DOT_GAP, s.MENU_CENTER_Y, s.MENU_DOT_RADIUS, paint)
    }

    private fun staticLayout(
        text: String,
        paint: TextPaint,
        width: Int,
        lineHeight: Float,
        maxLines: Int
    ): StaticLayout {
        val natural = paint.fontMetrics.let { it.descent - it.ascent }
        val builder = StaticLayout.Builder.obtain(text, 0, text.length, paint, width)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setIncludePad(false)
            .setLineSpacing(lineHeight - natural, 1f)
            .setMaxLines(maxLines)
        if (maxLines != Int.MAX_VALUE) builder.setEllipsize(android.text.TextUtils.TruncateAt.END)
        return builder.build()
    }

    private fun drawCover(context: Context, canvas: Canvas, card: TopilmaCardRow) {
        val s = TopilmaShareVisualSpec
        val rect = RectF(s.COVER_LEFT, s.COVER_TOP, s.COVER_LEFT + s.COVER_WIDTH, s.COVER_TOP + s.COVER_HEIGHT)
        val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            setShadowLayer(7f, 0f, 3f, Color.argb(36, 0, 0, 0))
        }
        canvas.drawRoundRect(rect, s.COVER_RADIUS, s.COVER_RADIUS, shadow)
        val frame = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
        canvas.drawRoundRect(rect, s.COVER_RADIUS, s.COVER_RADIUS, frame)
        val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(220, 220, 220)
            style = Paint.Style.STROKE
            strokeWidth = s.COVER_BORDER
        }
        canvas.drawRoundRect(rect, s.COVER_RADIUS, s.COVER_RADIUS, border)

        val thumbnail = card.sourceCoverPath?.let { relativePath ->
            runCatching { decodeThumbnail(TopilmalarMediaStorage(context).resolve(relativePath), 640) }.getOrNull()
        }
        val available = RectF(
            rect.left + s.COVER_INSET,
            rect.top + s.COVER_INSET,
            rect.right - s.COVER_INSET,
            rect.bottom - s.COVER_INSET
        )
        if (thumbnail != null) {
            // Fit, never crop or stretch: preserves the original book-cover ratio.
            val scale = minOf(available.width() / thumbnail.width, available.height() / thumbnail.height)
            val drawW = thumbnail.width * scale
            val drawH = thumbnail.height * scale
            val dst = RectF(
                available.centerX() - drawW / 2f,
                available.centerY() - drawH / 2f,
                available.centerX() + drawW / 2f,
                available.centerY() + drawH / 2f
            )
            canvas.save()
            val clip = Path().apply {
                addRoundRect(available, s.COVER_RADIUS - s.COVER_INSET, s.COVER_RADIUS - s.COVER_INSET, Path.Direction.CW)
            }
            canvas.clipPath(clip)
            canvas.drawBitmap(thumbnail, null, dst, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
            canvas.restore()
            thumbnail.recycle()
        } else {
            val fallback = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(241, 243, 241) }
            canvas.drawRoundRect(available, s.COVER_RADIUS - s.COVER_INSET, s.COVER_RADIUS - s.COVER_INSET, fallback)
            val letter = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(78, 99, 89)
                textSize = 52f
                typeface = Typeface.DEFAULT_BOLD
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("M", available.centerX(), available.centerY() - (letter.fontMetrics.ascent + letter.fontMetrics.descent) / 2f, letter)
        }
    }

    private fun drawTags(canvas: Canvas, tags: List<String>) {
        val s = TopilmaShareVisualSpec
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            color = Color.rgb(89, 102, 157)
            textSize = s.TAG_TEXT_SIZE
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        val chipPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(244, 243, 250) }
        val chipHeight = s.TAG_TEXT_SIZE + s.TAG_VERTICAL_PADDING * 2f + 8f
        var x = s.BODY_LEFT
        var y = s.TAG_AREA_TOP
        val maxX = s.BODY_RIGHT
        for (tag in tags) {
            val label = "#$tag"
            val w = textPaint.measureText(label) + s.TAG_HORIZONTAL_PADDING * 2f
            if (x > s.BODY_LEFT && x + w > maxX) {
                x = s.BODY_LEFT
                y += chipHeight + s.TAG_GAP_Y
            }
            if (y + chipHeight > s.TAG_AREA_BOTTOM) break
            canvas.drawRoundRect(x, y, x + w, y + chipHeight, chipHeight / 2f, chipHeight / 2f, chipPaint)
            val fm = textPaint.fontMetrics
            val baseline = y + chipHeight / 2f - (fm.ascent + fm.descent) / 2f
            canvas.drawText(label, x + s.TAG_HORIZONTAL_PADDING, baseline, textPaint)
            x += w + s.TAG_GAP_X
        }
    }

    private fun drawActions(canvas: Canvas, card: TopilmaCardRow) {
        val s = TopilmaShareVisualSpec
        val iconColor = Color.rgb(38, 39, 38)
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = iconColor
            style = Paint.Style.STROKE
            strokeWidth = s.ICON_STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        val countPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            color = Color.rgb(91, 92, 91)
            textSize = s.COUNT_TEXT_SIZE
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        }

        drawReferenceShareIcon(canvas, s.SHARE_CENTER_X, s.ACTION_CENTER_Y, stroke)
        drawHeart(canvas, s.LIKE_CENTER_X, s.ACTION_CENTER_Y, stroke, card.likeCount > 0)
        drawReferenceThoughtIcon(canvas, s.COMMENT_CENTER_X, s.ACTION_CENTER_Y, stroke)

        if (card.likeCount > 0) {
            canvas.drawText(card.likeCount.toString(), s.LIKE_CENTER_X + 60f, s.ACTION_CENTER_Y + 12f, countPaint)
        }
        if (card.commentCount > 0) {
            canvas.drawText(card.commentCount.toString(), s.COMMENT_CENTER_X + 58f, s.ACTION_CENTER_Y + 12f, countPaint)
        }
    }

    /** Square-up-arrow icon matching the approved reference family. */
    private fun drawReferenceShareIcon(canvas: Canvas, cx: Float, cy: Float, stroke: Paint) {
        val boxLeft = cx - 39f
        val boxRight = cx + 39f
        val boxTop = cy - 4f
        val boxBottom = cy + 55f
        val path = Path().apply {
            moveTo(boxLeft, boxTop + 18f)
            lineTo(boxLeft, boxBottom)
            lineTo(boxRight, boxBottom)
            lineTo(boxRight, boxTop + 18f)
            moveTo(cx, cy + 10f)
            lineTo(cx, cy - 58f)
            moveTo(cx, cy - 58f)
            lineTo(cx - 25f, cy - 31f)
            moveTo(cx, cy - 58f)
            lineTo(cx + 25f, cy - 31f)
        }
        canvas.drawPath(path, stroke)
    }

    private fun drawHeart(canvas: Canvas, cx: Float, cy: Float, stroke: Paint, filled: Boolean) {
        val path = Path().apply {
            moveTo(cx, cy + 52f)
            cubicTo(cx - 78f, cy + 3f, cx - 71f, cy - 58f, cx - 33f, cy - 59f)
            cubicTo(cx - 12f, cy - 60f, cx, cy - 42f, cx, cy - 27f)
            cubicTo(cx, cy - 42f, cx + 12f, cy - 60f, cx + 33f, cy - 59f)
            cubicTo(cx + 71f, cy - 58f, cx + 78f, cy + 3f, cx, cy + 52f)
            close()
        }
        if (filled) {
            canvas.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(222, 104, 113); style = Paint.Style.FILL })
        } else {
            canvas.drawPath(path, stroke)
        }
    }

    /** Notebook/pencil glyph from the approved visual reference; it represents the comment/thought action. */
    private fun drawReferenceThoughtIcon(canvas: Canvas, cx: Float, cy: Float, stroke: Paint) {
        val page = RectF(cx - 42f, cy - 51f, cx + 34f, cy + 43f)
        canvas.drawRoundRect(page, 12f, 12f, stroke)

        // Four small binding tabs along the top edge.
        listOf(-27f, -9f, 9f, 27f).forEach { dx ->
            canvas.drawLineCompat(cx + dx, cy - 60f, cx + dx, cy - 42f, stroke)
        }

        // Two subtle writing lines.
        canvas.drawLineCompat(cx - 24f, cy - 15f, cx + 12f, cy - 15f, stroke)
        canvas.drawLineCompat(cx - 24f, cy + 5f, cx + 5f, cy + 5f, stroke)

        // Diagonal pencil at the lower-right corner.
        val pencil = Path().apply {
            moveTo(cx + 5f, cy + 42f)
            lineTo(cx + 47f, cy + 1f)
            lineTo(cx + 58f, cy + 12f)
            lineTo(cx + 16f, cy + 53f)
            close()
        }
        canvas.drawPath(pencil, stroke)
    }

    private fun Canvas.drawLineCompat(x1: Float, y1: Float, x2: Float, y2: Float, paint: Paint) {
        val line = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        drawPath(line, paint)
    }

    private fun humanReadableShareName(card: TopilmaCardRow): String {
        val p = card.presentation()
        val raw = buildString {
            append("Topilma - ").append(p.title)
            if (p.author.isNotBlank()) append(" - ").append(p.author)
        }
        val safe = raw.replace(Regex("[\\/:*?\"<>|]"), "-").replace(Regex("\\s+"), " ").trim().take(110)
        return "$safe.png"
    }

    private fun decodeThumbnail(file: File, target: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (bounds.outWidth / sample > target * 2 || bounds.outHeight / sample > target * 2) sample *= 2
        return BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
    }
}
