# HabitCore 0.8.1

Large UI/theme/navigation release built on the 0.7.0 data-safe project.

## Main navigation

The left drawer is removed from the running app. The four main areas are always reachable from the bottom navigation:

- Habits
- Tasks
- Monitoring
- Profile

Android system Back returns from helper screens to their parent screen, and from Tasks / Monitoring / Profile to Habits. Back from the Habits root exits normally.

## Profile

Profile is now the control center and stores locally:

- Name
- Birth day / month / year
- Calculated age
- Birthday greeting toggle

Profile also links to Theme, Language, Notifications, Reports/Monitoring, Scheduled tasks, Archive, Settings and About.

Birthday greeting is scheduled for 09:00 local time and can be disabled. It is rescheduled after reboot with the rest of the notification system.

## Task scoring contract

A task contributes only to the day it is explicitly planned for.

- A future/today task moved before its old date has passed: the old plan is removed and the new date becomes the plan.
- An overdue task rescheduled after its old day has passed: the old day remains an unfinished historical result and the new date is a new plan.
- Overdue tasks are visible in a separate `Overdue` section on today's Tasks screen, but they do not affect today's percentage.
- Completing an overdue task today records the actual completion time for archive/day-detail, but does not create a new plan for today.
- Completing a task on time/early credits only its scheduled plan.

Room database is version 6. Migration 5 -> 6 removes only old synthetic forward carry-over rows for still-open tasks. Explicit historical commitments are preserved.

## 10 full visual families

1. Minimal Premium
2. Dark Glass
3. Productivity Pro
4. Organic Calm
5. Neo Brutalist
6. Futuristic Depth
7. Editorial Mono
8. Scandinavian Soft
9. Dark Gold Luxe
10. Modern Universal (default)

Each family has 4 coordinated accent palettes. The family controls background/surface system, dark/light character, typography, corner radius, border weight, density and low-cost decorative backdrop. Helper screens inherit the selected family's Material colors, typography, shapes and borders.

## Dynamic icon + splash

Each theme has its own launcher icon based on the user-provided artwork and a matching splash treatment. Assets are safe-zone inset so Android adaptive masks do not crop the important mark.

Theme-to-icon mapping:

- Minimal Premium -> 16_53_11 artwork
- Dark Glass -> 16_53_18 artwork
- Productivity Pro -> 16_53_21 artwork
- Organic Calm -> 16_53_24 artwork
- Neo Brutalist -> 16_53_29 artwork
- Futuristic Depth -> 16_53_31 artwork
- Editorial Mono -> 16_53_33 artwork
- Scandinavian Soft -> 16_53_36 artwork
- Dark Gold Luxe -> 16_53_40 artwork
- Modern Universal -> 16_53_43 artwork

The selected theme enables the corresponding launcher component. Android launchers can take a short moment to refresh the icon after a theme change; this is platform/launcher behavior. On the next cold launch, the matching launcher activity provides the matching splash background and icon.

## Performance work

- Removed the old day-by-day carry-over plan generator.
- Task list uses only explicit plan rows.
- Habit drag/reorder keeps stable keys/content types and persists ordering once when drag ends.
- Drag lookup uses an indexed map rather than scanning the list on each pointer frame.
- Main lists use LazyColumn with stable keys/content types.
- Theme decorative visuals are lightweight Canvas/vector operations rather than large live background bitmaps.
- Launcher/splash source artwork is downscaled into optimized runtime assets.

## Existing data safety

- Habit soft-delete/history behavior from 0.7.0 remains.
- No destructive Room migration is used.
- Existing signing key is unchanged, so 0.7.0 -> 0.8.0 is intended as an in-place update.
- Existing preferences are migrated to the nearest new theme family when old theme codes are found.

## GitHub build

Upload `HabitCore_0.8.1_SOURCE.zip` to the repository root and replace `.github/workflows/main.yml` with `main_0.8.0.yml`.

Artifact name: `HabitCore-0.8.1-debug-apk`


## 0.8.1 build fix

- Fixed the drag auto-scroll coroutine compile error in `HabitsScreen.kt`.
- The drag list now owns a `rememberCoroutineScope()` and uses it for `LazyListState.scrollBy(...)`.
- No Room schema change; database version and all user data remain compatible with 0.8.0.
- Signing key is unchanged, so install as a normal update.

## 0.8.2 compile patch

- Fixed `HabitsScreen.kt` drag auto-scroll compile failure by importing
  `kotlinx.coroutines.launch`.
- `rememberCoroutineScope()` now correctly launches the suspend
  `LazyListState.scrollBy(...)` call inside a coroutine.
- No Room schema change.
- No destructive migration.
- Existing signing key retained.
- Existing user data remains compatible with the 0.8.x line.
