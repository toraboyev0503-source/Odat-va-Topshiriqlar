# HabitCore 0.4.2

## Changes

### Habits
- "Habits" top title is replaced by a direction selector.
- Add unlimited directions with the `+` control.
- Each direction has its own habits and its own monitoring.
- Existing habits are migrated safely to the `General` direction.
- Last five days are shown in the requested order: today → yesterday → older.
- Manual habit order now works: tap a habit, then use ↑ / ↓.
- Name / color / score sorting remains available.
- Result notifications show every habit direction in one notification.

### Tasks
- Completed tasks can be returned to unfinished state.
- Priority has four visual states:
  - none = neutral circle
  - very important = red
  - important = orange
  - later = yellow
- Priority order: red → orange → yellow → none; then date/time.
- Reopening a completed task also updates its daily task score.

## Data-safe update system

Database version: 4.

`fallbackToDestructiveMigration()` has been removed.

The 3 → 4 Room migration:
- creates the directions table,
- keeps every existing habit, habit result, task and monitoring record,
- assigns old habits to `General`,
- adds the new `categoryId` without deleting the database.

Future database changes must be implemented as explicit Room migrations.

## Test signing

Starting with 0.4.0, debug APKs are signed with the same bundled TEST key:
`app/signing/habitcore-test.keystore`

This is only for pilot/testing builds, not for Play Store release signing.

Because builds before 0.4.0 used the runner's default debug key, Android may reject the first
0.4.0 install as a signature mismatch. Do not uninstall first if that happens.

Safety tools are included:
- `tools/backup-current-data.bat`
- `tools/restore-data.bat`

They use ADB + `run-as` and are intended only for these debuggable pilot APKs.

From 0.4.0 onward, keep the same test keystore in every source build so normal Android update
installation preserves app data.

## GitHub ZIP workflow

Put `HabitCore_0.4.0_SOURCE.zip` in the repository root.
Put `main.yml` at `.github/workflows/main.yml`.

Artifact:
`HabitCore-0.4.0-debug-apk`

## 0.4.1

- Added habit editing.
- Tap a habit to open its actions, then choose Edit.
- Editable fields: name, habit type, question, frequency, target/unit, color, notes.
- Habit history, ID, created date, archive/pause state, manual order and category are preserved.
- Database schema stays at version 4, so no migration is required for 0.4.0 -> 0.4.1.
- The same bundled test signing key is retained, enabling a normal update install over 0.4.0.

## 0.4.2

- Habits marked DONE or FAILED for the current day are hidden from the main habit list by default.
- They automatically reappear the next day because hiding is based only on today's entry.
- History, daily score, direction monitoring and notifications still include the hidden habits.
- A compact visibility icon appears only when there are hidden habits today.
- Tapping that icon temporarily shows today's hidden habits, so an accidental DONE/FAILED mark can still be corrected.
- Measurable partial results (for example 70%) stay visible until they become DONE or FAILED.
- Database schema remains version 4. No migration is needed from 0.4.1 to 0.4.2.
- The same test signing key is retained, so normal update installation preserves app data.
