package com.habitcore.app.data

class HabitRepository(private val dao: HabitDao) {
    val habits = dao.observeHabits()
    val entries = dao.observeEntries()
    val categories = dao.observeCategories()

    suspend fun addHabit(habit: HabitEntity) = dao.insertHabit(habit)
    suspend fun updateHabit(habit: HabitEntity) = dao.updateHabit(habit)
    suspend fun addCategory(name: String): Long {
        val nextOrder = dao.getCategoriesOnce().size
        return dao.insertCategory(
            HabitCategoryEntity(
                name = name.trim(),
                sortOrder = nextOrder
            )
        )
    }

    suspend fun moveHabit(habitId: Long, categoryId: Long, direction: Int) {
        val list = dao.getActiveHabitsForCategory(categoryId)
        if (list.isEmpty()) return

        // Normalize legacy 0 sortOrder values first.
        list.forEachIndexed { index, habit ->
            if (habit.sortOrder != index) dao.updateSortOrder(habit.id, index)
        }

        val currentIndex = list.indexOfFirst { it.id == habitId }
        if (currentIndex < 0) return
        val targetIndex = (currentIndex + direction).coerceIn(0, list.lastIndex)
        if (targetIndex == currentIndex) return

        val current = list[currentIndex]
        val target = list[targetIndex]
        dao.updateSortOrder(current.id, targetIndex)
        dao.updateSortOrder(target.id, currentIndex)
    }

    suspend fun saveEntry(entry: HabitEntryEntity) = dao.saveEntry(entry)
    suspend fun clearEntry(habitId: Long, epochDay: Long) = dao.deleteEntry(habitId, epochDay)
    suspend fun archiveHabit(habitId: Long, epochDay: Long) = dao.archiveHabit(habitId, epochDay)
    suspend fun restoreHabit(habitId: Long) = dao.restoreHabit(habitId)
    suspend fun setPaused(habitId: Long, paused: Boolean, sinceEpochDay: Long?) =
        dao.setPaused(habitId, paused, sinceEpochDay)
}
