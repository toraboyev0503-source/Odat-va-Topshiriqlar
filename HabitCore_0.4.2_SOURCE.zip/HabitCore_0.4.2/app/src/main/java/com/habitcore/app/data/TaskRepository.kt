package com.habitcore.app.data

import java.time.LocalDate

class TaskRepository(private val dao: TaskDao) {
    val tasks = dao.observeTasks()
    val plans = dao.observePlans()

    suspend fun addTask(
        text: String,
        priority: Int,
        scheduledEpochDay: Long,
        colorSlot: Int
    ) {
        val id = dao.insertTask(
            TaskEntity(
                text = text,
                priority = priority.coerceIn(0, 3),
                scheduledEpochDay = scheduledEpochDay,
                colorSlot = colorSlot
            )
        )
        dao.insertPlan(TaskPlanEntity(taskId = id, epochDay = scheduledEpochDay))
    }

    suspend fun updateText(taskId: Long, text: String) {
        dao.updateText(taskId, text)
    }

    suspend fun updatePriority(taskId: Long, priority: Int) {
        dao.updatePriority(taskId, priority.coerceIn(0, 3))
    }

    suspend fun reschedule(task: TaskEntity, newEpochDay: Long) {
        if (newEpochDay == task.scheduledEpochDay) return
        dao.updateScheduledDay(task.id, newEpochDay)

        // Old date remains an unfinished historical commitment.
        dao.insertPlan(TaskPlanEntity(taskId = task.id, epochDay = newEpochDay))
    }

    suspend fun complete(task: TaskEntity) {
        if (task.completed) return

        val today = LocalDate.now().toEpochDay()
        val creditDay = if (task.scheduledEpochDay < today) today else task.scheduledEpochDay

        if (creditDay != task.scheduledEpochDay) {
            dao.updateScheduledDay(task.id, creditDay)
            dao.insertPlan(TaskPlanEntity(taskId = task.id, epochDay = creditDay))
        }

        dao.upsertPlan(
            TaskPlanEntity(
                taskId = task.id,
                epochDay = creditDay,
                completed = true
            )
        )
        dao.completeTask(task.id, System.currentTimeMillis())
    }

    suspend fun reopen(task: TaskEntity) {
        if (!task.completed) return
        dao.upsertPlan(
            TaskPlanEntity(
                taskId = task.id,
                epochDay = task.scheduledEpochDay,
                completed = false
            )
        )
        dao.reopenTask(task.id)
    }

    suspend fun toggleCompletion(task: TaskEntity) {
        if (task.completed) reopen(task) else complete(task)
    }

    suspend fun delete(taskId: Long) {
        dao.deletePlansForTask(taskId)
        dao.deleteTask(taskId)
    }
}
