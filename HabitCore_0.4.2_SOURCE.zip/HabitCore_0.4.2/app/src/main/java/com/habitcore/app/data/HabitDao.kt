package com.habitcore.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface HabitDao {
    @Query("SELECT * FROM habits ORDER BY sortOrder ASC, id ASC")
    fun observeHabits(): Flow<List<HabitEntity>>

    @Query("SELECT * FROM habit_entries ORDER BY epochDay ASC")
    fun observeEntries(): Flow<List<HabitEntryEntity>>

    @Query("SELECT * FROM habit_categories ORDER BY sortOrder ASC, id ASC")
    fun observeCategories(): Flow<List<HabitCategoryEntity>>

    @Insert
    suspend fun insertHabit(habit: HabitEntity): Long

    @Update
    suspend fun updateHabit(habit: HabitEntity)

    @Insert
    suspend fun insertCategory(category: HabitCategoryEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveEntry(entry: HabitEntryEntity)

    @Query("DELETE FROM habit_entries WHERE habitId = :habitId AND epochDay = :epochDay")
    suspend fun deleteEntry(habitId: Long, epochDay: Long)

    @Query("UPDATE habits SET archivedEpochDay = :epochDay WHERE id = :habitId")
    suspend fun archiveHabit(habitId: Long, epochDay: Long)

    @Query("UPDATE habits SET archivedEpochDay = NULL WHERE id = :habitId")
    suspend fun restoreHabit(habitId: Long)

    @Query("UPDATE habits SET paused = :paused, pausedSinceEpochDay = :sinceEpochDay WHERE id = :habitId")
    suspend fun setPaused(habitId: Long, paused: Boolean, sinceEpochDay: Long?)

    @Query("UPDATE habits SET sortOrder = :sortOrder WHERE id = :habitId")
    suspend fun updateSortOrder(habitId: Long, sortOrder: Int)

    @Query("""
        SELECT * FROM habits
        WHERE categoryId = :categoryId AND archivedEpochDay IS NULL
        ORDER BY sortOrder ASC, id ASC
    """)
    suspend fun getActiveHabitsForCategory(categoryId: Long): List<HabitEntity>

    @Query("SELECT * FROM habits ORDER BY id ASC")
    suspend fun getAllHabitsOnce(): List<HabitEntity>

    @Query("SELECT * FROM habit_categories ORDER BY sortOrder ASC, id ASC")
    suspend fun getCategoriesOnce(): List<HabitCategoryEntity>

    @Query("SELECT * FROM habit_entries WHERE epochDay BETWEEN :startEpochDay AND :endEpochDay ORDER BY epochDay ASC")
    suspend fun getEntriesBetween(startEpochDay: Long, endEpochDay: Long): List<HabitEntryEntity>
}
