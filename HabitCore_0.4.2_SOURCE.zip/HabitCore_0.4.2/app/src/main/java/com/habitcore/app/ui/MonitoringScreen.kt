@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.habitcore.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.ChevronLeft
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.habitcore.app.domain.Schedule
import com.habitcore.app.domain.ScoreCalculator
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.TextStyle
import java.time.temporal.TemporalAdjusters
import java.util.Locale

private enum class MonitorMode { WEEK, MONTH }

@Composable
fun MonitoringScreen(vm: AppViewModel, categoryId: Long, onBack: () -> Unit) {
    val allHabits by vm.habits.collectAsState()
    val categories by vm.categories.collectAsState()
    val entries by vm.entries.collectAsState()
    val prefs by vm.prefs.collectAsState()
    val habits = allHabits.filter { it.categoryId == categoryId }
    val category = categories.firstOrNull { it.id == categoryId }
    val lang = prefs.language
    val today = LocalDate.now()
    var mode by remember { mutableStateOf(MonitorMode.MONTH) }
    var month by remember { mutableStateOf(YearMonth.from(today)) }
    var weekStart by remember { mutableStateOf(today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(category?.name ?: tr(lang, "monitoring")) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Outlined.ArrowBack, null) } }
            )
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 12.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                TextButton(onClick = { mode = MonitorMode.WEEK }) { Text(tr(lang, "week"), fontWeight = if (mode == MonitorMode.WEEK) FontWeight.Bold else FontWeight.Normal) }
                TextButton(onClick = { mode = MonitorMode.MONTH }) { Text(tr(lang, "month"), fontWeight = if (mode == MonitorMode.MONTH) FontWeight.Bold else FontWeight.Normal) }
            }
            if (mode == MonitorMode.MONTH) {
                MonthMonitor(month, today, habits, entries, onPrevious = { month = month.minusMonths(1) }, onNext = { month = month.plusMonths(1) })
            } else {
                WeekMonitor(weekStart, today, habits, entries, onPrevious = { weekStart = weekStart.minusWeeks(1) }, onNext = { weekStart = weekStart.plusWeeks(1) })
            }
        }
    }
}

@Composable
private fun MonthMonitor(
    month: YearMonth,
    today: LocalDate,
    habits: List<com.habitcore.app.data.HabitEntity>,
    entries: List<com.habitcore.app.data.HabitEntryEntity>,
    onPrevious: () -> Unit,
    onNext: () -> Unit
) {
    val days = (1..month.lengthOfMonth()).map { month.atDay(it) }
    val relevant = days.filter { !it.isAfter(today) }
    val scores = relevant.map { Schedule.dailyScore(it, habits, entries) }
    val monthScore = ScoreCalculator.percent(ScoreCalculator.periodScore(scores))
    val isCurrent = month == YearMonth.from(today)
    val headerColor = if (isCurrent) Color(0xFFD39B2D) else if (monthScore >= 90) Color(0xFF39865A) else Color(0xFF3E72B8)

    PeriodHeader(
        title = "${month.month.getDisplayName(TextStyle.FULL, Locale.getDefault())} ${month.year}",
        percent = monthScore,
        color = headerColor,
        onPrevious = onPrevious,
        onNext = onNext
    )

    Row(Modifier.fillMaxWidth().padding(top = 8.dp)) {
        DayOfWeek.values().forEach { dow ->
            Text(dow.getDisplayName(TextStyle.SHORT, Locale.getDefault()).take(2), modifier = Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }

    val firstOffset = month.atDay(1).dayOfWeek.value - 1
    val cells = MutableList<LocalDate?>(firstOffset) { null } + days
    cells.chunked(7).forEach { week ->
        Row(Modifier.fillMaxWidth()) {
            (week + List(7 - week.size) { null }).forEach { day ->
                Box(Modifier.weight(1f).padding(2.dp)) {
                    if (day != null) DayScoreCard(day, today, Schedule.dailyScore(day, habits, entries))
                    else Spacer(Modifier.height(66.dp))
                }
            }
        }
    }
}

@Composable
private fun WeekMonitor(
    start: LocalDate,
    today: LocalDate,
    habits: List<com.habitcore.app.data.HabitEntity>,
    entries: List<com.habitcore.app.data.HabitEntryEntity>,
    onPrevious: () -> Unit,
    onNext: () -> Unit
) {
    val days = (0..6).map { start.plusDays(it.toLong()) }
    val valid = days.filter { !it.isAfter(today) }
    val score = ScoreCalculator.percent(ScoreCalculator.periodScore(valid.map { Schedule.dailyScore(it, habits, entries) }))
    val currentWeekStart = today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
    val headerColor = if (start == currentWeekStart) Color(0xFFD39B2D) else if (score >= 90) Color(0xFF39865A) else Color(0xFF3E72B8)
    PeriodHeader("${start.dayOfMonth} ${start.month.getDisplayName(TextStyle.SHORT, Locale.getDefault())} – ${start.plusDays(6).dayOfMonth} ${start.plusDays(6).month.getDisplayName(TextStyle.SHORT, Locale.getDefault())}", score, headerColor, onPrevious, onNext)
    Spacer(Modifier.height(12.dp))
    days.forEach { day ->
        Card(
            modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            shape = RoundedCornerShape(4.dp)
        ) {
            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${day.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.getDefault())} ${day.dayOfMonth}", modifier = Modifier.weight(1f))
                val dScore = if (day.isAfter(today)) null else Schedule.dailyScore(day, habits, entries)
                if (dScore != null) {
                    val percent = ScoreCalculator.percent(dScore)
                    Text("$percent%", color = scoreColor(percent), fontWeight = FontWeight.SemiBold)
                } else Text("—", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun PeriodHeader(title: String, percent: Int, color: Color, onPrevious: () -> Unit, onNext: () -> Unit) {
    Row(Modifier.fillMaxWidth().height(56.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onPrevious) { Icon(Icons.Outlined.ChevronLeft, null) }
        Text(title, modifier = Modifier.weight(1f), textAlign = TextAlign.Center, fontWeight = FontWeight.Medium)
        Text("$percent%", color = color, fontWeight = FontWeight.Bold, modifier = Modifier.width(54.dp), textAlign = TextAlign.Center)
        IconButton(onClick = onNext) { Icon(Icons.Outlined.ChevronRight, null) }
    }
}

@Composable
private fun DayScoreCard(day: LocalDate, today: LocalDate, score: Double?) {
    val percent = if (day.isAfter(today) || score == null) null else ScoreCalculator.percent(score)
    Card(
        modifier = Modifier.fillMaxWidth().height(66.dp),
        border = BorderStroke(1.dp, if (day == today) Color(0xFFD39B2D) else MaterialTheme.colorScheme.outlineVariant),
        shape = RoundedCornerShape(3.dp)
    ) {
        Column(Modifier.fillMaxSize().padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(day.dayOfMonth.toString(), fontSize = 12.sp)
            if (percent != null) Text("$percent%", fontSize = 10.sp, color = scoreColor(percent), fontWeight = FontWeight.SemiBold)
            else Text("—", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private fun scoreColor(percent: Int): Color = when (percent) {
    in 0..49 -> Color(0xFFC83D3D)
    in 50..74 -> Color(0xFFD39B2D)
    in 75..89 -> Color(0xFF3E72B8)
    else -> Color(0xFF39865A)
}
