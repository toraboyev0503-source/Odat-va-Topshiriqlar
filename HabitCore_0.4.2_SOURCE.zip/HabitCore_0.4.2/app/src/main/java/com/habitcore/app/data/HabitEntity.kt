package com.habitcore.app.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "habits")
data class HabitEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val type: String,
    val colorArgb: Long,
    val question: String = "",
    val notes: String = "",
    val unit: String? = null,
    val target: Double = 1.0,
    val frequencyType: String = "DAILY",
    val frequencyValue: Int = 1,
    val frequencyWindowDays: Int = 1,
    val createdEpochDay: Long,
    val archivedEpochDay: Long? = null,
    val paused: Boolean = false,
    val pausedSinceEpochDay: Long? = null,
    val reminderEnabled: Boolean = false,
    val reminderHour: Int? = null,
    val reminderMinute: Int? = null,
    val sortOrder: Int = 0,
    @ColumnInfo(defaultValue = "1")
    val categoryId: Long = 1
)
