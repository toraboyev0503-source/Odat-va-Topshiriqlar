package com.habitcore.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface TaskDao {
    @Query("""
        SELECT * FROM tasks
        ORDER BY
          CASE priority
            WHEN 1 THEN 0
            WHEN 2 THEN 1
            WHEN 3 THEN 2
            ELSE 3
          END ASC,
          scheduledEpochDay ASC,
          createdAtMillis ASC
    """)
    fun observeTasks(): Flow<List<TaskEntity>>

    @Query("SELECT * FROM task_plans ORDER BY epochDay ASC")
    fun observePlans(): Flow<List<TaskPlanEntity>>

    @Insert
    suspend fun insertTask(task: TaskEntity): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertPlan(plan: TaskPlanEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPlan(plan: TaskPlanEntity)

    @Query("UPDATE tasks SET text = :text WHERE id = :taskId")
    suspend fun updateText(taskId: Long, text: String)

    @Query("UPDATE tasks SET priority = :priority WHERE id = :taskId")
    suspend fun updatePriority(taskId: Long, priority: Int)

    @Query("UPDATE tasks SET scheduledEpochDay = :epochDay WHERE id = :taskId")
    suspend fun updateScheduledDay(taskId: Long, epochDay: Long)

    @Query("UPDATE tasks SET completed = 1, completedAtMillis = :completedAt WHERE id = :taskId")
    suspend fun completeTask(taskId: Long, completedAt: Long)

    @Query("UPDATE tasks SET completed = 0, completedAtMillis = NULL WHERE id = :taskId")
    suspend fun reopenTask(taskId: Long)

    @Query("DELETE FROM tasks WHERE id = :taskId")
    suspend fun deleteTask(taskId: Long)

    @Query("DELETE FROM task_plans WHERE taskId = :taskId")
    suspend fun deletePlansForTask(taskId: Long)

    @Query("SELECT * FROM tasks ORDER BY createdAtMillis ASC")
    suspend fun getAllTasksOnce(): List<TaskEntity>

    @Query("SELECT * FROM task_plans WHERE epochDay BETWEEN :startEpochDay AND :endEpochDay ORDER BY epochDay ASC")
    suspend fun getPlansBetween(startEpochDay: Long, endEpochDay: Long): List<TaskPlanEntity>
}
