package com.habitcore.app.domain

import com.habitcore.app.data.TaskPlanEntity
import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.LocalDate

class TaskScoringTest {
    @Test
    fun dailyScoreIsCompletedOverPlanned() {
        val day = LocalDate.of(2026, 8, 21)
        val plans = (1L..10L).map { id ->
            TaskPlanEntity(taskId = id, epochDay = day.toEpochDay(), completed = id <= 7L)
        }
        assertEquals(70, TaskScoring.percent(TaskScoring.dailyScore(day, plans)))
    }

    @Test
    fun daysWithoutPlansAreExcludedFromPeriodAverage() {
        val d1 = LocalDate.of(2026, 8, 20)
        val d2 = LocalDate.of(2026, 8, 21)
        val d3 = LocalDate.of(2026, 8, 22)

        val plans = listOf(
            TaskPlanEntity(1L, d1.toEpochDay(), true),
            TaskPlanEntity(2L, d1.toEpochDay(), false),
            TaskPlanEntity(3L, d2.toEpochDay(), true)
        )

        // 50% and 100%; d3 has no plans and must be excluded => 75%.
        assertEquals(75, TaskScoring.percent(TaskScoring.periodScore(listOf(d1, d2, d3), plans)))
    }
}
