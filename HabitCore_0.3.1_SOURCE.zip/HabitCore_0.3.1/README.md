# HabitCore 0.3.1

Android habit + task tracker built with Kotlin, Jetpack Compose, Room and local notifications.

## 0.3.0 scope

### Home
- Two square, minimal panels: Habits / Tasks
- Stoic minimal visual language
- Custom launcher icon and splash mark

### Habits
- Yes/No and Measurable habits
- Last 5 days visible
- Measurable completion is proportional (70% = +0.7)
- Per-habit completion count and completion-rate color
- Daily / weekly / monthly monitoring
- Archive and pause
- 6 themes
- English / Russian / Uzbek
- Celebration animation toggle
- Reminder and result notifications

### Tasks
- Persistent quick-entry composer
- Three symbolic priority levels: ⇈ / ↑ / •
- Scheduling to another date
- Scheduled section in drawer
- Due tasks automatically appear on their date
- Completed tasks move below the divider
- Full multi-line task text
- Tap task text to edit
- Delete button
- Waiting-hours badge
- Priority sorting, then date/time sorting
- Completed archive
- Task calendar monitoring
- Stable daily task plan history when a task is rescheduled
- Daily score = completed planned tasks / total planned tasks
- Monthly score = average of available daily scores

### Notifications
- Reminders: 09:00 / 14:00 / 20:00, individually editable and switchable
- Daily result: 05:00
- Weekly result: Monday 09:00
- Monthly result: 1st day 10:00
- Result messages include both Habits and Tasks

## GitHub ZIP build workflow

Keep `HabitCore_0.3.0_SOURCE.zip` in the repository root.

Put `main.yml` at:

`.github/workflows/main.yml`

GitHub Actions will extract the ZIP, run unit tests, lint, assembleDebug, and upload the APK artifact.

## 0.3.1 fix
- Removed duplicate `performanceColor()` declaration that caused Kotlin overload ambiguity.
