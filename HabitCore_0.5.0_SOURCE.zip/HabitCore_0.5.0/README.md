# HabitCore 0.5.0

## Theme system overhaul

The theme system now changes the app's visual character, not only its primary color.

10 styles:
1. Minimal
2. Modern
3. Nordic
4. Executive
5. Zen
6. Classic
7. Material
8. Neo Brutal
9. Soft
10. Monochrome

Each style includes 4 coordinated color variants.

A style can change:
- background / surface family
- primary / secondary / tertiary accents
- card and field corner radius
- border strength
- compact vs relaxed density
- title/body font family and weight
- label character
- task card tinting

Old theme preference values remain compatible. Existing users keep their data and their old
theme selection maps to the matching new style.

## Task carry-over scoring

An unfinished overdue task is now carried into each following day's plan until it is completed.

Example:
- 6 tasks planned today
- 2 unfinished tasks carried from yesterday
- today's denominator = 8 tasks

If 5 of those 8 are completed, today's task score is 62.5%.

Carry-over plans are created:
- when the app starts
- when the Tasks screen is opened/kept open
- when scheduled notifications run

Historical task-plan rows are retained, so yesterday's score is not rewritten when the task
continues into today.

## Data safety

- Room database schema remains version 4.
- No destructive migration is used.
- Existing habits, directions, tasks, monitoring history and settings remain intact.
- The same bundled TEST signing key from 0.4.x is retained for update installation.
- New `themeAccent` is stored only in SharedPreferences and defaults safely to 0.

## GitHub build

Upload `HabitCore_0.5.0_SOURCE.zip` to the repository root.
Replace `.github/workflows/main.yml` with the supplied `main_0.5.0.yml`.

Artifact:
`HabitCore-0.5.0-debug-apk`
