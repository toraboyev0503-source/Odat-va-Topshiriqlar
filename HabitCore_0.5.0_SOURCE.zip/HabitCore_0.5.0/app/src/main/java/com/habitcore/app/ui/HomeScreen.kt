package com.habitcore.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.TaskAlt
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.habitcore.app.domain.AppLanguage

@Composable
fun HomeScreen(
    lang: AppLanguage,
    onHabits: () -> Unit,
    onTasks: () -> Unit
) {
    Scaffold { padding ->
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(padding)
                .padding(start = 14.dp, end = 14.dp, top = 18.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            HomePanel(
                title = tr(lang, "habits"),
                icon = { Icon(Icons.Outlined.CheckCircle, null, modifier = Modifier.fillMaxSize()) },
                modifier = Modifier.weight(1f),
                onClick = onHabits
            )
            HomePanel(
                title = tr(lang, "tasks"),
                icon = { Icon(Icons.Outlined.TaskAlt, null, modifier = Modifier.fillMaxSize()) },
                modifier = Modifier.weight(1f),
                onClick = onTasks
            )
        }
    }
}

@Composable
private fun HomePanel(
    title: String,
    icon: @Composable () -> Unit,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = modifier.height(150.dp),
        shape = appShape(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(appBorderWidth(), MaterialTheme.colorScheme.outlineVariant)
    ) {
        Box(Modifier.fillMaxSize().padding(14.dp)) {
            Text(
                title,
                style = MaterialTheme.typography.titleLarge,
                fontSize = 21.sp,
                modifier = Modifier.align(Alignment.TopStart)
            )
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .fillMaxSize(0.48f)
                    .graphicsLayer(alpha = 0.12f)
            ) {
                icon()
            }
        }
    }
}
