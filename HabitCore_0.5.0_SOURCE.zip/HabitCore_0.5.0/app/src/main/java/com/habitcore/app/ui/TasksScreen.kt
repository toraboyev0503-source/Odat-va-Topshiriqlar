@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.habitcore.app.ui

import android.app.DatePickerDialog
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.DateRange
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Menu
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.habitcore.app.data.TaskEntity
import com.habitcore.app.domain.AppLanguage
import com.habitcore.app.domain.TaskScoring
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun TasksScreen(
    vm: AppViewModel,
    onBack: () -> Unit,
    onScheduled: () -> Unit,
    onMonitoring: () -> Unit,
    onArchive: () -> Unit,
    onTheme: () -> Unit,
    onLanguage: () -> Unit,
    onNotifications: () -> Unit,
    onSettings: () -> Unit
) {
    val prefs by vm.prefs.collectAsState()
    val tasks by vm.tasks.collectAsState()
    val plans by vm.taskPlans.collectAsState()
    val lang = prefs.language
    val today = LocalDate.now()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var nowMillis by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var editingTask by remember { mutableStateOf<TaskEntity?>(null) }
    var editText by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        vm.refreshTaskCarryover()
        while (true) {
            delay(60L * 60L * 1000L)
            nowMillis = System.currentTimeMillis()
            vm.refreshTaskCarryover()
        }
    }

    val active = tasks
        .filter { !it.completed && it.scheduledEpochDay <= today.toEpochDay() }
        .sortedWith(
            compareBy<TaskEntity> { taskPriorityRank(it.priority) }
                .thenBy { it.scheduledEpochDay }
                .thenBy { it.createdAtMillis }
        )

    val completedToday = tasks
        .filter { it.completed && it.completedAtMillis?.let(::epochDayFromMillis) == today.toEpochDay() }
        .sortedByDescending { it.completedAtMillis ?: 0L }

    val todayPercent = TaskScoring.percent(TaskScoring.dailyScore(today, plans))

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(modifier = Modifier.fillMaxWidth(0.67f)) {
                TaskDrawerContent(
                    lang = lang,
                    onScheduled = { scope.launch { drawerState.close() }; onScheduled() },
                    onMonitoring = { scope.launch { drawerState.close() }; onMonitoring() },
                    onArchive = { scope.launch { drawerState.close() }; onArchive() },
                    onTheme = { scope.launch { drawerState.close() }; onTheme() },
                    onLanguage = { scope.launch { drawerState.close() }; onLanguage() },
                    onNotifications = { scope.launch { drawerState.close() }; onNotifications() },
                    onSettings = { scope.launch { drawerState.close() }; onSettings() }
                )
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(tr(lang, "tasks")) },
                    navigationIcon = {
                        Row {
                            IconButton(onClick = { scope.launch { drawerState.open() } }) {
                                Icon(Icons.Outlined.Menu, null)
                            }
                            IconButton(onClick = onBack) {
                                Icon(Icons.Outlined.ArrowBack, null)
                            }
                        }
                    },
                    actions = {
                        TextButton(onClick = onMonitoring) {
                            Text(
                                todayPercent?.let { "${tr(lang, "today")} $it%" } ?: "${tr(lang, "today")} —",
                                color = todayPercent?.let(::performanceColor) ?: MaterialTheme.colorScheme.onSurfaceVariant,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                )
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    NewTaskComposer(
                        lang = lang,
                        onSave = { text, priority, date ->
                            vm.addTask(text, priority, date.toEpochDay())
                        }
                    )
                }

                items(active, key = { "active_${it.id}" }) { task ->
                    TaskCard(
                        task = task,
                        lang = lang,
                        nowMillis = nowMillis,
                        completed = false,
                        onPriority = {
                            val next = nextTaskPriority(task.priority)
                            vm.updateTaskPriority(task.id, next)
                        },
                        onDate = { date -> vm.rescheduleTask(task, date.toEpochDay()) },
                        onComplete = { vm.toggleTaskCompletion(task) },
                        onEdit = {
                            editText = task.text
                            editingTask = task
                        },
                        onDelete = { vm.deleteTask(task.id) }
                    )
                }

                if (completedToday.isNotEmpty()) {
                    item {
                        Row(
                            Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            HorizontalDivider(modifier = Modifier.weight(1f))
                            Text(
                                "  ${tr(lang, "done")}  ",
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                style = MaterialTheme.typography.labelMedium
                            )
                            HorizontalDivider(modifier = Modifier.weight(1f))
                        }
                    }
                }

                items(completedToday, key = { "done_${it.id}" }) { task ->
                    TaskCard(
                        task = task,
                        lang = lang,
                        nowMillis = nowMillis,
                        completed = true,
                        onPriority = {},
                        onDate = {},
                        onComplete = { vm.toggleTaskCompletion(task) },
                        onEdit = {},
                        onDelete = { vm.deleteTask(task.id) }
                    )
                }

                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }

    editingTask?.let { task ->
        AlertDialog(
            onDismissRequest = { editingTask = null },
            title = { Text(tr(lang, "edit")) },
            text = {
                OutlinedTextField(
                    value = editText,
                    onValueChange = { editText = it },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2,
                    maxLines = 10,
                    shape = appShape()
                )
            },
            confirmButton = {
                TextButton(
                    enabled = editText.isNotBlank(),
                    onClick = {
                        vm.updateTaskText(task.id, editText)
                        editingTask = null
                    }
                ) { Text(tr(lang, "save")) }
            },
            dismissButton = {
                TextButton(onClick = { editingTask = null }) { Text(tr(lang, "cancel")) }
            }
        )
    }
}

@Composable
private fun NewTaskComposer(
    lang: AppLanguage,
    onSave: (String, Int, LocalDate) -> Unit
) {
    val context = LocalContext.current
    var text by remember { mutableStateOf("") }
    var priority by remember { mutableIntStateOf(0) }
    var date by remember { mutableStateOf(LocalDate.now()) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = appShape(),
        border = BorderStroke(appBorderWidth(), MaterialTheme.colorScheme.outlineVariant),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(8.dp),
            verticalAlignment = Alignment.Top
        ) {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text(tr(lang, "newTask")) },
                minLines = 1,
                maxLines = 8,
                shape = appShape()
            )
            Spacer(Modifier.width(6.dp))
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                PriorityCircle(priority = priority, enabled = true) {
                    priority = nextTaskPriority(priority)
                }
                CircleIconButton(
                    icon = { Icon(Icons.Outlined.DateRange, null, modifier = Modifier.size(18.dp)) },
                    contentColor = if (date == LocalDate.now()) MaterialTheme.colorScheme.primary else Color(0xFFD39B2D)
                ) {
                    showTaskDatePicker(context, date) { date = it }
                }
                CircleIconButton(
                    size = 42,
                    icon = { Icon(Icons.Outlined.Add, null, modifier = Modifier.size(22.dp)) }
                ) {
                    if (text.isNotBlank()) {
                        onSave(text.trim(), priority, date)
                        text = ""
                        priority = 0
                        date = LocalDate.now()
                    }
                }
            }
        }
    }
}

@Composable
fun TaskCard(
    task: TaskEntity,
    lang: AppLanguage,
    nowMillis: Long,
    completed: Boolean,
    onPriority: () -> Unit,
    onDate: (LocalDate) -> Unit,
    onComplete: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val context = LocalContext.current
    val waitingHours = ((nowMillis - task.createdAtMillis).coerceAtLeast(0L) / 3_600_000L)
    val date = LocalDate.ofEpochDay(task.scheduledEpochDay)

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = appShape(),
        border = BorderStroke(appBorderWidth(), MaterialTheme.colorScheme.outlineVariant),
        colors = CardDefaults.cardColors(containerColor = taskCardColor(task.colorSlot, completed))
    ) {
        Box(Modifier.fillMaxWidth()) {
            Row(
                Modifier.fillMaxWidth().padding(start = 12.dp, top = 10.dp, end = 42.dp, bottom = 10.dp),
                verticalAlignment = Alignment.Top
            ) {
                Column(
                    modifier = Modifier.weight(1f).clickable(enabled = !completed, onClick = onEdit)
                ) {
                    Text(
                        task.text,
                        style = MaterialTheme.typography.bodyLarge,
                        textDecoration = if (completed) TextDecoration.LineThrough else null,
                        color = if (completed) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
                    )
                    Row(
                        Modifier.padding(top = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = appShape(),
                            border = BorderStroke(appBorderWidth(), MaterialTheme.colorScheme.outlineVariant),
                            color = Color.Transparent
                        ) {
                            Text(
                                "${waitingHours}h",
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        Text(
                            date.format(DateTimeFormatter.ofPattern("dd MMM", taskLocale(lang))),
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(Modifier.width(6.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    PriorityCircle(task.priority, enabled = !completed, onClick = onPriority)
                    CircleIconButton(
                        icon = { Icon(Icons.Outlined.DateRange, null, modifier = Modifier.size(17.dp)) },
                        enabled = !completed
                    ) {
                        showTaskDatePicker(context, date) { onDate(it) }
                    }
                    CircleIconButton(
                        size = 44,
                        icon = {
                            if (completed) {
                                Icon(Icons.Outlined.Check, null, modifier = Modifier.size(22.dp))
                            } else {
                                Text("!", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            }
                        },
                        enabled = true,
                        contentColor = if (completed) Color(0xFF39865A) else MaterialTheme.colorScheme.primary
                    ) { onComplete() }
                }
            }

            IconButton(
                onClick = onDelete,
                modifier = Modifier.align(Alignment.TopEnd).size(34.dp)
            ) {
                Icon(
                    Icons.Outlined.DeleteOutline,
                    null,
                    tint = Color(0xFFD98787),
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
private fun PriorityCircle(
    priority: Int,
    enabled: Boolean,
    onClick: () -> Unit
) {
    val fill = when (priority) {
        1 -> Color(0xFFE45B5B)   // very important
        2 -> Color(0xFFE98B44)   // important
        3 -> Color(0xFFD6B64C)   // later
        else -> MaterialTheme.colorScheme.surface
    }
    val outline = when (priority) {
        1 -> Color(0xFFC83D3D)
        2 -> Color(0xFFD56F2E)
        3 -> Color(0xFFB99A32)
        else -> MaterialTheme.colorScheme.outline
    }

    Surface(
        modifier = Modifier
            .size(34.dp)
            .clickable(enabled = enabled, onClick = onClick),
        shape = CircleShape,
        border = BorderStroke(
            1.2.dp,
            outline.copy(alpha = if (enabled) 0.9f else 0.35f)
        ),
        color = fill.copy(alpha = if (priority == 0) 1f else 0.82f)
    ) {
        Box(contentAlignment = Alignment.Center) {
            if (priority == 0) {
                Text(
                    "·",
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.38f),
                    fontSize = 15.sp
                )
            }
        }
    }
}

private fun nextTaskPriority(priority: Int): Int = when (priority) {
    0 -> 1
    1 -> 2
    2 -> 3
    else -> 0
}

private fun taskPriorityRank(priority: Int): Int = when (priority) {
    1 -> 0
    2 -> 1
    3 -> 2
    else -> 3
}

@Composable
private fun CircleIconButton(
    size: Int = 34,
    enabled: Boolean = true,
    contentColor: Color = MaterialTheme.colorScheme.primary,
    icon: @Composable () -> Unit,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier.size(size.dp).clickable(enabled = enabled, onClick = onClick),
        shape = CircleShape,
        border = BorderStroke(1.dp, contentColor.copy(alpha = if (enabled) 0.65f else 0.25f)),
        color = Color.Transparent,
        contentColor = contentColor.copy(alpha = if (enabled) 1f else 0.35f)
    ) {
        Box(contentAlignment = Alignment.Center) { icon() }
    }
}

@Composable
private fun taskCardColor(slot: Int, completed: Boolean): Color {
    if (completed) {
        return MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.62f)
    }

    return when (((slot % 5) + 5) % 5) {
        0 -> MaterialTheme.colorScheme.primary.copy(alpha = 0.075f)
        1 -> MaterialTheme.colorScheme.secondary.copy(alpha = 0.085f)
        2 -> MaterialTheme.colorScheme.tertiary.copy(alpha = 0.09f)
        3 -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.72f)
        else -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.34f)
    }
}

fun showTaskDatePicker(
    context: android.content.Context,
    initial: LocalDate,
    onDate: (LocalDate) -> Unit
) {
    DatePickerDialog(
        context,
        { _, year, month, day -> onDate(LocalDate.of(year, month + 1, day)) },
        initial.year,
        initial.monthValue - 1,
        initial.dayOfMonth
    ).show()
}

fun taskLocale(lang: AppLanguage): Locale = when (lang) {
    AppLanguage.EN -> Locale.ENGLISH
    AppLanguage.RU -> Locale("ru")
    AppLanguage.UZ -> Locale("uz")
}

private fun epochDayFromMillis(millis: Long): Long =
    Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()).toLocalDate().toEpochDay()
