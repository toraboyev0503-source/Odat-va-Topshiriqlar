package com.habitcore.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.habitcore.app.data.AppDatabase
import com.habitcore.app.data.HabitCategoryEntity
import com.habitcore.app.data.HabitEntity
import com.habitcore.app.data.HabitEntryEntity
import com.habitcore.app.data.HabitRepository
import com.habitcore.app.data.PreferenceStore
import com.habitcore.app.data.TaskEntity
import com.habitcore.app.data.TaskPlanEntity
import com.habitcore.app.data.TaskRepository
import com.habitcore.app.domain.AppPrefs
import com.habitcore.app.notifications.NotificationScheduler
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

class AppViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getInstance(application)
    private val habitRepository = HabitRepository(db.habitDao())
    private val taskRepository = TaskRepository(db.taskDao())
    private val preferenceStore = PreferenceStore(application)

    val habits: StateFlow<List<HabitEntity>> = habitRepository.habits
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val entries: StateFlow<List<HabitEntryEntity>> = habitRepository.entries
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val categories: StateFlow<List<HabitCategoryEntity>> = habitRepository.categories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val tasks: StateFlow<List<TaskEntity>> = taskRepository.tasks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val taskPlans: StateFlow<List<TaskPlanEntity>> = taskRepository.plans
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _prefs = MutableStateFlow(preferenceStore.load())
    val prefs: StateFlow<AppPrefs> = _prefs

    init {
        viewModelScope.launch {
            taskRepository.ensureCarryoverPlans(LocalDate.now())
        }
        NotificationScheduler.scheduleAll(application, _prefs.value)
    }

    fun addCategory(name: String, onCreated: (Long) -> Unit = {}) = viewModelScope.launch {
        if (name.isBlank()) return@launch
        val id = habitRepository.addCategory(name)
        onCreated(id)
    }

    fun addHabit(habit: HabitEntity) = viewModelScope.launch {
        habitRepository.addHabit(habit)
    }

    fun updateHabit(habit: HabitEntity) = viewModelScope.launch {
        habitRepository.updateHabit(habit)
    }

    fun moveHabit(habitId: Long, categoryId: Long, direction: Int) = viewModelScope.launch {
        habitRepository.moveHabit(habitId, categoryId, direction)
    }

    fun saveEntry(entry: HabitEntryEntity) = viewModelScope.launch {
        habitRepository.saveEntry(entry)
    }

    fun clearEntry(habitId: Long, epochDay: Long) = viewModelScope.launch {
        habitRepository.clearEntry(habitId, epochDay)
    }

    fun archiveHabit(habitId: Long, epochDay: Long) = viewModelScope.launch {
        habitRepository.archiveHabit(habitId, epochDay)
    }

    fun restoreHabit(habitId: Long) = viewModelScope.launch {
        habitRepository.restoreHabit(habitId)
    }

    fun setPaused(habitId: Long, paused: Boolean) = viewModelScope.launch {
        habitRepository.setPaused(
            habitId,
            paused,
            if (paused) LocalDate.now().toEpochDay() else null
        )
    }

    fun refreshTaskCarryover() = viewModelScope.launch {
        taskRepository.ensureCarryoverPlans(LocalDate.now())
    }

    fun addTask(text: String, priority: Int, scheduledEpochDay: Long) = viewModelScope.launch {
        val slot = ((System.currentTimeMillis() / 1000L) % 5L).toInt()
        taskRepository.addTask(text.trim(), priority, scheduledEpochDay, slot)
    }

    fun updateTaskText(taskId: Long, text: String) = viewModelScope.launch {
        if (text.isNotBlank()) taskRepository.updateText(taskId, text.trim())
    }

    fun updateTaskPriority(taskId: Long, priority: Int) = viewModelScope.launch {
        taskRepository.updatePriority(taskId, priority)
    }

    fun rescheduleTask(task: TaskEntity, newEpochDay: Long) = viewModelScope.launch {
        taskRepository.reschedule(task, newEpochDay)
    }

    fun toggleTaskCompletion(task: TaskEntity) = viewModelScope.launch {
        taskRepository.toggleCompletion(task)
    }

    fun deleteTask(taskId: Long) = viewModelScope.launch {
        taskRepository.delete(taskId)
    }

    fun updatePrefs(block: (AppPrefs) -> AppPrefs) {
        val next = block(_prefs.value)
        _prefs.value = next
        preferenceStore.save(next)
        NotificationScheduler.scheduleAll(getApplication(), next)
    }
}
