@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.habitcore.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.ChevronLeft
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.habitcore.app.data.TaskPlanEntity
import com.habitcore.app.domain.TaskScoring
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.TextStyle

@Composable
fun TaskMonitoringScreen(vm: AppViewModel, onBack: () -> Unit) {
    val prefs by vm.prefs.collectAsState()
    val plans by vm.taskPlans.collectAsState()
    val today = LocalDate.now()
    var month by remember { mutableStateOf(YearMonth.from(today)) }

    val endDay = if (month == YearMonth.from(today)) today else month.atEndOfMonth()
    val daysForAverage = if (endDay.isBefore(month.atDay(1))) emptyList()
    else (1..endDay.dayOfMonth).map { month.atDay(it) }
    val monthPercent = TaskScoring.percent(TaskScoring.periodScore(daysForAverage, plans))

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(tr(prefs.language, "monitoring")) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Outlined.ArrowBack, null) } }
            )
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 12.dp)) {
            Row(
                Modifier.fillMaxWidth().padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { month = month.minusMonths(1) }) {
                    Icon(Icons.Outlined.ChevronLeft, null)
                }
                Text(
                    month.month.getDisplayName(TextStyle.FULL, taskLocale(prefs.language))
                        .replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() },
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.titleLarge
                )
                Text(
                    monthPercent?.let { "$it%" } ?: "—",
                    color = monthPercent?.let(::performanceColor) ?: MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Bold
                )
                IconButton(
                    enabled = month < YearMonth.from(today),
                    onClick = { month = month.plusMonths(1) }
                ) { Icon(Icons.Outlined.ChevronRight, null) }
            }

            TaskMonthGrid(month = month, plans = plans, today = today)
        }
    }
}

@Composable
private fun TaskMonthGrid(
    month: YearMonth,
    plans: List<TaskPlanEntity>,
    today: LocalDate
) {
    val first = month.atDay(1)
    val leading = first.dayOfWeek.value - 1
    val cells = MutableList<LocalDate?>(leading) { null }
    repeat(month.lengthOfMonth()) { cells += month.atDay(it + 1) }
    while (cells.size % 7 != 0) cells += null

    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        cells.chunked(7).forEach { week ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                week.forEach { day ->
                    Box(modifier = Modifier.weight(1f)) {
                        if (day == null) {
                            Box(Modifier.fillMaxWidth().aspectRatio(1f))
                        } else {
                            val percent = if (day.isAfter(today)) null
                            else TaskScoring.percent(TaskScoring.dailyScore(day, plans))
                            TaskDayCell(day.dayOfMonth, percent, day.isAfter(today))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TaskDayCell(day: Int, percent: Int?, future: Boolean) {
    Card(
        modifier = Modifier.fillMaxWidth().aspectRatio(1f),
        shape = appShape(),
        border = BorderStroke(appBorderWidth(), MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            Modifier.fillMaxSize().padding(5.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(day.toString(), fontSize = 12.sp)
            Text(
                when {
                    future -> "·"
                    percent == null -> "—"
                    else -> "$percent%"
                },
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                color = if (percent == null) MaterialTheme.colorScheme.onSurfaceVariant else performanceColor(percent)
            )
        }
    }
}
