@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.habitcore.app.ui

import android.app.TimePickerDialog
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.habitcore.app.domain.AppLanguage
import com.habitcore.app.domain.AppMode
import com.habitcore.app.domain.ReminderSlot
import com.habitcore.app.domain.ThemeChoice
import java.util.Locale

@Composable
private fun SimpleTop(title: String, onBack: () -> Unit, content: @Composable (androidx.compose.foundation.layout.PaddingValues) -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Outlined.ArrowBack, null) } }
            )
        },
        content = content
    )
}

@Composable
fun ThemeScreen(vm: AppViewModel, onBack: () -> Unit) {
    val prefs by vm.prefs.collectAsState()
    val lang = prefs.language
    SimpleTop(tr(lang, "theme"), onBack) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ModeChip(tr(lang, "system"), prefs.mode == AppMode.SYSTEM) { vm.updatePrefs { it.copy(mode = AppMode.SYSTEM) } }
                ModeChip(tr(lang, "light"), prefs.mode == AppMode.LIGHT) { vm.updatePrefs { it.copy(mode = AppMode.LIGHT) } }
                ModeChip(tr(lang, "dark"), prefs.mode == AppMode.DARK) { vm.updatePrefs { it.copy(mode = AppMode.DARK) } }
            }
            Spacer(Modifier.height(4.dp))
            ThemeChoice.entries.forEach { choice ->
                Card(
                    modifier = Modifier.fillMaxWidth().height(58.dp).clickable { vm.updatePrefs { it.copy(theme = choice) } },
                    border = BorderStroke(1.dp, if (prefs.theme == choice) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Row(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(24.dp).background(themePreviewColor(choice), CircleShape))
                        Text(choice.name.lowercase().replaceFirstChar { it.uppercase() }, modifier = Modifier.padding(start = 14.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun ModeChip(text: String, selected: Boolean, onClick: () -> Unit) {
    Card(
        modifier = Modifier.clickable(onClick = onClick),
        border = BorderStroke(1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant)
    ) { Text(text, modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) }
}

private fun themePreviewColor(choice: ThemeChoice): Color = when (choice) {
    ThemeChoice.GRAPHITE -> Color(0xFF4D535A)
    ThemeChoice.SLATE -> Color(0xFF536A77)
    ThemeChoice.FOREST -> Color(0xFF426A52)
    ThemeChoice.NAVY -> Color(0xFF465D84)
    ThemeChoice.SAND -> Color(0xFF7B6A4B)
    ThemeChoice.BURGUNDY -> Color(0xFF7E4E5A)
}

@Composable
fun LanguageScreen(vm: AppViewModel, onBack: () -> Unit) {
    val prefs by vm.prefs.collectAsState()
    val lang = prefs.language
    SimpleTop(tr(lang, "language"), onBack) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            LanguageRow("English", AppLanguage.EN, prefs.language) { vm.updatePrefs { p -> p.copy(language = it) } }
            LanguageRow("Русский", AppLanguage.RU, prefs.language) { vm.updatePrefs { p -> p.copy(language = it) } }
            LanguageRow("O‘zbek", AppLanguage.UZ, prefs.language) { vm.updatePrefs { p -> p.copy(language = it) } }
        }
    }
}

@Composable
private fun LanguageRow(label: String, value: AppLanguage, selected: AppLanguage, onChange: (AppLanguage) -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(58.dp).clickable { onChange(value) },
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected == value, onClick = { onChange(value) })
        Text(label, modifier = Modifier.padding(start = 8.dp))
    }
}

@Composable
fun NotificationsScreen(vm: AppViewModel, onBack: () -> Unit) {
    val prefs by vm.prefs.collectAsState()
    val lang = prefs.language
    SimpleTop(tr(lang, "notifications"), onBack) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp)) {
            ToggleRow(tr(lang, "master"), prefs.notificationsEnabled) { v -> vm.updatePrefs { it.copy(notificationsEnabled = v) } }
            SectionLabel(tr(lang, "reminders"))
            ReminderRow("1", prefs.reminder1, prefs.notificationsEnabled) { slot -> vm.updatePrefs { it.copy(reminder1 = slot) } }
            ReminderRow("2", prefs.reminder2, prefs.notificationsEnabled) { slot -> vm.updatePrefs { it.copy(reminder2 = slot) } }
            ReminderRow("3", prefs.reminder3, prefs.notificationsEnabled) { slot -> vm.updatePrefs { it.copy(reminder3 = slot) } }
            SectionLabel(tr(lang, "results"))
            ToggleRow("${tr(lang, "daily")} · 05:00", prefs.resultDaily, prefs.notificationsEnabled) { v -> vm.updatePrefs { it.copy(resultDaily = v) } }
            ToggleRow("${tr(lang, "weekly")} · Mon 09:00", prefs.resultWeekly, prefs.notificationsEnabled) { v -> vm.updatePrefs { it.copy(resultWeekly = v) } }
            ToggleRow("${tr(lang, "monthly")} · 1 · 10:00", prefs.resultMonthly, prefs.notificationsEnabled) { v -> vm.updatePrefs { it.copy(resultMonthly = v) } }
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(text, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 18.dp, bottom = 6.dp))
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().height(56.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}

@Composable
private fun ReminderRow(label: String, slot: ReminderSlot, masterEnabled: Boolean, onChange: (ReminderSlot) -> Unit) {
    val context = LocalContext.current
    Row(Modifier.fillMaxWidth().height(58.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.padding(end = 12.dp))
        Text(
            String.format(Locale.US, "%02d:%02d", slot.hour, slot.minute),
            modifier = Modifier.weight(1f).clickable(enabled = masterEnabled && slot.enabled) {
                TimePickerDialog(context, { _, h, m -> onChange(slot.copy(hour = h, minute = m)) }, slot.hour, slot.minute, true).show()
            },
            color = if (masterEnabled && slot.enabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
        )
        Switch(checked = slot.enabled, onCheckedChange = { onChange(slot.copy(enabled = it)) }, enabled = masterEnabled)
    }
}

@Composable
fun SettingsScreen(vm: AppViewModel, onBack: () -> Unit) {
    val prefs by vm.prefs.collectAsState()
    val lang = prefs.language
    SimpleTop(tr(lang, "settings"), onBack) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            ToggleRow(tr(lang, "celebration"), prefs.celebration) { v -> vm.updatePrefs { it.copy(celebration = v) } }
        }
    }
}
