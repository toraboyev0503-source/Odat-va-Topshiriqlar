package com.habitcore.app.ui

import com.habitcore.app.domain.AppLanguage

fun tr(lang: AppLanguage, key: String): String {
    val en = mapOf(
        "habits" to "Habits", "tasks" to "Tasks", "comingSoon" to "Coming soon",
        "today" to "TODAY", "add" to "Add", "createHabit" to "Create habit",
        "yesNo" to "Yes or No", "measurable" to "Measurable", "name" to "Name",
        "question" to "Question", "notes" to "Notes", "frequency" to "Frequency",
        "everyDay" to "Every day", "everyNDays" to "Every N days", "timesWeek" to "X times per week",
        "timesMonth" to "X times per month", "timesNDays" to "X times in N days",
        "target" to "Target", "unit" to "Unit", "save" to "Save", "cancel" to "Cancel",
        "theme" to "Theme", "language" to "Language", "notifications" to "Notifications",
        "monitoring" to "Monitoring", "settings" to "Settings", "celebration" to "Celebration animation",
        "light" to "Light", "dark" to "Dark", "system" to "System", "reminders" to "Reminders",
        "results" to "Results", "daily" to "Daily", "weekly" to "Weekly", "monthly" to "Monthly",
        "master" to "All notifications", "week" to "Week", "month" to "Month", "archive" to "Archive",
        "pause" to "Pause", "resume" to "Resume", "restore" to "Restore", "done" to "Done",
        "failed" to "Failed", "unknown" to "Unknown", "value" to "Value", "empty" to "No habits yet",
        "tapPlus" to "Tap + to create one", "sortManual" to "Manual", "sortName" to "Name", "sortColor" to "Color", "sortScore" to "Score", "archived" to "Archived"
    )
    val ru = mapOf(
        "habits" to "Привычки", "tasks" to "Задачи", "comingSoon" to "Скоро",
        "today" to "СЕГОДНЯ", "add" to "Добавить", "createHabit" to "Новая привычка",
        "yesNo" to "Да или нет", "measurable" to "Измеримая", "name" to "Название",
        "question" to "Вопрос", "notes" to "Заметки", "frequency" to "Частота",
        "everyDay" to "Каждый день", "everyNDays" to "Каждые N дней", "timesWeek" to "X раз в неделю",
        "timesMonth" to "X раз в месяц", "timesNDays" to "X раз за N дней",
        "target" to "Цель", "unit" to "Ед.", "save" to "Сохранить", "cancel" to "Отмена",
        "theme" to "Тема", "language" to "Язык", "notifications" to "Уведомления",
        "monitoring" to "Мониторинг", "settings" to "Настройки", "celebration" to "Анимация успеха",
        "light" to "Светлая", "dark" to "Тёмная", "system" to "Системная", "reminders" to "Напоминания",
        "results" to "Результаты", "daily" to "День", "weekly" to "Неделя", "monthly" to "Месяц",
        "master" to "Все уведомления", "week" to "Неделя", "month" to "Месяц", "archive" to "Архив",
        "pause" to "Пауза", "resume" to "Продолжить", "restore" to "Восстановить", "done" to "Готово",
        "failed" to "Не выполнено", "unknown" to "Неизвестно", "value" to "Значение", "empty" to "Привычек пока нет",
        "tapPlus" to "Нажмите +, чтобы добавить", "sortManual" to "Вручную", "sortName" to "Название", "sortColor" to "Цвет", "sortScore" to "Результат", "archived" to "Архив"
    )
    val uz = mapOf(
        "habits" to "Odatlar", "tasks" to "Vazifalar", "comingSoon" to "Tez orada",
        "today" to "BUGUN", "add" to "Qo‘shish", "createHabit" to "Yangi odat",
        "yesNo" to "Ha yoki yo‘q", "measurable" to "O‘lchanadigan", "name" to "Nomi",
        "question" to "Savol", "notes" to "Izoh", "frequency" to "Takrorlanish",
        "everyDay" to "Har kuni", "everyNDays" to "Har N kunda", "timesWeek" to "Haftasiga X marta",
        "timesMonth" to "Oyiga X marta", "timesNDays" to "N kunda X marta",
        "target" to "Maqsad", "unit" to "Birlik", "save" to "Saqlash", "cancel" to "Bekor",
        "theme" to "Mavzu", "language" to "Til", "notifications" to "Bildirishnomalar",
        "monitoring" to "Monitoring", "settings" to "Sozlamalar", "celebration" to "Bayram animatsiyasi",
        "light" to "Yorug‘", "dark" to "Tun", "system" to "Tizim", "reminders" to "Eslatmalar",
        "results" to "Natijalar", "daily" to "Kunlik", "weekly" to "Haftalik", "monthly" to "Oylik",
        "master" to "Barcha bildirishnomalar", "week" to "Hafta", "month" to "Oy", "archive" to "Arxiv",
        "pause" to "Pauza", "resume" to "Davom", "restore" to "Tiklash", "done" to "Bajarildi",
        "failed" to "Bajarilmadi", "unknown" to "Noma’lum", "value" to "Qiymat", "empty" to "Hozircha odat yo‘q",
        "tapPlus" to "+ orqali odat qo‘shing", "sortManual" to "Qo‘lda", "sortName" to "Nom", "sortColor" to "Rang", "sortScore" to "Natija", "archived" to "Arxiv"
    )
    return when (lang) {
        AppLanguage.EN -> en[key]
        AppLanguage.RU -> ru[key]
        AppLanguage.UZ -> uz[key]
    } ?: en[key] ?: key
}
