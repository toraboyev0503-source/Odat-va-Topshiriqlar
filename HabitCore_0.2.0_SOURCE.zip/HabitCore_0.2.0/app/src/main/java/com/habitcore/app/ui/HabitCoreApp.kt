package com.habitcore.app.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue

private enum class Screen { HOME, HABITS, CREATE, MONITORING, THEME, LANGUAGE, NOTIFICATIONS, ARCHIVE, SETTINGS }

@Composable
fun HabitCoreApp(vm: AppViewModel) {
    val prefs by vm.prefs.collectAsState()
    var screen by remember { mutableStateOf(Screen.HOME) }

    HabitCoreTheme(prefs.theme, prefs.mode) {
        when (screen) {
            Screen.HOME -> HomeScreen(
                lang = prefs.language,
                onHabits = { screen = Screen.HABITS },
                onTasks = { }
            )
            Screen.HABITS -> HabitsScreen(
                vm = vm,
                onBack = { screen = Screen.HOME },
                onCreate = { screen = Screen.CREATE },
                onMonitoring = { screen = Screen.MONITORING },
                onTheme = { screen = Screen.THEME },
                onLanguage = { screen = Screen.LANGUAGE },
                onNotifications = { screen = Screen.NOTIFICATIONS },
                onArchive = { screen = Screen.ARCHIVE },
                onSettings = { screen = Screen.SETTINGS }
            )
            Screen.CREATE -> CreateHabitScreen(vm = vm, onBack = { screen = Screen.HABITS })
            Screen.MONITORING -> MonitoringScreen(vm = vm, onBack = { screen = Screen.HABITS })
            Screen.THEME -> ThemeScreen(vm = vm, onBack = { screen = Screen.HABITS })
            Screen.LANGUAGE -> LanguageScreen(vm = vm, onBack = { screen = Screen.HABITS })
            Screen.NOTIFICATIONS -> NotificationsScreen(vm = vm, onBack = { screen = Screen.HABITS })
            Screen.ARCHIVE -> ArchiveScreen(vm = vm, onBack = { screen = Screen.HABITS })
            Screen.SETTINGS -> SettingsScreen(vm = vm, onBack = { screen = Screen.HABITS })
        }
    }
}
