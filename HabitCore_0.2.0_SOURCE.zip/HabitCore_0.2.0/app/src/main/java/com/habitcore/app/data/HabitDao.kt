package com.habitcore.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface HabitDao {
    @Query("SELECT * FROM habits ORDER BY sortOrder ASC, id ASC")
    fun observeHabits(): Flow<List<HabitEntity>>

    @Query("SELECT * FROM habit_entries ORDER BY epochDay ASC")
    fun observeEntries(): Flow<List<HabitEntryEntity>>

    @Insert
    suspend fun insertHabit(habit: HabitEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveEntry(entry: HabitEntryEntity)

    @Query("DELETE FROM habit_entries WHERE habitId = :habitId AND epochDay = :epochDay")
    suspend fun deleteEntry(habitId: Long, epochDay: Long)

    @Query("UPDATE habits SET archivedEpochDay = :epochDay WHERE id = :habitId")
    suspend fun archiveHabit(habitId: Long, epochDay: Long)

    @Query("UPDATE habits SET archivedEpochDay = NULL WHERE id = :habitId")
    suspend fun restoreHabit(habitId: Long)

    @Query("UPDATE habits SET paused = :paused, pausedSinceEpochDay = :sinceEpochDay WHERE id = :habitId")
    suspend fun setPaused(habitId: Long, paused: Boolean, sinceEpochDay: Long?)

    @Query("SELECT * FROM habits ORDER BY id ASC")
    suspend fun getAllHabitsOnce(): List<HabitEntity>

    @Query("SELECT * FROM habit_entries WHERE epochDay BETWEEN :startEpochDay AND :endEpochDay ORDER BY epochDay ASC")
    suspend fun getEntriesBetween(startEpochDay: Long, endEpochDay: Long): List<HabitEntryEntity>
}
