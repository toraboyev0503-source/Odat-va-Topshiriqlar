package com.habitcore.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.habitcore.app.domain.AppMode
import com.habitcore.app.domain.ThemeChoice

private data class Palette(val primary: Color, val secondary: Color, val background: Color, val surface: Color)

private fun palette(choice: ThemeChoice, dark: Boolean): Palette {
    return when (choice) {
        ThemeChoice.GRAPHITE -> if (dark) Palette(Color(0xFFB8BDC5), Color(0xFF8E949D), Color(0xFF111315), Color(0xFF1A1D20)) else Palette(Color(0xFF4D535A), Color(0xFF737A82), Color(0xFFF7F7F6), Color(0xFFFFFFFF))
        ThemeChoice.SLATE -> if (dark) Palette(Color(0xFFAFC2CE), Color(0xFF8299A7), Color(0xFF10161A), Color(0xFF182126)) else Palette(Color(0xFF536A77), Color(0xFF718994), Color(0xFFF4F7F8), Color(0xFFFFFFFF))
        ThemeChoice.FOREST -> if (dark) Palette(Color(0xFFA9C6B2), Color(0xFF789684), Color(0xFF101612), Color(0xFF18211B)) else Palette(Color(0xFF426A52), Color(0xFF6E8A77), Color(0xFFF5F8F5), Color(0xFFFFFFFF))
        ThemeChoice.NAVY -> if (dark) Palette(Color(0xFFAFBFDA), Color(0xFF7D91B3), Color(0xFF10141B), Color(0xFF181E28)) else Palette(Color(0xFF465D84), Color(0xFF6E82A3), Color(0xFFF5F7FA), Color(0xFFFFFFFF))
        ThemeChoice.SAND -> if (dark) Palette(Color(0xFFD2C2A4), Color(0xFFA79270), Color(0xFF18150F), Color(0xFF211D16)) else Palette(Color(0xFF7B6A4B), Color(0xFF9A896A), Color(0xFFFAF8F3), Color(0xFFFFFFFF))
        ThemeChoice.BURGUNDY -> if (dark) Palette(Color(0xFFD2B4BC), Color(0xFFA27D87), Color(0xFF191113), Color(0xFF23181B)) else Palette(Color(0xFF7E4E5A), Color(0xFF9A707A), Color(0xFFFAF5F6), Color(0xFFFFFFFF))
    }
}

@Composable
fun HabitCoreTheme(choice: ThemeChoice, mode: AppMode, content: @Composable () -> Unit) {
    val dark = when (mode) {
        AppMode.LIGHT -> false
        AppMode.DARK -> true
        AppMode.SYSTEM -> isSystemInDarkTheme()
    }
    val p = palette(choice, dark)
    val scheme = if (dark) {
        darkColorScheme(primary = p.primary, secondary = p.secondary, background = p.background, surface = p.surface)
    } else {
        lightColorScheme(primary = p.primary, secondary = p.secondary, background = p.background, surface = p.surface)
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

fun habitColor(index: Int): Long {
    val colors = listOf(
        0xFF4E78A8L, 0xFF4F7A5CL, 0xFF8B5E6BL, 0xFF7B6B4CL,
        0xFF5E6D83L, 0xFF806A99L, 0xFF557B78L, 0xFF8A674FL
    )
    return colors[index.coerceIn(0, colors.lastIndex)]
}
