package com.habitcore.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.habitcore.app.data.AppDatabase
import com.habitcore.app.data.HabitEntity
import com.habitcore.app.data.HabitEntryEntity
import com.habitcore.app.data.HabitRepository
import com.habitcore.app.data.PreferenceStore
import com.habitcore.app.domain.AppPrefs
import com.habitcore.app.notifications.NotificationScheduler
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AppViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getInstance(application)
    private val repository = HabitRepository(db.habitDao())
    private val preferenceStore = PreferenceStore(application)

    val habits: StateFlow<List<HabitEntity>> = repository.habits
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val entries: StateFlow<List<HabitEntryEntity>> = repository.entries
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _prefs = MutableStateFlow(preferenceStore.load())
    val prefs: StateFlow<AppPrefs> = _prefs

    init {
        NotificationScheduler.scheduleAll(application, _prefs.value)
    }

    fun addHabit(habit: HabitEntity) = viewModelScope.launch { repository.addHabit(habit) }
    fun saveEntry(entry: HabitEntryEntity) = viewModelScope.launch { repository.saveEntry(entry) }
    fun clearEntry(habitId: Long, epochDay: Long) = viewModelScope.launch { repository.clearEntry(habitId, epochDay) }
    fun archiveHabit(habitId: Long, epochDay: Long) = viewModelScope.launch { repository.archiveHabit(habitId, epochDay) }
    fun restoreHabit(habitId: Long) = viewModelScope.launch { repository.restoreHabit(habitId) }
    fun setPaused(habitId: Long, paused: Boolean) = viewModelScope.launch { repository.setPaused(habitId, paused, if (paused) java.time.LocalDate.now().toEpochDay() else null) }

    fun updatePrefs(block: (AppPrefs) -> AppPrefs) {
        val next = block(_prefs.value)
        _prefs.value = next
        preferenceStore.save(next)
        NotificationScheduler.scheduleAll(getApplication(), next)
    }
}
