package com.habitcore.app.notifications

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.habitcore.app.domain.AppPrefs
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.time.temporal.TemporalAdjusters

object NotificationScheduler {
    const val TYPE_R1 = "r1"
    const val TYPE_R2 = "r2"
    const val TYPE_R3 = "r3"
    const val TYPE_DAILY = "daily_result"
    const val TYPE_WEEKLY = "weekly_result"
    const val TYPE_MONTHLY = "monthly_result"

    private val requestCodes = mapOf(
        TYPE_R1 to 101,
        TYPE_R2 to 102,
        TYPE_R3 to 103,
        TYPE_DAILY to 201,
        TYPE_WEEKLY to 202,
        TYPE_MONTHLY to 203
    )

    fun scheduleAll(context: Context, prefs: AppPrefs) {
        requestCodes.keys.forEach { cancel(context, it) }
        if (!prefs.notificationsEnabled) return

        if (prefs.reminder1.enabled) scheduleDailyClock(context, TYPE_R1, prefs.reminder1.hour, prefs.reminder1.minute)
        if (prefs.reminder2.enabled) scheduleDailyClock(context, TYPE_R2, prefs.reminder2.hour, prefs.reminder2.minute)
        if (prefs.reminder3.enabled) scheduleDailyClock(context, TYPE_R3, prefs.reminder3.hour, prefs.reminder3.minute)
        if (prefs.resultDaily) scheduleDailyClock(context, TYPE_DAILY, 5, 0)
        if (prefs.resultWeekly) scheduleWeekly(context)
        if (prefs.resultMonthly) scheduleMonthly(context)
    }

    fun scheduleType(context: Context, type: String, prefs: AppPrefs) {
        if (!prefs.notificationsEnabled) return
        when (type) {
            TYPE_R1 -> if (prefs.reminder1.enabled) scheduleDailyClock(context, type, prefs.reminder1.hour, prefs.reminder1.minute)
            TYPE_R2 -> if (prefs.reminder2.enabled) scheduleDailyClock(context, type, prefs.reminder2.hour, prefs.reminder2.minute)
            TYPE_R3 -> if (prefs.reminder3.enabled) scheduleDailyClock(context, type, prefs.reminder3.hour, prefs.reminder3.minute)
            TYPE_DAILY -> if (prefs.resultDaily) scheduleDailyClock(context, type, 5, 0)
            TYPE_WEEKLY -> if (prefs.resultWeekly) scheduleWeekly(context)
            TYPE_MONTHLY -> if (prefs.resultMonthly) scheduleMonthly(context)
        }
    }

    private fun scheduleDailyClock(context: Context, type: String, hour: Int, minute: Int) {
        val now = LocalDateTime.now()
        var next = LocalDateTime.of(LocalDate.now(), LocalTime.of(hour, minute))
        if (!next.isAfter(now)) next = next.plusDays(1)
        setAlarm(context, type, next)
    }

    private fun scheduleWeekly(context: Context) {
        val now = LocalDateTime.now()
        var date = LocalDate.now().with(TemporalAdjusters.nextOrSame(DayOfWeek.MONDAY))
        var next = LocalDateTime.of(date, LocalTime.of(9, 0))
        if (!next.isAfter(now)) next = LocalDateTime.of(date.plusWeeks(1), LocalTime.of(9, 0))
        setAlarm(context, TYPE_WEEKLY, next)
    }

    private fun scheduleMonthly(context: Context) {
        val now = LocalDateTime.now()
        var date = LocalDate.now().withDayOfMonth(1)
        var next = LocalDateTime.of(date, LocalTime.of(10, 0))
        if (!next.isAfter(now)) next = LocalDateTime.of(date.plusMonths(1).withDayOfMonth(1), LocalTime.of(10, 0))
        setAlarm(context, TYPE_MONTHLY, next)
    }

    private fun setAlarm(context: Context, type: String, dateTime: LocalDateTime) {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val triggerAt = dateTime.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent(context, type))
    }

    private fun cancel(context: Context, type: String) {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarm.cancel(pendingIntent(context, type))
    }

    private fun pendingIntent(context: Context, type: String): PendingIntent {
        val intent = Intent(context, NotificationReceiver::class.java).putExtra("type", type)
        return PendingIntent.getBroadcast(
            context,
            requestCodes[type] ?: 999,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
