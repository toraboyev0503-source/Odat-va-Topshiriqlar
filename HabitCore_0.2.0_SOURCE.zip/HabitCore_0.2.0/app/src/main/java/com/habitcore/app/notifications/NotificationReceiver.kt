package com.habitcore.app.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.habitcore.app.data.AppDatabase
import com.habitcore.app.data.PreferenceStore
import com.habitcore.app.domain.AppLanguage
import com.habitcore.app.domain.Schedule
import com.habitcore.app.domain.ScoreCalculator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.TemporalAdjusters

class NotificationReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pending = goAsync()
        val type = intent.getStringExtra("type") ?: return pending.finish()
        val appContext = context.applicationContext
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                val prefs = PreferenceStore(appContext).load()
                when (type) {
                    NotificationScheduler.TYPE_R1,
                    NotificationScheduler.TYPE_R2,
                    NotificationScheduler.TYPE_R3 -> showReminder(appContext, prefs.language)
                    NotificationScheduler.TYPE_DAILY -> showDailyResult(appContext, prefs.language)
                    NotificationScheduler.TYPE_WEEKLY -> showWeeklyResult(appContext, prefs.language)
                    NotificationScheduler.TYPE_MONTHLY -> showMonthlyResult(appContext, prefs.language)
                }
                NotificationScheduler.scheduleType(appContext, type, prefs)
            } finally {
                pending.finish()
            }
        }
    }

    private fun showReminder(context: Context, lang: AppLanguage) {
        val text = when (lang) {
            AppLanguage.EN -> "Check your habits and tasks. Keep the day under control."
            AppLanguage.RU -> "Проверьте привычки и задачи. Держите день под контролем."
            AppLanguage.UZ -> "Odatlar va vazifalarni ko‘rib chiqing. Kunni nazoratda tuting."
        }
        show(context, "HabitCore", "⏱ $text")
    }

    private suspend fun showDailyResult(context: Context, lang: AppLanguage) {
        val day = LocalDate.now().minusDays(1)
        val percent = scoreForDays(context, listOf(day))
        show(context, resultTitle(lang, "day"), resultText(lang, percent))
    }

    private suspend fun showWeeklyResult(context: Context, lang: AppLanguage) {
        val end = LocalDate.now().with(TemporalAdjusters.previous(DayOfWeek.MONDAY)).minusDays(1)
        val start = end.minusDays(6)
        val days = generateSequence(start) { if (it < end) it.plusDays(1) else null }.toList()
        val percent = scoreForDays(context, days)
        show(context, resultTitle(lang, "week"), resultText(lang, percent))
    }

    private suspend fun showMonthlyResult(context: Context, lang: AppLanguage) {
        val month = YearMonth.from(LocalDate.now()).minusMonths(1)
        val days = (1..month.lengthOfMonth()).map { month.atDay(it) }
        val percent = scoreForDays(context, days)
        show(context, resultTitle(lang, "month"), resultText(lang, percent))
    }

    private suspend fun scoreForDays(context: Context, days: List<LocalDate>): Int {
        if (days.isEmpty()) return 0
        val dao = AppDatabase.getInstance(context).habitDao()
        val habits = dao.getAllHabitsOnce()
        val entries = dao.getEntriesBetween(days.first().toEpochDay(), days.last().toEpochDay())
        val scores = days.map { Schedule.dailyScore(it, habits, entries) }
        return ScoreCalculator.percent(ScoreCalculator.periodScore(scores))
    }

    private fun resultTitle(lang: AppLanguage, period: String): String = when (lang) {
        AppLanguage.EN -> when (period) { "day" -> "Yesterday"; "week" -> "Last week"; else -> "Last month" }
        AppLanguage.RU -> when (period) { "day" -> "Вчера"; "week" -> "Прошлая неделя"; else -> "Прошлый месяц" }
        AppLanguage.UZ -> when (period) { "day" -> "Kecha"; "week" -> "O‘tgan hafta"; else -> "O‘tgan oy" }
    }

    private fun resultText(lang: AppLanguage, percent: Int): String {
        val emoji = when (percent) { in 0..39 -> "🧭"; in 40..59 -> "⚠️"; in 60..74 -> "🙂"; in 75..89 -> "💪"; else -> "🔥" }
        return when (lang) {
            AppLanguage.EN -> "$emoji Habits: $percent%. Keep the rhythm deliberate."
            AppLanguage.RU -> "$emoji Привычки: $percent%. Сохраняйте осознанный ритм."
            AppLanguage.UZ -> "$emoji Odatlar: $percent%. Ritmni ongli ravishda saqlang."
        }
    }

    private fun show(context: Context, title: String, text: String) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "habitcore_main"
        manager.createNotificationChannel(NotificationChannel(channelId, "HabitCore", NotificationManager.IMPORTANCE_DEFAULT))
        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .build()
        manager.notify((System.currentTimeMillis() % 100000).toInt(), notification)
    }
}
