package com.habitcore.app.data

class HabitRepository(private val dao: HabitDao) {
    val habits = dao.observeHabits()
    val entries = dao.observeEntries()

    suspend fun addHabit(habit: HabitEntity) = dao.insertHabit(habit)
    suspend fun saveEntry(entry: HabitEntryEntity) = dao.saveEntry(entry)
    suspend fun clearEntry(habitId: Long, epochDay: Long) = dao.deleteEntry(habitId, epochDay)
    suspend fun archiveHabit(habitId: Long, epochDay: Long) = dao.archiveHabit(habitId, epochDay)
    suspend fun restoreHabit(habitId: Long) = dao.restoreHabit(habitId)
    suspend fun setPaused(habitId: Long, paused: Boolean, sinceEpochDay: Long?) = dao.setPaused(habitId, paused, sinceEpochDay)
}
