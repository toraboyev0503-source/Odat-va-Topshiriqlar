package com.habitcore.app.domain

enum class HabitType { YES_NO, MEASURABLE }
enum class HabitStatus { DONE, FAILED, UNKNOWN }
enum class FrequencyType { DAILY, EVERY_N_DAYS, TIMES_PER_WEEK, TIMES_PER_MONTH, TIMES_IN_N_DAYS }
enum class PerformanceLevel { RED, YELLOW, BLUE, GREEN }
enum class AppLanguage { EN, RU, UZ }
enum class ThemeChoice { GRAPHITE, SLATE, FOREST, NAVY, SAND, BURGUNDY }
enum class AppMode { SYSTEM, LIGHT, DARK }

data class ReminderSlot(
    val enabled: Boolean,
    val hour: Int,
    val minute: Int
)

data class AppPrefs(
    val language: AppLanguage = AppLanguage.EN,
    val theme: ThemeChoice = ThemeChoice.GRAPHITE,
    val mode: AppMode = AppMode.SYSTEM,
    val celebration: Boolean = true,
    val notificationsEnabled: Boolean = true,
    val reminder1: ReminderSlot = ReminderSlot(true, 9, 0),
    val reminder2: ReminderSlot = ReminderSlot(true, 14, 0),
    val reminder3: ReminderSlot = ReminderSlot(true, 20, 0),
    val resultDaily: Boolean = true,
    val resultWeekly: Boolean = true,
    val resultMonthly: Boolean = true
)
