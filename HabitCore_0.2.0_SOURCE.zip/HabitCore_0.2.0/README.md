# HabitCore 0.2.0

Functional pilot of the Habits module.

Implemented:
- Home: Habits + Tasks placeholder
- Habits screen with last 5 days
- Yes/No and measurable habits
- Daily score and performance colors
- Completion-count circle and <50% red state
- Add habit and frequency options
- Entry dialog: done / failed / ? / notes
- Measurable proportional score (e.g. 70% = 0.7)
- Confetti from tapped habit-day position; toggleable
- Week and month monitoring
- Theme: 6 palettes + System/Light/Dark
- Language: English / Russian / Uzbek; default English
- Notifications: 09:00 / 14:00 / 20:00 editable and individually switchable
- Daily/weekly/monthly result notification scheduling
- Pause, archive and restore
- Room persistence

Tasks module is intentionally a placeholder in this build.
