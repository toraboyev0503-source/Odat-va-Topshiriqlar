import 'dart:math';

List<int> buildExerciseWordOrder({
  required int wordCount,
  required int exerciseNumber,
  Random? random,
}) {
  final order = List<int>.generate(wordCount, (index) => index, growable: false);
  if (exerciseNumber <= 1 || wordCount <= 1) return order;

  final shuffled = List<int>.of(order);
  shuffled.shuffle(random ?? Random());

  // Tasodifiy shuffle juda kam holatda asl tartibni qaytarishi mumkin.
  // 2-mashqdan boshlab tartib albatta farq qilishi uchun buni oldini olamiz.
  var unchanged = true;
  for (var index = 0; index < wordCount; index += 1) {
    if (shuffled[index] != order[index]) {
      unchanged = false;
      break;
    }
  }
  if (unchanged) {
    final first = shuffled.removeAt(0);
    shuffled.add(first);
  }
  return List<int>.unmodifiable(shuffled);
}
