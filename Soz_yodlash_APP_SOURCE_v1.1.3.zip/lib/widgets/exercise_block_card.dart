import 'dart:async';

import 'package:flutter/material.dart';

import '../models/lesson.dart';
import '../models/practice.dart';
import '../theme/app_theme.dart';
import '../utils/exercise_order.dart';

class ExerciseBlockCard extends StatefulWidget {
  const ExerciseBlockCard({
    super.key,
    required this.exerciseNumber,
    required this.block,
    required this.words,
    required this.isExpanded,
    required this.onExpansionChanged,
    required this.onTranslationVisibilityChanged,
    required this.onAnswerChanged,
    required this.onScoreChanged,
    required this.onExerciseCompleted,
    this.onDelete,
  });

  final int exerciseNumber;
  final PracticeBlock block;
  final List<WordPair> words;
  final bool isExpanded;
  final ValueChanged<bool> onExpansionChanged;
  final Future<void> Function(bool showTranslations)
  onTranslationVisibilityChanged;
  final Future<void> Function(ExerciseAnswer answer) onAnswerChanged;
  final VoidCallback onScoreChanged;
  final Future<void> Function() onExerciseCompleted;
  final VoidCallback? onDelete;

  @override
  State<ExerciseBlockCard> createState() => _ExerciseBlockCardState();
}

class _ExerciseBlockCardState extends State<ExerciseBlockCard> {
  late List<int> _displayOrder;

  @override
  void initState() {
    super.initState();
    _prepareDisplayOrder();
  }

  @override
  void didUpdateWidget(covariant ExerciseBlockCard oldWidget) {
    super.didUpdateWidget(oldWidget);
    final justOpened = !oldWidget.isExpanded && widget.isExpanded;
    final exerciseChanged = oldWidget.exerciseNumber != widget.exerciseNumber ||
        oldWidget.words.length != widget.words.length;
    if (justOpened || exerciseChanged) {
      _prepareDisplayOrder();
    }
  }

  void _prepareDisplayOrder() {
    _displayOrder = buildExerciseWordOrder(
      wordCount: widget.words.length,
      exerciseNumber: widget.exerciseNumber,
    );
  }

  void _toggleTranslations() {
    setState(() {
      widget.block.showTranslations = !widget.block.showTranslations;
    });
    unawaited(
      widget.onTranslationVisibilityChanged(widget.block.showTranslations),
    );
  }

  void _cycleResult(int wordIndex) {
    final wasComplete = widget.block.isComplete;
    final answer = widget.block.answers[wordIndex];
    setState(() {
      answer.result = answer.result.next;
    });
    final becameComplete = !wasComplete && widget.block.isComplete;
    widget.onScoreChanged();
    unawaited(_persistResult(answer, becameComplete));
  }

  Future<void> _persistResult(
    ExerciseAnswer answer,
    bool becameComplete,
  ) async {
    await widget.onAnswerChanged(answer);
    if (becameComplete) {
      await widget.onExerciseCompleted();
    }
  }

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    return Card(
      margin: EdgeInsets.zero,
      elevation: 0,
      color: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(18),
        side: const BorderSide(color: Color(0xFFDDE2EE)),
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        children: [
          ListTile(
            onTap: () => widget.onExpansionChanged(!widget.isExpanded),
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
            leading: Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                color: colorScheme.primary.withAlpha(25),
                borderRadius: BorderRadius.circular(12),
              ),
              alignment: Alignment.center,
              child: Text(
                '${widget.exerciseNumber}',
                style: TextStyle(
                  color: colorScheme.primary,
                  fontSize: 17,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
            title: Text(
              '${widget.exerciseNumber}-mashq',
              style: const TextStyle(fontWeight: FontWeight.w800),
            ),
            subtitle: Text(_subtitle()),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (widget.onDelete != null)
                  IconButton(
                    onPressed: widget.onDelete,
                    tooltip: 'Mashqni o‘chirish',
                    icon: Icon(
                      Icons.delete_outline_rounded,
                      color: colorScheme.error,
                    ),
                  ),
                Icon(
                  widget.isExpanded
                      ? Icons.expand_less_rounded
                      : Icons.expand_more_rounded,
                ),
              ],
            ),
          ),
          if (widget.isExpanded)
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 0, 14, 16),
              child: Column(
                children: [
                  _TranslationToggle(
                    showTranslations: widget.block.showTranslations,
                    onTap: _toggleTranslations,
                  ),
                  const SizedBox(height: 10),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'Har bir so‘zdagi bo‘sh belgini bosing: bo‘sh → ✓ → ✕.',
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: const Color(0xFF687083),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  _ExerciseWordList(
                    order: _displayOrder,
                    words: widget.words,
                    answers: widget.block.answers,
                    showTranslations: widget.block.showTranslations,
                    onResultTap: _cycleResult,
                    onAnswerChanged: widget.onAnswerChanged,
                  ),
                  const SizedBox(height: 14),
                  _ScorePanel(block: widget.block),
                ],
              ),
            ),
        ],
      ),
    );
  }

  String _subtitle() {
    if (widget.block.isComplete) {
      return '${widget.block.score.round()}% • ${widget.block.correctCount}/${widget.block.answers.length} to‘g‘ri';
    }
    if (widget.block.markedCount > 0) {
      return '${widget.block.markedCount}/${widget.block.answers.length} ta belgilandi';
    }
    return '${widget.block.answers.length} ta so‘z';
  }
}

class _ExerciseWordList extends StatelessWidget {
  const _ExerciseWordList({
    required this.order,
    required this.words,
    required this.answers,
    required this.showTranslations,
    required this.onResultTap,
    required this.onAnswerChanged,
  });

  final List<int> order;
  final List<WordPair> words;
  final List<ExerciseAnswer> answers;
  final bool showTranslations;
  final ValueChanged<int> onResultTap;
  final Future<void> Function(ExerciseAnswer answer) onAnswerChanged;

  @override
  Widget build(BuildContext context) {
    // Oddiy darslarda (odatda ~12 so‘z) sahifaning tabiiy scrolli qoladi.
    if (order.length <= 24) {
      return Column(
        children: [
          for (var displayIndex = 0; displayIndex < order.length; displayIndex++) ...[
            _buildRow(context, displayIndex),
            if (displayIndex != order.length - 1) const SizedBox(height: 10),
          ],
        ],
      );
    }

    // Takrorlash darslarida 90–110 ta TextFieldni birdan yaratmaymiz.
    // Faqat ekranda ko‘rinayotgan qatorlar quriladi.
    final height = (MediaQuery.sizeOf(context).height * 0.66)
        .clamp(420.0, 620.0)
        .toDouble();
    return SizedBox(
      height: height,
      child: ListView.separated(
        primary: false,
        keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
        itemCount: order.length,
        separatorBuilder: (_, __) => const SizedBox(height: 10),
        itemBuilder: (context, displayIndex) => _buildRow(context, displayIndex),
      ),
    );
  }

  Widget _buildRow(BuildContext context, int displayIndex) {
    final wordIndex = order[displayIndex];
    return _ExerciseWordRow(
      key: ValueKey('exercise-word-$wordIndex'),
      displayIndex: displayIndex,
      word: words[wordIndex],
      showTranslation: showTranslations,
      answer: answers[wordIndex],
      isLast: displayIndex == order.length - 1,
      onResultTap: () => onResultTap(wordIndex),
      onAnswerChanged: onAnswerChanged,
    );
  }
}

class _TranslationToggle extends StatelessWidget {
  const _TranslationToggle({
    required this.showTranslations,
    required this.onTap,
  });

  final bool showTranslations;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final color = showTranslations ? AppTheme.success : AppTheme.danger;
    return Material(
      color: color.withAlpha(18),
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 11),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: color.withAlpha(90)),
          ),
          child: Row(
            children: [
              Container(
                width: 30,
                height: 30,
                decoration: BoxDecoration(color: color, shape: BoxShape.circle),
                alignment: Alignment.center,
                child: Icon(
                  showTranslations ? Icons.check_rounded : Icons.close_rounded,
                  color: Colors.white,
                  size: 20,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  showTranslations
                      ? 'O‘zbekcha tarjimalar ko‘rinadi'
                      : 'O‘zbekcha tarjimalar yashirilgan',
                  style: TextStyle(color: color, fontWeight: FontWeight.w800),
                ),
              ),
              Icon(Icons.touch_app_rounded, color: color, size: 20),
            ],
          ),
        ),
      ),
    );
  }
}

class _ExerciseWordRow extends StatefulWidget {
  const _ExerciseWordRow({
    super.key,
    required this.displayIndex,
    required this.word,
    required this.showTranslation,
    required this.answer,
    required this.isLast,
    required this.onResultTap,
    required this.onAnswerChanged,
  });

  final int displayIndex;
  final WordPair word;
  final bool showTranslation;
  final ExerciseAnswer answer;
  final bool isLast;
  final VoidCallback onResultTap;
  final Future<void> Function(ExerciseAnswer answer) onAnswerChanged;

  @override
  State<_ExerciseWordRow> createState() => _ExerciseWordRowState();
}

class _ExerciseWordRowState extends State<_ExerciseWordRow> {
  late final TextEditingController _controller;
  Timer? _saveDebounce;
  bool _hasPendingSave = false;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.answer.answerText);
  }

  @override
  void didUpdateWidget(covariant _ExerciseWordRow oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.answer.wordIndex != widget.answer.wordIndex &&
        _controller.text != widget.answer.answerText) {
      _controller.value = TextEditingValue(
        text: widget.answer.answerText,
        selection: TextSelection.collapsed(offset: widget.answer.answerText.length),
      );
    }
  }

  void _queueSave(String value) {
    widget.answer.answerText = value;
    _hasPendingSave = true;
    _saveDebounce?.cancel();
    _saveDebounce = Timer(const Duration(milliseconds: 320), _flushSave);
  }

  void _flushSave() {
    _saveDebounce?.cancel();
    _saveDebounce = null;
    if (!_hasPendingSave) return;
    _hasPendingSave = false;
    unawaited(widget.onAnswerChanged(widget.answer));
  }

  @override
  void dispose() {
    _flushSave();
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFF8F9FC),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE3E7F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 34,
                height: 34,
                decoration: const BoxDecoration(
                  color: Color(0xFFE8ECF7),
                  shape: BoxShape.circle,
                ),
                alignment: Alignment.center,
                child: Text(
                  '${widget.displayIndex + 1}',
                  style: const TextStyle(
                    color: Color(0xFF46516A),
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.word.english,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                        color: Color(0xFF20283A),
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      widget.showTranslation
                          ? widget.word.uzbek
                          : 'Tarjima yashirilgan',
                      style: TextStyle(
                        color: widget.showTranslation
                            ? const Color(0xFF555E71)
                            : const Color(0xFF9299A8),
                        fontStyle: widget.showTranslation
                            ? FontStyle.normal
                            : FontStyle.italic,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              _ResultButton(result: widget.answer.result, onTap: widget.onResultTap),
            ],
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _controller,
            textInputAction:
                widget.isLast ? TextInputAction.done : TextInputAction.next,
            autocorrect: false,
            enableSuggestions: false,
            decoration: const InputDecoration(
              labelText: 'Javobingiz',
              hintText: 'Tarjimasini eslab yozing',
              isDense: true,
            ),
            onChanged: _queueSave,
            onSubmitted: (_) {
              _flushSave();
              if (widget.isLast) {
                FocusScope.of(context).unfocus();
              } else {
                FocusScope.of(context).nextFocus();
              }
            },
            onTapOutside: (_) {
              _flushSave();
              FocusScope.of(context).unfocus();
            },
          ),
        ],
      ),
    );
  }
}

class _ResultButton extends StatelessWidget {
  const _ResultButton({required this.result, required this.onTap});

  final AnswerResult result;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final (color, icon, label) = switch (result) {
      AnswerResult.correct => (
        AppTheme.success,
        Icons.check_rounded,
        'To‘g‘ri',
      ),
      AnswerResult.wrong => (AppTheme.danger, Icons.close_rounded, 'Noto‘g‘ri'),
      AnswerResult.unmarked => (
        const Color(0xFF8790A3),
        Icons.horizontal_rule_rounded,
        'Bo‘sh',
      ),
    };

    return Tooltip(
      message: label,
      child: Material(
        color: color.withAlpha(18),
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(12),
          child: Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: color.withAlpha(90)),
            ),
            alignment: Alignment.center,
            child: Icon(icon, color: color, size: 28),
          ),
        ),
      ),
    );
  }
}

class _ScorePanel extends StatelessWidget {
  const _ScorePanel({required this.block});

  final PracticeBlock block;

  @override
  Widget build(BuildContext context) {
    final completed = block.isComplete;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: completed
            ? AppTheme.success.withAlpha(14)
            : const Color(0xFFF2F4F9),
        borderRadius: BorderRadius.circular(14),
      ),
      child: completed
          ? Row(
              children: [
                Icon(Icons.insights_rounded, color: AppTheme.success),
                const SizedBox(width: 9),
                Expanded(
                  child: Text(
                    'Natija: ${block.score.round()}% • ${block.correctCount} to‘g‘ri • ${block.wrongCount} noto‘g‘ri',
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                ),
              ],
            )
          : Text(
              'Natija mashqdagi barcha so‘zlar ✓ yoki ✕ bilan belgilangandan keyin hisoblanadi.',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: const Color(0xFF687083),
                height: 1.4,
              ),
            ),
    );
  }
}
