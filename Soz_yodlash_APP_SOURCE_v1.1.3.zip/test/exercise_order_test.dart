import 'dart:math';

import 'package:flutter_test/flutter_test.dart';
import 'package:soz_yodlash/utils/exercise_order.dart';

void main() {
  test('birinchi mashq lugat tartibini saqlaydi', () {
    expect(
      buildExerciseWordOrder(wordCount: 6, exerciseNumber: 1),
      [0, 1, 2, 3, 4, 5],
    );
  });

  test('keyingi mashq aralash va toliq permutatsiya boladi', () {
    final order = buildExerciseWordOrder(
      wordCount: 8,
      exerciseNumber: 2,
      random: Random(42),
    );

    expect(order, isNot([0, 1, 2, 3, 4, 5, 6, 7]));
    expect(order.toList()..sort(), [0, 1, 2, 3, 4, 5, 6, 7]);
  });
}
