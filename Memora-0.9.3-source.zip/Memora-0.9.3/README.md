# Memora 0.9.3 Play Release Candidate

Memora is a private, local-first Android journal for short and long notes. The
launcher and in-app name are **Memora**; the intended Google Play listing title
is **Memora – Private Journal**.

## Release configuration

- Android application ID: `com.memora.app`
- `versionName`: `0.9.3`; `versionCode`: `23`
- `compileSdk` / `targetSdk`: 36
- `minSdk`: 26 (Android 8.0+)
- Google Play Billing product: `memora_premium`
- Base plans: `monthly`, `quarterly`, `semiannual`, `annual`
- 1-month trial offer tag: `memora-free-trial`
- Paragraph gap: exactly 60% of line-height through `ParagraphMetrics.GAP_RATIO`

## Privacy model

Notes, titles, images, audio, statistics and backup contents stay in the app's
private storage. Android cloud/device backup is disabled. The only app network
traffic is Google Play Billing and a purchase-verification HTTPS request containing
`packageName`, `productId` and the Google Play `purchaseToken`. There are no ads,
analytics or crash-tracking SDKs.

An active subscription permits create/edit/delete/import. Expiry switches Memora
to read-only: existing notes, search, statistics, media playback and HTML/Word/
Memora exports remain available. A successfully verified entitlement is cached,
encrypted by Android Keystore, for at most seven offline days and never beyond the
subscription expiry reported by Google Play.

## Build and test

Use JDK 17 and the official, checksum-pinned Gradle 8.13 wrapper:

```bash
./gradlew testDebugUnitTest
./gradlew lintRelease
```

Debug builds use a normal machine-local Android debug key and enable a debug-only
entitlement so UI development does not require a Play test purchase. Release builds
never enable it. A release bundle fails unless the following environment variables
are supplied:

- `MEMORA_KEYSTORE_PATH`
- `MEMORA_KEYSTORE_PASSWORD`
- `MEMORA_KEY_ALIAS`
- `MEMORA_KEY_PASSWORD`
- `MEMORA_BILLING_VERIFICATION_URL` (must be HTTPS)

No signing key, password, service-account key or environment file belongs in Git.
See `docs/PLAY_CONSOLE_SETUP.md`, `docs/PRODUCTION_AUDIT.md`, and `backend/README.md`.
