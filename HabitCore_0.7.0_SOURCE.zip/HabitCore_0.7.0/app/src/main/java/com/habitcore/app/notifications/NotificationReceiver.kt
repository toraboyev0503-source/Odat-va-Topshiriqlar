package com.habitcore.app.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.habitcore.app.data.AppDatabase
import com.habitcore.app.data.PreferenceStore
import com.habitcore.app.data.TaskRepository
import com.habitcore.app.domain.AppLanguage
import com.habitcore.app.domain.Schedule
import com.habitcore.app.domain.TaskScoring
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.TemporalAdjusters
import kotlin.math.roundToInt

class NotificationReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pending = goAsync()
        val type = intent.getStringExtra("type") ?: return pending.finish()
        val appContext = context.applicationContext

        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                val prefs = PreferenceStore(appContext).load()
                TaskRepository(
                    AppDatabase.getInstance(appContext).taskDao()
                ).ensureCarryoverPlans(LocalDate.now())

                when (type) {
                    NotificationScheduler.TYPE_R1,
                    NotificationScheduler.TYPE_R2,
                    NotificationScheduler.TYPE_R3 -> {
                        showReminder(appContext, prefs.language)
                    }

                    NotificationScheduler.TYPE_DAILY -> {
                        val day = LocalDate.now().minusDays(1)
                        showResult(
                            appContext,
                            prefs.language,
                            "day",
                            listOf(day)
                        )
                    }

                    NotificationScheduler.TYPE_WEEKLY -> {
                        val end = LocalDate.now()
                            .with(TemporalAdjusters.previous(DayOfWeek.MONDAY))
                            .minusDays(1)
                        val start = end.minusDays(6)

                        val days = generateSequence(start) {
                            if (it < end) it.plusDays(1) else null
                        }.toList()

                        showResult(
                            appContext,
                            prefs.language,
                            "week",
                            days
                        )
                    }

                    NotificationScheduler.TYPE_MONTHLY -> {
                        val month = YearMonth
                            .from(LocalDate.now())
                            .minusMonths(1)

                        val days = (1..month.lengthOfMonth())
                            .map { month.atDay(it) }

                        showResult(
                            appContext,
                            prefs.language,
                            "month",
                            days
                        )
                    }
                }

                NotificationScheduler.scheduleType(
                    appContext,
                    type,
                    prefs
                )
            } finally {
                pending.finish()
            }
        }
    }

    private fun showReminder(
        context: Context,
        lang: AppLanguage
    ) {
        val text = when (lang) {
            AppLanguage.EN ->
                "Check habits and tasks. Keep the day deliberate."

            AppLanguage.RU ->
                "Проверьте привычки и задачи. Держите день под контролем."

            AppLanguage.UZ ->
                "Odatlar va vazifalarni ko‘rib chiqing. Kunni nazoratda tuting."
        }

        show(
            context,
            "HabitCore",
            "⏱ $text"
        )
    }

    private suspend fun showResult(
        context: Context,
        lang: AppLanguage,
        period: String,
        days: List<LocalDate>
    ) {
        val db = AppDatabase.getInstance(context)
        val allHabits = db.habitDao().getAllHabitsOnce()

        val habitEntries = if (days.isEmpty()) {
            emptyList()
        } else {
            db.habitDao().getEntriesBetween(
                days.first().toEpochDay(),
                days.last().toEpochDay()
            )
        }

        val habitScores = days
            .map { day ->
                Schedule.dailyScore(
                    day,
                    allHabits,
                    habitEntries
                )
            }
            .filterNotNull()

        val habitPercent = if (habitScores.isEmpty()) {
            null
        } else {
            (habitScores.average() * 100.0).roundToInt()
        }

        val taskPlans = if (days.isEmpty()) {
            emptyList()
        } else {
            db.taskDao().getPlansBetween(
                days.first().toEpochDay(),
                days.last().toEpochDay()
            )
        }

        val taskPercent = TaskScoring.percent(
            TaskScoring.periodScore(
                days,
                taskPlans
            )
        )

        val allPercents = listOfNotNull(
            habitPercent,
            taskPercent
        )

        val overall = if (allPercents.isEmpty()) {
            0
        } else {
            allPercents.average().roundToInt()
        }

        val emoji = when (overall) {
            in 0..39 -> "🧭"
            in 40..59 -> "⚠️"
            in 60..74 -> "🙂"
            in 75..89 -> "💪"
            else -> "🔥"
        }

        val title = when (lang) {
            AppLanguage.EN -> when (period) {
                "day" -> "Yesterday"
                "week" -> "Last week"
                else -> "Last month"
            }

            AppLanguage.RU -> when (period) {
                "day" -> "Вчера"
                "week" -> "Прошлая неделя"
                else -> "Прошлый месяц"
            }

            AppLanguage.UZ -> when (period) {
                "day" -> "Kecha"
                "week" -> "O‘tgan hafta"
                else -> "O‘tgan oy"
            }
        }

        val habitPart = habitPercent?.let {
            when (lang) {
                AppLanguage.EN -> "Habits $it%"
                AppLanguage.RU -> "Привычки $it%"
                AppLanguage.UZ -> "Odatlar $it%"
            }
        }

        val taskPart = taskPercent?.let {
            when (lang) {
                AppLanguage.EN -> "Tasks $it%"
                AppLanguage.RU -> "Задачи $it%"
                AppLanguage.UZ -> "Vazifalar $it%"
            }
        }

        val resultParts = listOfNotNull(
            habitPart,
            taskPart
        )

        val tail = when (lang) {
            AppLanguage.EN ->
                "Keep the rhythm deliberate."

            AppLanguage.RU ->
                "Сохраняйте осознанный ритм."

            AppLanguage.UZ ->
                "Ritmni ongli saqlang."
        }

        val body = if (resultParts.isEmpty()) {
            "$emoji —"
        } else {
            "$emoji ${
                resultParts.joinToString(" · ")
            }. $tail"
        }

        show(
            context,
            title,
            body
        )
    }

    private fun show(
        context: Context,
        title: String,
        text: String
    ) {
        val manager = context.getSystemService(
            Context.NOTIFICATION_SERVICE
        ) as NotificationManager

        val channelId = "habitcore_main"

        manager.createNotificationChannel(
            NotificationChannel(
                channelId,
                "HabitCore",
                NotificationManager.IMPORTANCE_DEFAULT
            )
        )

        val notification = NotificationCompat.Builder(
            context,
            channelId
        )
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText(text)
            )
            .setAutoCancel(true)
            .build()

        manager.notify(
            (System.currentTimeMillis() % 100000).toInt(),
            notification
        )
    }
}
