@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.habitcore.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun TaskDayDetailScreen(
    vm: AppViewModel,
    day: LocalDate,
    onBack: () -> Unit
) {
    val tasks by vm.tasks.collectAsState()
    val plans by vm.taskPlans.collectAsState()
    val prefs by vm.prefs.collectAsState()

    val completedIds = plans
        .asSequence()
        .filter {
            it.epochDay == day.toEpochDay() &&
                it.completed
        }
        .map { it.taskId }
        .toSet()

    val completedTasks = tasks
        .filter { it.id in completedIds }
        .sortedBy { it.createdAtMillis }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        day.format(
                            DateTimeFormatter.ofPattern(
                                "dd.MM.yyyy",
                                Locale.getDefault()
                            )
                        )
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            Icons.Outlined.ArrowBack,
                            null
                        )
                    }
                },
                actions = {
                    Text(
                        "${completedTasks.size} ${tr(prefs.language, "done")}",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(end = 14.dp)
                    )
                }
            )
        }
    ) { padding ->
        if (completedTasks.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    "—",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentPadding =
                    androidx.compose.foundation.layout.PaddingValues(
                        horizontal = 12.dp,
                        vertical = 8.dp
                    ),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(
                    completedTasks,
                    key = { it.id }
                ) { task ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = appShape(),
                        border = BorderStroke(
                            appBorderWidth(),
                            MaterialTheme.colorScheme.outlineVariant
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(
                                Icons.Outlined.CheckCircle,
                                null,
                                tint = MaterialTheme.colorScheme.primary
                            )

                            Text(
                                task.text,
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(start = 12.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
