package com.habitcore.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.habitcore.app.domain.AppMode
import com.habitcore.app.domain.ThemeChoice

@Immutable
data class AppVisualSpec(
    val cardRadius: Dp,
    val fieldRadius: Dp,
    val borderWidth: Dp,
    val compact: Boolean,
    val uppercaseLabels: Boolean,
    val strongDividers: Boolean
)

val LocalAppVisualSpec = staticCompositionLocalOf {
    AppVisualSpec(
        cardRadius = 0.dp,
        fieldRadius = 0.dp,
        borderWidth = 1.dp,
        compact = true,
        uppercaseLabels = false,
        strongDividers = false
    )
}

private data class AccentPair(
    val primary: Color,
    val secondary: Color,
    val tertiary: Color
)

private data class ThemeBase(
    val lightBackground: Color,
    val lightSurface: Color,
    val lightSurfaceVariant: Color,
    val lightOutline: Color,
    val darkBackground: Color,
    val darkSurface: Color,
    val darkSurfaceVariant: Color,
    val darkOutline: Color,
    val fontFamily: FontFamily,
    val titleWeight: FontWeight,
    val bodyWeight: FontWeight,
    val letterSpacing: Float,
    val spec: AppVisualSpec
)

private fun accents(choice: ThemeChoice): List<AccentPair> = when (choice) {
    ThemeChoice.GRAPHITE -> listOf(
        AccentPair(Color(0xFF4D535A), Color(0xFF747B83), Color(0xFF8D755D)),
        AccentPair(Color(0xFF2F5F73), Color(0xFF668492), Color(0xFF9D7B59)),
        AccentPair(Color(0xFF435F4C), Color(0xFF728678), Color(0xFF9A7B56)),
        AccentPair(Color(0xFF6A4D57), Color(0xFF91727C), Color(0xFF997A50))
    )
    ThemeChoice.SLATE -> listOf(
        AccentPair(Color(0xFF536A77), Color(0xFF718994), Color(0xFF6C8091)),
        AccentPair(Color(0xFF3F628E), Color(0xFF6987AA), Color(0xFF7A7197)),
        AccentPair(Color(0xFF3D756F), Color(0xFF6E9690), Color(0xFF807A5E)),
        AccentPair(Color(0xFF6A5A83), Color(0xFF8B7CA1), Color(0xFF6F7D95))
    )
    ThemeChoice.FOREST -> listOf(
        AccentPair(Color(0xFF426A52), Color(0xFF6E8A77), Color(0xFF8E7951)),
        AccentPair(Color(0xFF355F4B), Color(0xFF628473), Color(0xFF9C6B4F)),
        AccentPair(Color(0xFF4D6C3A), Color(0xFF7C905F), Color(0xFF82704A)),
        AccentPair(Color(0xFF2F6A63), Color(0xFF5D8B83), Color(0xFF8C7656))
    )
    ThemeChoice.NAVY -> listOf(
        AccentPair(Color(0xFF465D84), Color(0xFF6E82A3), Color(0xFF9A7A55)),
        AccentPair(Color(0xFF2F4F79), Color(0xFF617AA2), Color(0xFF8B5F72)),
        AccentPair(Color(0xFF385A6D), Color(0xFF6B8290), Color(0xFF8E7A56)),
        AccentPair(Color(0xFF514D82), Color(0xFF7773A0), Color(0xFF9B725A))
    )
    ThemeChoice.SAND -> listOf(
        AccentPair(Color(0xFF7B6A4B), Color(0xFF9A896A), Color(0xFF6A7B6D)),
        AccentPair(Color(0xFF826245), Color(0xFFA47F61), Color(0xFF6D7661)),
        AccentPair(Color(0xFF6B7053), Color(0xFF8B8B6A), Color(0xFF8B6D55)),
        AccentPair(Color(0xFF755B52), Color(0xFF99786F), Color(0xFF77755A))
    )
    ThemeChoice.BURGUNDY -> listOf(
        AccentPair(Color(0xFF7E4E5A), Color(0xFF9A707A), Color(0xFF8D7651)),
        AccentPair(Color(0xFF6F4554), Color(0xFF956A78), Color(0xFF6E718A)),
        AccentPair(Color(0xFF77484B), Color(0xFF9C6A6D), Color(0xFF867257)),
        AccentPair(Color(0xFF684F6F), Color(0xFF8D7491), Color(0xFF8B6A52))
    )
    ThemeChoice.MATERIAL -> listOf(
        AccentPair(Color(0xFF3F5F90), Color(0xFF6D7FA1), Color(0xFF7C6A91)),
        AccentPair(Color(0xFF006B5F), Color(0xFF4F857C), Color(0xFF7B6C50)),
        AccentPair(Color(0xFF7A526B), Color(0xFF9A7487), Color(0xFF7A7459)),
        AccentPair(Color(0xFF625B71), Color(0xFF7D748A), Color(0xFF7D6F55))
    )
    ThemeChoice.NEOBRUTAL -> listOf(
        AccentPair(Color(0xFF1D1D1D), Color(0xFF4C4C4C), Color(0xFFFFC857)),
        AccentPair(Color(0xFF152D50), Color(0xFF385C84), Color(0xFFFFB84D)),
        AccentPair(Color(0xFF214A37), Color(0xFF4D775F), Color(0xFFF5C15C)),
        AccentPair(Color(0xFF5A2436), Color(0xFF834A5A), Color(0xFFF0B84C))
    )
    ThemeChoice.SOFT -> listOf(
        AccentPair(Color(0xFF6A718C), Color(0xFF8C92A8), Color(0xFFAA8F93)),
        AccentPair(Color(0xFF5F7C73), Color(0xFF81978F), Color(0xFFA58D78)),
        AccentPair(Color(0xFF8A6D82), Color(0xFFA88DA1), Color(0xFF8E9478)),
        AccentPair(Color(0xFF6E7F96), Color(0xFF8FA0B2), Color(0xFFA58E73))
    )
    ThemeChoice.MONO -> listOf(
        AccentPair(Color(0xFF202020), Color(0xFF5C5C5C), Color(0xFF7A7A7A)),
        AccentPair(Color(0xFF313131), Color(0xFF666666), Color(0xFF8A8A8A)),
        AccentPair(Color(0xFF1D2730), Color(0xFF59636B), Color(0xFF7B858D)),
        AccentPair(Color(0xFF2C2926), Color(0xFF625E59), Color(0xFF8A847C))
    )
}

private fun base(choice: ThemeChoice): ThemeBase = when (choice) {
    ThemeChoice.GRAPHITE -> ThemeBase(
        Color(0xFFF7F7F6), Color.White, Color(0xFFF0F1F1), Color(0xFFD4D6D8),
        Color(0xFF111315), Color(0xFF1A1D20), Color(0xFF22262A), Color(0xFF444A50),
        FontFamily.SansSerif, FontWeight.SemiBold, FontWeight.Normal, 0f,
        AppVisualSpec(0.dp, 0.dp, 1.dp, true, false, false)
    )
    ThemeChoice.SLATE -> ThemeBase(
        Color(0xFFF4F7F8), Color.White, Color(0xFFE9EFF2), Color(0xFFC8D1D6),
        Color(0xFF10161A), Color(0xFF182126), Color(0xFF202B31), Color(0xFF46545B),
        FontFamily.SansSerif, FontWeight.Medium, FontWeight.Normal, 0.05f,
        AppVisualSpec(10.dp, 10.dp, 1.dp, false, false, false)
    )
    ThemeChoice.FOREST -> ThemeBase(
        Color(0xFFF5F8F5), Color(0xFFFCFEFC), Color(0xFFEAF1EC), Color(0xFFC8D5CB),
        Color(0xFF101612), Color(0xFF18211B), Color(0xFF202A23), Color(0xFF435247),
        FontFamily.SansSerif, FontWeight.SemiBold, FontWeight.Normal, 0f,
        AppVisualSpec(6.dp, 6.dp, 1.dp, false, false, false)
    )
    ThemeChoice.NAVY -> ThemeBase(
        Color(0xFFF5F7FA), Color.White, Color(0xFFE9EDF4), Color(0xFFC8D0DD),
        Color(0xFF10141B), Color(0xFF181E28), Color(0xFF222A36), Color(0xFF465164),
        FontFamily.SansSerif, FontWeight.Bold, FontWeight.Normal, 0.02f,
        AppVisualSpec(2.dp, 2.dp, 1.dp, true, true, true)
    )
    ThemeChoice.SAND -> ThemeBase(
        Color(0xFFFAF8F3), Color(0xFFFFFDF8), Color(0xFFF2ECE1), Color(0xFFD9CDBA),
        Color(0xFF18150F), Color(0xFF211D16), Color(0xFF2A251D), Color(0xFF534B3D),
        FontFamily.Serif, FontWeight.Medium, FontWeight.Normal, 0.01f,
        AppVisualSpec(16.dp, 14.dp, 1.dp, false, false, false)
    )
    ThemeChoice.BURGUNDY -> ThemeBase(
        Color(0xFFFAF5F6), Color(0xFFFFFBFC), Color(0xFFF3E9EC), Color(0xFFDAC7CD),
        Color(0xFF191113), Color(0xFF23181B), Color(0xFF2E2024), Color(0xFF5A454C),
        FontFamily.Serif, FontWeight.SemiBold, FontWeight.Normal, 0.03f,
        AppVisualSpec(4.dp, 4.dp, 1.dp, false, false, true)
    )
    ThemeChoice.MATERIAL -> ThemeBase(
        Color(0xFFF9F9FC), Color(0xFFFFFBFF), Color(0xFFEDEEF5), Color(0xFFCACBD3),
        Color(0xFF111318), Color(0xFF1B1B21), Color(0xFF25252C), Color(0xFF484850),
        FontFamily.SansSerif, FontWeight.Medium, FontWeight.Normal, 0f,
        AppVisualSpec(12.dp, 12.dp, 1.dp, false, false, false)
    )
    ThemeChoice.NEOBRUTAL -> ThemeBase(
        Color(0xFFF8F7F2), Color(0xFFFFFEFA), Color(0xFFECEBE4), Color(0xFF202020),
        Color(0xFF121212), Color(0xFF1E1E1E), Color(0xFF292929), Color(0xFFE2E2E2),
        FontFamily.SansSerif, FontWeight.Black, FontWeight.Medium, 0.08f,
        AppVisualSpec(0.dp, 0.dp, 2.dp, true, true, true)
    )
    ThemeChoice.SOFT -> ThemeBase(
        Color(0xFFF8F7FA), Color(0xFFFFFDFF), Color(0xFFF0ECF3), Color(0xFFD8D1DD),
        Color(0xFF141317), Color(0xFF201E24), Color(0xFF2B2830), Color(0xFF514B58),
        FontFamily.SansSerif, FontWeight.Medium, FontWeight.Normal, 0f,
        AppVisualSpec(22.dp, 18.dp, 1.dp, false, false, false)
    )
    ThemeChoice.MONO -> ThemeBase(
        Color(0xFFF7F7F7), Color.White, Color(0xFFEFEFEF), Color(0xFFCBCBCB),
        Color(0xFF101010), Color(0xFF1B1B1B), Color(0xFF242424), Color(0xFF4A4A4A),
        FontFamily.Monospace, FontWeight.Bold, FontWeight.Normal, 0.04f,
        AppVisualSpec(0.dp, 0.dp, 1.dp, true, true, true)
    )
}

private fun appTypography(base: ThemeBase): Typography {
    val family = base.fontFamily
    return Typography(
        headlineLarge = TextStyle(
            fontFamily = family,
            fontWeight = base.titleWeight,
            fontSize = 32.sp,
            letterSpacing = base.letterSpacing.sp
        ),
        headlineMedium = TextStyle(
            fontFamily = family,
            fontWeight = base.titleWeight,
            fontSize = 28.sp,
            letterSpacing = base.letterSpacing.sp
        ),
        titleLarge = TextStyle(
            fontFamily = family,
            fontWeight = base.titleWeight,
            fontSize = 22.sp,
            letterSpacing = base.letterSpacing.sp
        ),
        titleMedium = TextStyle(
            fontFamily = family,
            fontWeight = base.titleWeight,
            fontSize = 16.sp,
            letterSpacing = base.letterSpacing.sp
        ),
        bodyLarge = TextStyle(
            fontFamily = family,
            fontWeight = base.bodyWeight,
            fontSize = 16.sp
        ),
        bodyMedium = TextStyle(
            fontFamily = family,
            fontWeight = base.bodyWeight,
            fontSize = 14.sp
        ),
        labelLarge = TextStyle(
            fontFamily = family,
            fontWeight = if (base.spec.uppercaseLabels) FontWeight.Bold else FontWeight.Medium,
            fontSize = 13.sp,
            letterSpacing = if (base.spec.uppercaseLabels) 0.08.sp else 0.sp
        )
    )
}

private fun appShapes(spec: AppVisualSpec): Shapes = Shapes(
    extraSmall = RoundedCornerShape(spec.fieldRadius),
    small = RoundedCornerShape(spec.fieldRadius),
    medium = RoundedCornerShape(spec.cardRadius),
    large = RoundedCornerShape(spec.cardRadius),
    extraLarge = RoundedCornerShape(spec.cardRadius)
)

@Composable
fun HabitCoreTheme(
    choice: ThemeChoice,
    accent: Int,
    mode: AppMode,
    content: @Composable () -> Unit
) {
    val dark = when (mode) {
        AppMode.LIGHT -> false
        AppMode.DARK -> true
        AppMode.SYSTEM -> isSystemInDarkTheme()
    }

    val base = base(choice)
    val accentPair = accents(choice)[accent.coerceIn(0, 3)]

    val scheme = if (dark) {
        darkColorScheme(
            primary = accentPair.primary.copy(
                red = (accentPair.primary.red + 0.25f).coerceAtMost(1f),
                green = (accentPair.primary.green + 0.25f).coerceAtMost(1f),
                blue = (accentPair.primary.blue + 0.25f).coerceAtMost(1f)
            ),
            secondary = accentPair.secondary.copy(
                red = (accentPair.secondary.red + 0.18f).coerceAtMost(1f),
                green = (accentPair.secondary.green + 0.18f).coerceAtMost(1f),
                blue = (accentPair.secondary.blue + 0.18f).coerceAtMost(1f)
            ),
            tertiary = accentPair.tertiary.copy(
                red = (accentPair.tertiary.red + 0.16f).coerceAtMost(1f),
                green = (accentPair.tertiary.green + 0.16f).coerceAtMost(1f),
                blue = (accentPair.tertiary.blue + 0.16f).coerceAtMost(1f)
            ),
            background = base.darkBackground,
            surface = base.darkSurface,
            surfaceVariant = base.darkSurfaceVariant,
            outline = base.darkOutline
        )
    } else {
        lightColorScheme(
            primary = accentPair.primary,
            secondary = accentPair.secondary,
            tertiary = accentPair.tertiary,
            background = base.lightBackground,
            surface = base.lightSurface,
            surfaceVariant = base.lightSurfaceVariant,
            outline = base.lightOutline
        )
    }

    androidx.compose.runtime.CompositionLocalProvider(
        LocalAppVisualSpec provides base.spec
    ) {
        MaterialTheme(
            colorScheme = scheme,
            typography = appTypography(base),
            shapes = appShapes(base.spec),
            content = content
        )
    }
}

@Composable
fun appShape(): Shape = RoundedCornerShape(LocalAppVisualSpec.current.cardRadius)

@Composable
fun appFieldShape(): Shape = RoundedCornerShape(LocalAppVisualSpec.current.fieldRadius)

@Composable
fun appBorderWidth(): Dp = LocalAppVisualSpec.current.borderWidth

@Composable
fun appCompact(): Boolean = LocalAppVisualSpec.current.compact

fun themeStyleName(choice: ThemeChoice): String = when (choice) {
    ThemeChoice.GRAPHITE -> "Minimal"
    ThemeChoice.SLATE -> "Modern"
    ThemeChoice.FOREST -> "Nordic"
    ThemeChoice.NAVY -> "Executive"
    ThemeChoice.SAND -> "Zen"
    ThemeChoice.BURGUNDY -> "Classic"
    ThemeChoice.MATERIAL -> "Material"
    ThemeChoice.NEOBRUTAL -> "Neo Brutal"
    ThemeChoice.SOFT -> "Soft"
    ThemeChoice.MONO -> "Monochrome"
}

fun themeAccentColors(choice: ThemeChoice): List<Color> =
    accents(choice).map { it.primary }

fun habitColor(index: Int): Long {
    val colors = listOf(
        0xFF4E78A8L,
        0xFF4F7A5CL,
        0xFF8B5E6BL,
        0xFF7B6B4CL,
        0xFF5E6D83L,
        0xFF806A99L,
        0xFF557B78L,
        0xFF8A674FL
    )
    return colors[index.coerceIn(0, colors.lastIndex)]
}
