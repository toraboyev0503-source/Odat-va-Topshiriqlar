package com.habitcore.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Archive
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.EventNote
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.habitcore.app.domain.AppLanguage

@Composable
fun TaskDrawerContent(
    lang: AppLanguage,
    onScheduled: () -> Unit,
    onMonitoring: () -> Unit,
    onArchive: () -> Unit,
    onTheme: () -> Unit,
    onLanguage: () -> Unit,
    onNotifications: () -> Unit,
    onSettings: () -> Unit
) {
    Column(Modifier.fillMaxWidth().padding(top = 16.dp)) {
        Text(tr(lang, "tasks"), style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(16.dp))
        HorizontalDivider()
        Spacer(Modifier.height(8.dp))
        TaskDrawerRow(Icons.Outlined.EventNote, tr(lang, "scheduled"), onScheduled)
        TaskDrawerRow(Icons.Outlined.BarChart, tr(lang, "monitoring"), onMonitoring)
        TaskDrawerRow(Icons.Outlined.Archive, tr(lang, "archive"), onArchive)
        TaskDrawerRow(Icons.Outlined.Palette, tr(lang, "theme"), onTheme)
        TaskDrawerRow(Icons.Outlined.Language, tr(lang, "language"), onLanguage)
        TaskDrawerRow(Icons.Outlined.Notifications, tr(lang, "notifications"), onNotifications)
        TaskDrawerRow(Icons.Outlined.Settings, tr(lang, "settings"), onSettings)
    }
}

@Composable
private fun TaskDrawerRow(icon: ImageVector, text: String, onClick: () -> Unit) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 4.dp)
            .clickable(onClick = onClick),
        shape = appShape(),
        border = BorderStroke(appBorderWidth(), MaterialTheme.colorScheme.outlineVariant),
        color = MaterialTheme.colorScheme.surface
    ) {
        Row(
            Modifier.padding(horizontal = 14.dp, vertical = 15.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
            Text(text, modifier = Modifier.padding(start = 14.dp))
        }
    }
}
