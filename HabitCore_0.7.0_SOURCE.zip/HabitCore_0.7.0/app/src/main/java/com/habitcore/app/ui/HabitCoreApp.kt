package com.habitcore.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.habitcore.app.data.HabitEntity
import java.time.LocalDate

private enum class Screen {
    HABITS,
    CREATE_HABIT,
    HABIT_MONITORING,
    HABIT_DAY_DETAIL,
    HABIT_ARCHIVE,
    TASKS,
    SCHEDULED_TASKS,
    TASK_ARCHIVE,
    TASK_MONITORING,
    TASK_DAY_DETAIL,
    THEME,
    LANGUAGE,
    NOTIFICATIONS,
    SETTINGS
}

@Composable
fun HabitCoreApp(vm: AppViewModel) {
    val prefs by vm.prefs.collectAsState()
    var screen by remember { mutableStateOf(Screen.HABITS) }
    var sharedReturn by remember { mutableStateOf(Screen.HABITS) }
    var editingHabit by remember { mutableStateOf<HabitEntity?>(null) }
    var selectedDay by remember { mutableStateOf(LocalDate.now()) }

    fun openShared(target: Screen, from: Screen) {
        sharedReturn = from
        screen = target
    }

    BackHandler(enabled = screen != Screen.HABITS) {
        when (screen) {
            Screen.HABITS -> Unit
            Screen.TASKS -> screen = Screen.HABITS
            Screen.CREATE_HABIT -> {
                editingHabit = null
                screen = Screen.HABITS
            }
            Screen.HABIT_MONITORING -> screen = Screen.HABITS
            Screen.HABIT_DAY_DETAIL -> screen = Screen.HABIT_MONITORING
            Screen.HABIT_ARCHIVE -> screen = Screen.HABITS
            Screen.SCHEDULED_TASKS -> screen = Screen.TASKS
            Screen.TASK_ARCHIVE -> screen = Screen.TASKS
            Screen.TASK_MONITORING -> screen = Screen.TASKS
            Screen.TASK_DAY_DETAIL -> screen = Screen.TASK_MONITORING
            Screen.THEME,
            Screen.LANGUAGE,
            Screen.NOTIFICATIONS,
            Screen.SETTINGS -> screen = sharedReturn
        }
    }

    HabitCoreTheme(
        prefs.theme,
        prefs.themeAccent,
        prefs.mode
    ) {
        when (screen) {
            Screen.HABITS -> HabitsScreen(
                vm = vm,
                onSwitchSection = { screen = Screen.TASKS },
                onCreate = {
                    editingHabit = null
                    screen = Screen.CREATE_HABIT
                },
                onEditHabit = { habit ->
                    editingHabit = habit
                    screen = Screen.CREATE_HABIT
                },
                onMonitoring = { screen = Screen.HABIT_MONITORING },
                onTheme = { openShared(Screen.THEME, Screen.HABITS) },
                onLanguage = { openShared(Screen.LANGUAGE, Screen.HABITS) },
                onNotifications = { openShared(Screen.NOTIFICATIONS, Screen.HABITS) },
                onArchive = { screen = Screen.HABIT_ARCHIVE },
                onSettings = { openShared(Screen.SETTINGS, Screen.HABITS) }
            )

            Screen.CREATE_HABIT ->
                CreateHabitScreen(
                    vm = vm,
                    categoryId = editingHabit?.categoryId ?: 1L,
                    habitToEdit = editingHabit,
                    onBack = {
                        editingHabit = null
                        screen = Screen.HABITS
                    }
                )

            Screen.HABIT_MONITORING ->
                MonitoringScreen(
                    vm = vm,
                    onBack = { screen = Screen.HABITS },
                    onDaySelected = { day ->
                        selectedDay = day
                        screen = Screen.HABIT_DAY_DETAIL
                    }
                )

            Screen.HABIT_DAY_DETAIL ->
                HabitDayDetailScreen(
                    vm = vm,
                    day = selectedDay,
                    onBack = { screen = Screen.HABIT_MONITORING }
                )

            Screen.HABIT_ARCHIVE ->
                ArchiveScreen(
                    vm = vm,
                    onBack = { screen = Screen.HABITS }
                )

            Screen.TASKS -> TasksScreen(
                vm = vm,
                onSwitchSection = { screen = Screen.HABITS },
                onScheduled = { screen = Screen.SCHEDULED_TASKS },
                onMonitoring = { screen = Screen.TASK_MONITORING },
                onArchive = { screen = Screen.TASK_ARCHIVE },
                onTheme = { openShared(Screen.THEME, Screen.TASKS) },
                onLanguage = { openShared(Screen.LANGUAGE, Screen.TASKS) },
                onNotifications = { openShared(Screen.NOTIFICATIONS, Screen.TASKS) },
                onSettings = { openShared(Screen.SETTINGS, Screen.TASKS) }
            )

            Screen.SCHEDULED_TASKS ->
                ScheduledTasksScreen(
                    vm = vm,
                    onBack = { screen = Screen.TASKS }
                )

            Screen.TASK_ARCHIVE ->
                TaskArchiveScreen(
                    vm = vm,
                    onBack = { screen = Screen.TASKS },
                    onMonitoring = { screen = Screen.TASK_MONITORING }
                )

            Screen.TASK_MONITORING ->
                TaskMonitoringScreen(
                    vm = vm,
                    onBack = { screen = Screen.TASKS },
                    onDaySelected = { day ->
                        selectedDay = day
                        screen = Screen.TASK_DAY_DETAIL
                    }
                )

            Screen.TASK_DAY_DETAIL ->
                TaskDayDetailScreen(
                    vm = vm,
                    day = selectedDay,
                    onBack = { screen = Screen.TASK_MONITORING }
                )

            Screen.THEME ->
                ThemeScreen(
                    vm = vm,
                    onBack = { screen = sharedReturn }
                )

            Screen.LANGUAGE ->
                LanguageScreen(
                    vm = vm,
                    onBack = { screen = sharedReturn }
                )

            Screen.NOTIFICATIONS ->
                NotificationsScreen(
                    vm = vm,
                    onBack = { screen = sharedReturn }
                )

            Screen.SETTINGS ->
                SettingsScreen(
                    vm = vm,
                    onBack = { screen = sharedReturn }
                )
        }
    }
}
