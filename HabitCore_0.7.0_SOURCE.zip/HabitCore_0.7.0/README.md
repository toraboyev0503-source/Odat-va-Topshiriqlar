# HabitCore 0.7.0

## Habit deletion without breaking history

Habits can now be deleted from both:
- the main Habits screen
- the Habit archive

Deletion is intentionally **soft-delete**, not a physical database delete.
A `deletedEpochDay` tombstone is stored on the habit.

Effect:
- the habit disappears from current lists immediately
- future scoring no longer includes it
- historical entries remain in the database
- reports for dates before deletion keep the same result
- notes and old DONE/FAILED/PARTIAL records remain available to historical monitoring

Room schema moves from version 4 to version 5 with an explicit `4 -> 5` migration.
`fallbackToDestructiveMigration()` is not used.

## Faster / smoother operation

Performance changes in 0.7.0:
- habit entries are grouped once per habit instead of repeatedly scanning the whole entry history for every row
- completion statistics are calculated once and reused for sorting and rendering
- daily scheduling no longer creates unnecessary per-call habit-entry copies
- task carry-over no longer retries every historical day on every refresh; it resumes from the latest existing plan day
- task carry-over refresh on the Tasks screen runs at startup and again only when the calendar day changes
- drag ordering updates the UI locally and writes the final order to Room only when the drag finishes
- Room persists the final habit order inside one transaction
- lazy-list item placement uses a short non-bouncy animation

## Android system Back behavior

System Back now follows the app hierarchy:
- Tasks -> Habits
- create/edit habit -> Habits
- habit day detail -> habit monitoring -> Habits
- task day detail -> task monitoring -> Tasks
- scheduled/archive screens -> their parent section
- theme/language/notifications/settings -> the section they were opened from

Only when the user is already on the root Habits screen does Android use normal app-exit behavior.

## Drag-and-drop habit ordering

Manual habit order is now changed by long-pressing a habit and dragging it vertically.

Behavior:
- hold a habit, then move it up or down
- crossed habits shift into their new positions automatically
- stable item IDs are used
- non-dragged items animate into place
- the dragged row follows the finger with elevation
- edge auto-scroll lets the user move a habit beyond the currently visible part of the list
- final order is persisted only after the gesture ends

Manual dragging is active in the existing `Manual` sort mode. Other sort modes remain read-only views.

## Data safety

- Database version: 5
- Migration chain retained: 3 -> 4 -> 5
- Existing 0.6.0 data is preserved
- Same bundled TEST signing key from 0.4.x / 0.5.x / 0.6.0 is retained
- Normal update install is intended for 0.6.0 -> 0.7.0

## GitHub build

Upload `HabitCore_0.7.0_SOURCE.zip` to the repository root.
Replace `.github/workflows/main.yml` with the supplied `main_0.7.0.yml`.

Artifact:
`HabitCore-0.7.0-debug-apk`
