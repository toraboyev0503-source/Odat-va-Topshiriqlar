#!/usr/bin/env python3
"""Static safety gate for Memora 0.9.35."""
from pathlib import Path
import re, xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
failures=[]
checks=0

def read(rel):
    p=ROOT/rel
    if not p.is_file():
        failures.append(f"missing file: {rel}")
        return ""
    return p.read_text(encoding="utf-8", errors="replace")

def require(label, cond):
    global checks
    checks += 1
    if not cond: failures.append(label)

def balanced(path):
    text=path.read_text(encoding='utf-8', errors='replace')
    stack=[]; pairs={')':'(',']':'[','}':'{'}
    i=0; block=0
    while i<len(text):
        if block:
            if text.startswith('/*',i): block+=1; i+=2; continue
            if text.startswith('*/',i): block-=1; i+=2; continue
            i+=1; continue
        if text.startswith('//',i):
            j=text.find('\n',i+2); i=len(text) if j<0 else j; continue
        if text.startswith('/*',i): block=1; i+=2; continue
        if text.startswith('"""',i):
            j=text.find('"""',i+3)
            if j<0: return False
            i=j+3; continue
        if text[i] in ('"',"'"):
            q=text[i]; i+=1
            while i<len(text):
                if text[i]=='\\': i+=2; continue
                if text[i]==q: i+=1; break
                i+=1
            continue
        c=text[i]
        if c in '([{': stack.append(c)
        elif c in ')]}':
            if not stack or stack.pop()!=pairs[c]: return False
        i+=1
    return not stack and block==0

gradle=read('app/build.gradle.kts')
flow=read('app/src/main/java/com/memora/app/ui/screens/TopilmaCreateFlow.kt')
ocr_ui=read('app/src/main/java/com/memora/app/ui/screens/TopilmaOcrCaptureScreen.kt')
ocr=read('app/src/main/java/com/memora/app/share/TopilmaOcrManager.kt')
settings=read('app/src/main/java/com/memora/app/ui/screens/SettingsHubV2Screen.kt')
integration=read('app/src/main/java/com/memora/app/ui/screens/TopilmaIntegrationScreen.kt')
prefs=read('app/src/main/java/com/memora/app/prefs/TopilmaIntegrationPreferences.kt')
service=read('app/src/main/java/com/memora/app/integration/TopilmaAccessibilityService.kt')
process=read('app/src/main/java/com/memora/app/integration/TopilmaProcessTextActivity.kt')
external=read('app/src/main/java/com/memora/app/integration/TopilmaExternalCapture.kt')
manifest=read('app/src/main/AndroidManifest.xml')
worker=read('app/src/main/java/com/memora/app/share/TopilmalarMetadataWorker.kt')
repo=read('app/src/main/java/com/memora/app/data/repository/TopilmalarRepository.kt')
app=read('app/src/main/java/com/memora/app/ui/MemoraApp.kt')
card=read('app/src/main/java/com/memora/app/ui/components/TopilmaCard.kt')
visual=read('app/src/main/java/com/memora/app/ui/components/TopilmaCardVisualSpec.kt')
renderer=read('app/src/main/java/com/memora/app/share/TopilmaShareManager.kt')

require('versionName 0.9.35', 'versionName = "0.9.35"' in gradle)
require('versionCode 55+', bool(re.search(r'versionCode\s*=\s*(?:5[5-9]|[6-9]\d|\d{3,})', gradle)))
require('document scanner dependency', 'play-services-mlkit-document-scanner:16.0.0' in gradle)
require('stable debug signing preserved', 'keystore/memora-test-debug.jks' in gradle)

# 72-80 scanner/OCR
require('scanner icon replaces copy icon', 'Icons.Rounded.DocumentScanner' in flow and 'Icons.Rounded.ContentCopy' not in flow)
require('ML Kit document scanner full mode', all(x in ocr_ui for x in ['GmsDocumentScanning.getClient', 'SCANNER_MODE_FULL', 'RESULT_FORMAT_JPEG']))
require('custom perspective no longer applied to OCR input', 'private fun loadPreparedOcrBitmap(file: File, maxDimension: Int = 2600): Bitmap? =' in ocr_ui and 'loadUprightBitmap(file, maxDimension)' in ocr_ui)
require('OCR line/paragraph aware', 'readingLines' in ocr and 'readingParagraphs' in ocr)
require('tap selects a full line', 'line.first().key' in ocr_ui and 'line.last().key' in ocr_ui)
require('editable OCR review', 'Matnni tekshiring' in ocr_ui and 'OutlinedTextField' in ocr_ui and 'Text("Qo‘shish")' in ocr_ui)

# 81-89 external integrations
require('integration settings entry', 'Topilmalar integratsiyasi' in settings and 'onTopilmaIntegration' in settings)
require('integration route wired', 'TOPILMA_INTEGRATION' in app and 'TopilmaIntegrationScreen' in app)
require('per-app preferences', 'enabledPackages' in prefs and 'setEnabled' in prefs)
require('launchable app picker', 'CATEGORY_LAUNCHER' in integration and 'queryIntentActivities' in integration)
require('quick monitoring toggle', 'Tezkor kuzatuv' in integration and 'setQuickMonitorEnabled' in integration)
require('process text action implemented', 'EXTRA_PROCESS_TEXT' in process and 'TopilmaExternalCapture.save' in process)
require('process text manifest filter', 'android.intent.action.PROCESS_TEXT' in manifest)
require('accessibility service declared', 'TopilmaAccessibilityService' in manifest and 'BIND_ACCESSIBILITY_SERVICE' in manifest)
require('clipboard quick monitor', 'OnPrimaryClipChangedListener' in service and 'Topilmaga saqlansinmi?' in service)
require('selected packages gate quick monitor', 'prefs.isEnabled(pkg)' in service)
require('external metadata detects browser URL', 'url_bar' in external and 'ARTICLE_WEBSITE' in external)
require('ChatGPT source mapping', 'chatgpt' in external.lower() and 'TopilmaSourceType.CHAT' in external)
require('book/eReader mapping', 'reader' in external.lower() and 'TopilmaSourceType.BOOK' in external)
require('web title author favicon enrichment', 'article:author' in worker and 'pageIcon' in worker and 'og:title' in worker)
require('website cover can be enriched', 'coverPath = if (type == TopilmaSourceType.ARTICLE_WEBSITE) null else originIconPath' in repo)

# 90-95 back behavior
require('Topilma back no synchronous Obsidian force sync', 'syncTopilmaToObsidianNow' not in flow)
require('Topilma back guarded against double tap', 'if (leaving) return' in flow and 'leaving = true' in flow)
require('system and toolbar back share finish', 'BackHandler' in flow and 'IconButton(onClick = ::finish)' in flow)
require('local overlays close before editor', all(x in flow for x in ['showCreateSource -> showCreateSource = false','copySheet -> copySheet = false','sourceSheet -> sourceSheet = false']))
require('save failure is surfaced', 'Saqlashda xato' in flow and 'saveError' in flow)
require('OCR review back is local-first', 'if (reviewText != null) reviewText = null else onBack()' in ocr_ui)

# Canonical Topilma card remains frozen.
require('canonical visual spec preserved', 'object TopilmaCardVisualSpec' in visual)
require('app card still canonical renderer', 'TopilmaShareManager.renderCardBitmap' in card)
require('share renderer dynamic layout preserved', all(x in renderer for x in ['bodyLayout','canvasHeight','cardBottom']))
require('create flow does not render card', 'renderCardBitmap' not in flow and 'TopilmaCardVisualSpec' not in flow)

# XML parse smoke tests.
for rel in ['app/src/main/AndroidManifest.xml','app/src/main/res/xml/topilma_accessibility_service.xml','app/src/main/res/values/strings.xml']:
    try: ET.parse(ROOT/rel)
    except Exception as e: failures.append(f'XML parse {rel}: {e}')
    checks += 1

bad=[]
for p in (ROOT/'app/src').rglob('*.kt'):
    if not balanced(p): bad.append(str(p.relative_to(ROOT)))
require('Kotlin delimiter smoke test', not bad)
failures.extend(f'unbalanced Kotlin: {x}' for x in bad)

if failures:
    print('Memora 0.9.35 regression FAILED')
    for x in failures: print(' -',x)
    raise SystemExit(1)
print(f'Memora 0.9.35 regression PASS ({checks} checks)')
