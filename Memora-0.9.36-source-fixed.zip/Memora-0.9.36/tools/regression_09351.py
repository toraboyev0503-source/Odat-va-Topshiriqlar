#!/usr/bin/env python3
"""Static safety gate for Memora 0.9.35.1 installation-compatibility build."""
from pathlib import Path
import re, xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
failures=[]
checks=0

def read(rel):
    p=ROOT/rel
    if not p.is_file():
        failures.append(f"missing file: {rel}")
        return ""
    return p.read_text(encoding="utf-8", errors="replace")

def require(label, cond):
    global checks
    checks += 1
    if not cond: failures.append(label)

gradle=read('app/build.gradle.kts')
flow=read('app/src/main/java/com/memora/app/ui/screens/TopilmaCreateFlow.kt')
ocr_ui=read('app/src/main/java/com/memora/app/ui/screens/TopilmaOcrCaptureScreen.kt')
settings=read('app/src/main/java/com/memora/app/ui/screens/SettingsHubV2Screen.kt')
integration=read('app/src/main/java/com/memora/app/ui/screens/TopilmaIntegrationScreen.kt')
process=read('app/src/main/java/com/memora/app/integration/TopilmaProcessTextActivity.kt')
external=read('app/src/main/java/com/memora/app/integration/TopilmaExternalCapture.kt')
manifest=read('app/src/main/AndroidManifest.xml')
card=read('app/src/main/java/com/memora/app/ui/components/TopilmaCard.kt')
visual=read('app/src/main/java/com/memora/app/ui/components/TopilmaCardVisualSpec.kt')
renderer=read('app/src/main/java/com/memora/app/share/TopilmaShareManager.kt')

require('versionName 0.9.35.1', 'versionName = "0.9.35.1"' in gradle)
require('versionCode 56', 'versionCode = 56' in gradle)
require('document scanner dependency retained', 'play-services-mlkit-document-scanner:16.0.0' in gradle)
require('scanner icon retained', 'Icons.Rounded.DocumentScanner' in flow)
require('document scanner retained', 'GmsDocumentScanning.getClient' in ocr_ui and 'SCANNER_MODE_FULL' in ocr_ui)
require('integration settings retained', 'Topilmalar integratsiyasi' in settings)
require('explicit PROCESS_TEXT capture retained', 'EXTRA_PROCESS_TEXT' in process and 'TopilmaExternalCapture.save' in process)
require('PROCESS_TEXT manifest retained', 'android.intent.action.PROCESS_TEXT' in manifest and 'Topilmaga saqlash' in manifest)
require('app picker retained', 'CATEGORY_LAUNCHER' in integration and 'queryIntentActivities' in integration)
require('accessibility service manifest removed', 'BIND_ACCESSIBILITY_SERVICE' not in manifest and 'TopilmaAccessibilityService' not in manifest)
require('accessibility service source removed', not (ROOT/'app/src/main/java/com/memora/app/integration/TopilmaAccessibilityService.kt').exists())
require('accessibility service config removed', not (ROOT/'app/src/main/res/xml/topilma_accessibility_service.xml').exists())
require('settings no longer opens accessibility settings', 'ACTION_ACCESSIBILITY_SETTINGS' not in integration and 'TopilmaAccessibilityService' not in integration)
require('back fix retained', 'if (leaving) return' in flow and 'IconButton(onClick = ::finish)' in flow)
require('canonical visual spec preserved', 'object TopilmaCardVisualSpec' in visual)
require('app card still canonical renderer', 'TopilmaShareManager.renderCardBitmap' in card)
require('share renderer preserved', all(x in renderer for x in ['bodyLayout','canvasHeight','cardBottom']))
require('create flow does not render card', 'renderCardBitmap' not in flow and 'TopilmaCardVisualSpec' not in flow)
require('external source mapping retained', all(x in external for x in ['TopilmaSourceType.CHAT','TopilmaSourceType.ARTICLE_WEBSITE','TopilmaSourceType.BOOK']))

for rel in ['app/src/main/AndroidManifest.xml','app/src/main/res/values/strings.xml']:
    try: ET.parse(ROOT/rel)
    except Exception as e: failures.append(f'XML parse {rel}: {e}')
    checks += 1

if failures:
    print('Memora 0.9.35.1 regression FAILED')
    for x in failures: print(' -',x)
    raise SystemExit(1)
print(f'Memora 0.9.35.1 regression PASS ({checks} checks)')
