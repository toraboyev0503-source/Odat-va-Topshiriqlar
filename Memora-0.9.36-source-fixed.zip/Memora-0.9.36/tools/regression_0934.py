#!/usr/bin/env python3
"""Static safety gate for Memora 0.9.34."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
failures=[]
checks=0

def read(rel):
    p=ROOT/rel
    if not p.is_file():
        failures.append(f"missing file: {rel}")
        return ""
    return p.read_text(encoding="utf-8", errors="replace")

def require(label, cond):
    global checks
    checks += 1
    if not cond: failures.append(label)

def balanced(path):
    text=path.read_text(encoding='utf-8', errors='replace')
    stack=[]; pairs={')':'(',']':'[','}':'{'}
    i=0; block=0
    while i<len(text):
        if block:
            if text.startswith('/*',i): block+=1; i+=2; continue
            if text.startswith('*/',i): block-=1; i+=2; continue
            i+=1; continue
        if text.startswith('//',i):
            j=text.find('\n',i+2); i=len(text) if j<0 else j; continue
        if text.startswith('/*',i): block=1; i+=2; continue
        if text.startswith('"""',i):
            j=text.find('"""',i+3)
            if j<0: return False
            i=j+3; continue
        if text[i] in ('"',"'"):
            q=text[i]; i+=1
            while i<len(text):
                if text[i]=='\\': i+=2; continue
                if text[i]==q: i+=1; break
                i+=1
            continue
        c=text[i]
        if c in '([{': stack.append(c)
        elif c in ')]}':
            if not stack or stack.pop()!=pairs[c]: return False
        i+=1
    return not stack and block==0

gradle=read('app/build.gradle.kts')
new_sheet=read('app/src/main/java/com/memora/app/ui/components/NewNoteSheet.kt')
app=read('app/src/main/java/com/memora/app/ui/MemoraApp.kt')
top=read('app/src/main/java/com/memora/app/ui/screens/TopilmalarScreen.kt')
flow=read('app/src/main/java/com/memora/app/ui/screens/TopilmaCreateFlow.kt')
ocr_ui=read('app/src/main/java/com/memora/app/ui/screens/TopilmaOcrCaptureScreen.kt')
ocr=read('app/src/main/java/com/memora/app/share/TopilmaOcrManager.kt')
dao=read('app/src/main/java/com/memora/app/data/local/TopilmalarDaos.kt')
repo=read('app/src/main/java/com/memora/app/data/repository/TopilmalarRepository.kt')
card=read('app/src/main/java/com/memora/app/ui/components/TopilmaCard.kt')
visual=read('app/src/main/java/com/memora/app/ui/components/TopilmaCardVisualSpec.kt')
renderer=read('app/src/main/java/com/memora/app/share/TopilmaShareManager.kt')

require('versionName 0.9.34', 'versionName = "0.9.34"' in gradle)
require('versionCode 54+', bool(re.search(r'versionCode\s*=\s*(?:5[4-9]|[6-9]\d|\d{3,})', gradle)))
require('package preserved', 'applicationId = "com.memora.app"' in gradle)
require('stable debug signing preserved', 'keystore/memora-test-debug.jks' in gradle)

# Frozen 54-58
short_i=new_sheet.find('title = L.t(language, S.SHORT_NOTES)')
long_i=new_sheet.find('title = L.t(language, S.LONG_NOTES)')
top_i=new_sheet.find('title = topilmaTitle(language)')
require('new-note order Short Long Topilma', 0 <= short_i < long_i < top_i)
require('equal minimum option height', '.heightIn(min = 82.dp)' in new_sheet)
require('compact sheet spacing', 'bottom = 18.dp' in new_sheet and 'bottom = 12.dp' in new_sheet)
require('new-note uses theme accent tint', 'MaterialTheme.colorScheme.primary.copy(alpha = 0.065f)' in new_sheet)

# Frozen 59-65
require('direct composer is create entry', 'TopilmaCreateStep.COMPOSER' in top and 'TopilmaComposerScreen(' in top)
require('old mode not used in create flow', 'TopilmaCreateStep.MODE' not in top and 'WRITE_SOURCE' not in top and 'COPY_METHOD' not in top)
require('last used source default', 'maxByOrNull { it.lastAddedAt }' in top)
require('recent-first source picker', 'sortedByDescending { it.lastAddedAt }' in flow)
require('new source action at bottom', 'Text("Yangi manba"' in flow)
require('source selector and copy action', 'sourceSheet = true' in flow and 'Icons.Rounded.ContentCopy' in flow)
require('camera and gallery copy choices', all(x in flow for x in ['"Kamera"', '"Galereya"', 'PickVisualMedia.ImageOnly']))
require('clean transparent composer field', 'focusedContainerColor = Color.Transparent' in flow and 'Topilmangizni yozing' in flow)

# Frozen 66-69 OCR
require('OCR perspective rectify', 'autoPerspectiveRectify' in ocr_ui and 'setPolyToPoly' in ocr_ui)
require('OCR auto deskew', 'autoDeskew' in ocr_ui and 'projectionScore' in ocr_ui)
require('OCR paragraph aware order', 'readingParagraphs' in ocr and 'visualParagraphBreak' in ocr)
require('OCR selection no arbitrary distant snapping', 'val maxGap' in ocr_ui and 'takeIf' in ocr_ui)
require('OCR editable review before insert', 'Matnni tekshiring' in ocr_ui and 'OutlinedTextField' in ocr_ui and 'Text("Qo‘shish")' in ocr_ui)

# Frozen 70-71 back behavior
require('Topilma internal back returns one step', 'if (ocrFromCamera) TopilmaCreateStep.CAMERA else TopilmaCreateStep.COMPOSER' in top)
require('Topilmalar local layers have BackHandler', 'selectedCard != null || showStats || showTags || searchOpen || selectedSource != null' in top)
require('app-level local-first back', 'showNewNoteSheet || showExportDialog' in app and '!showNewNoteSheet && !showExportDialog' in app)

# Moving draft source should preserve source metadata.
require('card move updates source metadata', all(x in dao for x in ['sourceUri = :sourceUri','originAppPackage = :originAppPackage','originAppName = :originAppName']))
require('repository resolves target source metadata', 'val source = sourceId?.let { sources.getById(it) }' in repo)

# Canonical Topilma card freeze.
require('canonical Topilma visual spec preserved', 'object TopilmaCardVisualSpec' in visual)
require('app card still uses canonical renderer', 'TopilmaShareManager.renderCardBitmap' in card)
require('renderer still uses dynamic body/canvas logic', all(x in renderer for x in ['bodyLayout','canvasHeight','cardBottom']))
require('no second card renderer introduced in create flow', 'renderCardBitmap' not in flow and 'TopilmaCardVisualSpec' not in flow)

bad=[]
for p in (ROOT/'app/src').rglob('*.kt'):
    if not balanced(p): bad.append(str(p.relative_to(ROOT)))
require('Kotlin delimiter smoke test', not bad)
failures.extend(f'unbalanced Kotlin: {x}' for x in bad)

if failures:
    print('Memora 0.9.34 regression FAILED')
    for x in failures: print(' -',x)
    raise SystemExit(1)
print(f'Memora 0.9.34 regression PASS ({checks} checks)')
