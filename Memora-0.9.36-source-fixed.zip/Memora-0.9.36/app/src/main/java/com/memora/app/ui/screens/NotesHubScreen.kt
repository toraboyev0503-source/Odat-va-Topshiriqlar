package com.memora.app.ui.screens

import android.app.DatePickerDialog
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.FilterList
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AssistChip
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memora.app.data.local.NoteEntity
import com.memora.app.data.local.NoteType
import com.memora.app.data.model.NoteMood
import com.memora.app.i18n.L
import com.memora.app.i18n.S
import com.memora.app.prefs.AppLanguage
import com.memora.app.ui.components.MemoraConfirmationDialog
import com.memora.app.ui.components.MemoraEmptyState
import com.memora.app.ui.components.MoodSticker
import com.memora.app.ui.components.NoteCard
import com.memora.app.ui.theme.MemoraDesign
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.time.format.DateTimeFormatter

private enum class NotesKind { ALL, SHORT, LONG }
private enum class MediaFilter { ANY, IMAGE, AUDIO, ANY_MEDIA, NO_MEDIA }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotesHubScreen(
    notes: List<NoteEntity>,
    language: AppLanguage,
    initialType: NoteType? = null,
    canEdit: Boolean,
    onOpen: (String) -> Unit,
    onEdit: (NoteEntity) -> Unit,
    onDelete: (NoteEntity) -> Unit
) {
    var kind by remember(initialType) {
        mutableStateOf(
            when (initialType) {
                NoteType.SHORT -> NotesKind.SHORT
                NoteType.LONG -> NotesKind.LONG
                null -> NotesKind.ALL
            }
        )
    }
    var query by remember { mutableStateOf("") }
    var mood by remember { mutableStateOf<NoteMood?>(null) }
    var media by remember { mutableStateOf(MediaFilter.ANY) }
    var filterSheet by remember { mutableStateOf(false) }
    var dateFrom by remember { mutableStateOf<LocalDate?>(null) }
    var dateTo by remember { mutableStateOf<LocalDate?>(null) }
    var pendingDelete by remember { mutableStateOf<NoteEntity?>(null) }
    val listState = rememberLazyListState()
    val zone = remember { ZoneId.systemDefault() }
    val context = LocalContext.current

    val filtered = remember(notes, kind, query, mood, media, dateFrom, dateTo) {
        val q = query.trim().lowercase()
        notes.asSequence()
            .filter {
                when (kind) {
                    NotesKind.ALL -> true
                    NotesKind.SHORT -> it.type == NoteType.SHORT.name
                    NotesKind.LONG -> it.type == NoteType.LONG.name
                }
            }
            .filter { mood == null || it.mood == mood?.name }
            .filter {
                when (media) {
                    MediaFilter.ANY -> true
                    MediaFilter.IMAGE -> it.hasImages
                    MediaFilter.AUDIO -> it.hasAudio
                    MediaFilter.ANY_MEDIA -> it.hasImages || it.hasAudio
                    MediaFilter.NO_MEDIA -> !it.hasImages && !it.hasAudio
                }
            }
            .filter { note ->
                val date = Instant.ofEpochMilli(note.createdAt).atZone(zone).toLocalDate()
                (dateFrom == null || !date.isBefore(dateFrom)) && (dateTo == null || !date.isAfter(dateTo))
            }
            .filter { q.isBlank() || it.title.lowercase().contains(q) || it.plainText.lowercase().contains(q) }
            .sortedByDescending { it.createdAt }
            .toList()
    }
    val today = remember { LocalDate.now() }
    var expandedYears by rememberSaveable { mutableStateOf(listOf(today.year)) }
    var expandedMonths by rememberSaveable { mutableStateOf(listOf(YearMonth.from(today).toString())) }
    val discoveryMode = query.isNotBlank() || mood != null || media != MediaFilter.ANY || dateFrom != null || dateTo != null
    val groupedByDay = remember(filtered, zone) {
        filtered.groupBy { Instant.ofEpochMilli(it.createdAt).atZone(zone).toLocalDate() }
            .toSortedMap(compareByDescending { it })
    }
    val groupedArchive = remember(filtered, zone) {
        filtered.groupBy { Instant.ofEpochMilli(it.createdAt).atZone(zone).year }
            .toSortedMap(compareByDescending { it })
            .mapValues { (_, yearNotes) ->
                yearNotes.groupBy { YearMonth.from(Instant.ofEpochMilli(it.createdAt).atZone(zone)) }
                    .toSortedMap(compareByDescending { it })
            }
    }

    Column(Modifier.fillMaxSize()) {
        Column(
            Modifier.padding(
                start = MemoraDesign.screenPadding,
                end = MemoraDesign.screenPadding,
                top = MemoraDesign.screenPadding,
                bottom = 8.dp
            )
        ) {
            Text(
                text = notesTitle(language),
                style = MaterialTheme.typography.headlineLarge.copy(fontSize = 38.sp),
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NotesKind.entries.forEach { option ->
                    FilterChip(
                        selected = kind == option,
                        onClick = { kind = option },
                        label = {
                            Text(
                                when (option) {
                                    NotesKind.ALL -> allLabel(language)
                                    NotesKind.SHORT -> L.t(language, S.SHORT)
                                    NotesKind.LONG -> L.t(language, S.LONG)
                                }
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor = Color.Transparent,
                            selectedContainerColor = notesSelectedContainer(),
                            selectedLabelColor = MaterialTheme.colorScheme.onSurface
                        )
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(24.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surface.copy(alpha = .72f),
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface.copy(alpha = .58f),
                    focusedBorderColor = MaterialTheme.colorScheme.primary.copy(alpha = .75f),
                    unfocusedBorderColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = .55f)
                ),
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                placeholder = { Text(L.t(language, S.SEARCH)) },
                trailingIcon = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (query.isNotBlank()) {
                            IconButton(onClick = { query = "" }) { Icon(Icons.Rounded.Close, contentDescription = null) }
                        }
                        IconButton(onClick = { filterSheet = true }) {
                            Icon(
                                Icons.Rounded.FilterList,
                                contentDescription = filterLabel(language),
                                tint = if (mood != null || media != MediaFilter.ANY || dateFrom != null || dateTo != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            )
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    if (query.isBlank()) countLabel(language, filtered.size) else foundLabel(language, filtered.size),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f)
                )
                mood?.let {
                    MoodSticker(
                        mood = it,
                        description = moodName(language, it),
                        modifier = Modifier.padding(start = 8.dp).size(25.dp)
                    )
                }
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            state = listState,
            contentPadding = PaddingValues(
                start = MemoraDesign.screenPadding,
                end = MemoraDesign.screenPadding,
                top = 4.dp,
                bottom = 28.dp
            )
        ) {
            if (filtered.isEmpty()) {
                item("empty") {
                    Column(Modifier.fillMaxWidth().padding(top = 24.dp)) {
                        MemoraEmptyState(
                            title = if (query.isBlank()) emptyNotes(language) else noMatches(language),
                            body = if (query.isBlank()) {
                                if (language == AppLanguage.UZ) "Yozuvlaringiz shu yerda bir joyga jamlanadi." else "Your notes will gather here in one place."
                            } else {
                                if (language == AppLanguage.UZ) "Qidiruv yoki filtrlarni o‘zgartirib ko‘ring." else "Try changing the search or filters."
                            }
                        )
                        if (query.isNotBlank() || mood != null || media != MediaFilter.ANY || dateFrom != null || dateTo != null) {
                            TextButton(
                                onClick = { query = ""; mood = null; media = MediaFilter.ANY; dateFrom = null; dateTo = null },
                                modifier = Modifier.align(Alignment.CenterHorizontally)
                            ) { Text(clearFilters(language)) }
                        }
                    }
                }
            }
            if (discoveryMode) {
                groupedByDay.forEach { (date, dayNotes) ->
                    item("result-day-$date") {
                        DayArchiveHeader(date = date, language = language)
                    }
                    items(dayNotes, key = { "result-${it.id}" }) { note ->
                        ArchiveNoteCard(
                            note = note,
                            language = language,
                            canEdit = canEdit,
                            onOpen = onOpen,
                            onEdit = onEdit,
                            onDelete = { pendingDelete = it }
                        )
                    }
                }
            } else {
                groupedArchive.forEach { (year, months) ->
                    val yearNotesCount = months.values.sumOf { it.size }
                    val yearExpanded = year in expandedYears
                    item("year-$year") {
                        ArchiveGroupHeader(
                            title = year.toString(),
                            count = yearNotesCount,
                            expanded = yearExpanded,
                            level = ArchiveHeaderLevel.YEAR,
                            language = language,
                            onClick = {
                                expandedYears = if (yearExpanded) expandedYears - year else expandedYears + year
                            }
                        )
                    }
                    if (yearExpanded) {
                        months.forEach { (yearMonth, monthNotes) ->
                            val monthKey = yearMonth.toString()
                            val monthExpanded = monthKey in expandedMonths
                            item("month-$monthKey") {
                                ArchiveGroupHeader(
                                    title = monthLabel(yearMonth, language),
                                    count = monthNotes.size,
                                    expanded = monthExpanded,
                                    level = ArchiveHeaderLevel.MONTH,
                                    language = language,
                                    onClick = {
                                        expandedMonths = if (monthExpanded) expandedMonths - monthKey else expandedMonths + monthKey
                                    }
                                )
                            }
                            if (monthExpanded) {
                                monthNotes
                                    .groupBy { Instant.ofEpochMilli(it.createdAt).atZone(zone).toLocalDate() }
                                    .toSortedMap(compareByDescending { it })
                                    .forEach { (date, dayNotes) ->
                                        item("day-$monthKey-$date") {
                                            DayArchiveHeader(date = date, language = language)
                                        }
                                        items(dayNotes, key = { it.id }) { note ->
                                            ArchiveNoteCard(
                                                note = note,
                                                language = language,
                                                canEdit = canEdit,
                                                onOpen = onOpen,
                                                onEdit = onEdit,
                                                onDelete = { pendingDelete = it }
                                            )
                                        }
                                    }
                            }
                        }
                    }
                }
            }
        }
    }

    if (filterSheet) {
        ModalBottomSheet(onDismissRequest = { filterSheet = false }) {
            Column(Modifier.padding(horizontal = 22.dp, vertical = 8.dp)) {
                Text(filterLabel(language), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
                Text(moodFilterLabel(language), style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 18.dp, bottom = 8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    NoteMood.entries.forEach { option ->
                        val selected = mood == option
                        Surface(
                            onClick = { mood = if (selected) null else option },
                            shape = RoundedCornerShape(MemoraDesign.radiusSmall),
                            color = if (selected) MaterialTheme.colorScheme.primary.copy(alpha = .12f) else MaterialTheme.colorScheme.surface
                        ) {
                            MoodSticker(option, moodName(language, option), Modifier.padding(7.dp).size(42.dp))
                        }
                    }
                }
                Text(dateFilterLabel(language), style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 18.dp, bottom = 6.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            val d = dateFrom ?: LocalDate.now()
                            DatePickerDialog(context, { _, y, m, day -> dateFrom = LocalDate.of(y, m + 1, day) }, d.year, d.monthValue - 1, d.dayOfMonth).show()
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text(dateFrom?.toString() ?: fromLabel(language)) }
                    OutlinedButton(
                        onClick = {
                            val d = dateTo ?: LocalDate.now()
                            DatePickerDialog(context, { _, y, m, day -> dateTo = LocalDate.of(y, m + 1, day) }, d.year, d.monthValue - 1, d.dayOfMonth).show()
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text(dateTo?.toString() ?: toLabel(language)) }
                }
                if (dateFrom != null || dateTo != null) {
                    TextButton(onClick = { dateFrom = null; dateTo = null }) { Text(clearDateLabel(language)) }
                }

                Text(mediaFilterLabel(language), style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 18.dp, bottom = 6.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    listOf(MediaFilter.ANY, MediaFilter.IMAGE, MediaFilter.AUDIO).forEach { option ->
                        AssistChip(onClick = { media = option }, label = { Text(mediaName(language, option)) })
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    listOf(MediaFilter.ANY_MEDIA, MediaFilter.NO_MEDIA).forEach { option ->
                        AssistChip(onClick = { media = option }, label = { Text(mediaName(language, option)) })
                    }
                }
                TextButton(
                    onClick = { mood = null; media = MediaFilter.ANY; dateFrom = null; dateTo = null },
                    modifier = Modifier.align(Alignment.End).padding(vertical = 12.dp)
                ) { Text(clearFilters(language)) }
            }
        }
    }

    pendingDelete?.let { note ->
        MemoraConfirmationDialog(
            language = language,
            title = deleteNoteTitle(language),
            text = deleteNoteText(language),
            onConfirm = { onDelete(note); pendingDelete = null },
            onDismiss = { pendingDelete = null }
        )
    }
}

private enum class ArchiveHeaderLevel { YEAR, MONTH }

@Composable
private fun ArchiveGroupHeader(
    title: String,
    count: Int,
    expanded: Boolean,
    level: ArchiveHeaderLevel,
    language: AppLanguage,
    onClick: () -> Unit
) {
    val rotation by animateFloatAsState(
        targetValue = if (expanded) 90f else 0f,
        animationSpec = tween(160),
        label = "archive-chevron"
    )
    Surface(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .padding(
                start = if (level == ArchiveHeaderLevel.YEAR) 0.dp else 12.dp,
                top = if (level == ArchiveHeaderLevel.YEAR) 12.dp else 4.dp,
                bottom = 4.dp
            ),
        shape = RoundedCornerShape(if (level == ArchiveHeaderLevel.YEAR) 16.dp else 13.dp),
        color = if (level == ArchiveHeaderLevel.YEAR)
            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .42f)
        else MaterialTheme.colorScheme.surface.copy(alpha = .62f)
    ) {
        Row(
            modifier = Modifier.padding(
                horizontal = if (level == ArchiveHeaderLevel.YEAR) 14.dp else 12.dp,
                vertical = if (level == ArchiveHeaderLevel.YEAR) 11.dp else 9.dp
            ),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.Rounded.ChevronRight,
                contentDescription = null,
                modifier = Modifier.size(20.dp).rotate(rotation),
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                title,
                style = if (level == ArchiveHeaderLevel.YEAR) MaterialTheme.typography.titleLarge else MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f).padding(start = 7.dp)
            )
            Text(
                archiveCountLabel(count, language),
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun DayArchiveHeader(date: LocalDate, language: AppLanguage) {
    Text(
        dayLabel(date, language),
        style = MaterialTheme.typography.titleMedium.copy(fontSize = 17.sp),
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(start = 18.dp, top = 12.dp, bottom = 7.dp)
    )
}

@Composable
private fun ArchiveNoteCard(
    note: NoteEntity,
    language: AppLanguage,
    canEdit: Boolean,
    onOpen: (String) -> Unit,
    onEdit: (NoteEntity) -> Unit,
    onDelete: (NoteEntity) -> Unit
) {
    NoteCard(
        note = note,
        displayTitle = note.title.ifBlank { L.t(language, S.UNTITLED) },
        language = language,
        selected = false,
        previewLines = if (note.type == NoteType.SHORT.name) 2 else 3,
        onClick = { onOpen(note.id) },
        onLongClick = {},
        onDeleteRequest = { onDelete(note) },
        onEditRequest = if (canEdit) ({ onEdit(note) }) else null
    )
    Spacer(Modifier.height(9.dp))
}

private fun monthLabel(month: YearMonth, language: AppLanguage): String {
    val locale = java.util.Locale.forLanguageTag(language.tag)
    val raw = month.atDay(1).format(DateTimeFormatter.ofPattern("MMMM", locale))
    return raw.replaceFirstChar { if (it.isLowerCase()) it.titlecase(locale) else it.toString() }
}

private fun archiveCountLabel(count: Int, language: AppLanguage): String = when (language) {
    AppLanguage.UZ -> "$count yozuv"
    AppLanguage.RU -> "$count записей"
    else -> "$count notes"
}

private fun notesTitle(l: AppLanguage) = when(l){ AppLanguage.UZ->"Yozuvlar"; AppLanguage.RU->"Записи"; AppLanguage.FR->"Écrits"; AppLanguage.DE->"Einträge"; AppLanguage.ES->"Notas"; AppLanguage.PT_BR->"Notas"; AppLanguage.TR->"Yazılar"; AppLanguage.AR->"الكتابات"; AppLanguage.HI->"लेखन"; AppLanguage.ID->"Catatan"; AppLanguage.JA->"記録"; AppLanguage.KO->"기록"; else->"Notes" }
private fun allLabel(l: AppLanguage)=when(l){AppLanguage.UZ->"Barchasi";AppLanguage.RU->"Все";AppLanguage.FR->"Tout";AppLanguage.DE->"Alle";AppLanguage.ES->"Todo";AppLanguage.PT_BR->"Tudo";AppLanguage.TR->"Tümü";AppLanguage.AR->"الكل";AppLanguage.HI->"सभी";AppLanguage.ID->"Semua";AppLanguage.JA->"すべて";AppLanguage.KO->"전체";else->"All"}
private fun filterLabel(l: AppLanguage)=when(l){AppLanguage.UZ->"Filtr";AppLanguage.RU->"Фильтр";AppLanguage.FR->"Filtres";AppLanguage.DE->"Filter";AppLanguage.ES->"Filtros";AppLanguage.PT_BR->"Filtros";AppLanguage.TR->"Filtre";AppLanguage.AR->"تصفية";AppLanguage.HI->"फ़िल्टर";AppLanguage.ID->"Filter";AppLanguage.JA->"フィルター";AppLanguage.KO->"필터";else->"Filters"}
private fun clearFilters(l:AppLanguage)=when(l){AppLanguage.UZ->"Filtrlarni tozalash";AppLanguage.RU->"Сбросить фильтры";else->"Clear filters"}
private fun moodFilterLabel(l:AppLanguage)=when(l){AppLanguage.UZ->"Kayfiyat";AppLanguage.RU->"Настроение";else->"Mood"}
private fun mediaFilterLabel(l:AppLanguage)=when(l){AppLanguage.UZ->"Media";AppLanguage.RU->"Медиа";else->"Media"}
private fun countLabel(l:AppLanguage,n:Int)=when(l){AppLanguage.UZ->"$n yozuv";AppLanguage.RU->"Записей: $n";else->"$n notes"}
private fun foundLabel(l:AppLanguage,n:Int)=when(l){AppLanguage.UZ->"$n ta topildi";AppLanguage.RU->"Найдено: $n";else->"$n found"}
private fun emptyNotes(l:AppLanguage)=when(l){AppLanguage.UZ->"Hali yozuv yo‘q. Markazdagi + orqali birinchi xotirangizni yozing.";AppLanguage.RU->"Пока нет записей. Создайте первую через +.";else->"No notes yet. Use + to capture your first memory."}
private fun noMatches(l:AppLanguage)=when(l){AppLanguage.UZ->"Mos yozuv topilmadi";AppLanguage.RU->"Подходящих записей нет";else->"No matching notes"}
private fun mediaName(l:AppLanguage,m:MediaFilter)=when(m){MediaFilter.ANY->if(l==AppLanguage.UZ)"Barchasi" else "Any";MediaFilter.IMAGE->if(l==AppLanguage.UZ)"Rasm" else "Image";MediaFilter.AUDIO->if(l==AppLanguage.UZ)"Audio" else "Audio";MediaFilter.ANY_MEDIA->if(l==AppLanguage.UZ)"Media bor" else "Has media";MediaFilter.NO_MEDIA->if(l==AppLanguage.UZ)"Mediasiz" else "No media"}
private fun moodName(l:AppLanguage,m:NoteMood)=when(m){NoteMood.GREAT->if(l==AppLanguage.UZ)"Zo‘r" else "Great";NoteMood.GOOD->if(l==AppLanguage.UZ)"Yaxshi" else "Good";NoteMood.NEUTRAL->if(l==AppLanguage.UZ)"O‘rtacha" else "Neutral";NoteMood.BAD->if(l==AppLanguage.UZ)"Yomon" else "Bad";NoteMood.VERY_BAD->if(l==AppLanguage.UZ)"Juda yomon" else "Very bad"}
private fun dateFilterLabel(l:AppLanguage)=if(l==AppLanguage.UZ) "Sana oralig‘i" else "Date range"
private fun fromLabel(l:AppLanguage)=if(l==AppLanguage.UZ) "Boshlanish" else "From"
private fun toLabel(l:AppLanguage)=if(l==AppLanguage.UZ) "Tugash" else "To"
private fun clearDateLabel(l:AppLanguage)=if(l==AppLanguage.UZ) "Sanani tozalash" else "Clear dates"
private fun deleteNoteTitle(l:AppLanguage)=if(l==AppLanguage.UZ) "Yozuvni o‘chirish" else "Delete note"
private fun deleteNoteText(l:AppLanguage)=if(l==AppLanguage.UZ) "Bu yozuv va unga tegishli media o‘chiriladi." else "This note and its attached media will be deleted."
private fun cancelNotesLabel(l:AppLanguage)=if(l==AppLanguage.UZ) "Bekor qilish" else "Cancel"

@Composable
private fun notesSelectedContainer(): Color =
    MaterialTheme.colorScheme.primary.copy(alpha = if (MaterialTheme.colorScheme.background.luminance() < .5f) .22f else .14f)

private fun dayLabel(date: LocalDate, language: AppLanguage): String {
    val now=LocalDate.now()
    if(date==now) return if(language==AppLanguage.UZ) "Bugun" else if(language==AppLanguage.RU) "Сегодня" else "Today"
    if(date==now.minusDays(1)) return if(language==AppLanguage.UZ) "Kecha" else if(language==AppLanguage.RU) "Вчера" else "Yesterday"
    return date.format(DateTimeFormatter.ofPattern(if(date.year==now.year) "d MMMM" else "d MMMM yyyy", java.util.Locale.forLanguageTag(language.tag)))
}
