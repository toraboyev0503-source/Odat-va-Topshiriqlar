# Memora 0.9.36 — external Topilma source chooser

- “Topilmaga saqlash” now opens a compact bottom source chooser before saving.
- The last-used source is the primary large option with cover/title.
- The next five recently used sources appear as compact horizontal cover tiles with short titles.
- Tapping any source saves immediately; no second confirmation is required.
- “Barcha manbalar” opens a searchable full source list.
- Current-source metadata is surfaced as a separate suggestion only when usable title/author/URL metadata is available.
- Detected new sources are created only after the user explicitly selects the suggestion.
- Detected source contexts are remembered and mapped back to the selected existing source on later captures.
- External app names are fallback metadata only, not the preferred source.
- Browser URL metadata continues to be enriched asynchronously into article/site title, author and image/favicon where available.
- Back/outside tap dismisses the chooser without saving.
- Canonical Topilma card visuals remain unchanged.
- Version bumped to `0.9.36` / code `57`.

# Memora 0.9.35 — Topilma scanner + external app integrations + Back fix

## 0.9.35.1
- Installation compatibility build: Accessibility Service component temporarily removed from the APK.
- Explicit Android “Topilmaga saqlash” PROCESS_TEXT integration remains available.
- Scanner/OCR and Topilma creation/back-navigation improvements remain unchanged.

- Topilma copy icon is now a scanner icon.
- Camera copy flow now uses Google ML Kit Document Scanner FULL mode with automatic page detection, perspective correction, crop and cleanup.
- The old custom perspective transform is no longer applied to OCR input, avoiding bent/skewed page rendering.
- OCR keeps line/paragraph-aware reading order, adds full-line tap selection, range dragging and editable review before insertion.
- Settings now includes “Topilmalar integratsiyasi”.
- Users can add/remove launchable apps such as ChatGPT, Chrome and eReader from the allowed-app list.
- Android PROCESS_TEXT integration adds “Topilmaga saqlash” to compatible text-selection menus.
- Optional quick monitoring uses an Accessibility Service for selected apps and offers a small save prompt after copied text is detected.
- External captures create/reuse Topilma sources automatically and use app metadata as fallback.
- Browser captures attempt to detect the current URL; network enrichment fetches page title, author, Open Graph image or favicon when available.
- ChatGPT-like apps map to a Chat source; eReader/book apps map to a Book source with available metadata.
- Topilma editor Back now waits only for safe local save; it no longer forces synchronous Obsidian sync before navigating back.
- Toolbar Back and system Back share the same guarded exit path; local sheets/dialogs close first; repeated taps are ignored.
- Save failures are shown in the editor instead of leaving the screen apparently frozen.
- Canonical Topilma card visual renderer/spec remains unchanged.
- Version bumped to `0.9.35` / code `55`.
