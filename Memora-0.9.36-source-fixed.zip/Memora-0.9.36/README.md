# Memora 0.9.36

Android source package for the Memora 0.9.36 test build.

- `versionName`: `0.9.36`
- `versionCode`: `57`
- Stable Memora test/debug signing configuration is preserved so debug APKs can update earlier compatible test builds.

## 0.9.36 scope

This build implements frozen decisions 96–115 for external-app → Topilmalar source selection:

- PROCESS_TEXT now opens a compact bottom source chooser instead of saving immediately.
- The last-used source is the large primary choice; the next five recent sources appear as compact cover tiles.
- “Barcha manbalar” opens a searchable full source list.
- A detected current source is shown as a separate suggestion when the source app supplies usable URL/title/author metadata.
- New detected sources are only created after the user taps the suggestion.
- Detected URL/title contexts are remembered and remapped to the previously chosen source on later captures.
- App name is a fallback only, not an automatic default source.
- Existing web metadata enrichment (title/author/Open Graph image/favicon) remains active when a usable URL is available.
- Canonical Topilma card visual renderer/spec remains unchanged.
