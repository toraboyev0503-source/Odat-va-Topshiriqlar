# Memora 0.9.24

Memora is a private, local-first Android journal for short and long notes plus
**Topilmalar** — source-linked ideas, quotations and discoveries. The launcher
and in-app name are **Memora**; the intended Google Play listing title is
**Memora – Private Journal**.

## Release configuration

- Android application ID: `com.memora.app`
- `versionName`: `0.9.24`; `versionCode`: `43`
- Room schema: `8` with non-destructive migrations through `6 → 7 → 8`
- `compileSdk` / `targetSdk`: 36
- `minSdk`: 26 (Android 8.0+)
- Google Play Billing product: `memora_premium`
- Base plans: `monthly`, `quarterly`, `semiannual`, `annual`
- 1-month trial offer tag: `memora-free-trial`
- Paragraph gap: exactly 60% of line-height through `ParagraphMetrics.GAP_RATIO`
- Title presets: no built-in/system presets; the title list and picker contain only user-created saved titles

## 0.9.24 scope

This revision adds the frozen Obsidian bridge and hashtag system while refining the
Topilmalar card to the approved master visual. In-app and exported cards share one
visual specification: larger fixed-proportion cover art, refined source title/author
geometry, horizontal overflow dots, serif body text, equal Share / Like / Comment
action zones, and full-text PNG export. List cards stay at two lines until the user
taps the text; several cards may remain expanded until the section is left.

Settings now contains **External apps → Obsidian**. The user selects an Obsidian
vault with Android's Storage Access Framework; Memora persists the granted access
and creates `Memora/Qisqa matn`, `Memora/Topilmalar`, and `Memora/Uzun matn` plus
local `_assets` folders. Sync is one-way (Memora → Obsidian), debounced during
editing and flushed on editor exit. A managed Markdown block is updated in place so
user-authored Obsidian content outside that block is preserved. Topilmalar export
with the same full-card PNG used by Share plus a collapsed searchable text block.

`#hashtags` are recognized in Short, Long and Topilma editors, visually highlighted
in Memora, stored as metadata, rendered as chips, and exported as real Obsidian tags.
Note media and Topilma card images are copied to `_assets` and embedded with
Obsidian wiki-embed syntax. Existing backups remain importable; backup schema is 6.

Before Android build tasks, run the static acceptance gate and backend contract tests:

```bash
python3 tools/regression_0923.py
(cd backend && npm test)
```

## Privacy model

Notes, Topilmalar, sources, comments, likes, titles, images, audio, statistics and
backup contents remain local. When the user explicitly enables Obsidian integration,
selected Memora content is additionally written to the user-selected local Obsidian
vault through Android's Storage Access Framework; this is file access, not a Memora
server upload. Android cloud/device backup remains disabled. Topilmalar does not
upload cards or comments to a server. The only app network traffic is Google Play
Billing and a purchase-verification HTTPS request containing `packageName`,
`productId` and the Google Play `purchaseToken`. There are no ads, analytics or
crash-tracking SDKs.

An active subscription permits create/edit/delete/import. Expiry switches Memora
to read-only: existing notes, Topilmalar, search, statistics, media playback and
HTML/Word/Memora exports remain available. A successfully verified entitlement is
cached, encrypted by Android Keystore, for at most seven offline days and never
beyond the subscription expiry reported by Google Play.

## Build and test

Use JDK 17 and the official, checksum-pinned Gradle 8.13 wrapper:

```bash
./gradlew clean compileDebugKotlin
./gradlew testDebugUnitTest
./gradlew lintDebug
./gradlew assembleDebug
```

Debug builds use Memora's bundled, test-only stable signing key and enable a
debug-only entitlement so UI development does not require a Play test purchase.
This key exists only so GitHub debug APKs can update one another; Play Store release
signing is separate and private. The GitHub workflow also verifies the expected
certificate before uploading the debug APK artifact.

### Debug APK update chain

GitHub `assembleDebug` builds use the bundled test-only certificate with SHA-256
`77:2D:4A:04:10:F9:19:FD:0F:E2:77:DA:5E:DC:F4:92:10:25:DD:EC:3E:31:A0:71:D0:9A:79:DD:C8:17:FD:33`.
All debug APKs from 0.9.4 onward therefore share the same debug package ID and
signing certificate. An APK from 0.9.1–0.9.3 that was signed by GitHub's temporary
default debug key may require one final uninstall before 0.9.4 can be installed;
after 0.9.4, later debug builds update in place.

A release bundle fails unless the following environment variables are supplied:

- `MEMORA_KEYSTORE_PATH`
- `MEMORA_KEYSTORE_PASSWORD`
- `MEMORA_KEY_ALIAS`
- `MEMORA_KEY_PASSWORD`
- `MEMORA_BILLING_VERIFICATION_URL` (must be HTTPS)

No **production** signing key, password, service-account key or environment file
belongs in Git. The bundled `memora-test-debug.jks` is intentionally non-production
and exists only for debug update compatibility.
