package com.memora.app.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memora.app.prefs.AppLanguage

enum class RootTab { HOME, SEARCH, CALENDAR, SETTINGS }

@Composable
fun MemoraBottomBar(
    language: AppLanguage,
    selected: RootTab,
    onHome: () -> Unit,
    onSearch: () -> Unit,
    onAdd: () -> Unit,
    onCalendar: () -> Unit,
    onSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 8.dp),
        shape = RoundedCornerShape(28.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f),
        shadowElevation = 10.dp,
        tonalElevation = 2.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 7.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            RootItem(
                icon = Icons.Rounded.Home,
                label = bottomLabel(language, RootTab.HOME),
                selected = selected == RootTab.HOME,
                onClick = onHome
            )
            RootItem(
                icon = Icons.Rounded.Search,
                label = bottomLabel(language, RootTab.SEARCH),
                selected = selected == RootTab.SEARCH,
                onClick = onSearch
            )
            AddItem(onClick = onAdd)
            RootItem(
                icon = Icons.Rounded.CalendarMonth,
                label = bottomLabel(language, RootTab.CALENDAR),
                selected = selected == RootTab.CALENDAR,
                onClick = onCalendar
            )
            RootItem(
                icon = Icons.Rounded.Settings,
                label = bottomLabel(language, RootTab.SETTINGS),
                selected = selected == RootTab.SETTINGS,
                onClick = onSettings
            )
        }
    }
}

@Composable
private fun RootItem(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    val scale by animateFloatAsState(
        targetValue = if (selected) 1.07f else 1f,
        animationSpec = tween(190),
        label = "root-tab-scale"
    )
    val foreground = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
    val background = if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.10f) else Color.Transparent

    Surface(
        modifier = Modifier
            .scale(scale)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        color = background
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 7.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Icon(icon, contentDescription = label, tint = foreground, modifier = Modifier.size(24.dp))
            Text(
                label,
                color = foreground,
                fontSize = 9.sp,
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun AddItem(onClick: () -> Unit) {
    val primary = MaterialTheme.colorScheme.primary
    Surface(
        modifier = Modifier
            .size(56.dp)
            .clickable(onClick = onClick),
        shape = CircleShape,
        color = primary,
        shadowElevation = 8.dp
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(
                Icons.Rounded.Add,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.size(31.dp)
            )
        }
    }
}

private fun bottomLabel(language: AppLanguage, tab: RootTab): String = when (language) {
    AppLanguage.UZ -> when (tab) {
        RootTab.HOME -> "Bosh sahifa"
        RootTab.SEARCH -> "Qidirish"
        RootTab.CALENDAR -> "Taqvim"
        RootTab.SETTINGS -> "Sozlamalar"
    }
    AppLanguage.RU -> when (tab) {
        RootTab.HOME -> "Главная"
        RootTab.SEARCH -> "Поиск"
        RootTab.CALENDAR -> "Календарь"
        RootTab.SETTINGS -> "Настройки"
    }
    AppLanguage.AR -> when (tab) {
        RootTab.HOME -> "الرئيسية"
        RootTab.SEARCH -> "بحث"
        RootTab.CALENDAR -> "التقويم"
        RootTab.SETTINGS -> "الإعدادات"
    }
    AppLanguage.FR -> when (tab) {
        RootTab.HOME -> "Accueil"
        RootTab.SEARCH -> "Recherche"
        RootTab.CALENDAR -> "Calendrier"
        RootTab.SETTINGS -> "Réglages"
    }
    AppLanguage.DE -> when (tab) {
        RootTab.HOME -> "Start"
        RootTab.SEARCH -> "Suche"
        RootTab.CALENDAR -> "Kalender"
        RootTab.SETTINGS -> "Einstellungen"
    }
    AppLanguage.HI -> when (tab) {
        RootTab.HOME -> "होम"
        RootTab.SEARCH -> "खोज"
        RootTab.CALENDAR -> "कैलेंडर"
        RootTab.SETTINGS -> "सेटिंग्स"
    }
    AppLanguage.ID -> when (tab) {
        RootTab.HOME -> "Beranda"
        RootTab.SEARCH -> "Cari"
        RootTab.CALENDAR -> "Kalender"
        RootTab.SETTINGS -> "Setelan"
    }
    AppLanguage.JA -> when (tab) {
        RootTab.HOME -> "ホーム"
        RootTab.SEARCH -> "検索"
        RootTab.CALENDAR -> "カレンダー"
        RootTab.SETTINGS -> "設定"
    }
    AppLanguage.KO -> when (tab) {
        RootTab.HOME -> "홈"
        RootTab.SEARCH -> "검색"
        RootTab.CALENDAR -> "달력"
        RootTab.SETTINGS -> "설정"
    }
    AppLanguage.PT_BR -> when (tab) {
        RootTab.HOME -> "Início"
        RootTab.SEARCH -> "Buscar"
        RootTab.CALENDAR -> "Calendário"
        RootTab.SETTINGS -> "Ajustes"
    }
    AppLanguage.ES -> when (tab) {
        RootTab.HOME -> "Inicio"
        RootTab.SEARCH -> "Buscar"
        RootTab.CALENDAR -> "Calendario"
        RootTab.SETTINGS -> "Ajustes"
    }
    AppLanguage.TR -> when (tab) {
        RootTab.HOME -> "Ana sayfa"
        RootTab.SEARCH -> "Ara"
        RootTab.CALENDAR -> "Takvim"
        RootTab.SETTINGS -> "Ayarlar"
    }
    AppLanguage.EN -> when (tab) {
        RootTab.HOME -> "Home"
        RootTab.SEARCH -> "Search"
        RootTab.CALENDAR -> "Calendar"
        RootTab.SETTINGS -> "Settings"
    }
}
