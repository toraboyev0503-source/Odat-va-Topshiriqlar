package com.memora.app.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.memora.app.i18n.L
import com.memora.app.i18n.S
import com.memora.app.prefs.AppLanguage

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewNoteSheet(
    language: AppLanguage,
    onDismiss: () -> Unit,
    onShort: () -> Unit,
    onLong: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 20.dp, end = 20.dp, bottom = 28.dp)
        ) {
            Text(
                L.t(language, S.NEW_NOTE),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(bottom = 14.dp)
            )
            NewNoteOption(
                icon = { Icon(Icons.Rounded.Description, contentDescription = null) },
                title = L.t(language, S.SHORT_NOTES),
                subtitle = shortSubtitle(language),
                onClick = onShort
            )
            NewNoteOption(
                icon = { Icon(Icons.Rounded.MenuBook, contentDescription = null) },
                title = L.t(language, S.LONG_NOTES),
                subtitle = longSubtitle(language),
                onClick = onLong,
                modifier = Modifier.padding(top = 10.dp)
            )
        }
    }
}

@Composable
private fun NewNoteOption(
    icon: @Composable () -> Unit,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(22.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.11f)
            ) {
                androidx.compose.foundation.layout.Box(Modifier.padding(12.dp)) { icon() }
            }
            Column(Modifier.weight(1f).padding(start = 14.dp)) {
                Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Medium)
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 3.dp)
                )
            }
            Text("›", style = MaterialTheme.typography.titleLarge)
        }
    }
}

private fun shortSubtitle(language: AppLanguage): String = when (language) {
    AppLanguage.UZ -> "Kundalik qisqa qayd — 50 so‘zgacha"
    AppLanguage.RU -> "Короткая запись — до 50 слов"
    AppLanguage.AR -> "ملاحظة يومية قصيرة — حتى 50 كلمة"
    AppLanguage.FR -> "Note courte du jour — jusqu’à 50 mots"
    AppLanguage.DE -> "Kurzer Tagesnotiz — bis 50 Wörter"
    AppLanguage.HI -> "छोटी दैनिक नोट — 50 शब्द तक"
    AppLanguage.ID -> "Catatan singkat harian — hingga 50 kata"
    AppLanguage.JA -> "短い日記 — 50語まで"
    AppLanguage.KO -> "짧은 일상 기록 — 최대 50단어"
    AppLanguage.PT_BR -> "Registro curto — até 50 palavras"
    AppLanguage.ES -> "Nota breve — hasta 50 palabras"
    AppLanguage.TR -> "Kısa günlük not — en fazla 50 kelime"
    AppLanguage.EN -> "Short daily note — up to 50 words"
}

private fun longSubtitle(language: AppLanguage): String = when (language) {
    AppLanguage.UZ -> "Batafsil yozuv — cheklovsiz"
    AppLanguage.RU -> "Подробная запись — без лимита"
    AppLanguage.AR -> "كتابة مفصلة — بلا حد"
    AppLanguage.FR -> "Écriture détaillée — sans limite"
    AppLanguage.DE -> "Ausführlicher Eintrag — ohne Limit"
    AppLanguage.HI -> "विस्तृत लेखन — बिना सीमा"
    AppLanguage.ID -> "Tulisan panjang — tanpa batas"
    AppLanguage.JA -> "詳しい記録 — 制限なし"
    AppLanguage.KO -> "긴 기록 — 제한 없음"
    AppLanguage.PT_BR -> "Texto detalhado — sem limite"
    AppLanguage.ES -> "Escritura detallada — sin límite"
    AppLanguage.TR -> "Ayrıntılı yazı — sınırsız"
    AppLanguage.EN -> "Detailed writing — no limit"
}
