package com.memora.app.ui.screens

import android.animation.ValueAnimator
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.memora.app.R
import com.memora.app.i18n.L
import com.memora.app.i18n.S
import com.memora.app.prefs.AppLanguage

private val TiniqSage = Color(0xFF789786)
private val TiniqLavender = Color(0xFFE9E1F2)
private val TiniqMist = Color(0xFFDDEAF1)
private val TiniqInk = Color(0xFF202923)
private val TiniqMuted = Color(0xFF6F7973)

@Composable
fun HomeScreen(
    language: AppLanguage,
    shortCount: Int,
    longCount: Int,
    isDark: Boolean,
    onToggleDark: () -> Unit,
    onShort: () -> Unit,
    onLong: () -> Unit
) {
    val scroll = rememberScrollState()
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scroll)
                .padding(bottom = 18.dp)
        ) {
            TiniqHero(
                language = language,
                isDark = isDark,
                onToggleDark = onToggleDark
            )
            Column(Modifier.padding(horizontal = 20.dp)) {
                HomeNoteTypeCard(
                    title = L.t(language, S.SHORT_NOTES),
                    count = shortCount,
                    language = language,
                    icon = {
                        Icon(
                            Icons.Rounded.Description,
                            contentDescription = null,
                            tint = TiniqSage,
                            modifier = Modifier.size(32.dp)
                        )
                    },
                    tint = TiniqMist,
                    onClick = onShort
                )
                Spacer(Modifier.height(14.dp))
                HomeNoteTypeCard(
                    title = L.t(language, S.LONG_NOTES),
                    count = longCount,
                    language = language,
                    icon = {
                        Icon(
                            Icons.Rounded.MenuBook,
                            contentDescription = null,
                            tint = Color(0xFF7777A8),
                            modifier = Modifier.size(32.dp)
                        )
                    },
                    tint = TiniqLavender,
                    onClick = onLong
                )
                Spacer(Modifier.height(14.dp))
                MemoryQuoteCard(language)
                Spacer(Modifier.height(14.dp))
            }
        }
    }
}

@Composable
private fun TiniqHero(
    language: AppLanguage,
    isDark: Boolean,
    onToggleDark: () -> Unit
) {
    val context = LocalContext.current
    val animationsEnabled = remember { ValueAnimator.areAnimatorsEnabled() }
    val transition = rememberInfiniteTransition(label = "tiniq-home-atmosphere")

    val sunPulse by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 4800),
            repeatMode = RepeatMode.Reverse
        ),
        label = "sun-pulse"
    )
    val leftSway by transition.animateFloat(
        initialValue = -1.1f,
        targetValue = 1.1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3400),
            repeatMode = RepeatMode.Reverse
        ),
        label = "left-branch"
    )
    val rightSway by transition.animateFloat(
        initialValue = 0.9f,
        targetValue = -0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 4100),
            repeatMode = RepeatMode.Reverse
        ),
        label = "right-branch"
    )
    val waterShift by transition.animateFloat(
        initialValue = -10f,
        targetValue = 10f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 5200),
            repeatMode = RepeatMode.Reverse
        ),
        label = "water-shimmer"
    )
    val mistShift by transition.animateFloat(
        initialValue = -8f,
        targetValue = 8f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 8600),
            repeatMode = RepeatMode.Reverse
        ),
        label = "mist-shift"
    )

    val pulse = if (animationsEnabled && !isDark) sunPulse else 0.5f
    val leftAngle = if (animationsEnabled && !isDark) leftSway else 0f
    val rightAngle = if (animationsEnabled && !isDark) rightSway else 0f
    val waterX = if (animationsEnabled && !isDark) waterShift else 0f
    val mistX = if (animationsEnabled && !isDark) mistShift else 0f

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(430.dp)
            .clip(RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp))
            .background(
                if (isDark) MaterialTheme.colorScheme.background
                else Brush.verticalGradient(listOf(Color(0xFFF7FAFB), Color(0xFFF2F7F5)))
            )
    ) {
        if (!isDark) {
            Image(
                painter = painterResource(R.drawable.memora_tiniq_mountains),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(310.dp)
                    .align(Alignment.BottomCenter)
                    .alpha(0.98f)
            )

            Image(
                painter = painterResource(R.drawable.memora_tiniq_water),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(118.dp)
                    .align(Alignment.BottomCenter)
                    .graphicsLayer { translationX = waterX }
                    .alpha(0.83f)
            )

            Box(
                modifier = Modifier
                    .size((86 + pulse * 3).dp)
                    .align(Alignment.TopEnd)
                    .offset(x = (-52).dp, y = 132.dp)
                    .graphicsLayer { alpha = 0.73f + pulse * 0.10f }
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                Color(0xFFFFE6B3).copy(alpha = 0.92f),
                                Color(0xFFFFE6B3).copy(alpha = 0.26f),
                                Color.Transparent
                            )
                        ),
                        shape = CircleShape
                    )
            )

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(150.dp)
                    .align(Alignment.BottomCenter)
                    .graphicsLayer { translationX = mistX }
                    .background(
                        Brush.horizontalGradient(
                            listOf(
                                Color.Transparent,
                                Color.White.copy(alpha = 0.18f),
                                Color.White.copy(alpha = 0.26f),
                                Color.Transparent
                            )
                        )
                    )
            )

            Image(
                painter = painterResource(R.drawable.memora_tiniq_branch),
                contentDescription = null,
                modifier = Modifier
                    .size(width = 160.dp, height = 218.dp)
                    .align(Alignment.CenterStart)
                    .offset(x = (-48).dp, y = 42.dp)
                    .graphicsLayer {
                        rotationZ = leftAngle
                        transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0.12f, 0.92f)
                    },
                contentScale = ContentScale.Fit
            )

            Image(
                painter = painterResource(R.drawable.memora_tiniq_branch),
                contentDescription = null,
                modifier = Modifier
                    .size(width = 122.dp, height = 168.dp)
                    .align(Alignment.BottomEnd)
                    .offset(x = 32.dp, y = (-6).dp)
                    .graphicsLayer {
                        scaleX = -1f
                        rotationZ = rightAngle
                        transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0.88f, 0.92f)
                    },
                contentScale = ContentScale.Fit
            )
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 22.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "Memora",
                        style = MaterialTheme.typography.displayMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = if (isDark) MaterialTheme.colorScheme.onBackground else TiniqInk
                    )
                    Text(
                        L.t(language, S.HOME_TAGLINE),
                        style = MaterialTheme.typography.bodyLarge,
                        color = if (isDark) MaterialTheme.colorScheme.onSurfaceVariant else TiniqMuted,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.88f),
                    shadowElevation = 2.dp
                ) {
                    IconButton(onClick = onToggleDark, modifier = Modifier.size(46.dp)) {
                        Icon(
                            if (isDark) Icons.Rounded.LightMode else Icons.Rounded.DarkMode,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeNoteTypeCard(
    title: String,
    count: Int,
    language: AppLanguage,
    icon: @Composable () -> Unit,
    tint: Color,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(28.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.98f),
        shadowElevation = 2.dp
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = tint.copy(alpha = 0.72f),
                modifier = Modifier.size(62.dp)
            ) {
                Box(contentAlignment = Alignment.Center) { icon() }
            }
            Column(Modifier.weight(1f).padding(start = 18.dp)) {
                Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Medium)
                Text(
                    "$count ${L.t(language, S.NOTES)}",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
            Icon(Icons.Rounded.ArrowForward, contentDescription = null, modifier = Modifier.size(26.dp))
        }
    }
}

@Composable
private fun MemoryQuoteCard(language: AppLanguage) {
    Surface(
        shape = RoundedCornerShape(28.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f),
        shadowElevation = 1.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "“",
                style = MaterialTheme.typography.displaySmall,
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.70f)
            )
            Text(
                memoryQuote(language),
                style = MaterialTheme.typography.bodyLarge,
                fontStyle = FontStyle.Italic,
                textAlign = TextAlign.Center,
                modifier = Modifier.weight(1f).padding(horizontal = 10.dp)
            )
            Image(
                painter = painterResource(R.drawable.memora_tiniq_branch),
                contentDescription = null,
                modifier = Modifier.size(54.dp).alpha(0.62f),
                contentScale = ContentScale.Fit
            )
        }
    }
}

private fun memoryQuote(language: AppLanguage): String = when (language) {
    AppLanguage.UZ -> "Bugungi kichik fikrlar, ertangi katta o‘zgarishlar."
    AppLanguage.RU -> "Маленькие мысли сегодня — большие перемены завтра."
    AppLanguage.AR -> "أفكار صغيرة اليوم، تغييرات كبيرة غدًا."
    AppLanguage.FR -> "Petites pensées aujourd’hui, grands changements demain."
    AppLanguage.DE -> "Kleine Gedanken heute, große Veränderungen morgen."
    AppLanguage.HI -> "आज के छोटे विचार, कल के बड़े बदलाव।"
    AppLanguage.ID -> "Pikiran kecil hari ini, perubahan besar esok."
    AppLanguage.JA -> "今日の小さな思いが、明日の大きな変化へ。"
    AppLanguage.KO -> "오늘의 작은 생각이 내일의 큰 변화를 만듭니다."
    AppLanguage.PT_BR -> "Pequenos pensamentos hoje, grandes mudanças amanhã."
    AppLanguage.ES -> "Pequeños pensamientos hoy, grandes cambios mañana."
    AppLanguage.TR -> "Bugünün küçük düşünceleri, yarının büyük değişimleri."
    AppLanguage.EN -> "Small thoughts today, big changes tomorrow."
}
