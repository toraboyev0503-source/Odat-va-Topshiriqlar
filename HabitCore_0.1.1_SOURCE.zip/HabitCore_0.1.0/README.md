# HabitCore 0.1.0 — GitHub Build

This ZIP is prepared specifically for GitHub Actions.

## Current 0.1.0 scope
- Kotlin + Jetpack Compose base
- Home: Habits + Tasks placeholder
- Room data model for habits, entries, archive/pause
- Yes/No and measurable scoring core
- Daily / weekly / monthly score math foundation
- EN / RU / UZ string resources
- API 37 / JDK 17
- GitHub Actions builds the debug APK

## How to build on GitHub
1. Extract the ZIP.
2. Upload **the contents inside the extracted folder** to the repository root.
3. Confirm `.github/workflows/main.yml` exists in the repo.
4. Open **Actions → Android Build → Run workflow**.
5. After success, download artifact: `HabitCore-0.1.0-debug-apk`.

The workflow installs Gradle 9.4.1 and Android API 37 itself, so a Gradle Wrapper JAR is not required for GitHub Actions.
