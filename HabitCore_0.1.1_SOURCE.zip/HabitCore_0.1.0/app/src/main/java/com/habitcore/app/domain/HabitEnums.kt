package com.habitcore.app.domain

enum class HabitType { YES_NO, MEASURABLE }
enum class HabitStatus { DONE, FAILED, UNKNOWN }
enum class FrequencyType { DAILY, EVERY_N_DAYS, TIMES_PER_WEEK, TIMES_PER_MONTH, TIMES_IN_N_DAYS }
enum class PerformanceLevel { RED, YELLOW, BLUE, GREEN }
