package com.habitcore.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.TaskAlt
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.habitcore.app.R

@Composable
fun HomeScreen(onHabitsClick: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = onHabitsClick) {
            Icon(Icons.Outlined.CheckCircle, contentDescription = null)
            Text(stringResource(R.string.habits), modifier = Modifier.padding(start = 10.dp))
        }

        OutlinedButton(
            modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
            onClick = { }
        ) {
            Icon(Icons.Outlined.TaskAlt, contentDescription = null)
            Text(stringResource(R.string.tasks), modifier = Modifier.padding(start = 10.dp))
        }
    }
}
