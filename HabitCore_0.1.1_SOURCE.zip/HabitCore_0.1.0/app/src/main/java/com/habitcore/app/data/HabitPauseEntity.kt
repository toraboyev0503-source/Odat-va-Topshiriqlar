package com.habitcore.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "habit_pauses")
data class HabitPauseEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val habitId: Long,
    val startEpochDay: Long,
    val endEpochDay: Long? = null
)
