package com.habitcore.app.domain

import kotlin.math.roundToInt

object ScoreCalculator {
    fun yesNoScore(status: HabitStatus): Double = when (status) {
        HabitStatus.DONE -> 1.0
        HabitStatus.FAILED -> 0.0
        HabitStatus.UNKNOWN -> 0.0
    }

    fun measurableScore(actual: Double, target: Double): Double {
        if (target <= 0.0) return 0.0
        return (actual / target).coerceIn(0.0, 1.0)
    }

    fun completionCount(scores: List<Double>): Double = scores.sum()

    fun dailyScore(scheduledHabitScores: List<Double>): Double? {
        if (scheduledHabitScores.isEmpty()) return null
        return scheduledHabitScores.average().coerceIn(0.0, 1.0)
    }

    fun periodScore(dailyScores: List<Double?>): Double? {
        val valid = dailyScores.filterNotNull()
        return if (valid.isEmpty()) null else valid.average()
    }

    fun percent(score: Double?): Int = ((score ?: 0.0) * 100).roundToInt().coerceIn(0, 100)

    fun performanceLevel(percent: Int): PerformanceLevel = when (percent) {
        in 0..49 -> PerformanceLevel.RED
        in 50..74 -> PerformanceLevel.YELLOW
        in 75..89 -> PerformanceLevel.BLUE
        else -> PerformanceLevel.GREEN
    }
}
