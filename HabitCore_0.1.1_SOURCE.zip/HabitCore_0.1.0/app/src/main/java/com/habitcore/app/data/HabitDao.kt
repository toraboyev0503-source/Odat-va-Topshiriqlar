package com.habitcore.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface HabitDao {
    @Insert suspend fun insertHabit(habit: HabitEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveEntry(entry: HabitEntryEntity)

    @Insert suspend fun insertPause(pause: HabitPauseEntity)

    @Query("SELECT * FROM habits WHERE archivedEpochDay IS NULL ORDER BY id ASC")
    fun observeActiveHabits(): Flow<List<HabitEntity>>

    @Query("SELECT * FROM habit_entries WHERE habitId = :habitId ORDER BY epochDay ASC")
    suspend fun getEntries(habitId: Long): List<HabitEntryEntity>

    @Query("SELECT * FROM habit_entries WHERE epochDay = :epochDay")
    suspend fun getEntriesForDay(epochDay: Long): List<HabitEntryEntity>

    @Query("SELECT SUM(score) FROM habit_entries WHERE habitId = :habitId")
    suspend fun completionCount(habitId: Long): Double?

    @Query("UPDATE habits SET archivedEpochDay = :epochDay WHERE id = :habitId")
    suspend fun archiveHabit(habitId: Long, epochDay: Long)
}
