package com.memora.app.share

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.FileProvider
import com.memora.app.data.local.TopilmaCardRow
import com.memora.app.media.TopilmalarMediaStorage
import java.io.File
import java.io.FileOutputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object TopilmaShareManager {
    fun shareText(context: Context, card: TopilmaCardRow, includeSource: Boolean) {
        val text = buildString {
            append(card.text)
            if (includeSource && !card.sourceTitle.isNullOrBlank()) {
                append("\n\n— ").append(card.sourceTitle)
                if (!card.sourceAuthor.isNullOrBlank()) append(", ").append(card.sourceAuthor)
            }
        }
        context.startActivity(
            Intent.createChooser(
                Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, text)
                },
                "Topilmani ulashish"
            )
        )
    }

    suspend fun shareCardImage(context: Context, card: TopilmaCardRow) {
        val uri = withContext(Dispatchers.IO) {
            val bitmap = render(context, card)
            val directory = File(context.cacheDir, "shares").apply { mkdirs() }
            val file = File(directory, "topilma-${card.id}.png")
            FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            bitmap.recycle()
            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        }
        withContext(Dispatchers.Main) {
            context.startActivity(
                Intent.createChooser(
                    Intent(Intent.ACTION_SEND).apply {
                        type = "image/png"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    },
                    "Kartochka rasmini ulashish"
                )
            )
        }
    }

    private fun render(context: Context, card: TopilmaCardRow): Bitmap {
        val width = 1080
        val height = 1350
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.rgb(247, 246, 242))

        val accent = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(47, 93, 80) }
        canvas.drawRoundRect(72f, 72f, 1008f, 1278f, 48f, 48f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE })
        canvas.drawRoundRect(104f, 108f, 118f, 1242f, 7f, 7f, accent)

        val quotePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(28, 35, 31)
            textSize = when {
                card.text.length < 220 -> 54f
                card.text.length < 480 -> 46f
                else -> 38f
            }
            typeface = Typeface.create(Typeface.SERIF, Typeface.NORMAL)
        }
        val quote = StaticLayout.Builder.obtain(card.text, 0, card.text.length, quotePaint, 780)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setLineSpacing(10f, 1f)
            .setMaxLines(18)
            .setEllipsize(android.text.TextUtils.TruncateAt.END)
            .build()
        canvas.save()
        canvas.translate(166f, 178f)
        quote.draw(canvas)
        canvas.restore()

        val source = buildString {
            if (!card.sourceTitle.isNullOrBlank()) append(card.sourceTitle)
            if (!card.sourceAuthor.isNullOrBlank()) {
                if (isNotEmpty()) append(" · ")
                append(card.sourceAuthor)
            }
            if (isEmpty()) append("Manbasi aniqlanmagan")
        }
        val thumbnail = card.sourceCoverPath?.let { relativePath ->
            runCatching {
                decodeThumbnail(TopilmalarMediaStorage(context).resolve(relativePath), 160)
            }.getOrNull()
        }
        val thumbLeft = 166f
        val thumbTop = 1088f
        if (thumbnail != null) {
            canvas.save()
            canvas.clipRect(thumbLeft, thumbTop, thumbLeft + 76f, thumbTop + 76f)
            canvas.drawBitmap(thumbnail, null, android.graphics.RectF(thumbLeft, thumbTop, thumbLeft + 76f, thumbTop + 76f), null)
            canvas.restore()
            thumbnail.recycle()
        } else {
            canvas.drawRoundRect(thumbLeft, thumbTop, thumbLeft + 76f, thumbTop + 76f, 16f, 16f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(226, 237, 232) })
            canvas.drawText("M", thumbLeft + 23f, thumbTop + 52f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(47, 93, 80); textSize = 42f; typeface = Typeface.DEFAULT_BOLD })
        }

        val sourcePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(82, 101, 92)
            textSize = 34f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val sourceLayout = StaticLayout.Builder.obtain(source, 0, source.length, sourcePaint, 650)
            .setMaxLines(2)
            .setEllipsize(android.text.TextUtils.TruncateAt.END)
            .build()
        canvas.save()
        canvas.translate(266f, 1090f)
        sourceLayout.draw(canvas)
        canvas.restore()

        val brand = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(47, 93, 80)
            textSize = 28f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        canvas.drawText("Memora · Topilmalar", 166f, 1234f, brand)
        return bitmap
    }

    private fun decodeThumbnail(file: File, target: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (bounds.outWidth / sample > target * 2 || bounds.outHeight / sample > target * 2) sample *= 2
        return BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
    }
}
