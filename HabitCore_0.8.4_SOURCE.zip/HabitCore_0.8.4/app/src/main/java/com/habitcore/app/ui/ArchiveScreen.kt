@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.habitcore.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.habitcore.app.data.HabitEntity
import java.time.LocalDate

@Composable
fun ArchiveScreen(
    vm: AppViewModel,
    onBack: () -> Unit
) {
    val prefs by vm.prefs.collectAsState()
    val habits by vm.habits.collectAsState()
    var deleteTarget by remember {
        mutableStateOf<HabitEntity?>(null)
    }

    val archived = remember(habits) {
        habits.filter {
            it.archivedEpochDay != null &&
                it.deletedEpochDay == null
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(tr(prefs.language, "archived"))
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            Icons.Outlined.ArrowBack,
                            null
                        )
                    }
                }
            )
        }
    ) { padding ->
        if (archived.isEmpty()) {
            Box(
                Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "—",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(12.dp)
            ) {
                items(
                    items = archived,
                    key = { it.id },
                    contentType = { "archivedHabit" }
                ) { habit ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(60.dp)
                            .padding(vertical = 3.dp),
                        shape = appShape(),
                        border = BorderStroke(
                            appBorderWidth(),
                            MaterialTheme.colorScheme.outlineVariant
                        )
                    ) {
                        Row(
                            Modifier
                                .fillMaxSize()
                                .padding(horizontal = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                habit.name,
                                modifier = Modifier.weight(1f)
                            )

                            TextButton(
                                onClick = {
                                    vm.restoreHabit(habit.id)
                                }
                            ) {
                                Text(tr(prefs.language, "restore"))
                            }

                            IconButton(
                                onClick = {
                                    deleteTarget = habit
                                }
                            ) {
                                Icon(
                                    Icons.Outlined.DeleteOutline,
                                    tr(prefs.language, "delete"),
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    deleteTarget?.let { habit ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = {
                Text(tr(prefs.language, "deleteHabit"))
            },
            text = {
                Text(tr(prefs.language, "deleteHabitConfirm"))
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        vm.deleteHabit(
                            habit.id,
                            LocalDate.now().toEpochDay()
                        )
                        deleteTarget = null
                    }
                ) {
                    Text(
                        tr(prefs.language, "delete"),
                        color = MaterialTheme.colorScheme.error
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { deleteTarget = null }) {
                    Text(tr(prefs.language, "cancel"))
                }
            }
        )
    }
}
