package com.habitcore.app.data

import androidx.room.Entity

@Entity(
    tableName = "task_plans",
    primaryKeys = ["taskId", "epochDay"]
)
data class TaskPlanEntity(
    val taskId: Long,
    val epochDay: Long,
    val completed: Boolean = false
)
