package com.habitcore.app.ui

import androidx.compose.ui.graphics.Color

fun performanceColor(percent: Int): Color = when (percent) {
    in 0..49 -> Color(0xFFC83D3D)
    in 50..74 -> Color(0xFFD39B2D)
    in 75..89 -> Color(0xFF3E72B8)
    else -> Color(0xFF39865A)
}
