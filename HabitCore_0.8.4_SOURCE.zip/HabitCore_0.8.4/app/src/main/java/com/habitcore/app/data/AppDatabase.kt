package com.habitcore.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        HabitEntity::class,
        HabitEntryEntity::class,
        HabitPauseEntity::class,
        HabitCategoryEntity::class,
        TaskEntity::class,
        TaskPlanEntity::class
    ],
    version = 6,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun habitDao(): HabitDao
    abstract fun taskDao(): TaskDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `habit_categories` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `name` TEXT NOT NULL,
                        `sortOrder` INTEGER NOT NULL,
                        `createdAtMillis` INTEGER NOT NULL
                    )
                    """.trimIndent()
                )

                db.execSQL(
                    """
                    INSERT OR IGNORE INTO `habit_categories`
                    (`id`, `name`, `sortOrder`, `createdAtMillis`)
                    VALUES (1, 'General', 0, ${System.currentTimeMillis()})
                    """.trimIndent()
                )

                db.execSQL(
                    "ALTER TABLE `habits` ADD COLUMN `categoryId` INTEGER NOT NULL DEFAULT 1"
                )
            }
        }

        private val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "ALTER TABLE `habits` ADD COLUMN `deletedEpochDay` INTEGER DEFAULT NULL"
                )
            }
        }


        private val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // 0.5-0.7 generated carry-over plans for every overdue day. The new contract
                // counts a task only on explicitly scheduled days. Remove only synthetic
                // forward rows for still-open tasks; original and rescheduled historical
                // commitments (which are <= the task's explicit scheduled day) remain intact.
                db.execSQL(
                    """
                    DELETE FROM task_plans
                    WHERE completed = 0
                      AND EXISTS (
                        SELECT 1 FROM tasks
                        WHERE tasks.id = task_plans.taskId
                          AND tasks.completed = 0
                          AND task_plans.epochDay > tasks.scheduledEpochDay
                      )
                    """.trimIndent()
                )
            }
        }

        private val DEFAULT_CATEGORY_CALLBACK = object : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                db.execSQL(
                    """
                    INSERT OR IGNORE INTO `habit_categories`
                    (`id`, `name`, `sortOrder`, `createdAtMillis`)
                    VALUES (1, 'General', 0, ${System.currentTimeMillis()})
                    """.trimIndent()
                )
            }

            override fun onOpen(db: SupportSQLiteDatabase) {
                super.onOpen(db)
                db.execSQL(
                    """
                    INSERT OR IGNORE INTO `habit_categories`
                    (`id`, `name`, `sortOrder`, `createdAtMillis`)
                    VALUES (1, 'General', 0, ${System.currentTimeMillis()})
                    """.trimIndent()
                )
            }
        }

        fun getInstance(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "habit_core.db"
                )
                    .addMigrations(MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6)
                    .addCallback(DEFAULT_CATEGORY_CALLBACK)
                    .build()
                    .also { INSTANCE = it }
            }
    }
}
