@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.habitcore.app.ui

import android.app.TimePickerDialog
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.habitcore.app.domain.AppLanguage
import com.habitcore.app.domain.AppMode
import com.habitcore.app.domain.ReminderSlot
import com.habitcore.app.domain.ThemeChoice
import java.util.Locale

@Composable
private fun SimpleTop(title: String, onBack: () -> Unit, content: @Composable (androidx.compose.foundation.layout.PaddingValues) -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Outlined.ArrowBack, null) } }
            )
        },
        content = content
    )
}

@Composable
fun ThemeScreen(vm: AppViewModel, onBack: () -> Unit) {
    val prefs by vm.prefs.collectAsState()
    val lang = prefs.language

    SimpleTop(tr(lang, "theme"), onBack) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ThemeChoice.entries.forEach { choice ->
                val selected = prefs.theme == choice
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            vm.updatePrefs {
                                it.copy(theme = choice, themeAccent = it.themeAccent.coerceIn(0, 3))
                            }
                        },
                    shape = appShape(),
                    border = BorderStroke(
                        if (selected) appBorderWidth() + 1.dp else appBorderWidth(),
                        if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
                    )
                ) {
                    Column(Modifier.fillMaxWidth().padding(14.dp)) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(themeStyleName(choice), style = MaterialTheme.typography.titleMedium)
                                Text(
                                    themeCharacter(choice, lang),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(top = 2.dp)
                                )
                            }
                            if (selected) {
                                Box(Modifier.size(12.dp).background(MaterialTheme.colorScheme.primary, CircleShape))
                            }
                        }

                        Row(
                            Modifier.padding(top = 12.dp),
                            horizontalArrangement = Arrangement.spacedBy(11.dp)
                        ) {
                            themeAccentColors(choice).forEachIndexed { index, color ->
                                val accentSelected = selected && prefs.themeAccent == index
                                Box(
                                    modifier = Modifier
                                        .size(if (accentSelected) 35.dp else 30.dp)
                                        .background(color, CircleShape)
                                        .then(
                                            if (accentSelected) Modifier.border(2.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                                            else Modifier
                                        )
                                        .clickable {
                                            vm.updatePrefs { it.copy(theme = choice, themeAccent = index) }
                                        }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun themeCharacter(choice: ThemeChoice, lang: AppLanguage): String = when (lang) {
    AppLanguage.EN -> when (choice) {
        ThemeChoice.MINIMAL_PREMIUM -> "quiet · premium · precise"
        ThemeChoice.DARK_GLASS -> "glass · deep navy · luminous"
        ThemeChoice.PRODUCTIVITY_PRO -> "focused · data-first · energetic"
        ThemeChoice.ORGANIC_CALM -> "warm · natural · calm"
        ThemeChoice.NEO_BRUTALIST -> "bold · square · high contrast"
        ThemeChoice.FUTURISTIC_DEPTH -> "neon · depth · technical"
        ThemeChoice.EDITORIAL_MONO -> "editorial · monochrome · disciplined"
        ThemeChoice.SCANDINAVIAN_SOFT -> "soft · airy · balanced"
        ThemeChoice.DARK_GOLD_LUXE -> "black · gold · luxurious"
        ThemeChoice.MODERN_UNIVERSAL -> "modern · universal · clear"
    }
    AppLanguage.RU -> when (choice) {
        ThemeChoice.MINIMAL_PREMIUM -> "тихий · премиальный · точный"
        ThemeChoice.DARK_GLASS -> "стекло · тёмный · светящийся"
        ThemeChoice.PRODUCTIVITY_PRO -> "рабочий · динамичный · аналитичный"
        ThemeChoice.ORGANIC_CALM -> "тёплый · природный · спокойный"
        ThemeChoice.NEO_BRUTALIST -> "смелый · угловатый · контрастный"
        ThemeChoice.FUTURISTIC_DEPTH -> "неон · глубина · технологичный"
        ThemeChoice.EDITORIAL_MONO -> "редакционный · моно · строгий"
        ThemeChoice.SCANDINAVIAN_SOFT -> "мягкий · воздушный · ровный"
        ThemeChoice.DARK_GOLD_LUXE -> "чёрный · золото · премиум"
        ThemeChoice.MODERN_UNIVERSAL -> "современный · универсальный · чистый"
    }
    AppLanguage.UZ -> when (choice) {
        ThemeChoice.MINIMAL_PREMIUM -> "sokin · premium · aniq"
        ThemeChoice.DARK_GLASS -> "shisha · chuqur tun · yorqin"
        ThemeChoice.PRODUCTIVITY_PRO -> "ishchan · tezkor · tahliliy"
        ThemeChoice.ORGANIC_CALM -> "iliq · tabiiy · sokin"
        ThemeChoice.NEO_BRUTALIST -> "dadil · burchakli · kontrast"
        ThemeChoice.FUTURISTIC_DEPTH -> "neon · chuqurlik · texnologik"
        ThemeChoice.EDITORIAL_MONO -> "editorial · mono · intizomli"
        ThemeChoice.SCANDINAVIAN_SOFT -> "yumshoq · yengil · muvozanatli"
        ThemeChoice.DARK_GOLD_LUXE -> "qora · oltin · hashamatli"
        ThemeChoice.MODERN_UNIVERSAL -> "zamonaviy · universal · tiniq"
    }
}

@Composable
fun LanguageScreen(vm: AppViewModel, onBack: () -> Unit) {
    val prefs by vm.prefs.collectAsState()
    val lang = prefs.language
    SimpleTop(tr(lang, "language"), onBack) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            LanguageRow("English", AppLanguage.EN, prefs.language) { vm.updatePrefs { p -> p.copy(language = it) } }
            LanguageRow("Русский", AppLanguage.RU, prefs.language) { vm.updatePrefs { p -> p.copy(language = it) } }
            LanguageRow("O‘zbek", AppLanguage.UZ, prefs.language) { vm.updatePrefs { p -> p.copy(language = it) } }
        }
    }
}

@Composable
private fun LanguageRow(label: String, value: AppLanguage, selected: AppLanguage, onChange: (AppLanguage) -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(58.dp).clickable { onChange(value) },
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected == value, onClick = { onChange(value) })
        Text(label, modifier = Modifier.padding(start = 8.dp))
    }
}

@Composable
fun NotificationsScreen(vm: AppViewModel, onBack: () -> Unit) {
    val prefs by vm.prefs.collectAsState()
    val lang = prefs.language
    SimpleTop(tr(lang, "notifications"), onBack) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp)) {
            ToggleRow(tr(lang, "master"), prefs.notificationsEnabled) { v -> vm.updatePrefs { it.copy(notificationsEnabled = v) } }
            SectionLabel(tr(lang, "reminders"))
            ReminderRow("1", prefs.reminder1, prefs.notificationsEnabled) { slot -> vm.updatePrefs { it.copy(reminder1 = slot) } }
            ReminderRow("2", prefs.reminder2, prefs.notificationsEnabled) { slot -> vm.updatePrefs { it.copy(reminder2 = slot) } }
            ReminderRow("3", prefs.reminder3, prefs.notificationsEnabled) { slot -> vm.updatePrefs { it.copy(reminder3 = slot) } }
            SectionLabel(tr(lang, "results"))
            ToggleRow("${tr(lang, "daily")} · 05:00", prefs.resultDaily, prefs.notificationsEnabled) { v -> vm.updatePrefs { it.copy(resultDaily = v) } }
            ToggleRow("${tr(lang, "weekly")} · Mon 09:00", prefs.resultWeekly, prefs.notificationsEnabled) { v -> vm.updatePrefs { it.copy(resultWeekly = v) } }
            ToggleRow("${tr(lang, "monthly")} · 1 · 10:00", prefs.resultMonthly, prefs.notificationsEnabled) { v -> vm.updatePrefs { it.copy(resultMonthly = v) } }
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(text, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 18.dp, bottom = 6.dp))
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().height(56.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}

@Composable
private fun ReminderRow(label: String, slot: ReminderSlot, masterEnabled: Boolean, onChange: (ReminderSlot) -> Unit) {
    val context = LocalContext.current
    Row(Modifier.fillMaxWidth().height(58.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.padding(end = 12.dp))
        Text(
            String.format(Locale.US, "%02d:%02d", slot.hour, slot.minute),
            modifier = Modifier.weight(1f).clickable(enabled = masterEnabled && slot.enabled) {
                TimePickerDialog(context, { _, h, m -> onChange(slot.copy(hour = h, minute = m)) }, slot.hour, slot.minute, true).show()
            },
            color = if (masterEnabled && slot.enabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
        )
        Switch(checked = slot.enabled, onCheckedChange = { onChange(slot.copy(enabled = it)) }, enabled = masterEnabled)
    }
}

@Composable
fun SettingsScreen(vm: AppViewModel, onBack: () -> Unit) {
    val prefs by vm.prefs.collectAsState()
    val lang = prefs.language
    SimpleTop(tr(lang, "settings"), onBack) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            ToggleRow(tr(lang, "celebration"), prefs.celebration) { v -> vm.updatePrefs { it.copy(celebration = v) } }
        }
    }
}
