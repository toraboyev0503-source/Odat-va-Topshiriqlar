package com.habitcore.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Assignment
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.habitcore.app.domain.AppLanguage

enum class MainTab { HABITS, TASKS, MONITORING, PROFILE }

@Composable
fun AppBottomBar(
    selected: MainTab,
    lang: AppLanguage,
    onSelect: (MainTab) -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surface.copy(alpha = appCardAlpha()),
        border = BorderStroke(appBorderWidth(), MaterialTheme.colorScheme.outlineVariant)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .height(if (appCompact()) 58.dp else 64.dp)
                .padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            BottomItem(MainTab.HABITS, selected, tr(lang, "habits"), Icons.Outlined.CheckCircle, onSelect)
            BottomItem(MainTab.TASKS, selected, tr(lang, "tasks"), Icons.Outlined.Assignment, onSelect)
            BottomItem(MainTab.MONITORING, selected, tr(lang, "monitoring"), Icons.Outlined.BarChart, onSelect)
            BottomItem(MainTab.PROFILE, selected, tr(lang, "profile"), Icons.Outlined.Person, onSelect)
        }
    }
}

@Composable
private fun BottomItem(
    tab: MainTab,
    selected: MainTab,
    label: String,
    icon: ImageVector,
    onSelect: (MainTab) -> Unit
) {
    val active = tab == selected
    val color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
    Box(
        modifier = Modifier
            .clickable { onSelect(tab) }
            .padding(horizontal = 9.dp, vertical = 5.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, contentDescription = label, tint = color)
            Text(
                label,
                fontSize = 10.sp,
                color = color,
                fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal,
                maxLines = 1
            )
        }
    }
}
