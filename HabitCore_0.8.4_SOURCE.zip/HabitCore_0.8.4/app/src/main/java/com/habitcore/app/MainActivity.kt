package com.habitcore.app

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.viewmodel.compose.viewModel
import com.habitcore.app.data.PreferenceStore
import com.habitcore.app.domain.ThemeChoice
import com.habitcore.app.ui.AppViewModel
import com.habitcore.app.ui.HabitCoreApp

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        val themeChoice = PreferenceStore(this).load().theme
        setTheme(mainThemeResource(themeChoice))
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent {
            val vm: AppViewModel = viewModel()
            HabitCoreApp(vm)
        }
    }

    private fun mainThemeResource(theme: ThemeChoice): Int = when (theme) {
        ThemeChoice.MINIMAL_PREMIUM -> R.style.Theme_HabitCore_Main_MinimalPremium
        ThemeChoice.DARK_GLASS -> R.style.Theme_HabitCore_Main_DarkGlass
        ThemeChoice.PRODUCTIVITY_PRO -> R.style.Theme_HabitCore_Main_ProductivityPro
        ThemeChoice.ORGANIC_CALM -> R.style.Theme_HabitCore_Main_OrganicCalm
        ThemeChoice.NEO_BRUTALIST -> R.style.Theme_HabitCore_Main_NeoBrutalist
        ThemeChoice.FUTURISTIC_DEPTH -> R.style.Theme_HabitCore_Main_FuturisticDepth
        ThemeChoice.EDITORIAL_MONO -> R.style.Theme_HabitCore_Main_EditorialMono
        ThemeChoice.SCANDINAVIAN_SOFT -> R.style.Theme_HabitCore_Main_ScandinavianSoft
        ThemeChoice.DARK_GOLD_LUXE -> R.style.Theme_HabitCore_Main_DarkGoldLuxe
        ThemeChoice.MODERN_UNIVERSAL -> R.style.Theme_HabitCore_Main_ModernUniversal
    }
}
