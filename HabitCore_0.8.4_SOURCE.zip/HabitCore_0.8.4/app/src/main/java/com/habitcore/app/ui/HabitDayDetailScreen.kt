@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.habitcore.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.habitcore.app.data.HabitEntity
import com.habitcore.app.data.HabitEntryEntity
import com.habitcore.app.domain.Schedule
import com.habitcore.app.domain.ScoreCalculator
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun HabitDayDetailScreen(
    vm: AppViewModel,
    day: LocalDate,
    onBack: () -> Unit
) {
    val habits by vm.habits.collectAsState()
    val entries by vm.entries.collectAsState()
    val prefs by vm.prefs.collectAsState()

    var failedOnly by remember {
        mutableStateOf(false)
    }

    val dayEntries = entries
        .filter { it.epochDay == day.toEpochDay() }
        .associateBy { it.habitId }

    val scheduled = habits
        .filter {
            Schedule.isScheduled(
                it,
                day,
                entries
            )
        }
        .sortedWith(
            compareBy<HabitEntity> { it.sortOrder }
                .thenBy { it.id }
        )

    val visible = if (failedOnly) {
        scheduled.filter { habit ->
            val entry = dayEntries[habit.id]
            entry == null || entry.score < 0.999
        }
    } else {
        scheduled
    }

    val dayScore = ScoreCalculator.percent(
        Schedule.dailyScore(
            day,
            habits,
            entries
        )
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        day.format(
                            DateTimeFormatter.ofPattern(
                                "dd.MM.yyyy",
                                Locale.getDefault()
                            )
                        )
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            Icons.Outlined.ArrowBack,
                            null
                        )
                    }
                },
                actions = {
                    Text(
                        "$dayScore%",
                        color = performanceColor(dayScore),
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(end = 6.dp)
                    )

                    IconButton(
                        onClick = {
                            failedOnly = !failedOnly
                        }
                    ) {
                        Icon(
                            imageVector = if (failedOnly) {
                                Icons.Outlined.Close
                            } else {
                                Icons.Outlined.Visibility
                            },
                            contentDescription = if (failedOnly) {
                                tr(
                                    prefs.language,
                                    "showAll"
                                )
                            } else {
                                tr(
                                    prefs.language,
                                    "showFailedOnly"
                                )
                            },
                            tint = if (failedOnly) {
                                Color(0xFFC83D3D)
                            } else {
                                MaterialTheme.colorScheme.primary
                            }
                        )
                    }
                }
            )
        }
    ) { padding ->
        if (visible.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "—",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentPadding =
                    androidx.compose.foundation.layout.PaddingValues(
                        horizontal = 12.dp,
                        vertical = 8.dp
                    ),
                verticalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                items(
                    visible,
                    key = { it.id }
                ) { habit ->
                    HabitDayRow(
                        habit = habit,
                        entry = dayEntries[habit.id]
                    )
                }
            }
        }
    }
}

@Composable
private fun HabitDayRow(
    habit: HabitEntity,
    entry: HabitEntryEntity?
) {
    val done = entry?.score?.let {
        it >= 0.999
    } == true

    val statusColor = if (done) {
        Color(habit.colorArgb)
    } else {
        Color(0xFFC83D3D)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = appShape(),
        border = BorderStroke(
            appBorderWidth(),
            MaterialTheme.colorScheme.outlineVariant
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(13.dp),
            verticalAlignment = Alignment.Top
        ) {
            Surface(
                modifier = Modifier.size(34.dp),
                shape = CircleShape,
                border = BorderStroke(
                    1.3.dp,
                    statusColor
                ),
                color = Color.Transparent
            ) {
                androidx.compose.foundation.layout.Box(
                    contentAlignment = Alignment.Center
                ) {
                    if (done) {
                        Icon(
                            Icons.Outlined.Check,
                            null,
                            tint = statusColor,
                            modifier = Modifier.size(19.dp)
                        )
                    } else {
                        Icon(
                            Icons.Outlined.Close,
                            null,
                            tint = statusColor,
                            modifier = Modifier.size(17.dp)
                        )
                    }
                }
            }

            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(start = 11.dp)
            ) {
                Text(
                    habit.name,
                    style = MaterialTheme.typography.bodyLarge
                )

                if (
                    entry != null &&
                    entry.score > 0.0 &&
                    entry.score < 0.999
                ) {
                    Text(
                        "${(entry.score * 100).roundToInt()}%",
                        fontSize = 11.sp,
                        color = Color(habit.colorArgb),
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(top = 3.dp)
                    )
                }

                if (!entry?.note.isNullOrBlank()) {
                    Text(
                        entry!!.note,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 5.dp)
                    )
                }
            }
        }
    }
}
