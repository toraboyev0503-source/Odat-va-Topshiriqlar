package com.habitcore.app

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import com.habitcore.app.domain.ThemeChoice

abstract class BaseThemeLauncherActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startActivity(Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        })
        finish()
    }
}

class MinimalPremiumLauncherActivity : BaseThemeLauncherActivity()
class DarkGlassLauncherActivity : BaseThemeLauncherActivity()
class ProductivityProLauncherActivity : BaseThemeLauncherActivity()
class OrganicCalmLauncherActivity : BaseThemeLauncherActivity()
class NeoBrutalistLauncherActivity : BaseThemeLauncherActivity()
class FuturisticDepthLauncherActivity : BaseThemeLauncherActivity()
class EditorialMonoLauncherActivity : BaseThemeLauncherActivity()
class ScandinavianSoftLauncherActivity : BaseThemeLauncherActivity()
class DarkGoldLuxeLauncherActivity : BaseThemeLauncherActivity()
class ModernUniversalLauncherActivity : BaseThemeLauncherActivity()

object LauncherIconManager {
    private val launcherClasses = mapOf(
        ThemeChoice.MINIMAL_PREMIUM to MinimalPremiumLauncherActivity::class.java,
        ThemeChoice.DARK_GLASS to DarkGlassLauncherActivity::class.java,
        ThemeChoice.PRODUCTIVITY_PRO to ProductivityProLauncherActivity::class.java,
        ThemeChoice.ORGANIC_CALM to OrganicCalmLauncherActivity::class.java,
        ThemeChoice.NEO_BRUTALIST to NeoBrutalistLauncherActivity::class.java,
        ThemeChoice.FUTURISTIC_DEPTH to FuturisticDepthLauncherActivity::class.java,
        ThemeChoice.EDITORIAL_MONO to EditorialMonoLauncherActivity::class.java,
        ThemeChoice.SCANDINAVIAN_SOFT to ScandinavianSoftLauncherActivity::class.java,
        ThemeChoice.DARK_GOLD_LUXE to DarkGoldLuxeLauncherActivity::class.java,
        ThemeChoice.MODERN_UNIVERSAL to ModernUniversalLauncherActivity::class.java
    )

    fun applyTheme(context: Context, theme: ThemeChoice) {
        val pm = context.packageManager
        val appContext = context.applicationContext
        val target = launcherClasses.getValue(theme)

        // Enable first so a launcher entry always exists during the switch.
        pm.setComponentEnabledSetting(
            ComponentName(appContext, target),
            PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
            PackageManager.DONT_KILL_APP
        )

        launcherClasses.values.forEach { clazz ->
            if (clazz != target) {
                pm.setComponentEnabledSetting(
                    ComponentName(appContext, clazz),
                    PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                    PackageManager.DONT_KILL_APP
                )
            }
        }
    }
}
