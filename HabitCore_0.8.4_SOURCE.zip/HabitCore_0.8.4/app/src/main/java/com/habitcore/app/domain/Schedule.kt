package com.habitcore.app.domain

import com.habitcore.app.data.HabitEntity
import com.habitcore.app.data.HabitEntryEntity
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.TemporalAdjusters

object Schedule {
    fun isActiveOn(habit: HabitEntity, day: LocalDate): Boolean {
        val epoch = day.toEpochDay()
        if (epoch < habit.createdEpochDay) return false
        if (habit.archivedEpochDay != null && epoch >= habit.archivedEpochDay) return false
        if (habit.deletedEpochDay != null && epoch >= habit.deletedEpochDay) return false
        if (habit.pausedSinceEpochDay != null && epoch >= habit.pausedSinceEpochDay) return false
        return true
    }

    fun isScheduled(
        habit: HabitEntity,
        day: LocalDate,
        allEntries: List<HabitEntryEntity>
    ): Boolean {
        if (!isActiveOn(habit, day)) return false

        val type = runCatching { FrequencyType.valueOf(habit.frequencyType) }
            .getOrDefault(FrequencyType.DAILY)

        val created = LocalDate.ofEpochDay(habit.createdEpochDay)

        return when (type) {
            FrequencyType.DAILY -> true

            FrequencyType.EVERY_N_DAYS -> {
                val n = habit.frequencyValue.coerceAtLeast(1)
                val delta = day.toEpochDay() - created.toEpochDay()
                delta >= 0 && delta % n == 0L
            }

            FrequencyType.TIMES_PER_WEEK -> {
                val start = day.with(
                    TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)
                ).toEpochDay()
                val completedBefore = allEntries.count { entry ->
                    entry.habitId == habit.id &&
                        entry.epochDay in start until day.toEpochDay() &&
                        entry.score >= 0.999
                }
                completedBefore < habit.frequencyValue.coerceAtLeast(1)
            }

            FrequencyType.TIMES_PER_MONTH -> {
                val start = day.withDayOfMonth(1).toEpochDay()
                val completedBefore = allEntries.count { entry ->
                    entry.habitId == habit.id &&
                        entry.epochDay in start until day.toEpochDay() &&
                        entry.score >= 0.999
                }
                completedBefore < habit.frequencyValue.coerceAtLeast(1)
            }

            FrequencyType.TIMES_IN_N_DAYS -> {
                val window = habit.frequencyWindowDays.coerceAtLeast(1)
                val delta = (day.toEpochDay() - created.toEpochDay())
                    .coerceAtLeast(0)
                val windowIndex = delta / window
                val start = created.toEpochDay() + windowIndex * window
                val completedBefore = allEntries.count { entry ->
                    entry.habitId == habit.id &&
                        entry.epochDay in start until day.toEpochDay() &&
                        entry.score >= 0.999
                }
                completedBefore < habit.frequencyValue.coerceAtLeast(1)
            }
        }
    }

    fun dailyScore(
        day: LocalDate,
        habits: List<HabitEntity>,
        entries: List<HabitEntryEntity>
    ): Double? {
        val scheduled = habits.filter { isScheduled(it, day, entries) }
        if (scheduled.isEmpty()) return null
        val byHabit = entries.filter { it.epochDay == day.toEpochDay() }.associateBy { it.habitId }
        return scheduled.map { byHabit[it.id]?.score?.coerceIn(0.0, 1.0) ?: 0.0 }.average()
    }

    fun completionStats(
        habit: HabitEntity,
        today: LocalDate,
        entries: List<HabitEntryEntity>
    ): Pair<Double, Double> {
        val habitEntries = entries.filter { it.habitId == habit.id }
        val created = LocalDate.ofEpochDay(habit.createdEpochDay)
        var day = created
        var expected = 0.0
        var completed = 0.0

        while (!day.isAfter(today)) {
            if (isScheduled(habit, day, entries)) {
                val entry = habitEntries.firstOrNull { it.epochDay == day.toEpochDay() }
                val countToday = day.isBefore(today) || entry != null
                if (countToday) {
                    expected += 1.0
                    completed += entry?.score?.coerceIn(0.0, 1.0) ?: 0.0
                }
            }
            day = day.plusDays(1)
        }
        return completed to expected
    }
}
