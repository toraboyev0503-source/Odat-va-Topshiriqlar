package com.habitcore.app.data

import androidx.room.Entity

@Entity(
    tableName = "habit_entries",
    primaryKeys = ["habitId", "epochDay"]
)
data class HabitEntryEntity(
    val habitId: Long,
    val epochDay: Long,
    val status: String,
    val actualValue: Double? = null,
    val score: Double,
    val note: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)
