package com.habitcore.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "habit_categories")
data class HabitCategoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val sortOrder: Int = 0,
    val createdAtMillis: Long = System.currentTimeMillis()
)
