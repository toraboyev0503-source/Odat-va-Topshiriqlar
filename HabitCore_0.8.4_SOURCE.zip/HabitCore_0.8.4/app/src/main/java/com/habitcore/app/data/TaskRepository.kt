package com.habitcore.app.data

import java.time.LocalDate

class TaskRepository(private val dao: TaskDao) {
    val tasks = dao.observeTasks()
    val plans = dao.observePlans()

    suspend fun addTask(text: String, priority: Int, scheduledEpochDay: Long, colorSlot: Int) {
        val id = dao.insertTask(
            TaskEntity(
                text = text,
                priority = priority.coerceIn(0, 3),
                scheduledEpochDay = scheduledEpochDay,
                colorSlot = colorSlot
            )
        )
        dao.insertPlan(TaskPlanEntity(taskId = id, epochDay = scheduledEpochDay))
    }

    suspend fun cleanupInvalidCurrentAndFuturePlans() {
        dao.deleteInvalidCurrentAndFuturePlans(LocalDate.now().toEpochDay())
    }

    suspend fun updateText(taskId: Long, text: String) = dao.updateText(taskId, text)

    suspend fun updatePriority(taskId: Long, priority: Int) =
        dao.updatePriority(taskId, priority.coerceIn(0, 3))

    /**
     * Planning contract:
     * - A task affects only the day it is explicitly scheduled for.
     * - If the old scheduled day has not passed yet, moving the task removes the old commitment.
     * - If the old day has already passed, that old plan remains an unfinished historical result
     *   and a new plan is created for the new day.
     */
    suspend fun reschedule(task: TaskEntity, newEpochDay: Long) {
        if (newEpochDay == task.scheduledEpochDay) return
        val today = LocalDate.now().toEpochDay()
        val oldDay = task.scheduledEpochDay

        if (oldDay >= today) {
            dao.deletePlan(task.id, oldDay)
        }

        dao.updateScheduledDay(task.id, newEpochDay)
        dao.insertPlan(TaskPlanEntity(taskId = task.id, epochDay = newEpochDay, completed = false))
    }

    /**
     * Completion never creates today's plan implicitly.
     * On-time or early completion marks the explicitly scheduled plan complete.
     * Late completion preserves the original missed plan as incomplete; the completion timestamp
     * is still stored on the task so the archive/day-detail can show when it was actually done.
     */
    suspend fun complete(task: TaskEntity) {
        if (task.completed) return
        val today = LocalDate.now().toEpochDay()
        if (task.scheduledEpochDay >= today) {
            dao.upsertPlan(
                TaskPlanEntity(
                    taskId = task.id,
                    epochDay = task.scheduledEpochDay,
                    completed = true
                )
            )
        }
        dao.completeTask(task.id, System.currentTimeMillis())
    }

    suspend fun reopen(task: TaskEntity) {
        if (!task.completed) return
        dao.upsertPlan(
            TaskPlanEntity(
                taskId = task.id,
                epochDay = task.scheduledEpochDay,
                completed = false
            )
        )
        dao.reopenTask(task.id)
    }

    suspend fun toggleCompletion(task: TaskEntity) {
        if (task.completed) reopen(task) else complete(task)
    }

    suspend fun delete(taskId: Long) {
        dao.deletePlansForTask(taskId)
        dao.deleteTask(taskId)
    }
}
