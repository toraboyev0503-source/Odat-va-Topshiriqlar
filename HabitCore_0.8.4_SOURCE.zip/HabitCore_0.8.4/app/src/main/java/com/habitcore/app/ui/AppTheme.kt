package com.habitcore.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.habitcore.app.domain.AppMode
import com.habitcore.app.domain.ThemeChoice
import kotlin.math.min

private enum class DecorKind { NONE, GLASS, BARS, LEAVES, BRUTAL, FUTURE, EDITORIAL, SCANDI, GOLD, UNIVERSAL }

@Immutable
data class AppVisualSpec(
    val cardRadius: Dp,
    val fieldRadius: Dp,
    val borderWidth: Dp,
    val compact: Boolean,
    val uppercaseLabels: Boolean,
    val strongDividers: Boolean,
    val cardAlpha: Float,
    val decorKind: String,
    val forcedDark: Boolean?
)

val LocalAppVisualSpec = staticCompositionLocalOf {
    AppVisualSpec(14.dp, 14.dp, 1.dp, false, false, false, 1f, DecorKind.UNIVERSAL.name, false)
}

private data class AccentSet(val primary: Color, val secondary: Color, val tertiary: Color)

private data class ThemeBase(
    val lightBackground: Color,
    val lightSurface: Color,
    val lightVariant: Color,
    val lightOutline: Color,
    val darkBackground: Color,
    val darkSurface: Color,
    val darkVariant: Color,
    val darkOutline: Color,
    val fontFamily: FontFamily,
    val titleWeight: FontWeight,
    val bodyWeight: FontWeight,
    val spec: AppVisualSpec
)

private fun palettes(theme: ThemeChoice): List<AccentSet> = when (theme) {
    ThemeChoice.MINIMAL_PREMIUM -> listOf(
        AccentSet(Color(0xFFB8871D), Color(0xFF657A49), Color(0xFF202226)),
        AccentSet(Color(0xFF8E6C35), Color(0xFF526C62), Color(0xFF262626)),
        AccentSet(Color(0xFF3A6084), Color(0xFF73866C), Color(0xFFC08C2E)),
        AccentSet(Color(0xFF765E83), Color(0xFF6C806A), Color(0xFFC28D2B))
    )
    ThemeChoice.DARK_GLASS -> listOf(
        AccentSet(Color(0xFF61A9FF), Color(0xFF7C63FF), Color(0xFF42E0CB)),
        AccentSet(Color(0xFF28D6E7), Color(0xFF6D71FF), Color(0xFF7EF0B2)),
        AccentSet(Color(0xFF8C72FF), Color(0xFF4AB7FF), Color(0xFFE9B84E)),
        AccentSet(Color(0xFF5CCB9F), Color(0xFF45A6FF), Color(0xFFC178FF))
    )
    ThemeChoice.PRODUCTIVITY_PRO -> listOf(
        AccentSet(Color(0xFF5146D9), Color(0xFFFF8A00), Color(0xFF163A61)),
        AccentSet(Color(0xFF2D6DC4), Color(0xFFFF8A00), Color(0xFF163A61)),
        AccentSet(Color(0xFF008F7A), Color(0xFFFF8A00), Color(0xFF173D55)),
        AccentSet(Color(0xFF6F4ED1), Color(0xFFE66E32), Color(0xFF1B3854))
    )
    ThemeChoice.ORGANIC_CALM -> listOf(
        AccentSet(Color(0xFF6E8451), Color(0xFFB89463), Color(0xFF80927A)),
        AccentSet(Color(0xFF547461), Color(0xFFC48E6A), Color(0xFF8B9678)),
        AccentSet(Color(0xFF7A7448), Color(0xFFAE815F), Color(0xFF79917D)),
        AccentSet(Color(0xFF537A73), Color(0xFFB78A53), Color(0xFF7E8D68))
    )
    ThemeChoice.NEO_BRUTALIST -> listOf(
        AccentSet(Color(0xFF7C3CFF), Color(0xFFFFEA00), Color(0xFF9BE000)),
        AccentSet(Color(0xFFFF6B00), Color(0xFF7A43FF), Color(0xFF18C98D)),
        AccentSet(Color(0xFF00AEEF), Color(0xFFFFE500), Color(0xFFFF3D68)),
        AccentSet(Color(0xFF111111), Color(0xFFFFE500), Color(0xFF8B5CFF))
    )
    ThemeChoice.FUTURISTIC_DEPTH -> listOf(
        AccentSet(Color(0xFF7A5CFF), Color(0xFF20D8FF), Color(0xFFFFB100)),
        AccentSet(Color(0xFF00D4FF), Color(0xFF6648FF), Color(0xFF32E59A)),
        AccentSet(Color(0xFFBA54FF), Color(0xFF2C9BFF), Color(0xFFFFB400)),
        AccentSet(Color(0xFF4AF0D0), Color(0xFF7056FF), Color(0xFFFF8A4C))
    )
    ThemeChoice.EDITORIAL_MONO -> listOf(
        AccentSet(Color(0xFF17191C), Color(0xFFD89B25), Color(0xFF6E7B82)),
        AccentSet(Color(0xFF1D2B34), Color(0xFFC4872E), Color(0xFF727C72)),
        AccentSet(Color(0xFF262626), Color(0xFF9E8153), Color(0xFF61727D)),
        AccentSet(Color(0xFF2B2630), Color(0xFFC98B2F), Color(0xFF6D757D))
    )
    ThemeChoice.SCANDINAVIAN_SOFT -> listOf(
        AccentSet(Color(0xFF7597CA), Color(0xFF83A68B), Color(0xFFE4A07C)),
        AccentSet(Color(0xFF668CBA), Color(0xFF8AA17D), Color(0xFFD79A74)),
        AccentSet(Color(0xFF7C87B7), Color(0xFF7EA299), Color(0xFFE1A77D)),
        AccentSet(Color(0xFF648FA0), Color(0xFF8D9F77), Color(0xFFD68C8B))
    )
    ThemeChoice.DARK_GOLD_LUXE -> listOf(
        AccentSet(Color(0xFFE4B546), Color(0xFF9A742B), Color(0xFFDA793C)),
        AccentSet(Color(0xFFF0C968), Color(0xFF9C7B3E), Color(0xFF6A8A62)),
        AccentSet(Color(0xFFD8A43B), Color(0xFFAE843A), Color(0xFF8A6E4C)),
        AccentSet(Color(0xFFF1B84A), Color(0xFF8F7133), Color(0xFFB55F45))
    )
    ThemeChoice.MODERN_UNIVERSAL -> listOf(
        AccentSet(Color(0xFF6A46D9), Color(0xFF2D78D6), Color(0xFFFFA000)),
        AccentSet(Color(0xFF356ED4), Color(0xFF6750C8), Color(0xFF00A77B)),
        AccentSet(Color(0xFF008E77), Color(0xFF4C70C5), Color(0xFFFF8B3D)),
        AccentSet(Color(0xFF7A4FD1), Color(0xFFDA5A79), Color(0xFF2E8A76))
    )
}

private fun base(theme: ThemeChoice): ThemeBase = when (theme) {
    ThemeChoice.MINIMAL_PREMIUM -> ThemeBase(
        Color(0xFFFBFAF7), Color(0xFFFFFFFF), Color(0xFFF4F1EA), Color(0xFFE2DDD2),
        Color(0xFF171614), Color(0xFF211F1B), Color(0xFF2B2822), Color(0xFF544F45),
        FontFamily.SansSerif, FontWeight.SemiBold, FontWeight.Normal,
        AppVisualSpec(15.dp, 14.dp, 1.dp, false, false, false, 1f, DecorKind.NONE.name, false)
    )
    ThemeChoice.DARK_GLASS -> ThemeBase(
        Color(0xFFF4F8FC), Color(0xFFF8FBFF), Color(0xFFE6EEF6), Color(0xFFB9C8D6),
        Color(0xFF06101D), Color(0xFF0E1A2A), Color(0xFF14253A), Color(0xFF31506B),
        FontFamily.SansSerif, FontWeight.SemiBold, FontWeight.Normal,
        AppVisualSpec(16.dp, 15.dp, 1.dp, false, false, false, 0.84f, DecorKind.GLASS.name, true)
    )
    ThemeChoice.PRODUCTIVITY_PRO -> ThemeBase(
        Color(0xFFF7F8FB), Color(0xFFFFFFFF), Color(0xFFEEF1F6), Color(0xFFD2D8E2),
        Color(0xFF0B2238), Color(0xFF102A45), Color(0xFF193752), Color(0xFF3A5770),
        FontFamily.SansSerif, FontWeight.Bold, FontWeight.Normal,
        AppVisualSpec(10.dp, 10.dp, 1.dp, true, false, true, 1f, DecorKind.BARS.name, null)
    )
    ThemeChoice.ORGANIC_CALM -> ThemeBase(
        Color(0xFFFBF7ED), Color(0xFFFFFCF5), Color(0xFFF1EBDD), Color(0xFFD9D0BC),
        Color(0xFF171A13), Color(0xFF20251B), Color(0xFF2B3224), Color(0xFF4D5943),
        FontFamily.Serif, FontWeight.Medium, FontWeight.Normal,
        AppVisualSpec(18.dp, 16.dp, 1.dp, false, false, false, 0.96f, DecorKind.LEAVES.name, false)
    )
    ThemeChoice.NEO_BRUTALIST -> ThemeBase(
        Color(0xFFFFFEF7), Color(0xFFFFFFFF), Color(0xFFF7F4E9), Color(0xFF111111),
        Color(0xFF111111), Color(0xFF1D1D1D), Color(0xFF292929), Color(0xFFF2F2F2),
        FontFamily.SansSerif, FontWeight.Black, FontWeight.Medium,
        AppVisualSpec(0.dp, 0.dp, 2.dp, true, true, true, 1f, DecorKind.BRUTAL.name, false)
    )
    ThemeChoice.FUTURISTIC_DEPTH -> ThemeBase(
        Color(0xFFF4F6FF), Color(0xFFF9FAFF), Color(0xFFE8ECFA), Color(0xFFC7CFE2),
        Color(0xFF050A1B), Color(0xFF0B1228), Color(0xFF131B35), Color(0xFF343F62),
        FontFamily.SansSerif, FontWeight.SemiBold, FontWeight.Normal,
        AppVisualSpec(15.dp, 14.dp, 1.dp, false, false, false, 0.90f, DecorKind.FUTURE.name, true)
    )
    ThemeChoice.EDITORIAL_MONO -> ThemeBase(
        Color(0xFFF9F8F5), Color(0xFFFFFFFF), Color(0xFFF0EFEB), Color(0xFFD7D5CE),
        Color(0xFF111111), Color(0xFF1B1B1B), Color(0xFF262626), Color(0xFF4D4D4D),
        FontFamily.Monospace, FontWeight.Bold, FontWeight.Normal,
        AppVisualSpec(9.dp, 8.dp, 1.dp, true, true, true, 1f, DecorKind.EDITORIAL.name, false)
    )
    ThemeChoice.SCANDINAVIAN_SOFT -> ThemeBase(
        Color(0xFFF8FAFC), Color(0xFFFFFFFF), Color(0xFFF0F4F8), Color(0xFFDCE3EA),
        Color(0xFF151A20), Color(0xFF20262D), Color(0xFF2A323B), Color(0xFF4F5A66),
        FontFamily.SansSerif, FontWeight.Medium, FontWeight.Normal,
        AppVisualSpec(21.dp, 18.dp, 1.dp, false, false, false, 0.96f, DecorKind.SCANDI.name, false)
    )
    ThemeChoice.DARK_GOLD_LUXE -> ThemeBase(
        Color(0xFFFBF7EC), Color(0xFFFFFCF4), Color(0xFFF2E9D6), Color(0xFFD7C6A1),
        Color(0xFF080806), Color(0xFF12120F), Color(0xFF1B1B16), Color(0xFF5E512F),
        FontFamily.Serif, FontWeight.SemiBold, FontWeight.Normal,
        AppVisualSpec(14.dp, 12.dp, 1.dp, false, false, true, 0.95f, DecorKind.GOLD.name, true)
    )
    ThemeChoice.MODERN_UNIVERSAL -> ThemeBase(
        Color(0xFFF9F9FC), Color(0xFFFFFFFF), Color(0xFFF0F1F7), Color(0xFFD9DBE6),
        Color(0xFF12131A), Color(0xFF1C1D26), Color(0xFF272935), Color(0xFF4A4C5C),
        FontFamily.SansSerif, FontWeight.SemiBold, FontWeight.Normal,
        AppVisualSpec(17.dp, 16.dp, 1.dp, false, false, false, 1f, DecorKind.UNIVERSAL.name, false)
    )
}

private fun typography(base: ThemeBase): Typography = Typography(
    headlineLarge = TextStyle(fontFamily = base.fontFamily, fontWeight = base.titleWeight, fontSize = 31.sp),
    headlineMedium = TextStyle(fontFamily = base.fontFamily, fontWeight = base.titleWeight, fontSize = 27.sp),
    titleLarge = TextStyle(fontFamily = base.fontFamily, fontWeight = base.titleWeight, fontSize = 21.sp),
    titleMedium = TextStyle(fontFamily = base.fontFamily, fontWeight = base.titleWeight, fontSize = 16.sp),
    bodyLarge = TextStyle(fontFamily = base.fontFamily, fontWeight = base.bodyWeight, fontSize = 16.sp),
    bodyMedium = TextStyle(fontFamily = base.fontFamily, fontWeight = base.bodyWeight, fontSize = 14.sp),
    labelLarge = TextStyle(fontFamily = base.fontFamily, fontWeight = if (base.spec.uppercaseLabels) FontWeight.Bold else FontWeight.Medium, fontSize = 13.sp)
)

private fun shapes(spec: AppVisualSpec) = Shapes(
    extraSmall = RoundedCornerShape(spec.fieldRadius),
    small = RoundedCornerShape(spec.fieldRadius),
    medium = RoundedCornerShape(spec.cardRadius),
    large = RoundedCornerShape(spec.cardRadius),
    extraLarge = RoundedCornerShape(spec.cardRadius)
)

@Composable
fun HabitCoreTheme(choice: ThemeChoice, accent: Int, mode: AppMode, content: @Composable () -> Unit) {
    val b = base(choice)
    val dark = b.spec.forcedDark ?: when (mode) {
        AppMode.LIGHT -> false
        AppMode.DARK -> true
        AppMode.SYSTEM -> isSystemInDarkTheme()
    }
    val a = palettes(choice)[accent.coerceIn(0, 3)]
    val scheme = if (dark) {
        darkColorScheme(
            primary = brighten(a.primary, .18f),
            secondary = brighten(a.secondary, .14f),
            tertiary = brighten(a.tertiary, .12f),
            background = b.darkBackground,
            surface = b.darkSurface,
            surfaceVariant = b.darkVariant,
            outline = b.darkOutline
        )
    } else {
        lightColorScheme(
            primary = a.primary,
            secondary = a.secondary,
            tertiary = a.tertiary,
            background = b.lightBackground,
            surface = b.lightSurface,
            surfaceVariant = b.lightVariant,
            outline = b.lightOutline
        )
    }
    androidx.compose.runtime.CompositionLocalProvider(LocalAppVisualSpec provides b.spec) {
        MaterialTheme(scheme, shapes(b.spec), typography(b), content)
    }
}

private fun brighten(c: Color, amount: Float) = Color(
    red = (c.red + amount).coerceAtMost(1f),
    green = (c.green + amount).coerceAtMost(1f),
    blue = (c.blue + amount).coerceAtMost(1f),
    alpha = c.alpha
)

@Composable fun appShape(): Shape = RoundedCornerShape(LocalAppVisualSpec.current.cardRadius)
@Composable fun appFieldShape(): Shape = RoundedCornerShape(LocalAppVisualSpec.current.fieldRadius)
@Composable fun appBorderWidth(): Dp = LocalAppVisualSpec.current.borderWidth
@Composable fun appCompact(): Boolean = LocalAppVisualSpec.current.compact
@Composable fun appCardAlpha(): Float = LocalAppVisualSpec.current.cardAlpha

fun themeStyleName(choice: ThemeChoice): String = when (choice) {
    ThemeChoice.MINIMAL_PREMIUM -> "Minimal Premium"
    ThemeChoice.DARK_GLASS -> "Dark Glass"
    ThemeChoice.PRODUCTIVITY_PRO -> "Productivity Pro"
    ThemeChoice.ORGANIC_CALM -> "Organic Calm"
    ThemeChoice.NEO_BRUTALIST -> "Neo Brutalist"
    ThemeChoice.FUTURISTIC_DEPTH -> "Futuristic Depth"
    ThemeChoice.EDITORIAL_MONO -> "Editorial Mono"
    ThemeChoice.SCANDINAVIAN_SOFT -> "Scandinavian Soft"
    ThemeChoice.DARK_GOLD_LUXE -> "Dark Gold Luxe"
    ThemeChoice.MODERN_UNIVERSAL -> "Modern Universal"
}

fun themeAccentColors(choice: ThemeChoice): List<Color> = palettes(choice).map { it.primary }

@Composable
fun ThemeBackdrop(modifier: Modifier = Modifier) {
    val spec = LocalAppVisualSpec.current
    val primary = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary
    val bg = MaterialTheme.colorScheme.background
    Canvas(modifier) {
        drawRect(bg)
        when (DecorKind.valueOf(spec.decorKind)) {
            DecorKind.NONE -> Unit
            DecorKind.GLASS -> {
                drawCircle(primary.copy(alpha = .08f), radius = size.minDimension * .42f, center = Offset(size.width * .9f, size.height * .12f))
                drawCircle(secondary.copy(alpha = .06f), radius = size.minDimension * .35f, center = Offset(size.width * .1f, size.height * .85f))
            }
            DecorKind.BARS -> repeat(5) { i ->
                drawRect(primary.copy(alpha = .035f), Offset(size.width * .82f + i * 7f, size.height * .12f), Size(3f, size.height * .68f))
            }
            DecorKind.LEAVES -> {
                val p = Path().apply { moveTo(0f, size.height); cubicTo(size.width*.16f,size.height*.82f,size.width*.22f,size.height*.94f,size.width*.38f,size.height*.76f) }
                drawPath(p, primary.copy(alpha=.10f), style=Stroke(width=5f))
                repeat(5) { i -> drawOval(primary.copy(alpha=.06f), Offset(size.width*.05f+i*34f,size.height*.78f-i*26f), Size(58f,24f)) }
            }
            DecorKind.BRUTAL -> {
                drawRect(secondary.copy(alpha=.16f), Offset(size.width*.78f, 0f), Size(size.width*.22f, 10f))
                repeat(12) { i -> drawRect(primary.copy(alpha=.12f), Offset(size.width*.84f+(i%3)*13f, size.height*.08f+(i/3)*13f), Size(6f,6f)) }
            }
            DecorKind.FUTURE -> {
                repeat(5) { i ->
                    val y = size.height * (.72f + i*.045f)
                    val p = Path().apply { moveTo(0f,y); cubicTo(size.width*.25f,y-55f-i*8f,size.width*.62f,y+45f,size.width,y-25f) }
                    drawPath(p, if (i%2==0) primary.copy(alpha=.11f) else secondary.copy(alpha=.09f), style=Stroke(width=2f))
                }
            }
            DecorKind.EDITORIAL -> {
                drawLine(primary.copy(alpha=.12f), Offset(size.width*.08f,size.height*.1f), Offset(size.width*.92f,size.height*.1f), 1f)
                drawLine(secondary.copy(alpha=.24f), Offset(size.width*.46f,size.height*.1f), Offset(size.width*.54f,size.height*.1f), 2f)
            }
            DecorKind.SCANDI -> {
                repeat(3) { i -> drawCircle(primary.copy(alpha=.035f), size.minDimension*(.18f+i*.08f), Offset(size.width*.15f,size.height*.88f)) }
            }
            DecorKind.GOLD -> {
                drawRect(primary.copy(alpha=.10f), Offset(0f,0f), Size(size.width,1.5f))
                drawRect(primary.copy(alpha=.06f), Offset(0f,size.height-1.5f), Size(size.width,1.5f))
                val r=min(size.width,size.height)*.08f
                drawCircle(primary.copy(alpha=.045f), r, Offset(size.width*.92f,size.height*.9f))
            }
            DecorKind.UNIVERSAL -> {
                drawCircle(primary.copy(alpha=.025f), size.minDimension*.45f, Offset(size.width*.92f,size.height*.95f))
                drawCircle(secondary.copy(alpha=.025f), size.minDimension*.28f, Offset(size.width*.05f,size.height*.12f))
            }
        }
    }
}

fun habitColor(index: Int): Long {
    val colors = listOf(0xFF4E78A8L,0xFF4F7A5CL,0xFF8B5E6BL,0xFF7B6B4CL,0xFF5E6D83L,0xFF806A99L,0xFF557B78L,0xFF8A674FL)
    return colors[index.coerceIn(0, colors.lastIndex)]
}
