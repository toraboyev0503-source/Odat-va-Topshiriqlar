package com.habitcore.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.habitcore.app.data.HabitEntity
import java.time.LocalDate

private enum class Screen {
    HABITS,
    TASKS,
    MONITOR_HABITS,
    MONITOR_TASKS,
    PROFILE,
    CREATE_HABIT,
    HABIT_DAY_DETAIL,
    TASK_DAY_DETAIL,
    SCHEDULED_TASKS,
    ARCHIVE_HUB,
    HABIT_ARCHIVE,
    TASK_ARCHIVE,
    THEME,
    LANGUAGE,
    NOTIFICATIONS,
    SETTINGS,
    ABOUT
}

@Composable
fun HabitCoreApp(vm: AppViewModel) {
    val prefs by vm.prefs.collectAsState()
    var screen by remember { mutableStateOf(Screen.HABITS) }
    var editingHabit by remember { mutableStateOf<HabitEntity?>(null) }
    var selectedDay by remember { mutableStateOf(LocalDate.now()) }
    var lastMonitor by remember { mutableStateOf(Screen.MONITOR_HABITS) }

    fun openTab(tab: MainTab) {
        screen = when (tab) {
            MainTab.HABITS -> Screen.HABITS
            MainTab.TASKS -> Screen.TASKS
            MainTab.MONITORING -> lastMonitor
            MainTab.PROFILE -> Screen.PROFILE
        }
    }

    BackHandler(enabled = screen != Screen.HABITS) {
        screen = when (screen) {
            Screen.HABITS -> Screen.HABITS
            Screen.TASKS,
            Screen.MONITOR_HABITS,
            Screen.MONITOR_TASKS,
            Screen.PROFILE -> Screen.HABITS
            Screen.CREATE_HABIT -> Screen.HABITS
            Screen.HABIT_DAY_DETAIL -> Screen.MONITOR_HABITS
            Screen.TASK_DAY_DETAIL -> Screen.MONITOR_TASKS
            Screen.SCHEDULED_TASKS -> Screen.TASKS
            Screen.ARCHIVE_HUB,
            Screen.THEME,
            Screen.LANGUAGE,
            Screen.NOTIFICATIONS,
            Screen.SETTINGS,
            Screen.ABOUT -> Screen.PROFILE
            Screen.HABIT_ARCHIVE,
            Screen.TASK_ARCHIVE -> Screen.ARCHIVE_HUB
        }
        if (screen != Screen.CREATE_HABIT) editingHabit = null
    }

    HabitCoreTheme(prefs.theme, prefs.themeAccent, prefs.mode) {
        when (screen) {
            Screen.HABITS -> HabitsScreen(
                vm = vm,
                onTab = ::openTab,
                onCreate = {
                    editingHabit = null
                    screen = Screen.CREATE_HABIT
                },
                onEditHabit = { habit ->
                    editingHabit = habit
                    screen = Screen.CREATE_HABIT
                },
                onMonitoring = {
                    lastMonitor = Screen.MONITOR_HABITS
                    screen = Screen.MONITOR_HABITS
                }
            )

            Screen.TASKS -> TasksScreen(
                vm = vm,
                onTab = ::openTab,
                onScheduled = { screen = Screen.SCHEDULED_TASKS },
                onMonitoring = {
                    lastMonitor = Screen.MONITOR_TASKS
                    screen = Screen.MONITOR_TASKS
                }
            )

            Screen.MONITOR_HABITS -> MonitoringScreen(
                vm = vm,
                onTab = ::openTab,
                onSwitchToTasks = {
                    lastMonitor = Screen.MONITOR_TASKS
                    screen = Screen.MONITOR_TASKS
                },
                onDaySelected = { day ->
                    selectedDay = day
                    screen = Screen.HABIT_DAY_DETAIL
                }
            )

            Screen.MONITOR_TASKS -> TaskMonitoringScreen(
                vm = vm,
                onTab = ::openTab,
                onSwitchToHabits = {
                    lastMonitor = Screen.MONITOR_HABITS
                    screen = Screen.MONITOR_HABITS
                },
                onDaySelected = { day ->
                    selectedDay = day
                    screen = Screen.TASK_DAY_DETAIL
                }
            )

            Screen.PROFILE -> ProfileScreen(
                vm = vm,
                onTab = ::openTab,
                onTheme = { screen = Screen.THEME },
                onLanguage = { screen = Screen.LANGUAGE },
                onNotifications = { screen = Screen.NOTIFICATIONS },
                onArchive = { screen = Screen.ARCHIVE_HUB },
                onSettings = { screen = Screen.SETTINGS },
                onReports = {
                    lastMonitor = Screen.MONITOR_HABITS
                    screen = Screen.MONITOR_HABITS
                },
                onScheduled = { screen = Screen.SCHEDULED_TASKS },
                onAbout = { screen = Screen.ABOUT }
            )

            Screen.CREATE_HABIT -> CreateHabitScreen(
                vm = vm,
                categoryId = editingHabit?.categoryId ?: 1L,
                habitToEdit = editingHabit,
                onBack = {
                    editingHabit = null
                    screen = Screen.HABITS
                }
            )

            Screen.HABIT_DAY_DETAIL -> HabitDayDetailScreen(
                vm = vm,
                day = selectedDay,
                onBack = { screen = Screen.MONITOR_HABITS }
            )

            Screen.TASK_DAY_DETAIL -> TaskDayDetailScreen(
                vm = vm,
                day = selectedDay,
                onBack = { screen = Screen.MONITOR_TASKS }
            )

            Screen.SCHEDULED_TASKS -> ScheduledTasksScreen(
                vm = vm,
                onBack = { screen = Screen.TASKS }
            )

            Screen.ARCHIVE_HUB -> ArchiveHubScreen(
                lang = prefs.language,
                onBack = { screen = Screen.PROFILE },
                onHabits = { screen = Screen.HABIT_ARCHIVE },
                onTasks = { screen = Screen.TASK_ARCHIVE }
            )

            Screen.HABIT_ARCHIVE -> ArchiveScreen(
                vm = vm,
                onBack = { screen = Screen.ARCHIVE_HUB }
            )

            Screen.TASK_ARCHIVE -> TaskArchiveScreen(
                vm = vm,
                onBack = { screen = Screen.ARCHIVE_HUB },
                onMonitoring = {
                    lastMonitor = Screen.MONITOR_TASKS
                    screen = Screen.MONITOR_TASKS
                }
            )

            Screen.THEME -> ThemeScreen(vm = vm, onBack = { screen = Screen.PROFILE })
            Screen.LANGUAGE -> LanguageScreen(vm = vm, onBack = { screen = Screen.PROFILE })
            Screen.NOTIFICATIONS -> NotificationsScreen(vm = vm, onBack = { screen = Screen.PROFILE })
            Screen.SETTINGS -> SettingsScreen(vm = vm, onBack = { screen = Screen.PROFILE })
            Screen.ABOUT -> AboutScreen(lang = prefs.language, onBack = { screen = Screen.PROFILE })
        }
    }
}
