@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.habitcore.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

@Composable
fun TaskArchiveScreen(
    vm: AppViewModel,
    onBack: () -> Unit,
    onMonitoring: () -> Unit
) {
    val prefs by vm.prefs.collectAsState()
    val tasks by vm.tasks.collectAsState()
    val completed = tasks.filter { it.completed }.sortedByDescending { it.completedAtMillis ?: 0L }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(tr(prefs.language, "archive")) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Outlined.ArrowBack, null) } }
            )
        }
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().clickable(onClick = onMonitoring),
                    shape = appShape(),
                    border = BorderStroke(appBorderWidth(), MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Outlined.BarChart, null, tint = MaterialTheme.colorScheme.primary)
                        Column(Modifier.padding(start = 12.dp)) {
                            Text(tr(prefs.language, "monitoring"), style = MaterialTheme.typography.titleMedium)
                            Text(tr(prefs.language, "calendar"), color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            if (completed.isNotEmpty()) {
                item { HorizontalDivider(Modifier.padding(vertical = 4.dp)) }
            }

            items(completed, key = { it.id }) { task ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = appShape(),
                    border = BorderStroke(appBorderWidth(), MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        IconButton(
                            onClick = { vm.toggleTaskCompletion(task) }
                        ) {
                            Icon(
                                Icons.Outlined.CheckCircle,
                                contentDescription = tr(prefs.language, "restore"),
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                        Column(Modifier.padding(start = 4.dp).weight(1f)) {
                            Text(task.text)
                            task.completedAtMillis?.let { millis ->
                                val date = Instant.ofEpochMilli(millis)
                                    .atZone(ZoneId.systemDefault())
                                    .toLocalDate()
                                Text(
                                    date.format(DateTimeFormatter.ofPattern("dd MMM yyyy", taskLocale(prefs.language))),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(top = 5.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
