package com.habitcore.app.domain

import com.habitcore.app.data.TaskEntity
import com.habitcore.app.data.TaskPlanEntity
import java.time.LocalDate
import kotlin.math.roundToInt

object TaskScoring {
    /**
     * Legacy overload kept for tests / historical callers.
     */
    fun dailyScore(day: LocalDate, plans: List<TaskPlanEntity>): Double? {
        val dayPlans = plans.filter { it.epochDay == day.toEpochDay() }
        if (dayPlans.isEmpty()) return null
        return dayPlans.count { it.completed }.toDouble() / dayPlans.size.toDouble()
    }

    /**
     * Data-safe score used by the app.
     *
     * Past days keep their historical plan rows.
     * Today/future only count plans whose task is currently scheduled for that exact day.
     * This prevents old carry-over rows from earlier app versions from inflating today's denominator.
     */
    fun dailyScore(
        day: LocalDate,
        plans: List<TaskPlanEntity>,
        tasks: List<TaskEntity>,
        today: LocalDate = LocalDate.now()
    ): Double? {
        val epochDay = day.toEpochDay()
        val rawPlans = plans.filter { it.epochDay == epochDay }

        val validPlans = if (day.isBefore(today)) {
            rawPlans
        } else {
            val validTaskIds = tasks
                .asSequence()
                .filter { it.scheduledEpochDay == epochDay }
                .map { it.id }
                .toSet()

            rawPlans.filter { it.taskId in validTaskIds }
        }

        if (validPlans.isEmpty()) return null

        return validPlans.count { it.completed }.toDouble() /
            validPlans.size.toDouble()
    }

    fun periodScore(days: List<LocalDate>, plans: List<TaskPlanEntity>): Double? {
        val scores = days.map { dailyScore(it, plans) }.filterNotNull()
        return if (scores.isEmpty()) null else scores.average()
    }

    fun periodScore(
        days: List<LocalDate>,
        plans: List<TaskPlanEntity>,
        tasks: List<TaskEntity>,
        today: LocalDate = LocalDate.now()
    ): Double? {
        val scores = days
            .map { dailyScore(it, plans, tasks, today) }
            .filterNotNull()

        return if (scores.isEmpty()) null else scores.average()
    }

    fun percent(score: Double?): Int? =
        score?.let { (it.coerceIn(0.0, 1.0) * 100.0).roundToInt() }
}
