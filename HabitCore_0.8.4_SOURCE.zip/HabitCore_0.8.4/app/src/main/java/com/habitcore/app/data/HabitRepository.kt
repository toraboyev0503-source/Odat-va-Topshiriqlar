package com.habitcore.app.data

class HabitRepository(private val dao: HabitDao) {
    val habits = dao.observeHabits()
    val entries = dao.observeEntries()
    val categories = dao.observeCategories()

    suspend fun addHabit(habit: HabitEntity) = dao.insertHabit(habit)
    suspend fun updateHabit(habit: HabitEntity) = dao.updateHabit(habit)
    suspend fun addCategory(name: String): Long {
        val nextOrder = dao.getCategoriesOnce().size
        return dao.insertCategory(
            HabitCategoryEntity(
                name = name.trim(),
                sortOrder = nextOrder
            )
        )
    }

    suspend fun reorderHabits(orderedIds: List<Long>) {
        if (orderedIds.isEmpty()) return
        dao.replaceSortOrder(orderedIds)
    }

    suspend fun saveEntry(entry: HabitEntryEntity) = dao.saveEntry(entry)
    suspend fun clearEntry(habitId: Long, epochDay: Long) = dao.deleteEntry(habitId, epochDay)
    suspend fun archiveHabit(habitId: Long, epochDay: Long) = dao.archiveHabit(habitId, epochDay)
    suspend fun restoreHabit(habitId: Long) = dao.restoreHabit(habitId)
    suspend fun deleteHabit(habitId: Long, epochDay: Long) =
        dao.softDeleteHabit(habitId, epochDay)
    suspend fun setPaused(habitId: Long, paused: Boolean, sinceEpochDay: Long?) =
        dao.setPaused(habitId, paused, sinceEpochDay)
}
