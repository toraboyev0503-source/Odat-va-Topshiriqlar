package com.habitcore.app.domain

import com.habitcore.app.data.HabitEntity
import com.habitcore.app.data.HabitEntryEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import java.time.LocalDate

class ScheduleDeletionTest {
    @Test
    fun softDeletedHabitKeepsHistoricalScoresButStopsFutureScoring() {
        val day1 = LocalDate.of(2026, 8, 20)
        val day2 = LocalDate.of(2026, 8, 21)
        val deletedDay = LocalDate.of(2026, 8, 22)

        val habit = HabitEntity(
            id = 10L,
            name = "Read",
            type = HabitType.YES_NO.name,
            colorArgb = 0xFF4E78A8L,
            createdEpochDay = day1.toEpochDay(),
            deletedEpochDay = deletedDay.toEpochDay()
        )

        val entries = listOf(
            HabitEntryEntity(
                habitId = habit.id,
                epochDay = day1.toEpochDay(),
                status = "DONE",
                actualValue = null,
                score = 1.0,
                note = ""
            ),
            HabitEntryEntity(
                habitId = habit.id,
                epochDay = day2.toEpochDay(),
                status = "FAILED",
                actualValue = null,
                score = 0.0,
                note = ""
            )
        )

        assertEquals(
            1.0,
            Schedule.dailyScore(day1, listOf(habit), entries)!!,
            0.0001
        )
        assertEquals(
            0.0,
            Schedule.dailyScore(day2, listOf(habit), entries)!!,
            0.0001
        )
        assertNull(
            Schedule.dailyScore(deletedDay, listOf(habit), entries)
        )
    }
}
