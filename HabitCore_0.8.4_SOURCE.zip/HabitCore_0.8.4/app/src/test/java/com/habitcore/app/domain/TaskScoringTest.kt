package com.habitcore.app.domain

import com.habitcore.app.data.TaskPlanEntity
import com.habitcore.app.data.TaskEntity
import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.LocalDate

class TaskScoringTest {
    @Test
    fun dailyScoreIsCompletedOverPlanned() {
        val day = LocalDate.of(2026, 8, 21)
        val plans = (1L..10L).map { id ->
            TaskPlanEntity(taskId = id, epochDay = day.toEpochDay(), completed = id <= 7L)
        }
        assertEquals(70, TaskScoring.percent(TaskScoring.dailyScore(day, plans)))
    }

    @Test
    fun daysWithoutPlansAreExcludedFromPeriodAverage() {
        val d1 = LocalDate.of(2026, 8, 20)
        val d2 = LocalDate.of(2026, 8, 21)
        val d3 = LocalDate.of(2026, 8, 22)
        val plans = listOf(
            TaskPlanEntity(1L, d1.toEpochDay(), true),
            TaskPlanEntity(2L, d1.toEpochDay(), false),
            TaskPlanEntity(3L, d2.toEpochDay(), true)
        )
        assertEquals(75, TaskScoring.percent(TaskScoring.periodScore(listOf(d1, d2, d3), plans)))
    }

    @Test
    fun planFromAnotherDayDoesNotAffectToday() {
        val yesterday = LocalDate.of(2026, 8, 22)
        val today = LocalDate.of(2026, 8, 23)
        val plans = listOf(
            TaskPlanEntity(1L, yesterday.toEpochDay(), false),
            TaskPlanEntity(2L, today.toEpochDay(), true)
        )
        assertEquals(100, TaskScoring.percent(TaskScoring.dailyScore(today, plans)))
        assertEquals(0, TaskScoring.percent(TaskScoring.dailyScore(yesterday, plans)))
    }

    @Test
    fun staleCurrentDayCarryOverPlanIsIgnored() {
        val today = LocalDate.of(2026, 8, 23)

        val tasks = (1L..6L).map { id ->
            TaskEntity(
                id = id,
                text = "Task $id",
                scheduledEpochDay = today.toEpochDay(),
                completed = id <= 5L
            )
        } + TaskEntity(
            id = 99L,
            text = "Legacy overdue task",
            scheduledEpochDay = today.minusDays(1).toEpochDay(),
            completed = false
        )

        val plans = (1L..6L).map { id ->
            TaskPlanEntity(
                taskId = id,
                epochDay = today.toEpochDay(),
                completed = id <= 5L
            )
        } + TaskPlanEntity(
            taskId = 99L,
            epochDay = today.toEpochDay(),
            completed = false
        )

        assertEquals(
            83,
            TaskScoring.percent(
                TaskScoring.dailyScore(today, plans, tasks, today)
            )
        )
    }

}
