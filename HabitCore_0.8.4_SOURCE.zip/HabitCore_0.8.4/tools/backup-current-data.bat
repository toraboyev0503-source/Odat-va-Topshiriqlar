@echo off
setlocal
echo.
echo HabitCore current data backup
echo =============================
echo.
adb devices
echo.
adb shell am force-stop com.habitcore.app
adb shell run-as com.habitcore.app mkdir -p databases shared_prefs files
adb exec-out run-as com.habitcore.app sh -c "cd /data/user/0/com.habitcore.app && tar -cf - databases shared_prefs files" > HabitCore_data_backup.tar
if errorlevel 1 (
  echo.
  echo Backup failed. Do NOT uninstall the current app.
  pause
  exit /b 1
)
echo.
echo Backup created: HabitCore_data_backup.tar
echo Do not delete this file until the new app is working.
pause
