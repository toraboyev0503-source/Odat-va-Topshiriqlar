@echo off
setlocal
if not exist HabitCore_data_backup.tar (
  echo HabitCore_data_backup.tar not found in this folder.
  pause
  exit /b 1
)
echo.
echo HabitCore data restore
echo ======================
echo.
adb devices
adb shell am force-stop com.habitcore.app
adb shell run-as com.habitcore.app mkdir -p databases shared_prefs files
adb exec-in run-as com.habitcore.app sh -c "cd /data/user/0/com.habitcore.app && tar -xf -" < HabitCore_data_backup.tar
if errorlevel 1 (
  echo.
  echo Restore failed.
  pause
  exit /b 1
)
echo.
echo Restore complete. Open HabitCore now.
pause
