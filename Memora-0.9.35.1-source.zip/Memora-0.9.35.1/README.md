# Memora 0.9.35

Android source package for the Memora 0.9.35 test build.

- `versionName`: `0.9.35`
- `versionCode`: `55`
- Stable Memora test/debug signing configuration is preserved so debug APKs can update earlier compatible test builds.

## 0.9.35 scope

This build implements frozen decisions 72–95: document scanner/OCR improvements, Topilmalar integration settings and external-app capture, browser/app metadata enrichment, and the Topilma editor Back-navigation fix.

The canonical Topilma card renderer and its approved visual specification are intentionally unchanged.
