package com.memora.app.integration

import androidx.activity.ComponentActivity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class TopilmaProcessTextActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState != null) return
        val text = intent.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)?.toString()?.trim().orEmpty()
        if (text.isBlank()) {
            finish()
            return
        }
        val originPackage = resolveOriginPackage(intent)
        lifecycleScope.launch(Dispatchers.IO) {
            val result = runCatching {
                TopilmaExternalCapture.save(applicationContext, text, originPackage)
            }
            withContext(Dispatchers.Main) {
                Toast.makeText(
                    this@TopilmaProcessTextActivity,
                    if (result.isSuccess) "Topilmaga saqlandi" else "Topilmaga saqlanmadi",
                    Toast.LENGTH_SHORT
                ).show()
                finish()
            }
        }
    }

    private fun resolveOriginPackage(sourceIntent: Intent): String? {
        callingPackage?.let { return it }
        if (Build.VERSION.SDK_INT >= 22) {
            referrer?.takeIf { it.scheme == "android-app" }?.host?.let { return it }
        }
        @Suppress("DEPRECATION")
        val extra = sourceIntent.getParcelableExtra<Uri>(Intent.EXTRA_REFERRER)
        return extra?.takeIf { it.scheme == "android-app" }?.host
    }
}
