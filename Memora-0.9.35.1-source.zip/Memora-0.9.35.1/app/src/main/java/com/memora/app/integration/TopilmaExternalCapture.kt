package com.memora.app.integration

import android.content.Context
import android.graphics.drawable.Drawable
import android.net.Uri
import android.view.accessibility.AccessibilityNodeInfo
import com.memora.app.MemoraApplication
import com.memora.app.data.local.TopilmaSourceType
import com.memora.app.data.repository.TopilmaCaptureRequest
import com.memora.app.data.repository.TopilmaCaptureResult
import com.memora.app.media.TopilmalarMediaStorage
import com.memora.app.share.TopilmalarMetadataWorker

object TopilmaExternalCapture {
    data class Metadata(
        val packageName: String?,
        val appName: String?,
        val sourceTitle: String?,
        val author: String? = null,
        val sourceUri: String? = null,
        val sourceType: TopilmaSourceType? = null,
        val appIconPath: String? = null
    )

    suspend fun save(
        context: Context,
        text: String,
        packageName: String?,
        root: AccessibilityNodeInfo? = null
    ): TopilmaCaptureResult {
        val app = context.applicationContext as MemoraApplication
        val clean = text.trim()
        require(clean.isNotBlank())
        val metadata = metadata(context, packageName, root)
        val result = app.topilmalarRepository.capture(
            TopilmaCaptureRequest(
                text = clean,
                sourceTitle = metadata.sourceTitle,
                author = metadata.author,
                sourceUri = metadata.sourceUri,
                originAppPackage = metadata.packageName,
                originAppName = metadata.appName,
                originAppIconPath = metadata.appIconPath,
                sourceType = metadata.sourceType
            )
        )
        if (result.sourceId != null && !metadata.sourceUri.isNullOrBlank()) {
            TopilmalarMetadataWorker.enqueue(context.applicationContext, result.sourceId, metadata.sourceUri)
        }
        return result
    }

    fun metadata(context: Context, packageName: String?, root: AccessibilityNodeInfo? = null): Metadata {
        val pm = context.packageManager
        val pkg = packageName?.takeIf { it.isNotBlank() }
        val appName = pkg?.let {
            runCatching {
                val info = pm.getApplicationInfo(it, 0)
                pm.getApplicationLabel(info).toString()
            }.getOrNull()
        }
        val iconPath = pkg?.let {
            runCatching {
                val drawable: Drawable = pm.getApplicationIcon(it)
                TopilmalarMediaStorage(context).storeAppIcon(it, drawable)
            }.getOrNull()
        }

        val url = root?.let(::findUrl)
        val visible = root?.let(::collectVisibleText).orEmpty()
        val titleCandidate = visible.firstOrNull { candidate ->
            candidate.length in 4..180 && candidate != url && !candidate.startsWith("http", ignoreCase = true)
        }
        val authorCandidate = visible.firstOrNull { candidate ->
            val lower = candidate.lowercase()
            candidate.length in 3..90 && (lower.startsWith("by ") || lower.startsWith("muallif") || lower.startsWith("author"))
        }?.let { raw ->
            when {
                raw.startsWith("By ", true) -> raw.substring(3).trim()
                ':' in raw -> raw.substringAfter(':').trim()
                else -> raw.trim()
            }.ifBlank { null }
        }

        val lowerPkg = pkg.orEmpty().lowercase()
        val type = when {
            lowerPkg.contains("chatgpt") || lowerPkg.contains("openai") -> TopilmaSourceType.CHAT
            url != null || lowerPkg.contains("chrome") || lowerPkg.contains("browser") -> TopilmaSourceType.ARTICLE_WEBSITE
            lowerPkg.contains("reader") || lowerPkg.contains("ebook") || lowerPkg.contains("book") -> TopilmaSourceType.BOOK
            else -> TopilmaSourceType.OTHER
        }

        val title = when {
            type == TopilmaSourceType.CHAT -> appName ?: "ChatGPT"
            titleCandidate != null -> titleCandidate
            url != null -> runCatching { Uri.parse(url).host }.getOrNull()?.removePrefix("www.") ?: appName
            else -> appName
        }
        return Metadata(pkg, appName, title, authorCandidate, url, type, iconPath)
    }

    private fun findUrl(root: AccessibilityNodeInfo): String? {
        val byId = sequenceOf(
            "com.android.chrome:id/url_bar",
            "org.mozilla.firefox:id/mozac_browser_toolbar_url_view",
            "com.microsoft.emmx:id/url_bar"
        ).flatMap { id -> runCatching { root.findAccessibilityNodeInfosByViewId(id).asSequence() }.getOrDefault(emptySequence()) }
            .mapNotNull { it.text?.toString()?.trim() }
            .firstOrNull { it.isNotBlank() }
        normalizeUrl(byId)?.let { return it }
        return collectVisibleText(root).asSequence().mapNotNull(::normalizeUrl).firstOrNull()
    }

    private fun normalizeUrl(raw: String?): String? {
        val value = raw?.trim()?.trimEnd('.', ',', ')', ']', '}') ?: return null
        val candidate = when {
            value.startsWith("https://", true) || value.startsWith("http://", true) -> value
            value.matches(Regex("[A-Za-z0-9.-]+\\.[A-Za-z]{2,}(/.*)?")) -> "https://$value"
            else -> return null
        }
        return runCatching { Uri.parse(candidate) }.getOrNull()?.takeIf { !it.host.isNullOrBlank() }?.toString()
    }

    private fun collectVisibleText(root: AccessibilityNodeInfo): List<String> {
        val out = ArrayList<String>(64)
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var visited = 0
        while (queue.isNotEmpty() && visited < 500) {
            val node = queue.removeFirst()
            visited++
            node.text?.toString()?.trim()?.takeIf { it.isNotBlank() }?.let(out::add)
            node.contentDescription?.toString()?.trim()?.takeIf { it.isNotBlank() }?.let(out::add)
            for (i in 0 until node.childCount) node.getChild(i)?.let(queue::add)
        }
        return out.distinct()
    }
}
