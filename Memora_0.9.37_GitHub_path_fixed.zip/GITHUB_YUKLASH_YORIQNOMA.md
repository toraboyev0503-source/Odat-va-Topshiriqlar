# Memora 0.9.37 — GitHubga to‘g‘ri yuklash

## Muhim: ZIPni GitHubga ZIP holida yuklamang
GitHub "Upload files" funksiyasi ZIPni avtomatik ochmaydi. ZIPni telefonda yoki kompyuterda oching. Uning ichidagi barcha fayl va papkalarni loyihaning asosiy katalogiga yuklang.

GitHub asosiy katalogida (yoki Memora-0.9.37/ ichida) quyidagilar bo‘lishi kerak:

- settings.gradle.kts
- gradlew
- app/
- backend/
- tools/regression_0937.py
- tools/verify_topilma_card_0931.py
- tools/verify_topilma_icons_0931.py
- .github/workflows/android-build.yml

## Eski repozitoriyga yangi ZIPni o‘rnatish
Agar repozitoriyda avvalgi Memora versiyasi bo‘lsa, o‘zgaradigan fayllarni ham yangilang. Faqat YAMLni almashtirish 0.9.37 kodini avtomatik yuklamaydi.

## ZIPdagi tuzilma
Ushbu ZIPning o‘zida oraliq Memora-0.9.37/ papkasi yo‘q; asosiy fayllar ZIPning ildizidan boshlanadi. Agar GitHubda Memora-0.9.37/ papkasi ichiga joylashtirsangiz ham, yangi YAML to‘g‘ri ishlay oladi. (Ammo u holda workflow .github/workflows/ ichida repozitoriy asosiy katalogida turishi shart.)

## Tezkor tekshiruv
GitHub Code bo‘limida `tools/regression_0937.py` fayli ko‘rinishi kerak. Ko‘rinmasa, ZIP tarkibi GitHubga to‘liq yuklanmagan bo‘ladi.
