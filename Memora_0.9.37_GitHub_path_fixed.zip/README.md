# Memora 0.9.37 — audited Android source

- `versionName`: `0.9.37`
- `versionCode`: `58`
- Room version: `8` (unchanged).
- Previous debug package identity and compatible debug signing are preserved.

**Release documentation and GitHub upload instructions:** `docs/RELEASE_0.9.37.md`.

**Build:** `.github/workflows/android-build.yml` (also provided separately as `android-build.yml`).

This source has passed local structural and backend checks; Android APK compilation and device testing are still required in GitHub Actions.

## Previous 0.9.36 functionality

## 0.9.36 scope

This build implements frozen decisions 96–115 for external-app → Topilmalar source selection:

- PROCESS_TEXT now opens a compact bottom source chooser instead of saving immediately.
- The last-used source is the large primary choice; the next five recent sources appear as compact cover tiles.
- “Barcha manbalar” opens a searchable full source list.
- A detected current source is shown as a separate suggestion when the source app supplies usable URL/title/author metadata.
- New detected sources are only created after the user taps the suggestion.
- Detected URL/title contexts are remembered and remapped to the previously chosen source on later captures.
- App name is a fallback only, not an automatic default source.
- Existing web metadata enrichment (title/author/Open Graph image/favicon) remains active when a usable URL is available.
- Canonical Topilma card visual renderer/spec remains unchanged.
