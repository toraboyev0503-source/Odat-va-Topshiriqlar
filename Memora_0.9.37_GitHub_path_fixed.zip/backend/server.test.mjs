import assert from "node:assert/strict";
import test from "node:test";
import { evaluateSubscription, createHandler, createRateLimiter } from "./server.mjs";

const NOW = Date.parse("2026-09-03T12:00:00Z");

function purchase(state, expiryTime, productId = "memora_premium") {
  return {
    subscriptionState: state,
    lineItems: [{ productId, expiryTime, offerDetails: { basePlanId: "monthly" } }],
  };
}

test("active and grace subscriptions remain entitled before expiry", () => {
  for (const state of ["SUBSCRIPTION_STATE_ACTIVE", "SUBSCRIPTION_STATE_IN_GRACE_PERIOD"]) {
    const result = evaluateSubscription(purchase(state, "2026-10-03T12:00:00Z"), NOW);
    assert.equal(result.active, true);
    assert.equal(result.basePlanId, "monthly");
  }
});

test("canceled subscription remains entitled only until its expiry", () => {
  assert.equal(
    evaluateSubscription(purchase("SUBSCRIPTION_STATE_CANCELED", "2026-10-03T12:00:00Z"), NOW).active,
    true,
  );
  assert.equal(
    evaluateSubscription(purchase("SUBSCRIPTION_STATE_CANCELED", "2026-08-03T12:00:00Z"), NOW).active,
    false,
  );
});

test("wrong products, pending, on-hold and expired purchases are read-only", () => {
  assert.equal(
    evaluateSubscription(purchase("SUBSCRIPTION_STATE_ACTIVE", "2026-10-03T12:00:00Z", "other"), NOW).active,
    false,
  );
  for (const state of [
    "SUBSCRIPTION_STATE_PENDING",
    "SUBSCRIPTION_STATE_ON_HOLD",
    "SUBSCRIPTION_STATE_EXPIRED",
  ]) {
    assert.equal(evaluateSubscription(purchase(state, "2026-10-03T12:00:00Z"), NOW).active, false);
  }
});


test("per-instance token limiter bounds repeated requests and releases concurrency", () => {
  let clock = 1000;
  const limiter = createRateLimiter({ now: () => clock, perMinute: 3, perToken: 2, maxConcurrent: 1 });
  limiter.enter("abc");
  assert.throws(() => limiter.enter("other"), /rate_limited/);
  limiter.leave();
  limiter.enter("abc");
  limiter.leave();
  assert.throws(() => limiter.enter("abc"), /rate_limited/);
  limiter.enter("other");
  limiter.leave();
  assert.throws(() => limiter.enter("fourth"), /rate_limited/);
  clock += 60_001;
  limiter.enter("abc");
  limiter.leave();
});

test("billing handler rejects excess validated calls without leaking tokens", async () => {
  const calls = [];
  const limiter = createRateLimiter({ now: () => 1000, perMinute: 1, perToken: 1 });
  const handler = createHandler({
    now: () => 1000,
    limiter,
    verify: async token => { calls.push(token); return null; },
  });
  const http = await import("node:http");
  const server = http.createServer(handler);
  await new Promise(resolve => server.listen(0, "127.0.0.1", resolve));
  try {
    const endpoint = `http://127.0.0.1:${server.address().port}/v1/google-play/subscriptions/verify`;
    async function send(token) {
      return fetch(endpoint, {
        method: "POST", headers: { "content-type": "application/json" },
        body: JSON.stringify({ packageName: "com.memora.app", productId: "memora_premium", purchaseToken: token }),
      });
    }
    assert.equal((await send("token-00000000001")).status, 200);
    const second = await send("token-00000000002");
    assert.equal(second.status, 429);
    assert.equal(second.headers.get("retry-after"), "60");
    assert.deepEqual(calls, ["token-00000000001"]);
  } finally {
    await new Promise(resolve => server.close(resolve));
  }
});
