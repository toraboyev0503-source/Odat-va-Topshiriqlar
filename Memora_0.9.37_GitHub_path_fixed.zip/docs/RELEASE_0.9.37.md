# Memora 0.9.37 — stability / audit remediation

**Version:** 0.9.37 (`versionCode = 58`). **Database:** Room version 8 (unchanged). **Package:** Existing Android application identity and debug-signing file retained.

## Approved decisions M-01…M-12

| ID | Implemented change |
|---|---|
| M-01 | Replace obsolete 0.9.34 GitHub workflow with a single 0.9.37 workflow; run up-to-date structural/visual regressions, backend tests, Android unit tests, lint and debug APK build. |
| M-02 | Defer removal of detached images/audio until note save succeeds; verify no surviving note references the media. |
| M-03 | Reject untitled notes at repository persistence level; unfinished drafts remain in the recovery mechanism rather than the notes table. |
| M-04 | Keep editor open on failed save; decouple Obsidian notification failure from committed local note saves. |
| M-05 | Review selector prioritizes eligible cards and source diversity, treating 25% favorites limit as soft so enough cards are returned when available. |
| M-06 | Preflight and stage imported media, guard against media overwrites, use a Room transaction for database restoration, remove newly-created files on failure and defer DataStore settings until after DB commit. |
| M-07 | Add a shared bounded (24 MiB) OCR temporary file copier with partial-file cleanup; retain IO coroutine dispatching. |
| M-08 | Connect the selected-app preference to source-suggestion handling in PROCESS_TEXT; manual sharing from other apps stays usable. |
| M-09 | Standardize the integration screen under the app theme and add Uzbek/Russian/English localization for touched integration UI. Existing language choices remain. |
| M-10 | Run a 3-to-8 historical Room schema migration test with the original 3.json schema, plus compilation of instrumented tests; emulator execution is an optional manually enabled GitHub workflow action. |
| M-11 | Add dependency-free Node request throttling and concurrency caps to the subscription verifier, plus unit tests, without logging purchase tokens. |
| M-12 | Targeted separation of title policy, review selection and OCR staging, avoiding wide interface/layout refactoring. |

## Validation carried out locally

- `python3 tools/regression_0937.py`: 169 structural checks passed.
- `python3 tools/verify_topilma_card_0931.py`: passed.
- `python3 tools/verify_topilma_icons_0931.py`: passed.
- `cd backend && npm test`: five tests passed.
- `TopilmaReviewSelector.kt`: compiled and exercised independently with local Kotlin compiler, passed.

**Not yet verified:** Full Gradle build, Android unit tests, lint, emulator migration test and real-device upgrade. The working environment has neither a usable installed Android SDK nor Gradle distribution network access. These stages must be confirmed in GitHub Actions **before treating the release as validated**. Historical Room schemas 4–7 were not present in the supplied project; the migration test therefore uses available original schema 3, not independent fixtures for every intermediate version. The touched integration UI offers direct UZ/RU/EN strings and fallback for other existing languages; full professional localization in all 13 languages is not claimed.

## GitHub upload & build

1. Unzip `Memora_0.9.37_GitHub.zip`. Upload the **contents of `Memora-0.9.37`** to the root of the GitHub source repository, retaining hidden `.github` directory and `app/keystore/memora-test-debug.jks`.
2. Commit to `main`. The workflow `.github/workflows/android-build.yml` should run automatically. An identical `android-build.yml` is also shipped separately for convenience; do not install it as a second competing workflow.
3. Open **Actions → Memora 0.9.37 Android Build → latest run**, confirm **all** test/build steps succeed, then download artifact `Memora-0.9.37-debug-apk`.
4. To test the 3→8 migration on an emulator: **Run workflow → run_android_tests = true** (optional extra job). Test upgrading a backup-bearing prior APK on a test handset too.
5. Debug APK is upgradable only over Android test builds with the **same applicationId and signing certificate**. Google Play release APKs need the release signing flow; debug APK is not a Play Store update.
6. The `backend/` changes require a **separate** deployment to the configured Cloud Run service to go live. The CI workflow only tests them. Per-process request limiting is not a globally distributed multi-instance quota; if needed, enforce global quotas at the edge.

## Behavior / compatibility notes

- Never uninstall the old app or clear app data when testing in-place upgrades. Make an independent backup first.
- An incomplete/invalid ZIP backup may now be rejected instead of restoring only part of its media. Existing files are not intentionally overwritten by backup import.
- No Room schema version bump is introduced; only migration test coverage is extended.
- The prior `main.yml` workflow is deliberately removed to prevent duplicated runs.
