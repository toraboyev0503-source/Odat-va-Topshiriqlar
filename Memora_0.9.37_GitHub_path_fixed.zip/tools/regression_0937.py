#!/usr/bin/env python3
"""Version-independent structural guards for the 0.9.37 stability release.

These smoke checks complement, but do not replace, Android compilation and tests.
"""
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
errors = []
checks = 0

def read(rel):
    p = ROOT / rel
    if not p.is_file():
        errors.append(f"missing: {rel}")
        return ""
    return p.read_text(encoding="utf-8")

def check(label, condition):
    global checks
    checks += 1
    if not condition: errors.append(label)

def balanced(text):
    stack=[]; pairs={')':'(',']':'[','}':'{'}
    i=0; block=0
    while i<len(text):
        if block:
            if text.startswith('/*',i): block+=1; i+=2; continue
            if text.startswith('*/',i): block-=1; i+=2; continue
            i+=1; continue
        if text.startswith('//',i):
            j=text.find('\n',i+2)
            i=len(text) if j<0 else j
            continue
        if text.startswith('/*',i): block=1; i+=2; continue
        if text.startswith('"""',i):
            j=text.find('"""',i+3)
            if j<0: return False
            i=j+3; continue
        if text[i] in ('"',"'"):
            q=text[i]; i+=1
            while i<len(text):
                if text[i]=='\\': i+=2; continue
                if text[i]==q: i+=1; break
                i+=1
            continue
        c=text[i]
        if c in '([{': stack.append(c)
        elif c in ')]}':
            if not stack or stack.pop()!=pairs[c]: return False
        i+=1
    return not stack and block==0

p='app/src/main/java/com/memora/app/'
gradle=read('app/build.gradle.kts')
editor=read(p+'ui/screens/EditorScreen.kt')
repository=read(p+'data/repository/MemoraRepository.kt')
backup=read(p+'export/ExportManager.kt')
review=read(p+'data/repository/TopilmaReviewSelector.kt')
ocr=read(p+'share/OcrCacheStorage.kt')
prefs=read(p+'prefs/TopilmaIntegrationPreferences.kt')
process=read(p+'integration/TopilmaProcessTextActivity.kt')
integration=read(p+'ui/screens/TopilmaIntegrationScreen.kt')
db=read(p+'data/local/AppDatabase.kt')
server=read('backend/server.mjs')
workflow=read('.github/workflows/android-build.yml')
check('version 0.9.37', 'versionName = "0.9.37"' in gradle and 'versionCode = 58' in gradle)
check('test debug signature preserved', 'keystore/memora-test-debug.jks' in gradle and 'applicationIdSuffix = ".debug"' in gradle)
check('database version unchanged', 'version = 8' in db and 'ALL_MIGRATIONS' in db)
check('save title validation', 'NoteTitlePolicy.canPersist(title)' in repository and 'NoteSaveResult.TitleRequired' in editor)
check('recovery for uncommitted draft', 'recoveryStore.write(' in editor and 'snapshot.title.isNotBlank()' in editor)
check('editor remains on save failure', 'showSaveFailure()\n                        return@launch' in editor)
check('media not removed on confirmation', 'storage.delete(media.relativePath)' not in editor)
check('media is referenced before cleanup', 'repository.isMediaReferenced(path)' in editor)
check('Obsidian not called synchronously when exiting editor', 'repository.syncNoteToObsidianNow(it)' not in editor)
check('review quota fallback', 'for (candidate in scored)' in review and 'selected.size >= target' in review)
check('backup transaction', 'repository.withImportTransaction' in backup and 'restoreDatabaseExtras' in backup)
check('backup rollback cleanups', all(s in backup for s in ['noteMediaCreated.forEach(storage::delete)', 'topilmalarMediaCreated.forEach(topilmalarStorage::delete)','timeTraceCreated.forEach(timeTraceStorage::delete)']))
check('media staged and validated', 'Backup is missing note media files' in backup and 'restoreBackupEntry' in backup)
check('OCR copy byte limit', 'MAX_BYTES = 24L' in ocr and 'target.delete()' in ocr)
check('integration selector actually checked', 'prefs::isEnabled' in process and 'if (isPreferredOrigin)' in process)
check('integration theme matches Memora', 'MemoraTheme(settings)' in process)
check('integration localized UX', 'AppLanguage.RU' in process and 'AppLanguage.RU' in integration)
check('Billing local limits', 'createRateLimiter' in server and 'limiter.enter(' in server and 'limiter.leave()' in server)
check('CI builds and checks', all(x in workflow for x in ['testDebugUnitTest','lintDebug','assembleDebug','assembleDebugAndroidTest','regression_0937.py']))
check('No old workflow to interfere', not (ROOT/'.github/workflows/main.yml').exists())
check('Android migration test included', (ROOT/'app/src/androidTest/java/com/memora/app/data/local/AppDatabaseMigrationTest.kt').exists())
for file in (ROOT/'app/src').rglob('*.kt'):
    check(f'Kotlin delimiters: {file.name}',balanced(file.read_text(encoding='utf-8')))
for file in (ROOT/'app/src/main').rglob('*.xml'):
    try: ET.parse(file)
    except ET.ParseError as e: errors.append(f'XML: {file}: {e}')
    checks += 1
if errors:
    print(f'Memora 0.9.37 regression FAILED ({len(errors)}/{checks})')
    for error in errors: print(' -', error)
    sys.exit(1)
print(f'Memora 0.9.37 structural regression PASS ({checks} checks).')
