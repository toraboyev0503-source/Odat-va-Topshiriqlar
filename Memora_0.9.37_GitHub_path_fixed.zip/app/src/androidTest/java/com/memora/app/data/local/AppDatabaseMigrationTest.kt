package com.memora.app.data.local

import androidx.room.testing.MigrationTestHelper
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/** Uses the original 3.json fixture and Room's generated version 8 schema. */
@RunWith(AndroidJUnit4::class)
class AppDatabaseMigrationTest {
    @get:Rule
    val helper = MigrationTestHelper(
        InstrumentationRegistry.getInstrumentation(),
        AppDatabase::class.java
    )

    @Test fun upgradeThreeToEightPreservesLegacyNote() {
        val name = "memora-migration-3-to-8"
        helper.createDatabase(name, 3).apply {
            execSQL(
                """INSERT INTO notes
                (id, type, title, contentHtml, plainText, createdAt, updatedAt,
                 wordCount, blocksJson, hasImages, hasAudio)
                VALUES ('legacy-1', 'LONG', 'Legacy note', '<p>Original</p>',
                        'Original', 1000, 1000, 1, '', 0, 0)""".trimIndent()
            )
            close()
        }
        helper.runMigrationsAndValidate(name, 8, true, *AppDatabase.ALL_MIGRATIONS).use { db ->
            db.query("SELECT title, plainText, mood, hashtagsJson FROM notes WHERE id = 'legacy-1'").use { cursor ->
                assertTrue(cursor.moveToFirst())
                assertEquals("Legacy note", cursor.getString(0))
                assertEquals("Original", cursor.getString(1))
                assertTrue(cursor.isNull(2))
                assertEquals("[]", cursor.getString(3))
            }
        }
    }
}
