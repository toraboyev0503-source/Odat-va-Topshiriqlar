# Qurish holati va muhim farq

**Tayyorlangan:** Vazifalar modulining Kotlin kodi, uch signalli WAV, integratsiya skripti, GitHub Actions YML va dastlabki avtomatik testlar.

**Mavjud bo'lmagan narsa:** foydalanuvchi yuborgan APK ichidagi maxsus OdatlarNazorati monitoring modulining asl Kotlin/Java manba kodi (`DailyMonitoringView`, `MonthlyMonitoringDialog` va boshqalar). Avvalgi loyiha sxemasida `monitoring-patch/tools/apply_patch.py` ishlatilgan, biroq uning o'zi yuborilgan arxivda mavjud emas.

`safe-preview` ishga tushirilsa, GitHub asl ochiq manbali Loop 2.3.1 + yangi Vazifalar modulini birlashtirib, **alohida** paket nomi bilan APK yig'ishga urinadi. Bu APK hozir qurilmadagi o'zgartirilgan OdatlarNazorati o'rniga o'rnatilmaydi va uning ma'lumotlariga tegmaydi. Dastur asli kabi odatlar va yangi vazifalar bo'ladi, lekin mavjud maxsus monitoringni aniq nusxada saqlash tasdiqlanmagan.

`integration-source-check` mavjud monitoring kodi bo'lmagani yoki asl imzolovchi kalit yo'qligi sababli to'liq integratsiya APK'sini chiqarishga ruxsat bermaydi. Soxta muvaffaqiyatli APK berishdan ko'ra ushbu tekshiruv noto'g'ri buildni to'xtatadi.

**Tekshiruv natijasi:** ikki unit testdan ikkitasi o'tdi: patch xavfsiz qo'llanadi va bitta WAV tovushda uchta aniq signal bor. Android SDK mavjud bo'lmagani va tarmoq orqali Android loyiha dependencies yuklab olinmagani uchun haqiqiy APK kompilyatsiyasi bu muhitda o'tkazilmadi.

**Yakuniy integratsiya uchun kerak:** aniq monitoring patch manbalari va amaldagi APK bilan mos imzolash kaliti, so'ng GitHub Actions APK build sinovi va qurilmadagi ma'lumotlarning saqlanish testi.
