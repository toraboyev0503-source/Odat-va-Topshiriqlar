import pathlib
import tempfile
import unittest
import subprocess
import sys
import struct
import wave
import shutil

ROOT = pathlib.Path(__file__).resolve().parents[1]
PATCH = ROOT / 'tools/apply_tasks.py'

class PatchTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.up = pathlib.Path(self.temp.name)
        files = {
            'uhabits-android/src/main/java/org/isoron/uhabits/activities/habits/list/ListHabitsActivity.kt': 'class ListHabitsActivity { fun onCreate() { setContentView(rootView) } }',
            'uhabits-android/src/main/AndroidManifest.xml': '<manifest><application android:label="@string/main_activity_title"><provider android:authorities="org.isoron.uhabits" /></application>\n    </application>',
            'uhabits-android/build.gradle.kts': 'buildTypes {\n        debug {\n            enableUnitTestCoverage = true\n        }\n}',
        }
        for name, data in files.items():
            file = self.up / name; file.parent.mkdir(parents=True,exist_ok=True); file.write_text(data)
    def tearDown(self):
        self.temp.cleanup()

    def test_preview_patches_without_overwriting_habits(self):
        p=subprocess.run([sys.executable,str(PATCH),str(self.up),'--safe-preview'],capture_output=True,text=True)
        self.assertEqual(p.returncode,0,p.stderr)
        activity=(self.up/'uhabits-android/src/main/java/org/isoron/uhabits/activities/habits/list/ListHabitsActivity.kt').read_text()
        self.assertIn('TasksBridge.wrapHabits',activity)
        self.assertIn('setContentView',activity)
        gradle=(self.up/'uhabits-android/build.gradle.kts').read_text()
        self.assertIn('applicationIdSuffix = ".tasks.preview"',gradle)
        self.assertTrue((self.up/'uhabits-android/src/main/res/raw/tasks_three_signals.wav').exists())
        self.assertTrue((self.up/'uhabits-android/src/main/java/org/isoron/uhabits/activities/tasks/TaskEngine.kt').exists())
        repeated=subprocess.run([sys.executable,str(PATCH),str(self.up)],capture_output=True,text=True)
        self.assertNotEqual(repeated.returncode,0)

    def test_three_tone_wav_has_three_clear_bursts(self):
        path=ROOT/'patch/res/raw/tasks_three_signals.wav'
        with wave.open(str(path),'rb') as f:
            self.assertEqual(f.getnchannels(),1)
            b=f.readframes(f.getnframes())
            samples=struct.unpack('<'+'h'*(len(b)//2),b)
            rate=f.getframerate()
        active=[]
        for i in range(0,len(samples),rate//100):
            chunk=samples[i:i+rate//100]
            active.append(max(map(abs,chunk))>600 if chunk else False)
        groups=0
        prev=False
        for value in active:
            if value and not prev: groups+=1
            prev=value
        self.assertEqual(groups,3)

if __name__=='__main__':unittest.main()
