# OdatlarNazorati / Vazifalar — GitHub patch source

This package contains **implementation source** for the Tasks module and a CI build definition.
It is NOT a reconstructed copy of the user's custom monitoring source, which was not part of the uploaded APK ZIP.

- Pinned base: iSoron/uhabits commit `2816b7c3d04b61277dab8765d17420f878241f09` (v2.3.1).
- New files: `TaskEngine.kt`, `TasksActivity.kt`, `TasksAlarms.kt`, `TasksBridge.kt`.
- Separate SQLite file `odatlar_tasks.db`; habit database untouched.
- Three tones are encoded in one WAV file. One Android notification, **not** three notifications.
- `safe-preview` (default): builds a distinct application ID `org.isoron.uhabits.tasks.preview`.
- This preview includes the unmodified upstream habits screen, **not the user's custom monitoring implementation**.

## Using with GitHub

Upload this project's contents to a repository root, keeping `.github/workflows/android-build.yml` in place.
Open Actions → OdatlarNazorati — Tasks module build → Run workflow → `safe-preview`.
The APK is published as an artifact **only after Gradle completes successfully**.

## Original installed APK and data

Do not uninstall the installed `org.isoron.uhabits` build to install this preview. They are intentionally different packages. The original custom build is retained on the device. To update that installation **without losing data** requires both:

1. The original `monitoring-patch/tools/apply_patch.py` and monitoring source files used for the supplied APK (M-001..M-018).
2. The original matching APK signing key, not a new GitHub Actions debug keystore.

`integration-source-check` refuses to produce a same-package APK if these requirements are not met.

## Features implemented

- Persistent bottom Odatlar/Vazifalar switch; habits activity content preserved via a wrapper.
- First-use start/end time and equal block count; optional custom per-block edges.
- Focus card with countdown; small past/future cards.
- Add/edit/reorder/duplicate/delete/move tasks; two-step move confirmation.
- Question mark / done / failed; failed tasks automatically archived.
- Unmarked tasks carry into the next available block (or next day).
- Two-color searchable archive: failed red, later neutral; restore and edit/delete.
- One notification with three audible tones on block transition (subject to OS notification permissions and Doze restrictions).
- Monthly calendar with daily percentages and counts, separate from habit monitoring.

## Known limitations / further validation

- No on-device Android UI test or GitHub Action run has been performed for this patch in the current execution environment.
- Matching the *exact* existing custom monitoring design needs the missing monitoring sources.
- Completion triggers a Konfetti animation using the same Konfetti library and Party settings as habits; exact geometry and color remain tasks-specific.
- Reordering works via Up/Down actions (not native drag-and-drop yet).
- To make three-tone sound audible, notification channel sound must be allowed by Android and the device must not be silent.
