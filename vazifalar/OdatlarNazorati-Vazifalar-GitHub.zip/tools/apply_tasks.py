#!/usr/bin/env python3
"""Apply the additive Tasks module to exact Loop Habit Tracker v2.3.1 sources.

Does not modify any habit database, migration, monitoring view, or existing resource.
Run *after* an existing custom monitoring patch, if one is provided.
"""
from pathlib import Path
import argparse
import os
import shutil
import sys

CURRENT = Path(__file__).resolve().parent.parent
ACTIVITY = Path('uhabits-android/src/main/java/org/isoron/uhabits/activities/habits/list/ListHabitsActivity.kt')
TASK_DIR = Path('uhabits-android/src/main/java/org/isoron/uhabits/activities/tasks')
MANIFEST = Path('uhabits-android/src/main/AndroidManifest.xml')
GRADLE = Path('uhabits-android/build.gradle.kts')


def single_replace(src: str, old: str, new: str, name: str) -> str:
    count = src.count(old)
    if count != 1:
        raise RuntimeError(f'{name}: expected exactly one anchor; got {count}: {old[:60]!r}')
    return src.replace(old, new, 1)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('upstream', type=Path)
    parser.add_argument('--safe-preview', action='store_true',
                        help='Use a distinct application ID to prevent overwriting existing user data')
    args = parser.parse_args()
    upstream = args.upstream.resolve()
    for required in [ACTIVITY, MANIFEST, GRADLE]:
        if not (upstream / required).is_file():
            raise RuntimeError(f'Not a complete Loop 2.3.1 checkout; missing {required}')
    old_activity = (upstream / ACTIVITY).read_text()
    old_manifest = (upstream / MANIFEST).read_text()
    old_gradle = (upstream / GRADLE).read_text()

    # Only substitute the final content view of the launcher. Existing monitoring
    # inside the original root view remains the exact same object and code.
    if 'TasksBridge.wrapHabits' in old_activity:
        raise RuntimeError('TasksBridge already installed; refusing double-patch')
    activity = single_replace(old_activity, 'setContentView(rootView)',
        'setContentView(org.isoron.uhabits.activities.tasks.TasksBridge.wrapHabits(this, rootView))',
        str(ACTIVITY))

    insertion = '''        <!-- Vazifalar: separate SQLite database; no habit tables or migrations. -->
        <activity android:name=".activities.tasks.TasksActivity" android:exported="false" />
        <receiver android:name=".activities.tasks.TasksAlarmReceiver" android:exported="false" />
        <receiver android:name=".activities.tasks.TasksBootReceiver" android:exported="false">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
                <action android:name="android.intent.action.TIME_SET" />
                <action android:name="android.intent.action.TIMEZONE_CHANGED" />
                <action android:name="android.intent.action.DATE_CHANGED" />
            </intent-filter>
        </receiver>
'''
    manifest = single_replace(old_manifest, '    </application>', insertion + '    </application>', str(MANIFEST))
    manifest = single_replace(manifest, 'android:authorities="org.isoron.uhabits"',
                              'android:authorities="${applicationId}"', str(MANIFEST))
    if args.safe_preview:
        manifest = single_replace(manifest, 'android:label="@string/main_activity_title"',
                                  'android:label="OdatlarNazorati Vazifalar - sinov"', str(MANIFEST))

    # A separate package is the only safe default without the *original APK signing key*.
    if args.safe_preview:
        needle = '''        debug {
            enableUnitTestCoverage = true
'''
        replacement = '''        debug {
            enableUnitTestCoverage = true
            applicationIdSuffix = ".tasks.preview"
            versionNameSuffix = "-tasks-preview"
'''
        gradle = single_replace(old_gradle, needle, replacement, str(GRADLE))
    else:
        gradle = old_gradle

    # Preflight every change before writing to prevent half-patched source trees.
    kotlin_srcs = sorted((CURRENT / 'patch/kotlin').glob('*.kt'))
    required_files = {'TaskEngine.kt', 'TasksActivity.kt', 'TasksAlarms.kt', 'TasksBridge.kt'}
    if {p.name for p in kotlin_srcs} != required_files:
        raise RuntimeError('Required module Kotlin sources are missing')
    audio = CURRENT / 'patch/res/raw/tasks_three_signals.wav'
    if not audio.is_file() or audio.stat().st_size < 10000:
        raise RuntimeError('Three-signal audio file is missing')
    target_dir = upstream / TASK_DIR
    if target_dir.exists() and any(target_dir.iterdir()):
        raise RuntimeError('Tasks destination already populated; refusing overwrite')
    target_dir.mkdir(parents=True, exist_ok=True)
    for src in kotlin_srcs:
        shutil.copy2(src, target_dir / src.name)
    sound_dir = upstream / 'uhabits-android/src/main/res/raw'
    sound_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(audio, sound_dir / audio.name)
    (upstream / ACTIVITY).write_text(activity)
    (upstream / MANIFEST).write_text(manifest)
    (upstream / GRADLE).write_text(gradle)
    assert (upstream / TASK_DIR / 'TaskEngine.kt').is_file()
    print('Tasks module patched; monitoring source left untouched.')
    print('Variant:', 'SIDE-BY-SIDE PREVIEW' if args.safe_preview else 'ORIGINAL PACKAGE (REQUIRES ORIGINAL SIGNER)')


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print('TASKS PATCH FAILED:', exc, file=sys.stderr)
        sys.exit(2)
