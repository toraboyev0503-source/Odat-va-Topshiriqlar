/*
 * Tasks module for Loop Habit Tracker 2.3.1.
 * Copyright (C) 2026 OdatlarNazorati contributors.
 * SPDX-License-Identifier: GPL-3.0-or-later
 */
package org.isoron.uhabits.activities.tasks

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import kotlin.math.max

internal data class TaskBlock(val index: Int, val start: Int, val end: Int) {
    fun caption(): String = "${minutesText(start)}–${minutesText(end)}"
}

internal fun minutesText(value: Int): String = "%02d:%02d".format(value / 60, value % 60)

internal data class TaskItem(
    val id: Long,
    val title: String,
    val date: String?,
    val block: Int?,
    val status: String,
    val archiveKind: String?,
    val position: Int,
    val carriedFrom: String?
)

internal data class DailySummary(val done: Int, val failed: Int, val pending: Int) {
    val total: Int get() = done + failed + pending
    val percentage: Int get() = if (total == 0) 0 else (done * 100 / total)
}

/** No habit tables or databases are touched by this repository. */
internal class TaskStore(context: Context) : SQLiteOpenHelper(context, "odatlar_tasks.db", null, 1) {
    private val pref = context.getSharedPreferences("tasks_config_v1", Context.MODE_PRIVATE)

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            plan_day TEXT,
            block_index INTEGER,
            status TEXT NOT NULL DEFAULT 'PENDING',
            archive_kind TEXT,
            position INTEGER NOT NULL DEFAULT 0,
            carried_from TEXT,
            created_at INTEGER NOT NULL,
            updated_at INTEGER NOT NULL
        )""")
        db.execSQL("CREATE INDEX tasks_by_block ON tasks(plan_day, block_index, status, position)")
        db.execSQL("CREATE INDEX tasks_by_archive ON tasks(archive_kind, updated_at)")
        db.execSQL("""CREATE TABLE day_results (
            task_id INTEGER NOT NULL,
            day TEXT NOT NULL,
            outcome TEXT NOT NULL,
            PRIMARY KEY(task_id, day)
        )""")
        db.execSQL("CREATE INDEX result_by_day ON day_results(day)")
        db.execSQL("""CREATE TABLE task_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            task_id INTEGER NOT NULL,
            happened_at INTEGER NOT NULL,
            action TEXT NOT NULL,
            details TEXT NOT NULL DEFAULT ''
        )""")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    fun configured(): Boolean = pref.getBoolean("initialized", false)
    fun blocks(): List<TaskBlock> {
        val custom = pref.getString("custom", null)
        if (custom != null) {
            try {
                val array = JSONArray(custom)
                val parsed = (0 until array.length()).map { i ->
                    val obj = array.getJSONObject(i)
                    TaskBlock(i, obj.getInt("start"), obj.getInt("end"))
                }
                if (validBlocks(parsed)) return parsed
            } catch (_: Exception) { /* Fall back to equal blocks */ }
        }
        val start = pref.getInt("start", 360)
        val end = pref.getInt("end", 1320)
        val count = pref.getInt("count", 8).coerceIn(1, 24)
        return (0 until count).map { index ->
            val a = start + ((end - start).toLong() * index / count).toInt()
            val b = start + ((end - start).toLong() * (index + 1) / count).toInt()
            TaskBlock(index, a, b)
        }
    }

    fun configure(start: Int, end: Int, count: Int) {
        require(start in 0..1438 && end in 1..1440 && end - start >= count && count in 1..24)
        pref.edit().putBoolean("initialized", true).putInt("start", start)
            .putInt("end", end).putInt("count", count).remove("custom").apply()
        // Preserve tasks when decreasing block count by moving out-of-range slots to the last block.
        writableDatabase.execSQL("UPDATE tasks SET block_index=? WHERE block_index>=? AND archive_kind IS NULL", arrayOf(count - 1, count))
    }

    fun setCustom(blocks: List<TaskBlock>) {
        require(validBlocks(blocks))
        val array = JSONArray()
        blocks.forEach { array.put(JSONObject().put("start", it.start).put("end", it.end)) }
        pref.edit().putString("custom", array.toString()).apply()
    }

    private fun validBlocks(items: List<TaskBlock>): Boolean =
        items.isNotEmpty() && items.size <= 24 && items.first().start >= 0 &&
            items.last().end <= 1440 && items.all { it.end > it.start } &&
            items.zipWithNext().all { (a, b) -> a.end == b.start }

    fun list(date: LocalDate, block: Int): List<TaskItem> = load(
        "plan_day=? AND block_index=? AND archive_kind IS NULL",
        arrayOf(date.toString(), block.toString()), "position ASC, id ASC"
    )

    fun archive(): List<TaskItem> = load("archive_kind IS NOT NULL", emptyArray(), "updated_at DESC")

    private fun load(where: String, args: Array<String>, order: String): List<TaskItem> {
        val out = mutableListOf<TaskItem>()
        readableDatabase.query("tasks", null, where, args, null, null, order).use { cursor ->
            fun string(col: String) = cursor.getString(cursor.getColumnIndexOrThrow(col))
            fun int(col: String) = cursor.getInt(cursor.getColumnIndexOrThrow(col))
            fun nullableString(col: String): String? {
                val i = cursor.getColumnIndexOrThrow(col)
                return if (cursor.isNull(i)) null else cursor.getString(i)
            }
            fun nullableInt(col: String): Int? {
                val i = cursor.getColumnIndexOrThrow(col)
                return if (cursor.isNull(i)) null else cursor.getInt(i)
            }
            while (cursor.moveToNext()) {
                out.add(TaskItem(cursor.getLong(cursor.getColumnIndexOrThrow("id")), string("title"),
                    nullableString("plan_day"), nullableInt("block_index"), string("status"),
                    nullableString("archive_kind"), int("position"), nullableString("carried_from")))
            }
        }
        return out
    }

    fun add(title: String, day: LocalDate?, block: Int?, later: Boolean = false): Long {
        val safeTitle = title.trim().take(500)
        require(safeTitle.isNotEmpty())
        require(later || (day != null && block != null && block in blocks().indices))
        val now = System.currentTimeMillis()
        return writableDatabase.run {
            beginTransaction()
            try {
                val values = ContentValues().apply {
                    put("title", safeTitle)
                    put("plan_day", day?.toString())
                    if (block == null) putNull("block_index") else put("block_index", block)
                    put("status", "PENDING")
                    if (later) put("archive_kind", "LATER") else putNull("archive_kind")
                    put("position", nextPosition(this@run, day, block))
                    put("created_at", now)
                    put("updated_at", now)
                }
                val id = insertOrThrow("tasks", null, values)
                if (!later && day != null) result(this, id, day, "PENDING")
                event(this, id, "CREATED", safeTitle)
                setTransactionSuccessful()
                id
            } finally { endTransaction() }
        }
    }

    private fun nextPosition(db: SQLiteDatabase, day: LocalDate?, block: Int?): Int {
        if (day == null || block == null) return 0
        db.rawQuery("SELECT COALESCE(MAX(position), 0)+1 FROM tasks WHERE plan_day=? AND block_index=?", arrayOf(day.toString(), block.toString())).use {
            return if (it.moveToFirst()) it.getInt(0) else 1
        }
    }

    fun rename(id: Long, title: String) {
        val safe = title.trim().take(500)
        require(safe.isNotBlank())
        writableDatabase.transaction {
            update("tasks", ContentValues().apply { put("title", safe); put("updated_at", System.currentTimeMillis()) }, "id=?", arrayOf(id.toString()))
            event(this, id, "RENAMED", safe)
        }
    }

    fun setStatus(task: TaskItem, newStatus: String) {
        require(newStatus in setOf("PENDING", "DONE", "FAILED"))
        val day = requireNotNull(task.date).let(LocalDate::parse)
        writableDatabase.transaction {
            update("tasks", ContentValues().apply {
                put("status", newStatus)
                if (newStatus == "FAILED") put("archive_kind", "FAILED") else putNull("archive_kind")
                put("updated_at", System.currentTimeMillis())
            }, "id=?", arrayOf(task.id.toString()))
            result(this, task.id, day, newStatus)
            event(this, task.id, "STATUS", newStatus)
        }
    }

    fun restore(task: TaskItem, day: LocalDate, block: Int) = relocate(task, day, block, reset = true)

    fun relocate(task: TaskItem, day: LocalDate, block: Int, reset: Boolean = false) {
        require(block in blocks().indices)
        writableDatabase.transaction {
            val oldDay = task.date
            if (oldDay != null && oldDay != day.toString() && task.status == "PENDING") {
                delete("day_results", "task_id=? AND day=? AND outcome='PENDING'", arrayOf(task.id.toString(), oldDay))
            }
            update("tasks", ContentValues().apply {
                put("plan_day", day.toString()); put("block_index", block)
                put("position", nextPosition(this@transaction, day, block))
                put("carried_from", if (oldDay != null && task.block != null) "$oldDay #${task.block + 1}" else "")
                put("updated_at", System.currentTimeMillis())
                if (reset) { put("status", "PENDING"); putNull("archive_kind") }
            }, "id=?", arrayOf(task.id.toString()))
            if (reset || task.status == "PENDING") result(this, task.id, day, "PENDING")
            event(this, task.id, if (reset) "RESTORED" else "MOVED", "$day #${block + 1}")
        }
    }

    fun duplicate(task: TaskItem): Long = add(task.title, task.date?.let(LocalDate::parse), task.block, false)

    fun erase(task: TaskItem) {
        writableDatabase.transaction {
            if (task.status == "PENDING" && task.date != null) {
                delete("day_results", "task_id=? AND day=? AND outcome='PENDING'", arrayOf(task.id.toString(), task.date))
            }
            event(this, task.id, "DELETED", task.title)
            delete("tasks", "id=?", arrayOf(task.id.toString()))
        }
    }

    fun reorder(task: TaskItem, direction: Int) {
        val day = task.date?.let(LocalDate::parse) ?: return
        val current = list(day, task.block ?: return)
        val index = current.indexOfFirst { it.id == task.id }
        val target = index + direction
        if (index !in current.indices || target !in current.indices) return
        val shifted = current.toMutableList().apply { add(target, removeAt(index)) }
        writableDatabase.transaction {
            shifted.forEachIndexed { i, row ->
                update("tasks", ContentValues().apply { put("position", i + 1) }, "id=?", arrayOf(row.id.toString()))
            }
        }
    }

    fun summary(day: LocalDate): DailySummary {
        var done = 0; var failed = 0; var pending = 0
        readableDatabase.rawQuery("SELECT outcome, count(*) FROM day_results WHERE day=? GROUP BY outcome", arrayOf(day.toString())).use { cursor ->
            while (cursor.moveToNext()) when (cursor.getString(0)) {
                "DONE" -> done = cursor.getInt(1)
                "FAILED" -> failed = cursor.getInt(1)
                "PENDING" -> pending = cursor.getInt(1)
            }
        }
        return DailySummary(done, failed, pending)
    }

    fun reconcile(now: Long = System.currentTimeMillis()): Int {
        val pending = load("status='PENDING' AND archive_kind IS NULL", emptyArray(), "id ASC")
        val today = Instant.ofEpochMilli(now).atZone(ZoneId.systemDefault()).toLocalDate()
        var moved = 0
        pending.forEach { task ->
            val day = task.date?.let(LocalDate::parse) ?: return@forEach
            val slot = blocks().getOrNull(task.block ?: -1) ?: return@forEach
            val end = day.atStartOfDay(ZoneId.systemDefault()).plusMinutes(slot.end.toLong()).toInstant().toEpochMilli()
            if (now >= end) {
                val (newDay, newBlock) = nextAvailable(now, today)
                if (newDay != day || newBlock != task.block) {
                    relocate(task, newDay, newBlock)
                    moved++
                }
            }
        }
        return moved
    }

    /** Returns the first block whose end has not yet passed; after work, tomorrow's first block. */
    fun nextAvailable(now: Long, today: LocalDate): Pair<LocalDate, Int> {
        val local = Instant.ofEpochMilli(now).atZone(ZoneId.systemDefault())
        val minute = local.hour * 60 + local.minute
        val index = blocks().indexOfFirst { it.end > minute }
        return if (index >= 0) today to index else today.plusDays(1) to 0
    }

    private fun result(db: SQLiteDatabase, taskId: Long, day: LocalDate, status: String) {
        db.insertWithOnConflict("day_results", null, ContentValues().apply {
            put("task_id", taskId); put("day", day.toString()); put("outcome", status)
        }, SQLiteDatabase.CONFLICT_REPLACE)
    }

    private fun event(db: SQLiteDatabase, taskId: Long, action: String, details: String) {
        db.insert("task_events", null, ContentValues().apply {
            put("task_id", taskId); put("happened_at", System.currentTimeMillis())
            put("action", action); put("details", details)
        })
    }

    private inline fun SQLiteDatabase.transaction(block: SQLiteDatabase.() -> Unit) {
        beginTransaction()
        try { block(); setTransactionSuccessful() } finally { endTransaction() }
    }
}
