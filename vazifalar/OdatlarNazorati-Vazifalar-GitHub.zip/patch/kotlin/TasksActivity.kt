/* SPDX-License-Identifier: GPL-3.0-or-later */
package org.isoron.uhabits.activities.tasks

import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.GridLayout
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import nl.dionsegijn.konfetti.xml.KonfettiView
import nl.dionsegijn.konfetti.core.Party
import nl.dionsegijn.konfetti.core.Position
import nl.dionsegijn.konfetti.core.emitter.Emitter
import java.util.concurrent.TimeUnit
import androidx.appcompat.app.AppCompatActivity
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.time.temporal.ChronoUnit
import kotlin.math.max

/** A native view-based task planner, isolated from the existing habit screens. */
class TasksActivity : AppCompatActivity() {
    private lateinit var store: TaskStore
    private lateinit var page: LinearLayout
    private lateinit var konfetti: KonfettiView
    private var selectedDay = LocalDate.now()
    private var selectedBlock: Int? = null
    private var countdown: TextView? = null
    private var countdownEnd: Long = 0L
    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            val remaining = max(0L, (countdownEnd - System.currentTimeMillis()) / 1000)
            countdown?.text = "%02d:%02d:%02d".format(remaining / 3600, remaining % 3600 / 60, remaining % 60)
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = TaskStore(this)
        page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(250, 250, 250)) }
        val container = FrameLayout(this)
        container.addView(page, FrameLayout.LayoutParams(-1, -1))
        konfetti = KonfettiView(this)
        container.addView(konfetti, FrameLayout.LayoutParams(-1, -1))
        konfetti.isClickable = false
        setContentView(container)
        render()
        if (!store.configured()) page.post { showConfiguration(true) }
    }

    override fun onResume() {
        super.onResume()
        if (store.configured()) {
            store.reconcile()
            TasksAlarms.schedule(this)
        }
        render()
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    private fun dp(value: Float) = TasksBridge.dp(this, value)
    private fun shape(color: Int, radius: Float = 14f, border: Int? = null): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        if (border != null) setStroke(dp(1f), border)
    }

    private fun text(value: String, size: Float = 14f, bold: Boolean = false, color: Int = Color.rgb(35, 40, 45)) = TextView(this).apply {
        this.text = value; textSize = size; setTextColor(color)
        if (bold) setTypeface(null, Typeface.BOLD)
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun space(h: Int = 10) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h.toFloat())) }
    private fun row(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    private fun col(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun tilePadding(v: View, px: Int = 12) = v.apply { setPadding(dp(px.toFloat()), dp(px.toFloat()), dp(px.toFloat()), dp(px.toFloat())) }
    private fun button(label: String, click: () -> Unit) = Button(this).apply {
        text = label; textSize = 12f; isAllCaps = false; setOnClickListener { click() }
    }

    private fun currentBlock(): Pair<LocalDate, Int> = store.nextAvailable(System.currentTimeMillis(), LocalDate.now())
    private fun dayEditable() = selectedDay >= LocalDate.now()

    private fun render() {
        page.removeAllViews(); countdown = null
        val top = col().apply { setPadding(dp(16f), dp(10f), dp(16f), dp(4f)) }
        val heading = row()
        heading.addView(text("Vazifalar", 21f, true), LinearLayout.LayoutParams(0, -2, 1f))
        heading.addView(button("◷ Keyinroq") { showTaskEditor(null, later = true) })
        heading.addView(button("⚙") { showConfiguration(false) })
        top.addView(heading)
        val dateSummary = store.summary(selectedDay)
        val progress = row()
        progress.addView(button("▦ ${selectedDay}") { showCalendar() }, LinearLayout.LayoutParams(0, -2, 1f))
        progress.addView(text("${dateSummary.percentage}%  ✓${dateSummary.done}  ×${dateSummary.failed}  ?${dateSummary.pending}", 13f, true))
        top.addView(progress)
        page.addView(top)

        val scroll = ScrollView(this).apply { isFillViewport = false }
        val body = col().apply { setPadding(dp(12f), dp(7f), dp(12f), dp(18f)) }
        scroll.addView(body)
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        if (!store.configured()) {
            body.addView(text("Ish vaqti va bloklar sonini belgilang.", 18f))
            body.addView(button("Sozlashni boshlash") { showConfiguration(true) })
        } else {
            val blocks = store.blocks()
            val (liveDay, liveIndex) = currentBlock()
            val focusedIndex = (selectedBlock ?: if (selectedDay == liveDay) liveIndex else 0).coerceIn(blocks.indices)
            val block = blocks[focusedIndex]
            val activeNow = selectedDay == liveDay && focusedIndex == liveIndex
            val card = col().apply {
                background = shape(Color.WHITE, 18f, Color.rgb(230, 233, 236))
                elevation = dp(1f).toFloat()
                setPadding(dp(15f), dp(15f), dp(15f), dp(15f))
            }
            val blockHeading = row()
            blockHeading.addView(text("${focusedIndex + 1}-BLOK  ${block.caption()}", 17f, true), LinearLayout.LayoutParams(0, -2, 1f))
            blockHeading.addView(text(if (activeNow) "● JORIY" else "KO‘RISH", 11f, true,
                if (activeNow) Color.rgb(20, 125, 65) else Color.GRAY))
            card.addView(blockHeading)
            if (activeNow) {
                card.addView(space(5))
                card.addView(text("Blok tugashiga qolgan vaqt", 12f, color = Color.GRAY).apply { gravity = Gravity.CENTER })
                countdown = text("", 29f, true).apply { gravity = Gravity.CENTER }
                card.addView(countdown)
                countdownEnd = selectedDay.atStartOfDay(ZoneId.systemDefault())
                    .plusMinutes(block.end.toLong()).toInstant().toEpochMilli()
                val elapsed = (System.currentTimeMillis() - selectedDay.atStartOfDay(ZoneId.systemDefault())
                    .plusMinutes(block.start.toLong()).toInstant().toEpochMilli()).coerceAtLeast(0)
                val duration = (block.end - block.start) * 60_000L
                val width = ((elapsed * 100 / max(1L, duration)).toInt()).coerceIn(0, 100)
                val track = LinearLayout(this).apply { background = shape(Color.rgb(234, 238, 241), 9f) }
                track.addView(View(this).apply { background = shape(Color.rgb(65, 125, 205), 9f) },
                    LinearLayout.LayoutParams(0, dp(5f), width.toFloat()))
                track.addView(View(this), LinearLayout.LayoutParams(0, dp(5f), (100-width).toFloat()))
                card.addView(track)
                card.addView(space(8))
            }
            val tasks = store.list(selectedDay, focusedIndex)
            if (tasks.isEmpty()) card.addView(text("Bu blokda hozircha vazifa yo‘q.", 13f, color = Color.GRAY))
            tasks.forEachIndexed { index, task ->
                val taskRow = row().apply {
                    background = shape(if (task.status == "DONE") Color.rgb(236, 236, 236)
                        else Color.rgb(248, 250, 252), 10f, Color.rgb(220, 225, 231))
                    setPadding(dp(8f), dp(5f), dp(4f), dp(5f))
                }
                taskRow.addView(text("%02d".format(index+1), 12f, true, Color.GRAY))
                val name = text(task.title, 14f, color = if (task.status == "DONE") Color.GRAY else Color.DKGRAY)
                name.setPadding(dp(8f), 0, dp(4f), 0)
                val label = col()
                label.addView(name)
                if (!task.carriedFrom.isNullOrBlank()) label.addView(text("↪ ${task.carriedFrom}", 10f, color = Color.GRAY))
                taskRow.addView(label, LinearLayout.LayoutParams(0, -2, 1f))
                taskRow.addView(button(if (task.status == "DONE") "✓" else "?") { showStatus(task) })
                taskRow.addView(button("⋮") { showTaskMenu(task) })
                taskRow.setOnLongClickListener { showTaskMenu(task); true }
                card.addView(taskRow)
                card.addView(space(7))
            }
            if (dayEditable()) {
                val controls = row()
                controls.addView(button("＋ Qo‘shish") { showTaskEditor(null, later = false) }, LinearLayout.LayoutParams(0, -2, 1f))
                controls.addView(button("▣ Arxivdan") { showArchive() }, LinearLayout.LayoutParams(0, -2, 1f))
                card.addView(controls)
            }
            body.addView(card)
            body.addView(space(14))
            val strip = row().apply { gravity = Gravity.TOP }
            val past = col()
            past.addView(text("O‘tgan bloklar", 12f, color = Color.GRAY))
            val leftScroller = HorizontalScrollView(this)
            val leftItems = row()
            (0 until focusedIndex).forEach { index -> leftItems.addView(miniBlock(index, blocks[index], index == liveIndex)) }
            leftScroller.addView(leftItems)
            past.addView(leftScroller)
            strip.addView(past, LinearLayout.LayoutParams(0, -2, 1f))
            val future = col()
            future.addView(text("Keyingi bloklar", 12f, color = Color.GRAY))
            val rightScroller = HorizontalScrollView(this)
            val rightItems = row()
            ((focusedIndex+1) until blocks.size).forEach { index -> rightItems.addView(miniBlock(index, blocks[index], index == liveIndex)) }
            rightScroller.addView(rightItems)
            future.addView(rightScroller)
            strip.addView(future, LinearLayout.LayoutParams(0, -2, 1f))
            body.addView(strip)
            body.addView(space(10))
            if (selectedBlock != null || selectedDay != LocalDate.now()) {
                body.addView(button("↩ Joriy blokka qaytish") {
                    selectedDay = LocalDate.now(); selectedBlock = null; render()
                })
            }
        }
        page.addView(TasksBridge.bottomBar(this, true), LinearLayout.LayoutParams(-1, dp(58f)))
    }

    private fun miniBlock(index: Int, block: TaskBlock, current: Boolean): View {
        return col().apply {
            background = shape(if (current) Color.rgb(221, 236, 254) else Color.rgb(234, 237, 240), 9f)
            setPadding(dp(9f), dp(8f), dp(9f), dp(8f))
            addView(text("${index+1}-blok", 12f, true))
            addView(text(block.caption(), 10f, color = Color.DKGRAY))
            addView(text("${store.list(selectedDay,index).size} ta", 10f, color = Color.GRAY))
            setOnClickListener { selectedBlock = index; render() }
            layoutParams = LinearLayout.LayoutParams(-2,-2).apply { marginEnd = dp(6f) }
        }
    }

    private fun showTaskEditor(existing: TaskItem?, later: Boolean = false) {
        val input = EditText(this).apply {
            hint = "Vazifa nomi"; setSingleLine(false); setText(existing?.title ?: "")
            setSelection(text.length)
            setPadding(dp(18f), dp(12f), dp(18f), dp(12f))
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle(if (existing != null) "Vazifani tahrirlash" else if (later) "Keyinroq bajarish" else "Yangi vazifa")
            .setView(input)
            .setNegativeButton("Bekor qilish", null)
            .setPositiveButton("Saqlash", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val value = input.text.toString().trim()
                if (value.isBlank()) { input.error = "Vazifa nomini kiriting"; return@setOnClickListener }
                if (existing != null) store.rename(existing.id, value)
                else if (later) store.add(value, null, null, later = true)
                else store.add(value, selectedDay, (selectedBlock ?: currentBlock().second).coerceIn(store.blocks().indices))
                dialog.dismiss(); render()
            }
        }
        dialog.show()
    }

    private fun showStatus(task: TaskItem) {
        AlertDialog.Builder(this).setTitle(task.title)
            .setItems(arrayOf("✓ Bajarildi", "× Bajarilmadi — arxivga", "? Hali noma’lum")) { _, which ->
                store.setStatus(task, arrayOf("DONE", "FAILED", "PENDING")[which])
                render()
                if (which == 0) {
                    konfetti.start(Party(
                        speed = 0f, maxSpeed = 16f, damping = 0.9f, spread = 360,
                        angle = 0,
                        colors = listOf(0xFF5A9FDF.toInt(), 0xFF79C69D.toInt(),
                            0xFFF0C16B.toInt(), 0xFFDA85B6.toInt()),
                        position = Position.Absolute(konfetti.width / 2f, konfetti.height / 2f),
                        emitter = Emitter(duration = 25, TimeUnit.MILLISECONDS).max(25),
                        timeToLive = 0
                    ))
                    Toast.makeText(this, "✓ Bajarildi", Toast.LENGTH_SHORT).show()
                } else if (which == 1) {
                    Toast.makeText(this, "Vazifa arxivga o‘tkazildi", Toast.LENGTH_SHORT).show()
                }
            }.setNegativeButton("Yopish", null).show()
    }

    private fun showTaskMenu(task: TaskItem) {
        val actions = arrayOf("Tahrirlash", "Boshqa blokka ko‘chirish", "Nusxalash", "Yuqoriga", "Pastga", "O‘chirish")
        AlertDialog.Builder(this).setTitle(task.title).setItems(actions) { _, which ->
            when (which) {
                0 -> showTaskEditor(task)
                1 -> showMovePicker(task)
                2 -> { store.duplicate(task); render() }
                3 -> { store.reorder(task, -1); render() }
                4 -> { store.reorder(task, 1); render() }
                5 -> AlertDialog.Builder(this).setMessage("Vazifa o‘chirilsinmi?")
                    .setNegativeButton("Yo‘q", null)
                    .setPositiveButton("O‘chirish") { _, _ -> store.erase(task); render() }.show()
            }
        }.show()
    }

    private fun showMovePicker(task: TaskItem) {
        val grid = GridLayout(this).apply { columnCount = 2; setPadding(dp(8f),dp(8f),dp(8f),dp(8f)) }
        val dialog = AlertDialog.Builder(this).setTitle("Qaysi blokka ko‘chirilsin?")
            .setView(grid).setNegativeButton("Yopish", null).create()
        store.blocks().forEach { block ->
            val b = button("${block.index+1}-BLOK\n${block.caption()}\n${store.list(selectedDay,block.index).size} vazifa") {
                dialog.dismiss(); confirmMove(task, block)
            }
            grid.addView(b, GridLayout.LayoutParams().apply {
                width = dp(151f); height = dp(90f); setMargins(dp(3f),dp(3f),dp(3f),dp(3f))
            })
        }
        dialog.show()
    }

    private fun confirmMove(task: TaskItem, destination: TaskBlock) {
        val message = "${destination.index+1}-blok • ${destination.caption()}\n\n" +
            store.list(selectedDay, destination.index).joinToString("\n") { "• ${it.title}" }
        AlertDialog.Builder(this).setTitle("${destination.index+1}-blok")
            .setMessage(message.ifBlank { "Bu blokda hozircha vazifa yo‘q" })
            .setNegativeButton("×") { _, _ -> showMovePicker(task) }
            .setPositiveButton("✓") { _, _ -> store.relocate(task, selectedDay, destination.index); render() }
            .show()
    }

    private fun showArchive() {
        val content = col().apply { setPadding(dp(12f), dp(8f), dp(12f), dp(8f)) }
        val search = EditText(this).apply { hint = "Arxivdan qidirish"; setSingleLine() }
        content.addView(search)
        val scroller = ScrollView(this)
        val items = col()
        scroller.addView(items)
        content.addView(scroller, LinearLayout.LayoutParams(-1, dp(350f)))
        val dialog = AlertDialog.Builder(this).setTitle("Vazifalar arxivi")
            .setView(content).setNegativeButton("Yopish", null).create()
        fun refreshArchive(query: String) {
            items.removeAllViews()
            store.archive().filter { it.title.contains(query, ignoreCase = true) }.forEach { task ->
                val r = row().apply {
                    background = shape(if (task.archiveKind == "FAILED") Color.rgb(255, 227, 227)
                        else Color.rgb(242, 245, 248), 9f)
                    setPadding(dp(6f),dp(4f),dp(4f),dp(4f))
                }
                val name = text("${if (task.archiveKind == "FAILED") "×" else "◷"}  ${task.title}",13f)
                r.addView(name, LinearLayout.LayoutParams(0,-2,1f))
                name.setOnClickListener {
                    val (day, current) = currentBlock()
                    val destinationDay = if (selectedDay >= LocalDate.now()) selectedDay else day
                    val index = (selectedBlock ?: current).coerceIn(store.blocks().indices)
                    store.restore(task, destinationDay, index)
                    dialog.dismiss(); render()
                }
                r.addView(button("✎") { dialog.dismiss(); showTaskEditor(task) })
                r.addView(button("⌫") {
                    AlertDialog.Builder(this).setMessage("Arxivdan butunlay o‘chirilsinmi?")
                        .setNegativeButton("Yo‘q", null)
                        .setPositiveButton("O‘chirish") { _, _ -> store.erase(task); refreshArchive(search.text.toString()); render() }.show()
                })
                items.addView(r)
                items.addView(space(6))
            }
            if (items.childCount == 0) items.addView(text("Arxivda mos vazifa topilmadi.", 14f, color = Color.GRAY))
        }
        search.addTextChangedListener(object: TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, st: Int, before: Int, count: Int) { refreshArchive(s?.toString() ?: "") }
            override fun afterTextChanged(s: Editable?) = Unit
        })
        refreshArchive("")
        dialog.show()
    }

    private fun showCalendar(initial: YearMonth = YearMonth.from(selectedDay)) {
        val outer = col().apply { setPadding(dp(10f),dp(8f),dp(10f),dp(8f)) }
        val header = row()
        var activeDialog: AlertDialog? = null
        val monthText = text(initial.toString(), 19f, true).apply { gravity = Gravity.CENTER }
        header.addView(button("‹") { activeDialog?.dismiss(); showCalendar(initial.minusMonths(1)) })
        header.addView(monthText, LinearLayout.LayoutParams(0,-2,1f))
        header.addView(button("›") { activeDialog?.dismiss(); showCalendar(initial.plusMonths(1)) })
        outer.addView(header)
        val monthGrid = GridLayout(this).apply { columnCount = 7 }
        listOf("Du","Se","Ch","Pa","Ju","Sh","Ya").forEach { day ->
            monthGrid.addView(text(day, 11f, true).apply { gravity = Gravity.CENTER },
                GridLayout.LayoutParams().apply { width=dp(40f);height=dp(35f) })
        }
        repeat(initial.atDay(1).dayOfWeek.value - 1) {
            monthGrid.addView(View(this), GridLayout.LayoutParams().apply { width=dp(40f);height=dp(48f) })
        }
        val dialog = AlertDialog.Builder(this).setTitle("Vazifalar monitoringi")
            .setView(outer).setNegativeButton("Yopish", null).create()
        activeDialog = dialog
        for (n in 1..initial.lengthOfMonth()) {
            val date = initial.atDay(n)
            val sum = store.summary(date)
            val cell = text("$n\n${if(sum.total==0) "–" else "${sum.percentage}%"}", 11f,
                date == selectedDay, if (sum.percentage > 74 && sum.total > 0) Color.rgb(20,100,53) else Color.DKGRAY)
            cell.gravity = Gravity.CENTER
            cell.background = shape(if (date == selectedDay) Color.rgb(215,234,255)
                else if (sum.percentage >= 75 && sum.total > 0) Color.rgb(221,246,225)
                else Color.TRANSPARENT, 8f)
            cell.setOnClickListener { selectedDay=date; selectedBlock=null; dialog.dismiss(); render() }
            monthGrid.addView(cell, GridLayout.LayoutParams().apply { width=dp(40f);height=dp(48f) })
        }
        outer.addView(monthGrid)
        val current = store.summary(selectedDay)
        outer.addView(space(8))
        outer.addView(text("${selectedDay}: ${current.percentage}%  •  ✓ ${current.done}  × ${current.failed}  ? ${current.pending}", 13f, true))
        dialog.show()
    }

    private fun showConfiguration(initial: Boolean) {
        val existing = store.blocks()
        var from = existing.first().start
        var to = existing.last().end
        val form = col().apply { setPadding(dp(16f),dp(10f),dp(16f),dp(6f)) }
        form.addView(text("Ish vaqti va bloklar soni", 16f, true))
        val startButton = button("Boshlanish: ${minutesText(from)}") { }
        val endButton = button("Tugash: ${minutesText(to)}") { }
        startButton.setOnClickListener {
            TimePickerDialog(this, { _,h,m -> from=h*60+m; startButton.text="Boshlanish: ${minutesText(from)}" }, from/60,from%60,true).show()
        }
        endButton.setOnClickListener {
            TimePickerDialog(this, { _,h,m -> to=h*60+m; endButton.text="Tugash: ${minutesText(to)}" }, to/60,to%60,true).show()
        }
        form.addView(startButton)
        form.addView(endButton)
        form.addView(text("Bloklar soni (1–24)", 13f))
        val count = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText(existing.size.toString()); setSingleLine()
        }
        form.addView(count)
        val alert = AlertDialog.Builder(this)
            .setTitle(if (initial) "Vazifalar — dastlabki sozlash" else "Vaqt bloklarini sozlash")
            .setView(form)
            .setCancelable(!initial)
            .setNegativeButton(if (initial) "Keyinroq" else "Yopish", null)
            .setPositiveButton("Saqlash", null).create()
        alert.setOnShowListener {
            alert.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val n = count.text.toString().toIntOrNull()
                if (n == null || n !in 1..24 || to <= from || (to-from) < n) {
                    Toast.makeText(this,"To‘g‘ri vaqt va bloklar sonini kiriting",Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                store.configure(from,to,n)
                store.reconcile()
                selectedBlock=null
                TasksAlarms.schedule(this)
                alert.dismiss(); render()
            }
        }
        alert.show()
        if (!initial) form.addView(button("Blok chegaralarini qo‘lda tahrirlash") {
            alert.dismiss(); showCustomBlocks()
        })
    }

    private fun showCustomBlocks() {
        val original = store.blocks()
        if (original.size <= 1) {
            Toast.makeText(this,"Bir blokning ichki chegarasi yo‘q",Toast.LENGTH_SHORT).show(); return
        }
        val scroller = ScrollView(this)
        val form = col().apply { setPadding(dp(16f),dp(8f),dp(16f),dp(8f)) }
        form.addView(text("Boshlanish ${minutesText(original.first().start)} — Tugash ${minutesText(original.last().end)}"))
        val fields = original.dropLast(1).map { block ->
            val field = EditText(this).apply { setSingleLine(); setText(minutesText(block.end)); hint="HH:mm" }
            form.addView(text("${block.index+1}-blok tugashi", 12f))
            form.addView(field)
            field
        }
        scroller.addView(form)
        val dialog = AlertDialog.Builder(this).setTitle("Blok vaqtlarini qo‘lda sozlash")
            .setView(scroller).setNegativeButton("Yopish",null).setPositiveButton("Saqlash",null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                fun parse(raw: String): Int? {
                    val split=raw.split(":")
                    if (split.size!=2) return null
                    val h=split[0].toIntOrNull() ?: return null
                    val m=split[1].toIntOrNull() ?: return null
                    return if(h in 0..23 && m in 0..59) h*60+m else null
                }
                val times=fields.map { parse(it.text.toString()) }
                if (times.any { it==null }) { Toast.makeText(this,"HH:mm formatini kiriting",Toast.LENGTH_LONG).show(); return@setOnClickListener }
                val edges=listOf(original.first().start)+times.filterNotNull()+listOf(original.last().end)
                if (edges.zipWithNext().any { (a,b)->b<=a }) {
                    Toast.makeText(this,"Vaqtlar o‘sib borishi kerak",Toast.LENGTH_LONG).show(); return@setOnClickListener
                }
                store.setCustom((0 until original.size).map { TaskBlock(it,edges[it],edges[it+1]) })
                TasksAlarms.schedule(this)
                dialog.dismiss(); render()
            }
        }
        dialog.show()
    }
}
