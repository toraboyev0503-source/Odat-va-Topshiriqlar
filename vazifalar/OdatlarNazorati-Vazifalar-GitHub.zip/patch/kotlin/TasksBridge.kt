/* SPDX-License-Identifier: GPL-3.0-or-later */
package org.isoron.uhabits.activities.tasks

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

internal object TasksBridge {
    fun wrapHabits(activity: Activity, habitsView: View): View {
        val root = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL }
        root.addView(habitsView, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(bottomBar(activity, false), LinearLayout.LayoutParams(-1, dp(activity, 58f)))
        return root
    }

    fun bottomBar(activity: Activity, onTasks: Boolean): View {
        val bar = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.rgb(250, 250, 250))
            elevation = dp(activity, 8f).toFloat()
        }
        val names = arrayOf("◉  Odatlar", "☷  Vazifalar")
        for (i in names.indices) {
            val selected = (i == 1) == onTasks
            val button = TextView(activity).apply {
                text = names[i]
                gravity = Gravity.CENTER
                textSize = 15f
                setTypeface(null, if (selected) Typeface.BOLD else Typeface.NORMAL)
                setTextColor(if (selected) Color.rgb(37, 100, 175) else Color.DKGRAY)
                isClickable = true
                isFocusable = true
                if (!selected) setOnClickListener {
                    if (i == 1) activity.startActivity(Intent(activity, TasksActivity::class.java))
                    else activity.finish()
                }
            }
            bar.addView(button, LinearLayout.LayoutParams(0, -1, 1f))
        }
        return bar
    }

    fun dp(activity: Activity, value: Float): Int =
        (value * activity.resources.displayMetrics.density + 0.5f).toInt()
}
