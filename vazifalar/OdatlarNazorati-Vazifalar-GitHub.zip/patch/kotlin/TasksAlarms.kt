/* SPDX-License-Identifier: GPL-3.0-or-later */
package org.isoron.uhabits.activities.tasks

import android.Manifest
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import org.isoron.uhabits.R
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

internal object TasksAlarms {
    private const val CHANNEL = "tasks_block_three_signals_v1"
    private const val REQUEST = 6805

    fun schedule(context: Context) {
        val store = TaskStore(context)
        val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, TasksAlarmReceiver::class.java)
        val alarm = PendingIntent.getBroadcast(context, REQUEST, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        manager.cancel(alarm)
        if (!store.configured()) return
        val now = System.currentTimeMillis()
        val zone = ZoneId.systemDefault()
        val today = Instant.ofEpochMilli(now).atZone(zone).toLocalDate()
        val endpoints = store.blocks().map { it.end }
        val next = (0L..1L).flatMap { delta ->
            val date = today.plusDays(delta)
            endpoints.map { time -> date.atStartOfDay(zone).plusMinutes(time.toLong()).toInstant().toEpochMilli() }
        }.firstOrNull { it > now + 1000 } ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && manager.canScheduleExactAlarms()) {
            manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, alarm)
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, alarm)
        } else {
            manager.set(AlarmManager.RTC_WAKEUP, next, alarm)
        }
    }

    fun notifyTransition(context: Context) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context,
                Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val uri = Uri.parse("android.resource://${context.packageName}/${R.raw.tasks_three_signals}")
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "Vazifa bloklari", NotificationManager.IMPORTANCE_HIGH)
            channel.description = "Blok almashganda bir xabar va uchta ketma-ket signal"
            channel.setSound(uri, AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            channel.enableVibration(true)
            channel.vibrationPattern = longArrayOf(0, 170, 250, 170, 250, 170)
            manager.createNotificationChannel(channel)
        }
        val open = PendingIntent.getActivity(context, REQUEST,
            Intent(context, TasksActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Yangi vaqt bloki boshlandi")
            .setContentText("Vazifalaringizni tekshiring")
            .setContentIntent(open)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setSound(uri)
            .setVibrate(longArrayOf(0, 170, 250, 170, 250, 170))
            .build()
        manager.notify(REQUEST, notification)
    }
}

internal class TasksAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val pending = goAsync()
        try {
            val store = TaskStore(context)
            if (store.configured()) {
                store.reconcile()
                TasksAlarms.notifyTransition(context)
                TasksAlarms.schedule(context)
            }
        } finally { pending.finish() }
    }
}

internal class TasksBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action in setOf(Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_TIME_CHANGED,
                Intent.ACTION_TIMEZONE_CHANGED, Intent.ACTION_DATE_CHANGED)) {
            TasksAlarms.schedule(context)
        }
    }
}
