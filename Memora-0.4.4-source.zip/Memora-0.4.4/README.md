# Memora 0.4.4

Memora is a local-first Android writing app for short and long daily notes. Version 0.4.4 focuses on durable mixed-media export. Save notes now offers HTML, Word and Memora backup. HTML export creates a normal folder with an index and self-contained month/part pages whose images and audio are embedded directly in each page; large archives are split automatically. Word export creates a normal folder with the DOCX plus a clearly cross-referenced Audio subfolder.

## Technology

- Kotlin
- Jetpack Compose + Material 3
- Room database
- DataStore preferences
- Android BiometricPrompt / device credentials
- AlarmManager reminders and statistics schedules
- Local `.memora` backup/import
- HTML folder export (`index.html` + self-contained month/part HTML pages)
- Word folder export (`.docx` + `Audio/` with A001/A002 cross-reference markers)
- English, Russian and Uzbek UI
- Light/Dark/System mode, five curated palettes, UI/writing font choices, and 80–120% interface scaling

Memora does not require a server or an internet connection for normal use.

## GitHub Actions — debug APK

The included `.github/workflows/main.yml` can build either:

1. an extracted Android project in the repository, or
2. a Memora source ZIP stored in the repository root.

If you keep the project as one source ZIP, the workflow file itself must still exist at:

`.github/workflows/main.yml`

GitHub cannot discover a workflow that exists only inside another ZIP.

The debug workflow:

- checks out the repository;
- locates/unpacks the source;
- installs JDK 17;
- installs Gradle 8.13;
- installs Android SDK 36;
- runs `testDebugUnitTest`;
- runs `lintDebug`;
- runs `assembleDebug`;
- uploads `app-debug.apk` as an artifact.

Debug application ID: `com.memora.app.debug`

Release application ID: `com.memora.app`

## Local / Android Studio build

The project includes `gradlew`, `gradlew.bat`, and a small bootstrap wrapper JAR. The bootstrap downloads the verified Gradle 8.13 binary distribution on first use and checks its official SHA-256 checksum.

Examples:

```bash
./gradlew testDebugUnitTest
./gradlew lintDebug
./gradlew assembleDebug
```

## Signed release

`.github/workflows/release.yml` is intentionally manual. It expects these GitHub Secrets:

- `MEMORA_KEYSTORE_BASE64`
- `MEMORA_KEYSTORE_PASSWORD`
- `MEMORA_KEY_ALIAS`
- `MEMORA_KEY_PASSWORD`

Keep the original release keystore permanently. Future Memora updates must use the same signing key.

## Version

- `versionName`: `0.4.4`
- `versionCode`: `10`

## Privacy and backup

Notes are stored locally in Room. Android automatic cloud/device backup is disabled for Memora's private data. Use Memora's own backup export when moving data to another phone.

A combined Memora backup preserves note type, title, text/media blocks, images, audio, creation/edit timestamps, saved titles, reminders, language, theme, palette, fonts and app-lock preference. During import, a note is skipped as a duplicate only when its title, body and creation timestamp all match an existing note.


## 0.4.1 test-update signing

Debug APKs are signed with the bundled `app/keystore/memora-test-debug.jks`. This key is **test-only** and intentionally stable so subsequent GitHub Actions debug APKs can be installed over the previous Memora debug APK without deleting app data.

Test signing certificate SHA-256: `77:2D:4A:04:10:F9:19:FD:0F:E2:77:DA:5E:DC:F4:92:10:25:DD:EC:3E:31:A0:71:D0:9A:79:DD:C8:17:FD:33`. Future debug builds must keep this same test key.

Because builds before 0.4.1 used GitHub runner-generated debug keys, upgrading from 0.4.0 (or older) to 0.4.1 may require **one final uninstall/reinstall**. From 0.4.1 onward, keep this test keystore unchanged and increase `versionCode`; debug APK updates will then install over the previous debug version. Production releases must use a separate private release key through GitHub Secrets.

## Camera images

The image button in both Short and Long editors now offers **Camera** or **Gallery**. Camera photos are captured through Android's FileProvider into a private temporary file, then imported into Memora's private media storage and participate in preview, backup and Word export like gallery images.


## HTML export

Choose **HTML** in Save notes and select a destination folder. Memora creates a `Memora-HTML-...` folder containing `index.html`, month/part HTML pages and a localized README. Every month/part page is self-contained: text, optimized images and audio are embedded directly in the HTML. Large archives are split automatically instead of forcing the browser to load a multi-gigabyte file at once. Open `index.html` for the archive index, or open any month/part page directly.

The HTML copy is optimized for reading; Memora backup remains the authoritative format for preserving the original media bytes.

## Word + audio export

Choose **Word** and select a destination folder. Memora creates a `Memora-Word-...` folder containing:

- `Memora-....docx` — text and images in note order;
- `Audio/` — original audio recordings;
- `README.txt` — localized guidance.

Each audio gets a marker such as `A001`, `A002`, etc. The audio filename contains the same marker and note date/time, for example `A001_2026-08-31_20-07-00.m4a`. At the exact audio position Word shows the same marker, date, duration and `Audio/...` path. This remains usable even when a mobile Word viewer refuses to launch local audio links.

## Audio seeking inside Memora

Audio blocks now include a seek slider and `current / total` time. Drag the slider to move directly to the needed minute and second, then play from that point.
