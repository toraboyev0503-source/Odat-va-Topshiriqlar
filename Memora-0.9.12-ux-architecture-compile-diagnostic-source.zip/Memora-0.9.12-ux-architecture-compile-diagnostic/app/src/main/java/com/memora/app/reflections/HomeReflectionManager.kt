package com.memora.app.reflections

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.memora.app.prefs.AppLanguage
import java.util.Calendar
import kotlinx.coroutines.flow.first
import org.json.JSONArray

private val Context.homeReflectionDataStore by preferencesDataStore("memora_home_reflection_state")

data class HomeReflection(
    val id: Int,
    val firstParagraph: String,
    val secondParagraph: String
) {
    val text: String
        get() = "$firstParagraph\n\n$secondParagraph"
}

class HomeReflectionManager(private val context: Context) {
    private object Keys {
        // v2 keys intentionally do not reuse the earlier prototype state. The 650-item
        // ordered content pack therefore starts cleanly from item 1 after this update.
        val lastSeenAt = longPreferencesKey("sequence_v2_last_seen_at")
        val nextId = intPreferencesKey("sequence_v2_next_id")
        val dayKey = stringPreferencesKey("sequence_v2_day_key")
        val shownToday = intPreferencesKey("sequence_v2_shown_today")
    }

    private val minimumGapMs = 6L * 60L * 60L * 1_000L
    private val maximumPerDay = 2

    /**
     * Returns exactly the next reflection in content order when it is eligible.
     * Eligibility rules:
     *  - at least six hours since the previous fully-seen reflection;
     *  - at most two fully-seen reflections per local calendar day;
     *  - ids advance 1 -> 2 -> ... -> last -> 1, never randomly.
     *
     * Merely displaying/starting an animation does not advance the sequence. Advancement
     * happens only from [markSeen], after the UI has confirmed that the complete reflection
     * was actually read according to the existing Home/reader rules.
     */
    suspend fun nextEligible(
        language: AppLanguage,
        now: Long = System.currentTimeMillis()
    ): HomeReflection? {
        val reflections = loadReflections(language).sortedBy { it.id }
        if (reflections.isEmpty()) return null

        val prefs = context.homeReflectionDataStore.data.first()
        val lastSeenAt = prefs[Keys.lastSeenAt] ?: 0L
        if (lastSeenAt > 0L && now - lastSeenAt < minimumGapMs) return null

        val today = localDayKey(now)
        val shownToday = if (prefs[Keys.dayKey] == today) {
            prefs[Keys.shownToday] ?: 0
        } else {
            0
        }
        if (shownToday >= maximumPerDay) return null

        val requestedId = prefs[Keys.nextId] ?: reflections.first().id
        return reflections.firstOrNull { it.id == requestedId }
            ?: reflections.firstOrNull { it.id > requestedId }
            ?: reflections.first()
    }

    suspend fun markSeen(
        reflectionId: Int,
        shownAt: Long = System.currentTimeMillis()
    ) {
        // Sequence ids are shared across languages. Uzbek is currently the canonical pack;
        // future translations will reuse the same ids, so language switching never changes
        // the user's place in the sequence.
        val orderedIds = loadReflections(AppLanguage.UZ).map { it.id }.sorted()
        if (orderedIds.isEmpty()) return

        val currentIndex = orderedIds.indexOf(reflectionId)
        val nextId = if (currentIndex >= 0) {
            orderedIds[(currentIndex + 1) % orderedIds.size]
        } else {
            orderedIds.first()
        }
        val today = localDayKey(shownAt)

        context.homeReflectionDataStore.edit { prefs ->
            val countBefore = if (prefs[Keys.dayKey] == today) {
                prefs[Keys.shownToday] ?: 0
            } else {
                0
            }
            prefs[Keys.lastSeenAt] = shownAt
            prefs[Keys.nextId] = nextId
            prefs[Keys.dayKey] = today
            prefs[Keys.shownToday] = (countBefore + 1).coerceAtMost(maximumPerDay)
        }
    }

    private fun loadReflections(language: AppLanguage): List<HomeReflection> {
        val preferred = "reflections/${language.tag}.json"
        val json = runCatching {
            context.assets.open(preferred).bufferedReader().use { it.readText() }
        }.getOrNull() ?: return emptyList()
        val array = JSONArray(json)
        return buildList {
            for (index in 0 until array.length()) {
                val item = array.getJSONObject(index)
                val first = item.optString("p1").trim()
                val second = item.optString("p2").trim()
                if (first.isNotEmpty() && second.isNotEmpty()) {
                    add(
                        HomeReflection(
                            id = item.getInt("id"),
                            firstParagraph = first,
                            secondParagraph = second
                        )
                    )
                } else {
                    // Backward-compatible parser for an older one-field prototype file.
                    val parts = item.optString("text")
                        .split(Regex("\\n\\s*\\n"), limit = 2)
                        .map { it.trim() }
                    if (parts.size == 2 && parts.all { it.isNotEmpty() }) {
                        add(
                            HomeReflection(
                                id = item.getInt("id"),
                                firstParagraph = parts[0],
                                secondParagraph = parts[1]
                            )
                        )
                    }
                }
            }
        }
    }

    private fun localDayKey(now: Long): String {
        val calendar = Calendar.getInstance().apply { timeInMillis = now }
        return "${calendar.get(Calendar.YEAR)}-${calendar.get(Calendar.DAY_OF_YEAR)}"
    }
}
