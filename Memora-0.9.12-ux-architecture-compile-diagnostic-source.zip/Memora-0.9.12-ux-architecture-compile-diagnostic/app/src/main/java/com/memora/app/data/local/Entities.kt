package com.memora.app.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

enum class NoteType { SHORT, LONG }

@Entity(
    tableName = "notes",
    indices = [
        Index(value = ["type", "createdAt"]),
        Index(value = ["title"]),
        Index(value = ["createdAt"])
    ]
)
data class NoteEntity(
    @PrimaryKey val id: String,
    val type: String,
    val title: String,
    val contentHtml: String,
    val plainText: String,
    val createdAt: Long,
    val updatedAt: Long,
    val wordCount: Int,
    val blocksJson: String = "",
    val hasImages: Boolean = false,
    val hasAudio: Boolean = false,
    val mood: String? = null
)

@Entity(
    tableName = "saved_titles",
    indices = [Index(value = ["value"], unique = true)]
)
data class SavedTitleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val value: String,
    val createdAt: Long = System.currentTimeMillis(),
    val pinnedAt: Long? = null
)

@Entity(
    tableName = "reminders",
    indices = [Index(value = ["hour", "minute"], unique = true)]
)
data class ReminderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val hour: Int,
    val minute: Int,
    val enabled: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "time_trace_photos",
    indices = [Index(value = ["capturedAt"])]
)
data class TimeTracePhotoEntity(
    @PrimaryKey val dateKey: String,
    val relativePath: String,
    val capturedAt: Long,
    val imported: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
