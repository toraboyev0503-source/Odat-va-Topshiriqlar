package com.memora.app.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface NoteDao {
    @Query("SELECT * FROM notes WHERE type = :type ORDER BY createdAt DESC")
    fun observeByType(type: String): Flow<List<NoteEntity>>

    @Query("SELECT * FROM notes ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<NoteEntity>>

    @Query("SELECT * FROM notes WHERE id = :id LIMIT 1")
    fun observeById(id: String): Flow<NoteEntity?>

    @Query("SELECT * FROM notes WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): NoteEntity?

    @Upsert
    suspend fun upsert(note: NoteEntity)

    @Query("DELETE FROM notes WHERE id IN (:ids)")
    suspend fun deleteByIds(ids: List<String>)

    @Query("UPDATE notes SET title = :newTitle, updatedAt = :updatedAt WHERE title = :oldTitle")
    suspend fun renameTitleInNotes(oldTitle: String, newTitle: String, updatedAt: Long)

    @Query("SELECT COUNT(*) FROM notes WHERE type = :type")
    fun observeCount(type: String): Flow<Int>

    @Query("SELECT COUNT(*) FROM notes WHERE type = :type AND createdAt >= :start AND createdAt < :end")
    fun observeCountBetween(type: String, start: Long, end: Long): Flow<Int>

    @Query("SELECT COUNT(*) FROM notes WHERE type = :type AND createdAt >= :start AND createdAt < :end")
    suspend fun countBetween(type: String, start: Long, end: Long): Int

    @Query("SELECT COUNT(*) FROM notes WHERE type = :type")
    suspend fun count(type: String): Int

    @Query("""
        SELECT * FROM notes
        WHERE (:type IS NULL OR type = :type)
          AND (:start IS NULL OR createdAt >= :start)
          AND (:end IS NULL OR createdAt < :end)
        ORDER BY createdAt ASC
    """)
    suspend fun getForExport(type: String?, start: Long?, end: Long?): List<NoteEntity>

    @Query("""
        SELECT COUNT(*) FROM notes
        WHERE title = :title
          AND plainText = :plainText
          AND createdAt = :createdAt
    """)
    suspend fun duplicateCount(title: String, plainText: String, createdAt: Long): Int
}

@Dao
interface SavedTitleDao {
    @Query("SELECT * FROM saved_titles ORDER BY CASE WHEN pinnedAt IS NULL THEN 1 ELSE 0 END, pinnedAt ASC, createdAt ASC")
    fun observeAll(): Flow<List<SavedTitleEntity>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(title: SavedTitleEntity): Long

    @Delete
    suspend fun delete(title: SavedTitleEntity)

    @Query("UPDATE saved_titles SET value = :newValue WHERE id = :id")
    suspend fun rename(id: Long, newValue: String)

    @Query("UPDATE saved_titles SET pinnedAt = :pinnedAt WHERE id = :id")
    suspend fun setPinned(id: Long, pinnedAt: Long?)

    @Query("SELECT * FROM saved_titles ORDER BY CASE WHEN pinnedAt IS NULL THEN 1 ELSE 0 END, pinnedAt ASC, createdAt ASC")
    suspend fun getAll(): List<SavedTitleEntity>
}

@Dao
interface ReminderDao {
    @Query("SELECT * FROM reminders ORDER BY hour ASC, minute ASC")
    fun observeAll(): Flow<List<ReminderEntity>>

    @Query("SELECT * FROM reminders WHERE enabled = 1 ORDER BY hour ASC, minute ASC")
    suspend fun getEnabled(): List<ReminderEntity>

    @Query("SELECT * FROM reminders WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): ReminderEntity?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(reminder: ReminderEntity): Long

    @Upsert
    suspend fun upsert(reminder: ReminderEntity)

    @Delete
    suspend fun delete(reminder: ReminderEntity)

    @Query("SELECT * FROM reminders ORDER BY hour ASC, minute ASC")
    suspend fun getAll(): List<ReminderEntity>
}


@Dao
interface TimeTraceDao {
    @Query("SELECT * FROM time_trace_photos ORDER BY capturedAt DESC")
    fun observeAll(): Flow<List<TimeTracePhotoEntity>>

    @Query("SELECT * FROM time_trace_photos WHERE dateKey = :dateKey LIMIT 1")
    fun observeByDate(dateKey: String): Flow<TimeTracePhotoEntity?>

    @Query("SELECT * FROM time_trace_photos WHERE dateKey = :dateKey LIMIT 1")
    suspend fun getByDate(dateKey: String): TimeTracePhotoEntity?

    @Query("SELECT * FROM time_trace_photos ORDER BY capturedAt ASC")
    suspend fun getAll(): List<TimeTracePhotoEntity>

    @Upsert
    suspend fun upsert(photo: TimeTracePhotoEntity)

    @Delete
    suspend fun delete(photo: TimeTracePhotoEntity)
}
