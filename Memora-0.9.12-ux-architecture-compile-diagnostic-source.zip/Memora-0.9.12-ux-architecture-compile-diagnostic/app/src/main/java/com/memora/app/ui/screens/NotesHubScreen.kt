package com.memora.app.ui.screens

import android.app.DatePickerDialog
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.FilterList
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.memora.app.data.local.NoteEntity
import com.memora.app.data.local.NoteType
import com.memora.app.data.model.NoteMood
import com.memora.app.i18n.L
import com.memora.app.i18n.S
import com.memora.app.prefs.AppLanguage
import com.memora.app.ui.components.MoodSticker
import com.memora.app.ui.components.NoteCard
import com.memora.app.ui.theme.MemoraDesign
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter

private enum class NotesKind { ALL, SHORT, LONG }
private enum class MediaFilter { ANY, IMAGE, AUDIO, ANY_MEDIA, NO_MEDIA }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotesHubScreen(
    notes: List<NoteEntity>,
    language: AppLanguage,
    initialType: NoteType? = null,
    canEdit: Boolean,
    onOpen: (String) -> Unit,
    onEdit: (NoteEntity) -> Unit,
    onDelete: (NoteEntity) -> Unit
) {
    var kind by remember(initialType) {
        mutableStateOf(
            when (initialType) {
                NoteType.SHORT -> NotesKind.SHORT
                NoteType.LONG -> NotesKind.LONG
                null -> NotesKind.ALL
            }
        )
    }
    var query by remember { mutableStateOf("") }
    var mood by remember { mutableStateOf<NoteMood?>(null) }
    var media by remember { mutableStateOf(MediaFilter.ANY) }
    var filterSheet by remember { mutableStateOf(false) }
    var dateFrom by remember { mutableStateOf<LocalDate?>(null) }
    var dateTo by remember { mutableStateOf<LocalDate?>(null) }
    var pendingDelete by remember { mutableStateOf<NoteEntity?>(null) }
    val listState = rememberLazyListState()
    val zone = remember { ZoneId.systemDefault() }
    val context = LocalContext.current

    val filtered = remember(notes, kind, query, mood, media, dateFrom, dateTo) {
        val q = query.trim().lowercase()
        notes.asSequence()
            .filter {
                when (kind) {
                    NotesKind.ALL -> true
                    NotesKind.SHORT -> it.type == NoteType.SHORT.name
                    NotesKind.LONG -> it.type == NoteType.LONG.name
                }
            }
            .filter { mood == null || it.mood == mood?.name }
            .filter {
                when (media) {
                    MediaFilter.ANY -> true
                    MediaFilter.IMAGE -> it.hasImages
                    MediaFilter.AUDIO -> it.hasAudio
                    MediaFilter.ANY_MEDIA -> it.hasImages || it.hasAudio
                    MediaFilter.NO_MEDIA -> !it.hasImages && !it.hasAudio
                }
            }
            .filter { note ->
                val date = Instant.ofEpochMilli(note.createdAt).atZone(zone).toLocalDate()
                (dateFrom == null || !date.isBefore(dateFrom)) && (dateTo == null || !date.isAfter(dateTo))
            }
            .filter { q.isBlank() || it.title.lowercase().contains(q) || it.plainText.lowercase().contains(q) }
            .sortedByDescending { it.createdAt }
            .toList()
    }
    val grouped = remember(filtered, zone) {
        filtered.groupBy { Instant.ofEpochMilli(it.createdAt).atZone(zone).toLocalDate() }
    }

    Column(Modifier.fillMaxSize()) {
        Column(
            Modifier.padding(
                start = MemoraDesign.screenPadding,
                end = MemoraDesign.screenPadding,
                top = MemoraDesign.screenPadding,
                bottom = 8.dp
            )
        ) {
            Text(
                text = notesTitle(language),
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = kind == NotesKind.ALL, onClick = { kind = NotesKind.ALL }, label = { Text(allLabel(language)) })
                FilterChip(selected = kind == NotesKind.SHORT, onClick = { kind = NotesKind.SHORT }, label = { Text(L.t(language, S.SHORT)) })
                FilterChip(selected = kind == NotesKind.LONG, onClick = { kind = NotesKind.LONG }, label = { Text(L.t(language, S.LONG)) })
            }
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(MemoraDesign.radiusMedium),
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                placeholder = { Text(L.t(language, S.SEARCH)) },
                trailingIcon = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (query.isNotBlank()) {
                            IconButton(onClick = { query = "" }) { Icon(Icons.Rounded.Close, contentDescription = null) }
                        }
                        IconButton(onClick = { filterSheet = true }) {
                            Icon(
                                Icons.Rounded.FilterList,
                                contentDescription = filterLabel(language),
                                tint = if (mood != null || media != MediaFilter.ANY || dateFrom != null || dateTo != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            )
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    if (query.isBlank()) countLabel(language, filtered.size) else foundLabel(language, filtered.size),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f)
                )
                mood?.let {
                    MoodSticker(
                        mood = it,
                        description = moodName(language, it),
                        modifier = Modifier.padding(start = 8.dp).size(25.dp)
                    )
                }
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            state = listState,
            contentPadding = PaddingValues(
                start = MemoraDesign.screenPadding,
                end = MemoraDesign.screenPadding,
                top = 4.dp,
                bottom = 28.dp
            )
        ) {
            if (filtered.isEmpty()) {
                item("empty") {
                    Surface(
                        modifier = Modifier.fillMaxWidth().padding(top = 24.dp),
                        color = MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(MemoraDesign.radiusMedium)
                    ) {
                        Column(Modifier.padding(24.dp)) {
                            Text(if (query.isBlank()) emptyNotes(language) else noMatches(language), style = MaterialTheme.typography.titleMedium)
                            if (query.isNotBlank() || mood != null || media != MediaFilter.ANY || dateFrom != null || dateTo != null) {
                                TextButton(onClick = { query = ""; mood = null; media = MediaFilter.ANY; dateFrom = null; dateTo = null }) { Text(clearFilters(language)) }
                            }
                        }
                    }
                }
            }
            grouped.entries.forEach { (date, dayNotes) ->
                item("header-$date") {
                    Text(
                        dayLabel(date, language),
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(start = 5.dp, top = 16.dp, bottom = 8.dp)
                    )
                }
                items(dayNotes, key = { it.id }) { note ->
                    NoteCard(
                        note = note,
                        displayTitle = note.title.ifBlank { L.t(language, S.UNTITLED) },
                        language = language,
                        selected = false,
                        previewLines = if (note.type == NoteType.SHORT.name) 2 else 3,
                        onClick = { onOpen(note.id) },
                        onLongClick = {},
                        onDeleteRequest = { pendingDelete = note },
                        onEditRequest = if (canEdit) ({ onEdit(note) }) else null
                    )
                    Spacer(Modifier.height(9.dp))
                }
            }
        }
    }

    if (filterSheet) {
        ModalBottomSheet(onDismissRequest = { filterSheet = false }) {
            Column(Modifier.padding(horizontal = 22.dp, vertical = 8.dp)) {
                Text(filterLabel(language), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
                Text(moodFilterLabel(language), style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 18.dp, bottom = 8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    NoteMood.entries.forEach { option ->
                        val selected = mood == option
                        Surface(
                            onClick = { mood = if (selected) null else option },
                            shape = RoundedCornerShape(MemoraDesign.radiusSmall),
                            color = if (selected) MaterialTheme.colorScheme.primary.copy(alpha = .12f) else MaterialTheme.colorScheme.surface
                        ) {
                            MoodSticker(option, moodName(language, option), Modifier.padding(7.dp).size(42.dp))
                        }
                    }
                }
                Text(dateFilterLabel(language), style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 18.dp, bottom = 6.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            val d = dateFrom ?: LocalDate.now()
                            DatePickerDialog(context, { _, y, m, day -> dateFrom = LocalDate.of(y, m + 1, day) }, d.year, d.monthValue - 1, d.dayOfMonth).show()
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text(dateFrom?.toString() ?: fromLabel(language)) }
                    OutlinedButton(
                        onClick = {
                            val d = dateTo ?: LocalDate.now()
                            DatePickerDialog(context, { _, y, m, day -> dateTo = LocalDate.of(y, m + 1, day) }, d.year, d.monthValue - 1, d.dayOfMonth).show()
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text(dateTo?.toString() ?: toLabel(language)) }
                }
                if (dateFrom != null || dateTo != null) {
                    TextButton(onClick = { dateFrom = null; dateTo = null }) { Text(clearDateLabel(language)) }
                }

                Text(mediaFilterLabel(language), style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 18.dp, bottom = 6.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    listOf(MediaFilter.ANY, MediaFilter.IMAGE, MediaFilter.AUDIO).forEach { option ->
                        AssistChip(onClick = { media = option }, label = { Text(mediaName(language, option)) })
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    listOf(MediaFilter.ANY_MEDIA, MediaFilter.NO_MEDIA).forEach { option ->
                        AssistChip(onClick = { media = option }, label = { Text(mediaName(language, option)) })
                    }
                }
                TextButton(
                    onClick = { mood = null; media = MediaFilter.ANY; dateFrom = null; dateTo = null },
                    modifier = Modifier.align(Alignment.End).padding(vertical = 12.dp)
                ) { Text(clearFilters(language)) }
            }
        }
    }

    pendingDelete?.let { note ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text(deleteNoteTitle(language)) },
            text = { Text(deleteNoteText(language)) },
            confirmButton = {
                TextButton(onClick = { onDelete(note); pendingDelete = null }) { Text(L.t(language, S.DELETE)) }
            },
            dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text(cancelNotesLabel(language)) } }
        )
    }
}

private fun notesTitle(l: AppLanguage) = when(l){ AppLanguage.UZ->"Yozuvlar"; AppLanguage.RU->"Записи"; AppLanguage.FR->"Écrits"; AppLanguage.DE->"Einträge"; AppLanguage.ES->"Notas"; AppLanguage.PT_BR->"Notas"; AppLanguage.TR->"Yazılar"; AppLanguage.AR->"الكتابات"; AppLanguage.HI->"लेखन"; AppLanguage.ID->"Catatan"; AppLanguage.JA->"記録"; AppLanguage.KO->"기록"; else->"Notes" }
private fun allLabel(l: AppLanguage)=when(l){AppLanguage.UZ->"Barchasi";AppLanguage.RU->"Все";AppLanguage.FR->"Tout";AppLanguage.DE->"Alle";AppLanguage.ES->"Todo";AppLanguage.PT_BR->"Tudo";AppLanguage.TR->"Tümü";AppLanguage.AR->"الكل";AppLanguage.HI->"सभी";AppLanguage.ID->"Semua";AppLanguage.JA->"すべて";AppLanguage.KO->"전체";else->"All"}
private fun filterLabel(l: AppLanguage)=when(l){AppLanguage.UZ->"Filtr";AppLanguage.RU->"Фильтр";AppLanguage.FR->"Filtres";AppLanguage.DE->"Filter";AppLanguage.ES->"Filtros";AppLanguage.PT_BR->"Filtros";AppLanguage.TR->"Filtre";AppLanguage.AR->"تصفية";AppLanguage.HI->"फ़िल्टर";AppLanguage.ID->"Filter";AppLanguage.JA->"フィルター";AppLanguage.KO->"필터";else->"Filters"}
private fun clearFilters(l:AppLanguage)=when(l){AppLanguage.UZ->"Filtrlarni tozalash";AppLanguage.RU->"Сбросить фильтры";else->"Clear filters"}
private fun moodFilterLabel(l:AppLanguage)=when(l){AppLanguage.UZ->"Kayfiyat";AppLanguage.RU->"Настроение";else->"Mood"}
private fun mediaFilterLabel(l:AppLanguage)=when(l){AppLanguage.UZ->"Media";AppLanguage.RU->"Медиа";else->"Media"}
private fun countLabel(l:AppLanguage,n:Int)=when(l){AppLanguage.UZ->"$n yozuv";AppLanguage.RU->"Записей: $n";else->"$n notes"}
private fun foundLabel(l:AppLanguage,n:Int)=when(l){AppLanguage.UZ->"$n ta topildi";AppLanguage.RU->"Найдено: $n";else->"$n found"}
private fun emptyNotes(l:AppLanguage)=when(l){AppLanguage.UZ->"Hali yozuv yo‘q. Markazdagi + orqali birinchi xotirangizni yozing.";AppLanguage.RU->"Пока нет записей. Создайте первую через +.";else->"No notes yet. Use + to capture your first memory."}
private fun noMatches(l:AppLanguage)=when(l){AppLanguage.UZ->"Mos yozuv topilmadi";AppLanguage.RU->"Подходящих записей нет";else->"No matching notes"}
private fun mediaName(l:AppLanguage,m:MediaFilter)=when(m){MediaFilter.ANY->if(l==AppLanguage.UZ)"Barchasi" else "Any";MediaFilter.IMAGE->if(l==AppLanguage.UZ)"Rasm" else "Image";MediaFilter.AUDIO->if(l==AppLanguage.UZ)"Audio" else "Audio";MediaFilter.ANY_MEDIA->if(l==AppLanguage.UZ)"Media bor" else "Has media";MediaFilter.NO_MEDIA->if(l==AppLanguage.UZ)"Mediasiz" else "No media"}
private fun moodName(l:AppLanguage,m:NoteMood)=when(m){NoteMood.GREAT->if(l==AppLanguage.UZ)"Zo‘r" else "Great";NoteMood.GOOD->if(l==AppLanguage.UZ)"Yaxshi" else "Good";NoteMood.NEUTRAL->if(l==AppLanguage.UZ)"O‘rtacha" else "Neutral";NoteMood.BAD->if(l==AppLanguage.UZ)"Yomon" else "Bad";NoteMood.VERY_BAD->if(l==AppLanguage.UZ)"Juda yomon" else "Very bad"}
private fun dateFilterLabel(l:AppLanguage)=if(l==AppLanguage.UZ) "Sana oralig‘i" else "Date range"
private fun fromLabel(l:AppLanguage)=if(l==AppLanguage.UZ) "Boshlanish" else "From"
private fun toLabel(l:AppLanguage)=if(l==AppLanguage.UZ) "Tugash" else "To"
private fun clearDateLabel(l:AppLanguage)=if(l==AppLanguage.UZ) "Sanani tozalash" else "Clear dates"
private fun deleteNoteTitle(l:AppLanguage)=if(l==AppLanguage.UZ) "Yozuvni o‘chirish" else "Delete note"
private fun deleteNoteText(l:AppLanguage)=if(l==AppLanguage.UZ) "Bu yozuv va unga tegishli media o‘chiriladi." else "This note and its attached media will be deleted."
private fun cancelNotesLabel(l:AppLanguage)=if(l==AppLanguage.UZ) "Bekor qilish" else "Cancel"

private fun dayLabel(date: LocalDate, language: AppLanguage): String {
    val now=LocalDate.now()
    if(date==now) return if(language==AppLanguage.UZ) "Bugun" else if(language==AppLanguage.RU) "Сегодня" else "Today"
    if(date==now.minusDays(1)) return if(language==AppLanguage.UZ) "Kecha" else if(language==AppLanguage.RU) "Вчера" else "Yesterday"
    return date.format(DateTimeFormatter.ofPattern(if(date.year==now.year) "d MMMM" else "d MMMM yyyy", java.util.Locale.forLanguageTag(language.tag)))
}
