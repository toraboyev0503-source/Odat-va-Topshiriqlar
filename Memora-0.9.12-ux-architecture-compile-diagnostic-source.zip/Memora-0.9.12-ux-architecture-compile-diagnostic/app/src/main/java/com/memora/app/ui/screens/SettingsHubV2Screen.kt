package com.memora.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Fingerprint
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Policy
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material.icons.rounded.Title
import androidx.compose.material.icons.rounded.WorkspacePremium
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.memora.app.BuildConfig
import com.memora.app.i18n.L
import com.memora.app.i18n.S
import com.memora.app.prefs.AppLanguage
import com.memora.app.prefs.UserSettings
import com.memora.app.ui.theme.MemoraDesign

private data class V2Setting(
    val icon: ImageVector,
    val title: String,
    val status: String? = null,
    val onClick: () -> Unit
)

@Composable
fun SettingsHubV2Screen(
    settings: UserSettings,
    onReminders: () -> Unit,
    onTitles: () -> Unit,
    onTheme: () -> Unit,
    onLanguage: () -> Unit,
    onData: () -> Unit,
    onSecurity: () -> Unit,
    onSubscription: () -> Unit,
    onAbout: () -> Unit
) {
    val l = settings.language
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(
            start = MemoraDesign.screenPadding,
            end = MemoraDesign.screenPadding,
            top = MemoraDesign.screenPadding,
            bottom = 110.dp
        )
    ) {
        item {
            Text(settingsTitle(l), style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.SemiBold)
            Text(
                L.t(l, S.HOME_TAGLINE),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 3.dp, bottom = 22.dp)
            )
        }
        item {
            SettingsV2Section(
                title = writingSection(l),
                entries = listOf(
                    V2Setting(Icons.Rounded.Notifications, remindersLabel(l), null, onReminders),
                    V2Setting(Icons.Rounded.Title, titlesLabel(l), null, onTitles)
                )
            )
        }
        item {
            SettingsV2Section(
                title = appearanceSection(l),
                entries = listOf(
                    V2Setting(Icons.Rounded.Palette, themeLabel(l), themeStatus(settings), onTheme),
                    V2Setting(Icons.Rounded.Language, languageLabel(l), settings.language.displayName, onLanguage)
                )
            )
        }
        item {
            SettingsV2Section(
                title = dataSection(l),
                entries = listOf(
                    V2Setting(Icons.Rounded.Storage, dataBackupLabel(l), null, onData),
                    V2Setting(Icons.Rounded.Fingerprint, securityLabel(l), lockStatus(settings), onSecurity)
                )
            )
        }
        item {
            SettingsV2Section(
                title = memoraSection(l),
                entries = listOf(
                    V2Setting(Icons.Rounded.WorkspacePremium, subscriptionLabel(l), null, onSubscription),
                    V2Setting(Icons.Rounded.Policy, privacyLabel(l), null, onAbout),
                    V2Setting(Icons.Rounded.Info, aboutLabel(l), "v${BuildConfig.VERSION_NAME}", onAbout)
                ),
                bottom = 0.dp
            )
        }
    }
}

@Composable
private fun SettingsV2Section(title: String, entries: List<V2Setting>, bottom: androidx.compose.ui.unit.Dp = 22.dp) {
    Column(Modifier.padding(bottom = bottom)) {
        Text(title, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(start=5.dp,bottom=8.dp))
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(MemoraDesign.radiusMedium),
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = MemoraDesign.shadowSubtle
        ) {
            Column {
                entries.forEachIndexed { i, e ->
                    Row(
                        Modifier.fillMaxWidth().clickable(onClick=e.onClick).padding(horizontal=18.dp,vertical=14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(e.icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Column(Modifier.weight(1f).padding(start=16.dp)) {
                            Text(e.title, style=MaterialTheme.typography.titleMedium)
                            e.status?.let { Text(it, style=MaterialTheme.typography.bodySmall, color=MaterialTheme.colorScheme.onSurfaceVariant, modifier=Modifier.padding(top=2.dp)) }
                        }
                        Text("›", style=MaterialTheme.typography.titleLarge, color=MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if(i!=entries.lastIndex) HorizontalDivider(Modifier.padding(start=58.dp), color=MaterialTheme.colorScheme.onSurface.copy(alpha=.06f))
                }
            }
        }
    }
}

private fun settingsTitle(l:AppLanguage)=if(l==AppLanguage.UZ)"Sozlamalar" else if(l==AppLanguage.RU)"Настройки" else "Settings"
private fun writingSection(l:AppLanguage)=if(l==AppLanguage.UZ)"Yozish" else if(l==AppLanguage.RU)"Письмо" else "Writing"
private fun appearanceSection(l:AppLanguage)=if(l==AppLanguage.UZ)"Ko‘rinish" else if(l==AppLanguage.RU)"Оформление" else "Appearance"
private fun dataSection(l:AppLanguage)=if(l==AppLanguage.UZ)"Ma’lumotlar va maxfiylik" else if(l==AppLanguage.RU)"Данные и приватность" else "Data & privacy"
private fun memoraSection(l:AppLanguage)="Memora"
private fun remindersLabel(l:AppLanguage)=if(l==AppLanguage.UZ)"Eslatmalar" else if(l==AppLanguage.RU)"Напоминания" else "Reminders"
private fun titlesLabel(l:AppLanguage)=if(l==AppLanguage.UZ)"Saqlangan sarlavhalar" else if(l==AppLanguage.RU)"Сохранённые заголовки" else "Saved titles"
private fun themeLabel(l:AppLanguage)=if(l==AppLanguage.UZ)"Mavzu" else if(l==AppLanguage.RU)"Тема" else "Theme"
private fun languageLabel(l:AppLanguage)=if(l==AppLanguage.UZ)"Til" else if(l==AppLanguage.RU)"Язык" else "Language"
private fun dataBackupLabel(l:AppLanguage)=if(l==AppLanguage.UZ)"Ma’lumotlar va backup" else if(l==AppLanguage.RU)"Данные и резервная копия" else "Data & backup"
private fun securityLabel(l:AppLanguage)=if(l==AppLanguage.UZ)"Xavfsizlik" else if(l==AppLanguage.RU)"Безопасность" else "Security"
private fun subscriptionLabel(l:AppLanguage)=if(l==AppLanguage.UZ)"Obuna" else if(l==AppLanguage.RU)"Подписка" else "Subscription"
private fun aboutLabel(l:AppLanguage)=if(l==AppLanguage.UZ)"Ilova haqida" else if(l==AppLanguage.RU)"О приложении" else "About"
private fun privacyLabel(l:AppLanguage)=if(l==AppLanguage.UZ)"Maxfiylik siyosati" else if(l==AppLanguage.RU)"Конфиденциальность" else "Privacy policy"
private fun themeStatus(s:UserSettings)="${s.palette.name.lowercase().replaceFirstChar{it.uppercase()}} · ${s.themeMode.name.lowercase().replaceFirstChar{it.uppercase()}}"
private fun lockStatus(s:UserSettings)=if(s.lockEnabled) (if(s.language==AppLanguage.UZ)"Yoqilgan" else "On") else (if(s.language==AppLanguage.UZ)"O‘chiq" else "Off")
