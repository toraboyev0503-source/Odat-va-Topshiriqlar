package com.memora.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.memora.app.i18n.L
import com.memora.app.i18n.S
import com.memora.app.prefs.AppLanguage
import com.memora.app.prefs.FontChoice
import com.memora.app.prefs.PaletteChoice
import com.memora.app.prefs.UserSettings
import com.memora.app.prefs.ThemeMode
import com.memora.app.ui.components.MemoraTopBar
import com.memora.app.ui.theme.fontFamily

@Composable
fun ThemeScreen(
    settings: UserSettings,
    onBack: () -> Unit,
    onPalette: (PaletteChoice) -> Unit,
    onThemeMode: (ThemeMode) -> Unit,
    onUiFont: (FontChoice) -> Unit,
    onWritingFont: (FontChoice) -> Unit,
    onUiScale: (Float) -> Unit
) {
    val language = settings.language
    var scalePreview by remember(settings.uiScale) { mutableFloatStateOf(settings.uiScale) }
    Column(Modifier.fillMaxSize()) {
        MemoraTopBar(
            title = L.t(language, S.THEME),
            navigation = {
                IconButton(onClick = onBack) {
                    Icon(Icons.Rounded.ArrowBack, contentDescription = null)
                }
            }
        )
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp)
        ) {
            SectionTitle(themeModeLabel(language))
            LazyRow {
                items(ThemeMode.entries) { mode ->
                    FilterChip(
                        selected = settings.themeMode == mode,
                        onClick = { onThemeMode(mode) },
                        label = { Text(themeModeName(language, mode)) },
                        modifier = Modifier.padding(end = 8.dp)
                    )
                }
            }

            SectionTitle(L.t(language, S.BACKGROUND))
            LazyRow {
                items(PaletteChoice.entries) { choice ->
                    PaletteChip(
                        choice = choice,
                        selected = settings.palette == choice,
                        language = language,
                        onClick = { onPalette(choice) }
                    )
                }
            }


            SectionTitle(L.t(language, S.SCALE))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Slider(
                    value = scalePreview,
                    onValueChange = { scalePreview = it },
                    onValueChangeFinished = { onUiScale(scalePreview) },
                    valueRange = 0.8f..1.5f,
                    steps = 13,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    "${(scalePreview * 100).toInt()}%",
                    style = MaterialTheme.typography.labelLarge,
                    modifier = Modifier.padding(start = 10.dp)
                )
            }

            SectionTitle(L.t(language, S.UI_FONT))
            ChoiceRow(FontChoice.entries, settings.uiFont, language, onUiFont)

            SectionTitle(L.t(language, S.WRITING_FONT))
            ChoiceRow(FontChoice.entries, settings.writingFont, language, onWritingFont)

        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleMedium,
        modifier = Modifier.padding(top = 20.dp, bottom = 10.dp)
    )
}

@Composable
private fun PaletteChip(
    choice: PaletteChoice,
    selected: Boolean,
    language: AppLanguage,
    onClick: () -> Unit
) {
    val swatch = when (choice) {
        PaletteChoice.PAPER -> Color(0xFFF7F0E6)
        PaletteChoice.IVORY -> Color(0xFFFBF7EE)
        PaletteChoice.MIST -> Color(0xFFE9F0EF)
        PaletteChoice.SAGE -> Color(0xFFE6ECE4)
        PaletteChoice.SLATE -> Color(0xFFDDE7EA)
    }
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = CircleShape,
                    color = swatch,
                    modifier = Modifier.padding(end = 7.dp)
                ) { androidx.compose.foundation.layout.Box(Modifier.padding(8.dp)) }
                Text(
                    L.t(language, when (choice) {
                        PaletteChoice.PAPER -> S.PAPER
                        PaletteChoice.IVORY -> S.IVORY
                        PaletteChoice.MIST -> S.MIST
                        PaletteChoice.SAGE -> S.SAGE
                        PaletteChoice.SLATE -> S.SLATE
                    })
                )
            }
        },
        modifier = Modifier.padding(end = 8.dp)
    )
}

@Composable
private fun ChoiceRow(
    values: List<FontChoice>,
    selected: FontChoice,
    language: AppLanguage,
    onSelect: (FontChoice) -> Unit
) {
    LazyRow {
        items(values) { choice ->
            FilterChip(
                selected = selected == choice,
                onClick = { onSelect(choice) },
                label = {
                    Text(
                        L.t(language, when (choice) {
                            FontChoice.SANS -> S.SANS
                            FontChoice.SERIF -> S.SERIF
                            FontChoice.MONO -> S.MONO
                            FontChoice.CURSIVE -> S.CURSIVE
                        }),
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontFamily = fontFamily(choice)
                        )
                    )
                },
                modifier = Modifier.padding(end = 8.dp)
            )
        }
    }
}

private fun themeModeLabel(language: AppLanguage): String = when (language) {
    AppLanguage.UZ -> "Ko‘rinish rejimi"
    AppLanguage.RU -> "Режим оформления"
    else -> "Appearance"
}

private fun themeModeName(language: AppLanguage, mode: ThemeMode): String = when (mode) {
    ThemeMode.SYSTEM -> if (language == AppLanguage.UZ) "Tizim" else if (language == AppLanguage.RU) "Система" else "System"
    ThemeMode.LIGHT -> if (language == AppLanguage.UZ) "Yorug‘" else if (language == AppLanguage.RU) "Светлая" else "Light"
    ThemeMode.DARK -> if (language == AppLanguage.UZ) "Tungi" else if (language == AppLanguage.RU) "Тёмная" else "Dark"
}
