package com.memora.app.notifications

import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import com.memora.app.MemoraApplication
import com.memora.app.i18n.L
import com.memora.app.i18n.S
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class CopyCardReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val clipboard = context.getSystemService(ClipboardManager::class.java)
        clipboard.setPrimaryClip(ClipData.newPlainText("Memora support card", CARD_NUMBER))

        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val app = context.applicationContext as MemoraApplication
                val language = app.preferences.settings.first().language
                withContext(Dispatchers.Main) {
                    Toast.makeText(context, L.t(language, S.CARD_COPIED), Toast.LENGTH_SHORT).show()
                }
            } finally {
                pending.finish()
            }
        }
    }

    companion object {
        const val CARD_NUMBER = "4916990337686304"
        const val DISPLAY_CARD_NUMBER = "4916 9903 3768 6304"
    }
}
