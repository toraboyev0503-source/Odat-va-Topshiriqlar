package com.memora.app.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.memora.app.MemoraApplication
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val app = context.applicationContext as MemoraApplication
                val scheduler = AlarmScheduler(context)
                app.repository.enabledReminders().forEach(scheduler::scheduleReminder)
                StatsScheduler(context).scheduleAll()
            } finally {
                pending.finish()
            }
        }
    }
}
