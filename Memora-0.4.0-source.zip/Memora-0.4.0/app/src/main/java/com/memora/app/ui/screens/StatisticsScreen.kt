package com.memora.app.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.memora.app.i18n.L
import com.memora.app.i18n.S
import com.memora.app.prefs.AppLanguage
import com.memora.app.ui.components.MemoraTopBar

data class StatsSnapshot(
    val allShort: Int,
    val allLong: Int,
    val monthShort: Int,
    val monthLong: Int,
    val yearShort: Int,
    val yearLong: Int
)

@Composable
fun StatisticsScreen(
    stats: StatsSnapshot,
    language: AppLanguage,
    onBack: () -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        MemoraTopBar(
            title = L.t(language, S.STATISTICS),
            navigation = {
                IconButton(onClick = onBack) {
                    Icon(Icons.Rounded.ArrowBack, contentDescription = null)
                }
            }
        )
        Column(Modifier.padding(horizontal = 20.dp)) {
            StatsCard(L.t(language, S.THIS_MONTH), stats.monthShort, stats.monthLong, language)
            StatsCard(L.t(language, S.THIS_YEAR), stats.yearShort, stats.yearLong, language)
            StatsCard(L.t(language, S.ALL_TIME), stats.allShort, stats.allLong, language)
        }
    }
}

@Composable
private fun StatsCard(title: String, short: Int, long: Int, language: AppLanguage) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 14.dp),
        shape = RoundedCornerShape(28.dp),
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(Modifier.padding(22.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(Modifier.fillMaxWidth().padding(top = 12.dp)) {
                Column(Modifier.weight(1f)) {
                    Text(short.toString(), style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Medium)
                    Text(L.t(language, S.SHORT), style = MaterialTheme.typography.bodyMedium)
                }
                Column(Modifier.weight(1f)) {
                    Text(long.toString(), style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Medium)
                    Text(L.t(language, S.LONG), style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}
