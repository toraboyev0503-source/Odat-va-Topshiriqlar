package com.memora.app.ui.components

import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.sp
import com.memora.app.prefs.FontChoice
import com.memora.app.ui.theme.fontFamily
import com.memora.app.util.EditorInputNormalizer

/**
 * Plain note editor.
 *
 * Memora intentionally does not apply inline rich-text spans anymore. Keeping the editor as
 * plain text avoids IME composing spans becoming permanent formatting and prevents punctuation
 * commits from being mistaken for paragraph breaks on keyboards such as SwiftKey.
 */
@Composable
fun PlainTextEditor(
    text: String,
    onValueChanged: (String) -> Unit,
    fontChoice: FontChoice,
    ink: Color,
    uiScale: Float = 1.0f,
    onFocused: () -> Unit = {},
    onCursorChanged: (Int) -> Unit = {},
    requestFocus: Boolean = false,
    requestCursorPosition: Int? = null,
    modifier: Modifier = Modifier
) {
    val focusRequester = remember { FocusRequester() }
    var fieldValue by remember {
        mutableStateOf(
            TextFieldValue(
                text = text,
                selection = TextRange(text.length)
            )
        )
    }

    // Sync only when text genuinely changed outside this editor (for example, loading a note).
    // Do not rebuild TextFieldValue on every keystroke because that would disrupt IME composing.
    LaunchedEffect(text) {
        if (text != fieldValue.text) {
            fieldValue = fieldValue.copy(
                text = text,
                selection = TextRange(fieldValue.selection.start.coerceAtMost(text.length))
            )
        }
    }


    LaunchedEffect(requestFocus, requestCursorPosition) {
        if (requestFocus) {
            val cursor = (requestCursorPosition ?: fieldValue.text.length).coerceIn(0, fieldValue.text.length)
            fieldValue = fieldValue.copy(selection = TextRange(cursor), composition = null)
            onCursorChanged(cursor)
            focusRequester.requestFocus()
        }
    }

    BasicTextField(
        value = fieldValue,
        onValueChange = { incoming ->
            val normalized = EditorInputNormalizer.normalize(
                previousText = fieldValue.text,
                incomingText = incoming.text,
                incomingCursor = incoming.selection.start,
                hasComposition = incoming.composition != null
            )
            val next = if (normalized.changed) {
                incoming.copy(
                    text = normalized.text,
                    selection = TextRange(normalized.cursor),
                    composition = null
                )
            } else {
                incoming
            }
            fieldValue = next
            onCursorChanged(next.selection.start)
            if (next.text != text) onValueChanged(next.text)
        },
        modifier = modifier
            .focusRequester(focusRequester)
            .onFocusChanged {
                if (it.isFocused) {
                    onFocused()
                    onCursorChanged(fieldValue.selection.start)
                }
            },
        textStyle = TextStyle(
            color = ink,
            fontFamily = fontFamily(fontChoice),
            fontSize = (16.2f * uiScale).sp,
            lineHeight = (24.0f * uiScale).sp
        ),
        keyboardOptions = KeyboardOptions(
            capitalization = KeyboardCapitalization.Sentences,
            keyboardType = KeyboardType.Text
        ),
        cursorBrush = SolidColor(ink)
    )
}
