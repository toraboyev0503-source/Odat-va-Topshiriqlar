package com.memora.app.ui.components

import android.graphics.BitmapFactory
import android.media.MediaPlayer
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import com.memora.app.data.model.NoteBlock
import com.memora.app.prefs.AppLanguage
import java.io.File
import java.util.Locale

@Composable
fun ImageBlockView(
    block: NoteBlock.Image,
    file: File,
    editable: Boolean,
    onDelete: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val bitmap = remember(file.absolutePath, file.lastModified()) {
        runCatching { BitmapFactory.decodeFile(file.absolutePath) }.getOrNull()
    }
    if (bitmap == null) return

    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
    ) {
        Box {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = null,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio((bitmap.width.toFloat() / bitmap.height.coerceAtLeast(1)).coerceIn(0.65f, 1.8f)),
                contentScale = ContentScale.Fit
            )
            if (editable) {
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.align(Alignment.TopEnd)
                ) {
                    Icon(Icons.Rounded.DeleteOutline, contentDescription = null)
                }
            }
        }
    }
}

@Composable
fun AudioBlockView(
    block: NoteBlock.Audio,
    file: File,
    editable: Boolean,
    isRecording: Boolean = false,
    recordingElapsedMs: Long = block.durationMs,
    language: AppLanguage = AppLanguage.EN,
    onStopRecording: () -> Unit = {},
    onDelete: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var player by remember(file.absolutePath) { mutableStateOf<MediaPlayer?>(null) }
    var playing by remember(file.absolutePath) { mutableStateOf(false) }

    DisposableEffect(file.absolutePath) {
        onDispose {
            runCatching { player?.stop() }
            player?.release()
            player = null
        }
    }

    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = if (isRecording) MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.55f)
        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.42f)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(Icons.Rounded.Mic, contentDescription = null)
            Column(Modifier.weight(1f)) {
                Text(
                    when (language) {
                        AppLanguage.EN -> if (isRecording) "Recording…" else "Audio"
                        AppLanguage.RU -> if (isRecording) "Запись…" else "Аудио"
                        AppLanguage.UZ -> if (isRecording) "Yozilmoqda…" else "Audio"
                    },
                    style = MaterialTheme.typography.labelLarge
                )
                Text(
                    formatDuration(if (isRecording) recordingElapsedMs else block.durationMs),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (isRecording) {
                IconButton(onClick = onStopRecording) {
                    Icon(Icons.Rounded.Stop, contentDescription = null)
                }
            } else if (file.exists()) {
                IconButton(
                    onClick = {
                        if (playing) {
                            player?.pause()
                            playing = false
                        } else {
                            val current = player ?: runCatching {
                                MediaPlayer().apply {
                                    setDataSource(file.absolutePath)
                                    prepare()
                                    setOnCompletionListener { playing = false }
                                }
                            }.getOrNull()?.also { player = it }
                            current?.start()
                            if (current != null) playing = true
                        }
                    }
                ) {
                    Icon(if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, contentDescription = null)
                }
            }

            if (editable && !isRecording) {
                IconButton(onClick = onDelete) {
                    Icon(Icons.Rounded.DeleteOutline, contentDescription = null)
                }
            }
        }
    }
}

fun formatDuration(durationMs: Long): String {
    val totalSeconds = (durationMs.coerceAtLeast(0L) / 1000L)
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return String.format(Locale.US, "%02d:%02d", minutes, seconds)
}
