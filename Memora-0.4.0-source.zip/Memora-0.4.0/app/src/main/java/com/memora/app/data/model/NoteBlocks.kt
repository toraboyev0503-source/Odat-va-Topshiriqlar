package com.memora.app.data.model

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

sealed interface NoteBlock {
    val id: String

    data class Text(
        override val id: String = UUID.randomUUID().toString(),
        val text: String = ""
    ) : NoteBlock

    data class Image(
        override val id: String = UUID.randomUUID().toString(),
        val relativePath: String,
        val mimeType: String = "image/jpeg"
    ) : NoteBlock

    data class Audio(
        override val id: String = UUID.randomUUID().toString(),
        val relativePath: String,
        val mimeType: String = "audio/mp4",
        val durationMs: Long = 0L
    ) : NoteBlock
}

object NoteBlocksCodec {
    fun decode(json: String?, legacyPlainText: String = ""): List<NoteBlock> {
        if (json.isNullOrBlank()) return legacy(legacyPlainText)
        return runCatching {
            val array = JSONArray(json)
            val result = buildList {
                for (index in 0 until array.length()) {
                    val obj = array.optJSONObject(index) ?: continue
                    val id = obj.optString("id").ifBlank { UUID.randomUUID().toString() }
                    when (obj.optString("type")) {
                        "text" -> add(NoteBlock.Text(id = id, text = obj.optString("text", "")))
                        "image" -> {
                            val path = obj.optString("path", "")
                            if (path.isNotBlank()) {
                                add(
                                    NoteBlock.Image(
                                        id = id,
                                        relativePath = path,
                                        mimeType = obj.optString("mime", "image/jpeg")
                                    )
                                )
                            }
                        }
                        "audio" -> {
                            val path = obj.optString("path", "")
                            if (path.isNotBlank()) {
                                add(
                                    NoteBlock.Audio(
                                        id = id,
                                        relativePath = path,
                                        mimeType = obj.optString("mime", "audio/mp4"),
                                        durationMs = obj.optLong("durationMs", 0L)
                                    )
                                )
                            }
                        }
                    }
                }
            }
            normalize(result, legacyPlainText)
        }.getOrElse { legacy(legacyPlainText) }
    }

    fun encode(blocks: List<NoteBlock>): String = JSONArray().apply {
        normalize(blocks).forEach { block ->
            put(
                JSONObject().apply {
                    put("id", block.id)
                    when (block) {
                        is NoteBlock.Text -> {
                            put("type", "text")
                            put("text", block.text)
                        }
                        is NoteBlock.Image -> {
                            put("type", "image")
                            put("path", block.relativePath)
                            put("mime", block.mimeType)
                        }
                        is NoteBlock.Audio -> {
                            put("type", "audio")
                            put("path", block.relativePath)
                            put("mime", block.mimeType)
                            put("durationMs", block.durationMs)
                        }
                    }
                }
            )
        }
    }.toString()

    fun plainText(blocks: List<NoteBlock>): String =
        normalize(blocks)
            .filterIsInstance<NoteBlock.Text>()
            .map { it.text.trimEnd() }
            .filter { it.isNotBlank() }
            .joinToString("\n\n")

    fun hasImages(blocks: List<NoteBlock>): Boolean = blocks.any { it is NoteBlock.Image }
    fun hasAudio(blocks: List<NoteBlock>): Boolean = blocks.any { it is NoteBlock.Audio }
    fun audioDuration(blocks: List<NoteBlock>): Long = blocks.filterIsInstance<NoteBlock.Audio>().sumOf { it.durationMs }

    fun normalize(blocks: List<NoteBlock>, fallbackPlain: String = ""): List<NoteBlock> {
        if (blocks.isEmpty()) return legacy(fallbackPlain)
        val cleaned = blocks.toMutableList()
        if (cleaned.none { it is NoteBlock.Text }) {
            cleaned.add(0, NoteBlock.Text(text = fallbackPlain))
        }
        return cleaned
    }

    fun legacy(plainText: String): List<NoteBlock> =
        listOf(NoteBlock.Text(text = plainText))

    fun updateText(blocks: List<NoteBlock>, id: String, text: String): List<NoteBlock> =
        blocks.map { block ->
            if (block is NoteBlock.Text && block.id == id) block.copy(text = text) else block
        }

    /** Insert media exactly at the current caret position and keep text editable on both sides. */
    fun insertAtCursor(
        blocks: List<NoteBlock>,
        activeTextId: String?,
        cursor: Int,
        media: NoteBlock
    ): Pair<List<NoteBlock>, String> {
        val mutable = normalize(blocks).toMutableList()
        val activeIndex = mutable.indexOfFirst { it is NoteBlock.Text && it.id == activeTextId }
            .takeIf { it >= 0 }
            ?: mutable.indexOfLast { it is NoteBlock.Text }.takeIf { it >= 0 }
            ?: 0
        val active = mutable.getOrNull(activeIndex) as? NoteBlock.Text ?: NoteBlock.Text()
        val split = cursor.coerceIn(0, active.text.length)
        val before = active.text.substring(0, split)
        val after = active.text.substring(split)
        mutable[activeIndex] = active.copy(text = before)
        val nextText = NoteBlock.Text(text = after)
        mutable.add((activeIndex + 1).coerceAtMost(mutable.size), media)
        mutable.add((activeIndex + 2).coerceAtMost(mutable.size), nextText)
        return mutable to nextText.id
    }

    fun remove(blocks: List<NoteBlock>, blockId: String): List<NoteBlock> {
        val result = blocks.filterNot { it.id == blockId }.toMutableList()
        if (result.isEmpty()) return listOf(NoteBlock.Text())

        // Merge adjacent text blocks after removing media so the editor remains simple.
        var index = 0
        while (index < result.lastIndex) {
            val current = result[index]
            val next = result[index + 1]
            if (current is NoteBlock.Text && next is NoteBlock.Text) {
                val merged = when {
                    current.text.isBlank() -> next.text
                    next.text.isBlank() -> current.text
                    else -> current.text.trimEnd() + "\n\n" + next.text.trimStart()
                }
                result[index] = current.copy(text = merged)
                result.removeAt(index + 1)
            } else {
                index++
            }
        }
        return normalize(result)
    }
}
