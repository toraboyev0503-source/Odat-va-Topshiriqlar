package com.memora.app.util

/**
 * Handles only two deliberate Memora typing conveniences:
 *  - one Enter becomes one blank line between paragraphs (two newline characters),
 *  - a sentence-ending period typed at the end gets one trailing space.
 *
 * The function refuses to transform IME composing updates or replacements. This is important for
 * SwiftKey/Gboard: autocorrect and punctuation can replace a composing range with several
 * characters at once, and those updates must never be interpreted as Enter.
 */
object EditorInputNormalizer {
    data class Result(
        val text: String,
        val cursor: Int,
        val changed: Boolean
    )

    fun normalize(
        previousText: String,
        incomingText: String,
        incomingCursor: Int,
        hasComposition: Boolean
    ): Result {
        val safeCursor = incomingCursor.coerceIn(0, incomingText.length)
        if (hasComposition || incomingText.length != previousText.length + 1 || safeCursor == 0) {
            return Result(incomingText, safeCursor, false)
        }

        val insertedIndex = safeCursor - 1
        if (insertedIndex !in incomingText.indices) {
            return Result(incomingText, safeCursor, false)
        }

        // Only a true one-character insertion is eligible. Replacements/autocorrect are ignored.
        val withoutInserted = incomingText.removeRange(insertedIndex, insertedIndex + 1)
        if (withoutInserted != previousText) {
            return Result(incomingText, safeCursor, false)
        }

        return when (incomingText[insertedIndex]) {
            '\n' -> normalizeEnter(incomingText, insertedIndex, safeCursor)
            '.' -> normalizePeriod(incomingText, insertedIndex, safeCursor)
            else -> Result(incomingText, safeCursor, false)
        }
    }

    private fun normalizeEnter(text: String, index: Int, cursor: Int): Result {
        // If the cursor is already next to a blank line, do not keep multiplying newlines.
        if (text.getOrNull(index - 1) == '\n' || text.getOrNull(index + 1) == '\n') {
            return Result(text, cursor, false)
        }
        val adjusted = text.substring(0, cursor) + "\n" + text.substring(cursor)
        return Result(adjusted, cursor + 1, true)
    }

    private fun normalizePeriod(text: String, index: Int, cursor: Int): Result {
        // Most keyboards already commit ". " together. Only help when a bare period was inserted
        // at the end of a word. Do not alter decimals or ellipses.
        if (cursor != text.length) return Result(text, cursor, false)
        val previous = text.getOrNull(index - 1) ?: return Result(text, cursor, false)
        if (previous.isWhitespace() || previous.isDigit() || previous == '.') {
            return Result(text, cursor, false)
        }
        return Result(text + " ", cursor + 1, true)
    }
}
