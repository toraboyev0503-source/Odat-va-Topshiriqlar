package com.memora.app.prefs

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.memoraDataStore by preferencesDataStore("memora_preferences")

enum class AppLanguage { EN, RU, UZ }
enum class ThemeMode { LIGHT, DARK, SYSTEM }
enum class PaletteChoice { PAPER, IVORY, MIST, SAGE, SLATE }
enum class FontChoice { SANS, SERIF, MONO, CURSIVE }
enum class LockInterval { IMMEDIATELY, ONE_MINUTE, FIVE_MINUTES, FIFTEEN_MINUTES }

data class UserSettings(
    val language: AppLanguage = AppLanguage.EN,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val palette: PaletteChoice = PaletteChoice.PAPER,
    val uiFont: FontChoice = FontChoice.SANS,
    val writingFont: FontChoice = FontChoice.SERIF,
    val uiScale: Float = 1.0f,
    val lockEnabled: Boolean = true,
    val lockInterval: LockInterval = LockInterval.IMMEDIATELY
)

class UserPreferences(private val context: Context) {
    private object Keys {
        val language = stringPreferencesKey("language")
        val themeMode = stringPreferencesKey("theme_mode")
        val palette = stringPreferencesKey("palette")
        val uiFont = stringPreferencesKey("ui_font")
        val writingFont = stringPreferencesKey("writing_font")
        val uiScale = floatPreferencesKey("ui_scale")
        val lockEnabled = booleanPreferencesKey("lock_enabled")
        val lockInterval = stringPreferencesKey("lock_interval")
    }

    val settings: Flow<UserSettings> = context.memoraDataStore.data.map { p ->
        UserSettings(
            language = p.enumOr(Keys.language, AppLanguage.EN),
            themeMode = p.enumOr(Keys.themeMode, ThemeMode.SYSTEM),
            palette = p.enumOr(Keys.palette, PaletteChoice.PAPER),
            uiFont = p.enumOr(Keys.uiFont, FontChoice.SANS),
            writingFont = p.enumOr(Keys.writingFont, FontChoice.SERIF),
            uiScale = (p[Keys.uiScale] ?: 1.0f).coerceIn(0.8f, 1.2f),
            lockEnabled = p[Keys.lockEnabled] ?: true,
            lockInterval = p.enumOr(Keys.lockInterval, LockInterval.IMMEDIATELY)
        )
    }

    suspend fun setLanguage(value: AppLanguage) = edit(Keys.language, value.name)
    suspend fun setThemeMode(value: ThemeMode) = edit(Keys.themeMode, value.name)
    suspend fun setPalette(value: PaletteChoice) = edit(Keys.palette, value.name)
    suspend fun setUiFont(value: FontChoice) = edit(Keys.uiFont, value.name)
    suspend fun setWritingFont(value: FontChoice) = edit(Keys.writingFont, value.name)
    suspend fun setUiScale(value: Float) {
        context.memoraDataStore.edit { it[Keys.uiScale] = value.coerceIn(0.8f, 1.2f) }
    }
    suspend fun setLockEnabled(value: Boolean) {
        context.memoraDataStore.edit { it[Keys.lockEnabled] = value }
    }
    suspend fun setLockInterval(value: LockInterval) = edit(Keys.lockInterval, value.name)

    private suspend fun edit(key: Preferences.Key<String>, value: String) {
        context.memoraDataStore.edit { it[key] = value }
    }

    private inline fun <reified E : Enum<E>> Preferences.enumOr(
        key: Preferences.Key<String>,
        default: E
    ): E {
        val raw = this[key] ?: return default
        return enumValues<E>().firstOrNull { it.name == raw } ?: default
    }
}
