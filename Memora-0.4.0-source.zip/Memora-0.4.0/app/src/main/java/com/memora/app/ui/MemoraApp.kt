package com.memora.app.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Surface
import androidx.compose.material3.rememberDrawerState
import androidx.compose.material3.DrawerValue
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.Density
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.graphics.luminance
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.memora.app.data.local.NoteType
import com.memora.app.data.local.ReminderEntity
import com.memora.app.data.repository.MemoraRepository
import com.memora.app.export.ExportRequest
import com.memora.app.notifications.AlarmScheduler
import com.memora.app.prefs.ThemeMode
import com.memora.app.prefs.UserPreferences
import com.memora.app.prefs.UserSettings
import com.memora.app.ui.components.DrawerContent
import com.memora.app.ui.components.ExportDialog
import com.memora.app.ui.screens.EditorScreen
import com.memora.app.ui.screens.HomeScreen
import com.memora.app.ui.screens.LanguageScreen
import com.memora.app.ui.screens.NotesScreen
import com.memora.app.ui.screens.ReaderScreen
import com.memora.app.ui.screens.RemindersScreen
import com.memora.app.ui.screens.SearchScreen
import com.memora.app.ui.screens.SecurityScreen
import com.memora.app.ui.screens.StatisticsScreen
import com.memora.app.ui.screens.StatsSnapshot
import com.memora.app.ui.screens.ThemeScreen
import com.memora.app.ui.screens.TitlesScreen
import com.memora.app.util.TimeUtils
import kotlinx.coroutines.launch

private object Routes {
    const val HOME = "home"
    const val NOTES = "notes/{type}"
    const val EDITOR = "editor/{type}/{id}"
    const val READER = "reader/{id}"
    const val SEARCH = "search/{type}"
    const val TITLES = "titles"
    const val REMINDERS = "reminders"
    const val STATS = "statistics"
    const val LANGUAGE = "language"
    const val THEME = "theme"
    const val SECURITY = "security"

    fun notes(type: NoteType) = "notes/${type.name}"
    fun editor(type: NoteType, id: String?) = "editor/${type.name}/${id ?: "new"}"
    fun reader(id: String) = "reader/$id"
    fun search(type: NoteType) = "search/${type.name}"
}

@Composable
fun MemoraApp(
    repository: MemoraRepository,
    preferences: UserPreferences,
    settings: UserSettings,
    pendingEditorType: String?,
    onPendingEditorConsumed: () -> Unit,
    onExport: (ExportRequest) -> Unit,
    onImport: () -> Unit,
    onRequestNotifications: () -> Unit,
    onRequestExactTiming: () -> Unit
) {
    val navController = rememberNavController()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var showExportDialog by remember { mutableStateOf(false) }

    val shortNotes by repository.observeNotes(NoteType.SHORT).collectAsStateWithLifecycle(emptyList())
    val longNotes by repository.observeNotes(NoteType.LONG).collectAsStateWithLifecycle(emptyList())
    val titles by repository.observeTitles().collectAsStateWithLifecycle(emptyList())
    val reminders by repository.observeReminders().collectAsStateWithLifecycle(emptyList())

    val allShort by repository.observeCount(NoteType.SHORT).collectAsStateWithLifecycle(0)
    val allLong by repository.observeCount(NoteType.LONG).collectAsStateWithLifecycle(0)

    val monthRange = remember { TimeUtils.currentMonthRange() }
    val yearRange = remember { TimeUtils.currentYearRange() }
    val monthShort by repository.observeCountBetween(NoteType.SHORT, monthRange.start!!, monthRange.end!!)
        .collectAsStateWithLifecycle(0)
    val monthLong by repository.observeCountBetween(NoteType.LONG, monthRange.start!!, monthRange.end!!)
        .collectAsStateWithLifecycle(0)
    val yearShort by repository.observeCountBetween(NoteType.SHORT, yearRange.start!!, yearRange.end!!)
        .collectAsStateWithLifecycle(0)
    val yearLong by repository.observeCountBetween(NoteType.LONG, yearRange.start!!, yearRange.end!!)
        .collectAsStateWithLifecycle(0)

    val stats = StatsSnapshot(
        allShort = allShort,
        allLong = allLong,
        monthShort = monthShort,
        monthLong = monthLong,
        yearShort = yearShort,
        yearLong = yearLong
    )
    val isDark = MaterialTheme.colorScheme.background.luminance() < 0.5f

    LaunchedEffect(Unit) {
        onRequestNotifications()
    }

    LaunchedEffect(pendingEditorType) {
        val raw = pendingEditorType ?: return@LaunchedEffect
        val type = runCatching { NoteType.valueOf(raw) }.getOrNull() ?: return@LaunchedEffect
        navController.navigate(Routes.editor(type, null)) {
            launchSingleTop = true
        }
        onPendingEditorConsumed()
    }

    val deviceDensity = LocalDensity.current
    val compactDensity = Density(
        density = deviceDensity.density * 0.80f * settings.uiScale,
        fontScale = deviceDensity.fontScale
    )

    CompositionLocalProvider(LocalDensity provides compactDensity) {
        ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = drawerState.isOpen,
        drawerContent = {
            DrawerContent(
                language = settings.language,
                isDark = isDark,
                onExport = {
                    showExportDialog = true
                    scope.launch { drawerState.close() }
                },
                onImport = {
                    scope.launch { drawerState.close() }
                    onImport()
                },
                onReminders = {
                    scope.launch { drawerState.close() }
                    navController.navigate(Routes.REMINDERS)
                },
                onTitles = {
                    scope.launch { drawerState.close() }
                    navController.navigate(Routes.TITLES)
                },
                onLanguage = {
                    scope.launch { drawerState.close() }
                    navController.navigate(Routes.LANGUAGE)
                },
                onStatistics = {
                    scope.launch { drawerState.close() }
                    navController.navigate(Routes.STATS)
                },
                onTheme = {
                    scope.launch { drawerState.close() }
                    navController.navigate(Routes.THEME)
                },
                onSecurity = {
                    scope.launch { drawerState.close() }
                    navController.navigate(Routes.SECURITY)
                },
                onToggleDark = {
                    scope.launch {
                        preferences.setThemeMode(if (isDark) ThemeMode.LIGHT else ThemeMode.DARK)
                        drawerState.close()
                    }
                }
            )
        }
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .windowInsetsPadding(WindowInsets.safeDrawing)
            ) {
                NavHost(
                    navController = navController,
                    startDestination = Routes.HOME,
                    modifier = Modifier.fillMaxSize()
                ) {
            composable(Routes.HOME) {
                HomeScreen(
                    language = settings.language,
                    shortCount = allShort,
                    longCount = allLong,
                    onMenu = { scope.launch { drawerState.open() } },
                    onShort = { navController.navigate(Routes.notes(NoteType.SHORT)) },
                    onLong = { navController.navigate(Routes.notes(NoteType.LONG)) }
                )
            }

            composable(
                route = Routes.NOTES,
                arguments = listOf(navArgument("type") { type = NavType.StringType })
            ) { entry ->
                val type = NoteType.valueOf(entry.arguments?.getString("type") ?: NoteType.SHORT.name)
                val notes = if (type == NoteType.SHORT) shortNotes else longNotes
                NotesScreen(
                    type = type,
                    notes = notes,
                    language = settings.language,
                    onBack = { navController.popBackStack() },
                    onNew = { navController.navigate(Routes.editor(type, null)) },
                    onOpen = { navController.navigate(Routes.reader(it)) },
                    onSearch = { navController.navigate(Routes.search(type)) },
                    onDelete = { ids -> scope.launch { repository.deleteNotes(ids) } }
                )
            }

            composable(
                route = Routes.EDITOR,
                arguments = listOf(
                    navArgument("type") { type = NavType.StringType },
                    navArgument("id") { type = NavType.StringType }
                )
            ) { entry ->
                val type = NoteType.valueOf(entry.arguments?.getString("type") ?: NoteType.SHORT.name)
                val idArg = entry.arguments?.getString("id")
                val compact = LocalDensity.current
                CompositionLocalProvider(
                    LocalDensity provides Density(
                        density = compact.density * 1.125f,
                        fontScale = compact.fontScale
                    )
                ) {
                    EditorScreen(
                        noteId = idArg?.takeUnless { it == "new" },
                        type = type,
                        repository = repository,
                        savedTitles = titles,
                        language = settings.language,
                        writingFont = settings.writingFont,
                        uiScale = settings.uiScale,
                        onBack = { navController.popBackStack() }
                    )
                }
            }

            composable(
                route = Routes.READER,
                arguments = listOf(navArgument("id") { type = NavType.StringType })
            ) { entry ->
                val id = entry.arguments?.getString("id").orEmpty()
                val note by repository.observeNote(id).collectAsStateWithLifecycle(initialValue = null)
                ReaderScreen(
                    note = note,
                    language = settings.language,
                    writingFont = settings.writingFont,
                    onBack = { navController.popBackStack() },
                    onEdit = {
                        note?.let {
                            navController.navigate(
                                Routes.editor(NoteType.valueOf(it.type), it.id)
                            )
                        }
                    }
                )
            }

            composable(
                route = Routes.SEARCH,
                arguments = listOf(navArgument("type") { type = NavType.StringType })
            ) { entry ->
                val type = NoteType.valueOf(entry.arguments?.getString("type") ?: NoteType.SHORT.name)
                SearchScreen(
                    type = type,
                    notes = if (type == NoteType.SHORT) shortNotes else longNotes,
                    titles = titles,
                    language = settings.language,
                    onBack = { navController.popBackStack() },
                    onOpen = { navController.navigate(Routes.reader(it)) }
                )
            }

            composable(Routes.TITLES) {
                TitlesScreen(
                    titles = titles,
                    language = settings.language,
                    onBack = { navController.popBackStack() },
                    onAdd = { value -> scope.launch { repository.addTitle(value) } },
                    onDelete = { title -> scope.launch { repository.deleteTitle(title) } }
                )
            }

            composable(Routes.REMINDERS) {
                val context = androidx.compose.ui.platform.LocalContext.current
                RemindersScreen(
                    reminders = reminders,
                    language = settings.language,
                    exactTimingAvailable = AlarmScheduler(context).canScheduleExact(),
                    onBack = { navController.popBackStack() },
                    onRequestNotifications = onRequestNotifications,
                    onRequestExactTiming = onRequestExactTiming,
                    onAdd = { hour, minute ->
                        scope.launch {
                            val id = repository.addReminder(hour, minute)
                            if (id != -1L) {
                                AlarmScheduler(context).scheduleReminder(
                                    ReminderEntity(id = id, hour = hour, minute = minute, enabled = true)
                                )
                            }
                        }
                    },
                    onToggle = { reminder, enabled ->
                        scope.launch {
                            val changed = reminder.copy(enabled = enabled)
                            repository.updateReminder(changed)
                            if (enabled) AlarmScheduler(context).scheduleReminder(changed)
                            else AlarmScheduler(context).cancelReminder(changed.id)
                        }
                    },
                    onDelete = { reminder ->
                        scope.launch {
                            AlarmScheduler(context).cancelReminder(reminder.id)
                            repository.deleteReminder(reminder)
                        }
                    }
                )
            }

            composable(Routes.STATS) {
                StatisticsScreen(
                    stats = stats,
                    language = settings.language,
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Routes.LANGUAGE) {
                LanguageScreen(
                    current = settings.language,
                    onBack = { navController.popBackStack() },
                    onSelect = { scope.launch { preferences.setLanguage(it) } }
                )
            }

            composable(Routes.THEME) {
                ThemeScreen(
                    settings = settings,
                    onBack = { navController.popBackStack() },
                    onPalette = { scope.launch { preferences.setPalette(it) } },
                    onUiFont = { scope.launch { preferences.setUiFont(it) } },
                    onWritingFont = { scope.launch { preferences.setWritingFont(it) } },
                    onThemeMode = { scope.launch { preferences.setThemeMode(it) } },
                    onUiScale = { scope.launch { preferences.setUiScale(it) } }
                )
            }

                composable(Routes.SECURITY) {
                    SecurityScreen(
                        settings = settings,
                        onBack = { navController.popBackStack() },
                        onEnabled = { scope.launch { preferences.setLockEnabled(it) } },
                        onInterval = { scope.launch { preferences.setLockInterval(it) } }
                    )
                }
                }
            }
        }
        }

        if (showExportDialog) {
            ExportDialog(
                language = settings.language,
                onDismiss = { showExportDialog = false },
                onExport = {
                    showExportDialog = false
                    onExport(it)
                }
            )
        }
    }
}
