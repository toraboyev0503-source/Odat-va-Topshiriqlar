# Memora 0.4.0

Memora is a local-first Android writing app for short and long daily notes. The 0.4.0 build extends the refined phone-testing version with reliable writing-reminder fallback scheduling, inline image and audio blocks in both note types, media-aware Memora backups, Word export with embedded images and preserved audio files, and two Word layouts: chronological or grouped by title.

## Technology

- Kotlin
- Jetpack Compose + Material 3
- Room database
- DataStore preferences
- Android BiometricPrompt / device credentials
- AlarmManager reminders and statistics schedules
- Local `.memora` backup/import
- Word `.docx` export
- English, Russian and Uzbek UI
- Light/Dark/System mode, five curated palettes, UI/writing font choices, and 80–120% interface scaling

Memora does not require a server or an internet connection for normal use.

## GitHub Actions — debug APK

The included `.github/workflows/main.yml` can build either:

1. an extracted Android project in the repository, or
2. a Memora source ZIP stored in the repository root.

If you keep the project as one source ZIP, the workflow file itself must still exist at:

`.github/workflows/main.yml`

GitHub cannot discover a workflow that exists only inside another ZIP.

The debug workflow:

- checks out the repository;
- locates/unpacks the source;
- installs JDK 17;
- installs Gradle 8.13;
- installs Android SDK 36;
- runs `testDebugUnitTest`;
- runs `lintDebug`;
- runs `assembleDebug`;
- uploads `app-debug.apk` as an artifact.

Debug application ID: `com.memora.app.debug`

Release application ID: `com.memora.app`

## Local / Android Studio build

The project includes `gradlew`, `gradlew.bat`, and a small bootstrap wrapper JAR. The bootstrap downloads the verified Gradle 8.13 binary distribution on first use and checks its official SHA-256 checksum.

Examples:

```bash
./gradlew testDebugUnitTest
./gradlew lintDebug
./gradlew assembleDebug
```

## Signed release

`.github/workflows/release.yml` is intentionally manual. It expects these GitHub Secrets:

- `MEMORA_KEYSTORE_BASE64`
- `MEMORA_KEYSTORE_PASSWORD`
- `MEMORA_KEY_ALIAS`
- `MEMORA_KEY_PASSWORD`

Keep the original release keystore permanently. Future Memora updates must use the same signing key.

## Version

- `versionName`: `0.4.0`
- `versionCode`: `6`

## Privacy and backup

Notes are stored locally in Room. Android automatic cloud/device backup is disabled for Memora's private data. Use Memora's own backup export when moving data to another phone.

A combined Memora backup preserves note type, title, text/media blocks, images, audio, creation/edit timestamps, saved titles, reminders, language, theme, palette, fonts and app-lock preference. During import, a note is skipped as a duplicate only when its title, body and creation timestamp all match an existing note.
