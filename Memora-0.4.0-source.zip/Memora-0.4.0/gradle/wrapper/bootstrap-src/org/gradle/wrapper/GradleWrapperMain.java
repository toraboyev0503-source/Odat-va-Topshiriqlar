package org.gradle.wrapper;

import java.io.*;
import java.net.URI;
import java.net.http.*;
import java.nio.file.*;
import java.security.MessageDigest;
import java.time.Duration;
import java.util.*;
import java.util.zip.*;

public final class GradleWrapperMain {
    public static void main(String[] args) throws Exception {
        Path projectDir = resolveProjectDir();
        Path propertiesPath = projectDir.resolve("gradle/wrapper/gradle-wrapper.properties");
        if (!Files.isRegularFile(propertiesPath)) {
            fail("Missing " + propertiesPath);
        }

        Properties props = new Properties();
        try (InputStream in = Files.newInputStream(propertiesPath)) {
            props.load(in);
        }

        String distributionUrl = require(props, "distributionUrl");
        String expectedSha = props.getProperty("distributionSha256Sum", "").trim().toLowerCase(Locale.ROOT);
        String fileName = distributionUrl.substring(distributionUrl.lastIndexOf('/') + 1);
        String version = versionFromFileName(fileName);

        Path gradleUserHome = resolveGradleUserHome();
        Path installBase = gradleUserHome.resolve("memora-wrapper");
        Path installDir = installBase.resolve("gradle-" + version);
        Path executable = installDir.resolve(isWindows() ? "bin/gradle.bat" : "bin/gradle");

        if (!Files.isRegularFile(executable)) {
            Files.createDirectories(installBase);
            Path zip = installBase.resolve(fileName);
            downloadIfNeeded(URI.create(distributionUrl), zip, expectedSha);
            install(zip, installBase, installDir, version);
        }

        if (!isWindows()) executable.toFile().setExecutable(true, false);

        List<String> command = new ArrayList<>();
        if (isWindows()) {
            command.add("cmd.exe");
            command.add("/d");
            command.add("/c");
        }
        command.add(executable.toAbsolutePath().toString());
        command.addAll(Arrays.asList(args));

        Process process = new ProcessBuilder(command)
            .directory(projectDir.toFile())
            .inheritIO()
            .start();
        System.exit(process.waitFor());
    }

    private static Path resolveProjectDir() {
        String explicit = System.getProperty("memora.projectDir");
        if (explicit != null && !explicit.isBlank()) return Paths.get(explicit).toAbsolutePath().normalize();
        Path current = Paths.get(System.getProperty("user.dir")).toAbsolutePath().normalize();
        for (Path p = current; p != null; p = p.getParent()) {
            if (Files.isRegularFile(p.resolve("gradle/wrapper/gradle-wrapper.properties"))) return p;
        }
        return current;
    }

    private static Path resolveGradleUserHome() {
        String env = System.getenv("GRADLE_USER_HOME");
        if (env != null && !env.isBlank()) return Paths.get(env).toAbsolutePath().normalize();
        return Paths.get(System.getProperty("user.home"), ".gradle").toAbsolutePath().normalize();
    }

    private static String require(Properties props, String key) {
        String value = props.getProperty(key);
        if (value == null || value.isBlank()) fail("Missing property: " + key);
        return value.trim();
    }

    private static String versionFromFileName(String fileName) {
        if (!fileName.startsWith("gradle-") || !fileName.endsWith("-bin.zip")) {
            fail("Unsupported Gradle distribution name: " + fileName);
        }
        return fileName.substring("gradle-".length(), fileName.length() - "-bin.zip".length());
    }

    private static void downloadIfNeeded(URI uri, Path target, String expectedSha) throws Exception {
        if (Files.isRegularFile(target) && verify(target, expectedSha)) return;

        Path temp = target.resolveSibling(target.getFileName() + ".part");
        Files.deleteIfExists(temp);
        System.out.println("Downloading " + uri);

        HttpClient client = HttpClient.newBuilder()
            .followRedirects(HttpClient.Redirect.ALWAYS)
            .connectTimeout(Duration.ofSeconds(30))
            .build();
        HttpRequest request = HttpRequest.newBuilder(uri)
            .timeout(Duration.ofMinutes(5))
            .header("User-Agent", "Memora-Gradle-Bootstrap/1.0")
            .GET()
            .build();
        HttpResponse<Path> response = client.send(request, HttpResponse.BodyHandlers.ofFile(temp));
        if (response.statusCode() < 200 || response.statusCode() >= 300) {
            Files.deleteIfExists(temp);
            fail("Gradle download failed with HTTP " + response.statusCode());
        }
        if (!verify(temp, expectedSha)) {
            Files.deleteIfExists(temp);
            fail("Gradle distribution checksum did not match.");
        }
        Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING);
    }

    private static boolean verify(Path file, String expectedSha) throws Exception {
        if (!Files.isRegularFile(file)) return false;
        if (expectedSha == null || expectedSha.isBlank()) return true;
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        try (InputStream in = Files.newInputStream(file)) {
            byte[] buffer = new byte[64 * 1024];
            int n;
            while ((n = in.read(buffer)) >= 0) {
                if (n > 0) md.update(buffer, 0, n);
            }
        }
        StringBuilder actual = new StringBuilder();
        for (byte b : md.digest()) actual.append(String.format("%02x", b));
        return expectedSha.equals(actual.toString());
    }

    private static void install(Path zip, Path installBase, Path installDir, String version) throws Exception {
        Path tempDir = installBase.resolve(".gradle-" + version + "-installing");
        deleteRecursively(tempDir);
        Files.createDirectories(tempDir);

        try (ZipInputStream zin = new ZipInputStream(new BufferedInputStream(Files.newInputStream(zip)))) {
            ZipEntry entry;
            while ((entry = zin.getNextEntry()) != null) {
                Path out = tempDir.resolve(entry.getName()).normalize();
                if (!out.startsWith(tempDir)) fail("Unsafe ZIP entry: " + entry.getName());
                if (entry.isDirectory()) {
                    Files.createDirectories(out);
                } else {
                    Files.createDirectories(out.getParent());
                    Files.copy(zin, out, StandardCopyOption.REPLACE_EXISTING);
                }
                zin.closeEntry();
            }
        }

        Path extracted = tempDir.resolve("gradle-" + version);
        if (!Files.isDirectory(extracted)) fail("Gradle ZIP did not contain gradle-" + version);
        deleteRecursively(installDir);
        try {
            Files.move(extracted, installDir, StandardCopyOption.ATOMIC_MOVE);
        } catch (AtomicMoveNotSupportedException ex) {
            Files.move(extracted, installDir, StandardCopyOption.REPLACE_EXISTING);
        }
        deleteRecursively(tempDir);
    }

    private static void deleteRecursively(Path root) throws IOException {
        if (!Files.exists(root)) return;
        try (var stream = Files.walk(root)) {
            stream.sorted(Comparator.reverseOrder()).forEach(path -> {
                try { Files.deleteIfExists(path); } catch (IOException e) { throw new UncheckedIOException(e); }
            });
        } catch (UncheckedIOException e) {
            throw e.getCause();
        }
    }

    private static boolean isWindows() {
        return System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");
    }

    private static void fail(String message) {
        throw new IllegalStateException(message);
    }
}
