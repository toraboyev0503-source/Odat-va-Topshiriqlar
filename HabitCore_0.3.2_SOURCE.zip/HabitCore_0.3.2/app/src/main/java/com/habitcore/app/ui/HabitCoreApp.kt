package com.habitcore.app.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue

private enum class Screen {
    HOME,
    HABITS,
    CREATE_HABIT,
    HABIT_MONITORING,
    HABIT_ARCHIVE,
    TASKS,
    SCHEDULED_TASKS,
    TASK_ARCHIVE,
    TASK_MONITORING,
    THEME,
    LANGUAGE,
    NOTIFICATIONS,
    SETTINGS
}

@Composable
fun HabitCoreApp(vm: AppViewModel) {
    val prefs by vm.prefs.collectAsState()
    var screen by remember { mutableStateOf(Screen.HOME) }
    var sharedReturn by remember { mutableStateOf(Screen.HABITS) }

    fun openShared(target: Screen, from: Screen) {
        sharedReturn = from
        screen = target
    }

    HabitCoreTheme(prefs.theme, prefs.mode) {
        when (screen) {
            Screen.HOME -> HomeScreen(
                lang = prefs.language,
                onHabits = { screen = Screen.HABITS },
                onTasks = { screen = Screen.TASKS }
            )

            Screen.HABITS -> HabitsScreen(
                vm = vm,
                onBack = { screen = Screen.HOME },
                onCreate = { screen = Screen.CREATE_HABIT },
                onMonitoring = { screen = Screen.HABIT_MONITORING },
                onTheme = { openShared(Screen.THEME, Screen.HABITS) },
                onLanguage = { openShared(Screen.LANGUAGE, Screen.HABITS) },
                onNotifications = { openShared(Screen.NOTIFICATIONS, Screen.HABITS) },
                onArchive = { screen = Screen.HABIT_ARCHIVE },
                onSettings = { openShared(Screen.SETTINGS, Screen.HABITS) }
            )

            Screen.CREATE_HABIT ->
                CreateHabitScreen(vm = vm, onBack = { screen = Screen.HABITS })

            Screen.HABIT_MONITORING ->
                MonitoringScreen(vm = vm, onBack = { screen = Screen.HABITS })

            Screen.HABIT_ARCHIVE ->
                ArchiveScreen(vm = vm, onBack = { screen = Screen.HABITS })

            Screen.TASKS -> TasksScreen(
                vm = vm,
                onBack = { screen = Screen.HOME },
                onScheduled = { screen = Screen.SCHEDULED_TASKS },
                onMonitoring = { screen = Screen.TASK_MONITORING },
                onArchive = { screen = Screen.TASK_ARCHIVE },
                onTheme = { openShared(Screen.THEME, Screen.TASKS) },
                onLanguage = { openShared(Screen.LANGUAGE, Screen.TASKS) },
                onNotifications = { openShared(Screen.NOTIFICATIONS, Screen.TASKS) },
                onSettings = { openShared(Screen.SETTINGS, Screen.TASKS) }
            )

            Screen.SCHEDULED_TASKS ->
                ScheduledTasksScreen(vm = vm, onBack = { screen = Screen.TASKS })

            Screen.TASK_ARCHIVE ->
                TaskArchiveScreen(
                    vm = vm,
                    onBack = { screen = Screen.TASKS },
                    onMonitoring = { screen = Screen.TASK_MONITORING }
                )

            Screen.TASK_MONITORING ->
                TaskMonitoringScreen(vm = vm, onBack = { screen = Screen.TASKS })

            Screen.THEME ->
                ThemeScreen(vm = vm, onBack = { screen = sharedReturn })

            Screen.LANGUAGE ->
                LanguageScreen(vm = vm, onBack = { screen = sharedReturn })

            Screen.NOTIFICATIONS ->
                NotificationsScreen(vm = vm, onBack = { screen = sharedReturn })

            Screen.SETTINGS ->
                SettingsScreen(vm = vm, onBack = { screen = sharedReturn })
        }
    }
}
