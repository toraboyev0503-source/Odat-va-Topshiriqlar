package com.habitcore.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val text: String,
    val priority: Int = 3,
    val scheduledEpochDay: Long,
    val createdAtMillis: Long = System.currentTimeMillis(),
    val completed: Boolean = false,
    val completedAtMillis: Long? = null,
    val colorSlot: Int = 0
)
