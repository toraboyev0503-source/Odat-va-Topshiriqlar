@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.habitcore.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.habitcore.app.data.HabitEntity
import com.habitcore.app.domain.FrequencyType
import com.habitcore.app.domain.HabitType
import java.time.LocalDate

@Composable
fun CreateHabitScreen(vm: AppViewModel, onBack: () -> Unit) {
    val prefs by vm.prefs.collectAsState()
    val lang = prefs.language
    var type by remember { mutableStateOf(HabitType.YES_NO) }
    var name by remember { mutableStateOf("") }
    var question by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var unit by remember { mutableStateOf("") }
    var target by remember { mutableStateOf("1") }
    var frequency by remember { mutableStateOf(FrequencyType.DAILY) }
    var frequencyValue by remember { mutableStateOf("1") }
    var windowDays by remember { mutableStateOf("7") }
    var colorIndex by remember { mutableIntStateOf(0) }
    var frequencyMenu by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(tr(lang, "createHabit")) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Outlined.ArrowBack, null) } },
                actions = {
                    TextButton(
                        enabled = name.isNotBlank(),
                        onClick = {
                            val targetValue = target.toDoubleOrNull()?.coerceAtLeast(0.0001) ?: 1.0
                            vm.addHabit(
                                HabitEntity(
                                    name = name.trim(),
                                    type = type.name,
                                    colorArgb = habitColor(colorIndex),
                                    question = question.trim(),
                                    notes = notes.trim(),
                                    unit = unit.trim().ifBlank { null },
                                    target = if (type == HabitType.MEASURABLE) targetValue else 1.0,
                                    frequencyType = frequency.name,
                                    frequencyValue = frequencyValue.toIntOrNull()?.coerceAtLeast(1) ?: 1,
                                    frequencyWindowDays = windowDays.toIntOrNull()?.coerceAtLeast(1) ?: 7,
                                    createdEpochDay = LocalDate.now().toEpochDay()
                                )
                            )
                            onBack()
                        }
                    ) { Text(tr(lang, "save")) }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                TypeCard(
                    modifier = Modifier.weight(1f),
                    title = tr(lang, "yesNo"),
                    selected = type == HabitType.YES_NO
                ) { type = HabitType.YES_NO }
                TypeCard(
                    modifier = Modifier.weight(1f),
                    title = tr(lang, "measurable"),
                    selected = type == HabitType.MEASURABLE
                ) { type = HabitType.MEASURABLE }
            }

            OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text(tr(lang, "name")) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(value = question, onValueChange = { question = it }, label = { Text(tr(lang, "question")) }, modifier = Modifier.fillMaxWidth())

            Text(tr(lang, "frequency"), style = MaterialTheme.typography.labelLarge)
            Box {
                Button(onClick = { frequencyMenu = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(frequencyLabel(lang, frequency))
                }
                DropdownMenu(expanded = frequencyMenu, onDismissRequest = { frequencyMenu = false }) {
                    FrequencyType.entries.forEach { item ->
                        DropdownMenuItem(
                            text = { Text(frequencyLabel(lang, item)) },
                            onClick = { frequency = item; frequencyMenu = false }
                        )
                    }
                }
            }

            if (frequency != FrequencyType.DAILY) {
                OutlinedTextField(
                    value = frequencyValue,
                    onValueChange = { if (it.all(Char::isDigit)) frequencyValue = it },
                    label = { Text(if (frequency == FrequencyType.EVERY_N_DAYS) "N" else "X") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
            if (frequency == FrequencyType.TIMES_IN_N_DAYS) {
                OutlinedTextField(
                    value = windowDays,
                    onValueChange = { if (it.all(Char::isDigit)) windowDays = it },
                    label = { Text("N") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }

            if (type == HabitType.MEASURABLE) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = target, onValueChange = { target = it }, label = { Text(tr(lang, "target")) }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(value = unit, onValueChange = { unit = it }, label = { Text(tr(lang, "unit")) }, modifier = Modifier.weight(1f), singleLine = true)
                }
            }

            Text("Color", style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                repeat(8) { i ->
                    val color = Color(habitColor(i))
                    Box(
                        modifier = Modifier.size(if (i == colorIndex) 34.dp else 30.dp)
                            .clip(CircleShape)
                            .background(color)
                            .clickable { colorIndex = i }
                    )
                }
            }

            OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text(tr(lang, "notes")) }, modifier = Modifier.fillMaxWidth(), minLines = 3)
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun TypeCard(modifier: Modifier, title: String, selected: Boolean, onClick: () -> Unit) {
    Card(
        modifier = modifier.height(72.dp).clickable(onClick = onClick),
        border = BorderStroke(1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant)
    ) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(title) }
    }
}

private fun frequencyLabel(lang: com.habitcore.app.domain.AppLanguage, type: FrequencyType): String = when (type) {
    FrequencyType.DAILY -> tr(lang, "everyDay")
    FrequencyType.EVERY_N_DAYS -> tr(lang, "everyNDays")
    FrequencyType.TIMES_PER_WEEK -> tr(lang, "timesWeek")
    FrequencyType.TIMES_PER_MONTH -> tr(lang, "timesMonth")
    FrequencyType.TIMES_IN_N_DAYS -> tr(lang, "timesNDays")
}
