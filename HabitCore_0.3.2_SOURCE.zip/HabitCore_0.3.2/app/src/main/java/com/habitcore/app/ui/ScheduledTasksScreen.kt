@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.habitcore.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.habitcore.app.data.TaskEntity
import java.time.LocalDate

@Composable
fun ScheduledTasksScreen(vm: AppViewModel, onBack: () -> Unit) {
    val prefs by vm.prefs.collectAsState()
    val tasks by vm.tasks.collectAsState()
    val today = LocalDate.now().toEpochDay()
    var editing by remember { mutableStateOf<TaskEntity?>(null) }
    var editText by remember { mutableStateOf("") }
    var nowMillis by remember { mutableLongStateOf(System.currentTimeMillis()) }

    val future = tasks
        .filter { !it.completed && it.scheduledEpochDay > today }
        .sortedWith(compareBy<TaskEntity> { it.scheduledEpochDay }.thenBy { it.priority }.thenBy { it.createdAtMillis })

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(tr(prefs.language, "scheduled")) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Outlined.ArrowBack, null) } }
            )
        }
    ) { padding ->
        if (future.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("—", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(
                Modifier.fillMaxSize().padding(padding).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(future, key = { it.id }) { task ->
                    TaskCard(
                        task = task,
                        lang = prefs.language,
                        nowMillis = nowMillis,
                        completed = false,
                        onPriority = {
                            val next = when (task.priority) { 3 -> 2; 2 -> 1; else -> 3 }
                            vm.updateTaskPriority(task.id, next)
                        },
                        onDate = { vm.rescheduleTask(task, it.toEpochDay()) },
                        onComplete = {},
                        onEdit = { editText = task.text; editing = task },
                        onDelete = { vm.deleteTask(task.id) }
                    )
                }
            }
        }
    }

    editing?.let { task ->
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text(tr(prefs.language, "edit")) },
            text = {
                OutlinedTextField(
                    value = editText,
                    onValueChange = { editText = it },
                    minLines = 2,
                    maxLines = 10
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (editText.isNotBlank()) vm.updateTaskText(task.id, editText)
                    editing = null
                }) { Text(tr(prefs.language, "save")) }
            },
            dismissButton = {
                TextButton(onClick = { editing = null }) { Text(tr(prefs.language, "cancel")) }
            }
        )
    }
}
