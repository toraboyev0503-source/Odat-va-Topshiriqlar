package com.memora.app.ui.theme

/**
 * One real paragraph is one text block. Adjacent paragraph blocks receive an additional
 * half-line gap; deliberate line breaks inside a paragraph receive no extra gap.
 */
object ParagraphMetrics {
    const val GAP_RATIO = 0.50f
    const val EDITOR_LINE_HEIGHT_SP = 24f
    const val READER_LINE_HEIGHT_SP = 28f
}
