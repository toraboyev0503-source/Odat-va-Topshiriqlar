package com.memora.app.util

/**
 * Conservative IME normalizer. Paragraph creation is handled structurally by PlainTextEditor, so
 * this class never turns Enter into blank lines. It only preserves the optional sentence-spacing
 * convenience after a true single period insertion.
 */
object EditorInputNormalizer {
    data class Result(val text: String, val cursor: Int, val changed: Boolean)

    fun normalize(
        previousText: String,
        incomingText: String,
        incomingCursor: Int,
        hasComposition: Boolean
    ): Result {
        val safeCursor = incomingCursor.coerceIn(0, incomingText.length)
        if (hasComposition || incomingText.length != previousText.length + 1 || safeCursor == 0) {
            return Result(incomingText, safeCursor, false)
        }
        val insertedIndex = safeCursor - 1
        if (insertedIndex !in incomingText.indices) return Result(incomingText, safeCursor, false)
        if (incomingText.removeRange(insertedIndex, insertedIndex + 1) != previousText) {
            return Result(incomingText, safeCursor, false)
        }
        return when (incomingText[insertedIndex]) {
            '.' -> normalizePeriod(incomingText, insertedIndex, safeCursor)
            else -> Result(incomingText, safeCursor, false)
        }
    }

    private fun normalizePeriod(text: String, index: Int, cursor: Int): Result {
        if (cursor != text.length) return Result(text, cursor, false)
        val previous = text.getOrNull(index - 1) ?: return Result(text, cursor, false)
        if (previous.isWhitespace() || previous.isDigit() || previous == '.') return Result(text, cursor, false)
        return Result(text + " ", cursor + 1, true)
    }
}
