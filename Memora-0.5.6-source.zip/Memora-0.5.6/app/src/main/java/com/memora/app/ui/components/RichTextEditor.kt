package com.memora.app.ui.components

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.ContentPaste
import androidx.compose.material.icons.rounded.SelectAll
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.Hyphens
import androidx.compose.ui.text.style.LineBreak
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memora.app.data.model.TextInlineStyle
import com.memora.app.i18n.L
import com.memora.app.i18n.S
import com.memora.app.prefs.AppLanguage
import com.memora.app.prefs.FontChoice
import com.memora.app.ui.theme.fontFamily
import com.memora.app.util.EditorInputNormalizer
import kotlinx.coroutines.delay

/**
 * One instance edits exactly one paragraph. Paragraph spacing is deliberately NOT encoded inside
 * this text field; EditorScreen owns the physical gap between adjacent paragraph blocks.
 */
@Composable
fun PlainTextEditor(
    text: String,
    styles: List<TextInlineStyle> = emptyList(),
    onValueChanged: (String, List<TextInlineStyle>, Int) -> Unit,
    onParagraphBreak: (cursor: Int, nextPrefix: String) -> Unit,
    onMergeWithPrevious: () -> Boolean,
    fontChoice: FontChoice,
    ink: Color,
    language: AppLanguage,
    uiScale: Float = 1.0f,
    onFocused: () -> Unit = {},
    onCursorChanged: (Int) -> Unit = {},
    requestFocus: Boolean = false,
    requestCursorPosition: Int? = null,
    modifier: Modifier = Modifier
) {
    val focusRequester = remember { FocusRequester() }
    val bringIntoViewRequester = remember { BringIntoViewRequester() }
    val clipboard = LocalClipboardManager.current
    val density = LocalDensity.current
    var textLayoutResult by remember { mutableStateOf<TextLayoutResult?>(null) }
    var localStyles by remember(styles) { mutableStateOf(styles.sanitize(text.length)) }
    var fieldValue by remember { mutableStateOf(TextFieldValue(text = text, selection = TextRange(text.length))) }

    LaunchedEffect(text) {
        if (text != fieldValue.text) {
            fieldValue = fieldValue.copy(
                text = text,
                selection = TextRange(fieldValue.selection.start.coerceAtMost(text.length)),
                composition = null
            )
            localStyles = styles.sanitize(text.length)
        }
    }
    LaunchedEffect(styles) { localStyles = styles.sanitize(fieldValue.text.length) }

    LaunchedEffect(requestFocus, requestCursorPosition) {
        if (requestFocus) {
            val cursor = (requestCursorPosition ?: fieldValue.text.length).coerceIn(0, fieldValue.text.length)
            fieldValue = fieldValue.copy(selection = TextRange(cursor), composition = null)
            onCursorChanged(cursor)
            focusRequester.requestFocus()
        }
    }

    LaunchedEffect(fieldValue.selection, fieldValue.text.length, textLayoutResult) {
        if (!fieldValue.selection.collapsed) return@LaunchedEffect
        val layout = textLayoutResult ?: return@LaunchedEffect
        delay(16)
        val cursor = fieldValue.selection.start.coerceIn(0, fieldValue.text.length)
        val cursorRect = layout.getCursorRect(cursor)
        val extraBottom = with(density) { 30.dp.toPx() }
        bringIntoViewRequester.bringIntoView(
            Rect(
                left = cursorRect.left,
                top = cursorRect.top,
                right = (cursorRect.right + 2f).coerceAtLeast(cursorRect.left + 2f),
                bottom = cursorRect.bottom + extraBottom
            )
        )
    }

    val selection = fieldValue.selection
    val hasSelection = !selection.collapsed && selection.min < selection.max

    androidx.compose.foundation.layout.Column(modifier) {
        if (hasSelection) {
            Surface(
                shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.74f),
                modifier = Modifier.padding(bottom = 4.dp)
            ) {
                Row(modifier = Modifier.padding(horizontal = 2.dp, vertical = 1.dp)) {
                    IconButton(onClick = {
                        clipboard.setText(AnnotatedString(fieldValue.text.substring(selection.min, selection.max)))
                    }) {
                        Icon(Icons.Rounded.ContentCopy, contentDescription = L.t(language, S.COPY))
                    }
                    IconButton(onClick = {
                        clipboard.setText(AnnotatedString(fieldValue.text.substring(selection.min, selection.max)))
                        replaceSelection(fieldValue, "") { next ->
                            val adjusted = adjustStylesForEdit(fieldValue.text, next.text, localStyles)
                            fieldValue = next
                            localStyles = adjusted
                            onValueChanged(next.text, adjusted, next.selection.start)
                        }
                    }) {
                        Icon(Icons.Rounded.ContentCut, contentDescription = L.t(language, S.CUT))
                    }
                    IconButton(onClick = {
                        val pasted = clipboard.getText()?.text.orEmpty()
                        if (pasted.isNotEmpty()) replaceSelection(fieldValue, pasted) { next ->
                            val adjusted = adjustStylesForEdit(fieldValue.text, next.text, localStyles)
                            fieldValue = next
                            localStyles = adjusted
                            onValueChanged(next.text, adjusted, next.selection.start)
                        }
                    }) {
                        Icon(Icons.Rounded.ContentPaste, contentDescription = L.t(language, S.PASTE))
                    }
                    IconButton(onClick = {
                        fieldValue = fieldValue.copy(selection = TextRange(0, fieldValue.text.length))
                    }) {
                        Icon(Icons.Rounded.SelectAll, contentDescription = L.t(language, S.SELECT_ALL))
                    }
                }
            }
        }

        BasicTextField(
            value = fieldValue,
            onValueChange = { incoming ->
                val paragraphCursor = directEnterCursor(fieldValue, incoming)
                if (paragraphCursor != null) {
                    onParagraphBreak(paragraphCursor, numberedListPrefix(fieldValue.text, paragraphCursor))
                    return@BasicTextField
                }

                val normalized = EditorInputNormalizer.normalize(
                    previousText = fieldValue.text,
                    incomingText = incoming.text,
                    incomingCursor = incoming.selection.start,
                    hasComposition = incoming.composition != null
                )
                val next = if (normalized.changed) incoming.copy(
                    text = normalized.text,
                    selection = TextRange(normalized.cursor),
                    composition = null
                ) else incoming
                val nextStyles = if (next.text != fieldValue.text) {
                    adjustStylesForEdit(fieldValue.text, next.text, localStyles)
                } else localStyles
                fieldValue = next
                localStyles = nextStyles
                onCursorChanged(next.selection.start)
                if (next.text != text || nextStyles != styles) {
                    onValueChanged(next.text, nextStyles, next.selection.start)
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .bringIntoViewRequester(bringIntoViewRequester)
                .focusRequester(focusRequester)
                .onPreviewKeyEvent { event ->
                    if (
                        event.type == KeyEventType.KeyDown &&
                        event.key == Key.Backspace &&
                        fieldValue.selection.collapsed &&
                        fieldValue.selection.start == 0
                    ) {
                        onMergeWithPrevious()
                    } else false
                }
                .onFocusChanged {
                    if (it.isFocused) {
                        onFocused()
                        onCursorChanged(fieldValue.selection.start)
                    }
                },
            onTextLayout = { textLayoutResult = it },
            textStyle = TextStyle(
                color = ink,
                fontFamily = fontFamily(fontChoice),
                fontSize = (16.2f * uiScale).sp,
                lineHeight = (24.0f * uiScale).sp,
                hyphens = Hyphens.Auto,
                lineBreak = LineBreak.Paragraph
            ),
            keyboardOptions = KeyboardOptions(
                capitalization = KeyboardCapitalization.Sentences,
                keyboardType = KeyboardType.Text
            ),
            cursorBrush = SolidColor(ink),
            visualTransformation = StoredStyleTransformation(localStyles)
        )
    }
}

/** Only legacy stored bold/italic spans are displayed; no formatting command is exposed. */
private class StoredStyleTransformation(
    private val styles: List<TextInlineStyle>
) : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val transformed = buildAnnotatedString {
            append(text.text)
            styles.forEach { span ->
                if (span.end > span.start && span.start >= 0 && span.end <= text.length) {
                    addStyle(
                        SpanStyle(
                            fontWeight = if (span.bold) FontWeight.Bold else null,
                            fontStyle = if (span.italic) FontStyle.Italic else null
                        ),
                        span.start,
                        span.end
                    )
                }
            }
        }
        return TransformedText(transformed, OffsetMapping.Identity)
    }
}

/** Detect only a genuine one-character Enter insertion, never an IME composing/autocorrect update. */
private fun directEnterCursor(previous: TextFieldValue, incoming: TextFieldValue): Int? {
    if (incoming.composition != null || incoming.text.length != previous.text.length + 1) return null
    val cursor = incoming.selection.start.coerceIn(0, incoming.text.length)
    if (cursor == 0) return null
    val inserted = cursor - 1
    if (incoming.text.getOrNull(inserted) != '\n') return null
    if (incoming.text.removeRange(inserted, inserted + 1) != previous.text) return null
    return inserted.coerceIn(0, previous.text.length)
}

private fun numberedListPrefix(text: String, cursor: Int): String {
    val before = text.substring(0, cursor.coerceIn(0, text.length))
    val currentLine = before.substringAfterLast('\n')
    val match = Regex("^\\s*(\\d+)\\.\\s+.*$").matchEntire(currentLine) ?: return ""
    val number = match.groupValues[1].toIntOrNull() ?: return ""
    return "${number + 1}. "
}

private fun List<TextInlineStyle>.sanitize(length: Int): List<TextInlineStyle> = mapNotNull { span ->
    val start = span.start.coerceIn(0, length)
    val end = span.end.coerceIn(start, length)
    if (end > start && (span.bold || span.italic)) span.copy(start = start, end = end) else null
}

private fun adjustStylesForEdit(oldText: String, newText: String, styles: List<TextInlineStyle>): List<TextInlineStyle> {
    if (oldText == newText || styles.isEmpty()) return styles
    var prefix = 0
    val min = minOf(oldText.length, newText.length)
    while (prefix < min && oldText[prefix] == newText[prefix]) prefix++
    var suffix = 0
    while (suffix < min - prefix && oldText[oldText.length - 1 - suffix] == newText[newText.length - 1 - suffix]) suffix++
    val oldEnd = oldText.length - suffix
    val newEnd = newText.length - suffix
    val delta = (newEnd - prefix) - (oldEnd - prefix)
    return styles.mapNotNull { span ->
        when {
            span.end <= prefix -> span
            span.start >= oldEnd -> span.copy(start = span.start + delta, end = span.end + delta)
            else -> {
                val newStart = minOf(span.start, prefix)
                val newSpanEnd = if (span.end >= oldEnd) span.end + delta else newEnd
                if (newSpanEnd > newStart) span.copy(start = newStart, end = newSpanEnd) else null
            }
        }
    }.sanitize(newText.length)
}

private fun replaceSelection(value: TextFieldValue, replacement: String, commit: (TextFieldValue) -> Unit) {
    val start = value.selection.min
    val end = value.selection.max
    val newText = value.text.replaceRange(start, end, replacement)
    val cursor = start + replacement.length
    commit(value.copy(text = newText, selection = TextRange(cursor), composition = null))
}
