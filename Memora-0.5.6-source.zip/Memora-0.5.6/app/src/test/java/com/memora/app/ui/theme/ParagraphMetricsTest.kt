package com.memora.app.ui.theme

import org.junit.Assert.assertEquals
import org.junit.Test

class ParagraphMetricsTest {
    @Test
    fun paragraphGapIsExactlyHalfLine() {
        assertEquals(0.50f, ParagraphMetrics.GAP_RATIO, 0.0001f)
        assertEquals(12f, ParagraphMetrics.EDITOR_LINE_HEIGHT_SP * ParagraphMetrics.GAP_RATIO, 0.0001f)
        assertEquals(14f, ParagraphMetrics.READER_LINE_HEIGHT_SP * ParagraphMetrics.GAP_RATIO, 0.0001f)
    }
}
