package com.memora.app.share

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.FileProvider
import com.memora.app.data.local.TopilmaCardRow
import com.memora.app.media.TopilmalarMediaStorage
import com.memora.app.ui.components.TopilmaCardVisualSpec
import com.memora.app.ui.components.presentation
import java.io.File
import java.io.FileOutputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object TopilmaShareManager {
    fun shareText(context: Context, card: TopilmaCardRow, includeSource: Boolean) {
        val presentation = card.presentation()
        val text = buildString {
            append(presentation.body)
            if (includeSource && presentation.title.isNotBlank()) {
                append("\n\n— ").append(presentation.title)
                if (presentation.author.isNotBlank()) append(", ").append(presentation.author)
            }
            if (presentation.tags.isNotEmpty()) append("\n\n").append(presentation.tags.joinToString(" ") { "#$it" })
        }
        context.startActivity(
            Intent.createChooser(
                Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, text)
                },
                "Topilmani ulashish"
            )
        )
    }

    /** Export always renders the complete card, never the 2-line list state. */
    suspend fun shareCardImage(context: Context, card: TopilmaCardRow) {
        val uri = withContext(Dispatchers.IO) {
            val bitmap = renderCardBitmap(context, card)
            val directory = File(context.cacheDir, "shares").apply { mkdirs() }
            val file = File(directory, humanReadableShareName(card))
            FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            bitmap.recycle()
            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        }
        withContext(Dispatchers.Main) {
            context.startActivity(
                Intent.createChooser(
                    Intent(Intent.ACTION_SEND).apply {
                        type = "image/png"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    },
                    "Kartochka rasmini ulashish"
                )
            )
        }
    }

    /**
     * Controlled off-screen renderer shared by Android Share and Obsidian.
     * Every dimension is derived from TopilmaCardVisualSpec's Compose dp/sp values.
     * The root canvas is deliberately opaque to prevent black/transparent margins
     * in Telegram, Honor Share, Gallery previews, and other receivers.
     */
    fun renderCardBitmap(context: Context, card: TopilmaCardRow): Bitmap {
        val spec = TopilmaCardVisualSpec
        val presentation = card.presentation()
        val width = spec.EXPORT_WIDTH
        val outer = spec.px(spec.EXPORT_OUTER_DP)
        val cardLeft = outer
        val cardRight = width - outer
        val cardTop = outer
        val innerLeft = cardLeft + spec.px(spec.HORIZONTAL_PADDING_DP)
        val innerRight = cardRight - spec.px(spec.HORIZONTAL_PADDING_DP)
        val contentWidth = (innerRight - innerLeft).toInt()

        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(37, 38, 38)
            textSize = spec.sp(spec.TITLE_SP)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        val authorPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(112, 112, 112)
            textSize = spec.sp(spec.AUTHOR_SP)
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        }
        val bodyPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(35, 35, 34)
            textSize = spec.sp(spec.BODY_SP)
            typeface = Typeface.create(Typeface.SERIF, Typeface.NORMAL)
        }

        val coverW = spec.px(spec.COVER_WIDTH_DP)
        val coverH = spec.px(spec.COVER_HEIGHT_DP)
        val coverToText = spec.px(spec.COVER_TO_TEXT_DP)
        val menuWidth = spec.px(spec.MENU_SIZE_DP)
        val headerTextWidth = (contentWidth - coverW - coverToText - menuWidth).toInt().coerceAtLeast(spec.px(120f).toInt())

        val titleLayout = fixedLineLayout(
            presentation.title,
            titlePaint,
            headerTextWidth,
            spec.sp(spec.TITLE_LINE_SP),
            maxLines = 2
        )
        val authorLayout = presentation.author.takeIf { it.isNotBlank() }?.let { author ->
            fixedLineLayout(
                author,
                authorPaint,
                headerTextWidth,
                spec.sp(spec.AUTHOR_LINE_SP),
                maxLines = 1
            )
        }
        val bodyLayout = fixedLineLayout(
            presentation.body,
            bodyPaint,
            contentWidth,
            spec.sp(spec.BODY_LINE_SP),
            maxLines = Int.MAX_VALUE
        )

        val verticalPadding = spec.px(spec.VERTICAL_PADDING_DP)
        val headerTop = cardTop + verticalPadding
        val authorTopGap = spec.px(spec.AUTHOR_TOP_DP)
        val textHeaderHeight = titleLayout.height.toFloat() +
            (authorLayout?.let { authorTopGap + it.height } ?: 0f)
        val headerHeight = maxOf(coverH, textHeaderHeight)
        val bodyTop = headerTop + headerHeight + spec.px(spec.HEADER_TO_BODY_DP)
        val bodyBottom = bodyTop + bodyLayout.height

        val tagMetrics = layoutTagRows(
            presentation.tags,
            contentWidth,
            spec.sp(spec.TAG_SP),
            spec.px(spec.TAG_HORIZONTAL_DP),
            spec.px(spec.TAG_GAP_X_DP)
        )
        val tagsTop = bodyBottom + spec.px(spec.BODY_TO_TAGS_DP)
        val tagLineHeight = spec.sp(16f)
        val chipHeight = tagLineHeight + spec.px(spec.TAG_VERTICAL_DP * 2f)
        val tagsHeight = if (tagMetrics.rows == 0) 0f
        else tagMetrics.rows * chipHeight + (tagMetrics.rows - 1) * spec.px(spec.TAG_GAP_Y_DP)
        val actionTop = if (tagMetrics.rows == 0) {
            bodyBottom + spec.px(spec.BODY_TO_TAGS_DP)
        } else {
            tagsTop + tagsHeight + spec.px(spec.TAGS_TO_ACTIONS_DP)
        }
        val actionHeight = spec.px(spec.ACTION_HEIGHT_DP)
        val cardBottom = actionTop + actionHeight + verticalPadding
        val bitmapHeight = kotlin.math.ceil(cardBottom + outer).toInt()

        val bitmap = Bitmap.createBitmap(width, bitmapHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        // T-249/T-250: the whole bitmap is opaque. No receiver can substitute black for alpha.
        canvas.drawColor(spec.EXPORT_BACKGROUND_ARGB.toInt())

        val cardPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = spec.EXPORT_CARD_ARGB.toInt()
            setShadowLayer(spec.px(3f), 0f, spec.px(1.25f), Color.argb(34, 0, 0, 0))
        }
        val radius = spec.px(spec.RADIUS_DP)
        canvas.drawRoundRect(cardLeft, cardTop, cardRight, cardBottom, radius, radius, cardPaint)

        drawCover(context, canvas, card, innerLeft, headerTop, coverW, coverH)

        val textLeft = innerLeft + coverW + coverToText
        canvas.save()
        canvas.translate(textLeft, headerTop)
        titleLayout.draw(canvas)
        canvas.restore()
        authorLayout?.let {
            canvas.save()
            canvas.translate(textLeft, headerTop + titleLayout.height + authorTopGap)
            it.draw(canvas)
            canvas.restore()
        }

        // Same horizontal MoreHoriz affordance, scaled from the in-app 38dp touch zone.
        val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(119, 119, 118) }
        val menuCenterX = innerRight - menuWidth / 2f
        val dotY = headerTop + spec.px(12f)
        val dotSpacing = spec.px(4.8f)
        val dotRadius = spec.px(1.35f)
        listOf(-1f, 0f, 1f).forEach { factor ->
            canvas.drawCircle(menuCenterX + factor * dotSpacing, dotY, dotRadius, dotPaint)
        }

        canvas.save()
        canvas.translate(innerLeft, bodyTop)
        bodyLayout.draw(canvas)
        canvas.restore()

        if (presentation.tags.isNotEmpty()) {
            drawTagChips(
                canvas = canvas,
                tags = presentation.tags,
                left = innerLeft,
                right = innerRight,
                top = tagsTop,
                textSize = spec.sp(spec.TAG_SP),
                horizontalPadding = spec.px(spec.TAG_HORIZONTAL_DP),
                verticalPadding = spec.px(spec.TAG_VERTICAL_DP),
                gapX = spec.px(spec.TAG_GAP_X_DP),
                gapY = spec.px(spec.TAG_GAP_Y_DP),
                lineHeight = tagLineHeight
            )
        }

        drawActions(canvas, card, innerLeft, innerRight, actionTop)
        return bitmap
    }

    private fun fixedLineLayout(
        text: String,
        paint: TextPaint,
        width: Int,
        desiredLineHeight: Float,
        maxLines: Int
    ): StaticLayout {
        val natural = paint.fontMetrics.let { it.descent - it.ascent }
        val builder = StaticLayout.Builder.obtain(text, 0, text.length, paint, width)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setIncludePad(false)
            .setLineSpacing(desiredLineHeight - natural, 1f)
            .setMaxLines(maxLines)
        if (maxLines != Int.MAX_VALUE) builder.setEllipsize(android.text.TextUtils.TruncateAt.END)
        return builder.build()
    }

    private data class TagLayoutMetrics(val rows: Int)

    private fun layoutTagRows(
        tags: List<String>,
        contentWidth: Int,
        textSize: Float,
        horizontalPadding: Float,
        gapX: Float
    ): TagLayoutMetrics {
        if (tags.isEmpty()) return TagLayoutMetrics(0)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.textSize = textSize }
        var rows = 1
        var used = 0f
        for (tag in tags) {
            val width = paint.measureText("#$tag") + horizontalPadding * 2f
            if (used > 0f && used + gapX + width > contentWidth) {
                rows++
                used = width
            } else {
                used += (if (used > 0f) gapX else 0f) + width
            }
        }
        return TagLayoutMetrics(rows)
    }

    private fun drawTagChips(
        canvas: Canvas,
        tags: List<String>,
        left: Float,
        right: Float,
        top: Float,
        textSize: Float,
        horizontalPadding: Float,
        verticalPadding: Float,
        gapX: Float,
        gapY: Float,
        lineHeight: Float
    ) {
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(88, 102, 161)
            this.textSize = textSize
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(242, 242, 249) }
        val fm = textPaint.fontMetrics
        val chipHeight = lineHeight + verticalPadding * 2f
        var x = left
        var y = top
        for (tag in tags) {
            val label = "#$tag"
            val chipWidth = textPaint.measureText(label) + horizontalPadding * 2f
            if (x > left && x + chipWidth > right) {
                x = left
                y += chipHeight + gapY
            }
            canvas.drawRoundRect(x, y, x + chipWidth, y + chipHeight, chipHeight / 2f, chipHeight / 2f, bgPaint)
            val baseline = y + verticalPadding + (lineHeight - (fm.descent + fm.ascent)) / 2f
            canvas.drawText(label, x + horizontalPadding, baseline, textPaint)
            x += chipWidth + gapX
        }
    }

    private fun drawCover(context: Context, canvas: Canvas, card: TopilmaCardRow, left: Float, top: Float, width: Float, height: Float) {
        val spec = TopilmaCardVisualSpec
        val rect = RectF(left, top, left + width, top + height)
        val framePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.FILL
            setShadowLayer(2f, 0f, 1f, Color.argb(25, 0, 0, 0))
        }
        canvas.drawRoundRect(rect, spec.px(spec.COVER_RADIUS_DP), spec.px(spec.COVER_RADIUS_DP), framePaint)
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(222, 222, 222)
            style = Paint.Style.STROKE
            strokeWidth = spec.px(spec.COVER_BORDER_DP)
        }
        canvas.drawRoundRect(rect, spec.px(spec.COVER_RADIUS_DP), spec.px(spec.COVER_RADIUS_DP), borderPaint)

        val thumbnail = card.sourceCoverPath?.let { relativePath ->
            runCatching { decodeThumbnail(TopilmalarMediaStorage(context).resolve(relativePath), 520) }.getOrNull()
        }
        if (thumbnail != null) {
            val inset = spec.px(spec.COVER_INSET_DP)
            val available = RectF(rect.left + inset, rect.top + inset, rect.right - inset, rect.bottom - inset)
            val scale = minOf(available.width() / thumbnail.width, available.height() / thumbnail.height)
            val drawW = thumbnail.width * scale
            val drawH = thumbnail.height * scale
            val dst = RectF(
                available.centerX() - drawW / 2f,
                available.centerY() - drawH / 2f,
                available.centerX() + drawW / 2f,
                available.centerY() + drawH / 2f
            )
            canvas.save()
            val clip = Path().apply { addRoundRect(available, spec.px(spec.COVER_RADIUS_DP - spec.COVER_INSET_DP), spec.px(spec.COVER_RADIUS_DP - spec.COVER_INSET_DP), Path.Direction.CW) }
            canvas.clipPath(clip)
            canvas.drawBitmap(thumbnail, null, dst, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
            canvas.restore()
            thumbnail.recycle()
        } else {
            val fallback = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(236, 241, 238) }
            canvas.drawRoundRect(rect, spec.px(spec.COVER_RADIUS_DP), spec.px(spec.COVER_RADIUS_DP), fallback)
            canvas.drawText("M", rect.centerX() - 22f, rect.centerY() + 20f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(64, 100, 84); textSize = 58f; typeface = Typeface.DEFAULT_BOLD
            })
        }
    }

    private fun drawActions(canvas: Canvas, card: TopilmaCardRow, innerLeft: Float, innerRight: Float, actionTop: Float) {
        val spec = TopilmaCardVisualSpec
        val actionY = actionTop + spec.px(26f)
        val iconColor = Color.rgb(56, 58, 57)
        val muted = Color.rgb(96, 98, 97)
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = iconColor
            strokeWidth = spec.px(1.8f)
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        val countPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = muted
            textSize = spec.sp(14f)
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        }
        val third = (innerRight - innerLeft) / 3f
        val shareX = innerLeft + third / 2f
        val heartX = innerLeft + third * 1.5f
        val commentX = innerLeft + third * 2.5f

        // Rounded Material-like share icon within the same 25dp optical box as Compose.
        val shareR = spec.px(3.2f)
        val shareDx = spec.px(8f)
        val shareDy = spec.px(7f)
        val sharePath = Path().apply {
            moveTo(shareX - shareDx + shareR, actionY)
            lineTo(shareX + shareDx - shareR, actionY - shareDy)
            moveTo(shareX - shareDx + shareR, actionY)
            lineTo(shareX + shareDx - shareR, actionY + shareDy)
        }
        canvas.drawPath(sharePath, stroke)
        val nodeFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = iconColor; style = Paint.Style.FILL }
        canvas.drawCircle(shareX - shareDx, actionY, shareR, nodeFill)
        canvas.drawCircle(shareX + shareDx, actionY - shareDy, shareR, nodeFill)
        canvas.drawCircle(shareX + shareDx, actionY + shareDy, shareR, nodeFill)

        // 27dp heart optical size, matching in-app Favorite/FavoriteBorder.
        val hw = spec.px(13.5f)
        val hh = spec.px(12f)
        val heartPath = Path().apply {
            moveTo(heartX, actionY + hh)
            cubicTo(heartX - hw * 1.05f, actionY + hh * .25f, heartX - hw * .80f, actionY - hh, heartX - hw * .30f, actionY - hh * .68f)
            cubicTo(heartX - hw * .10f, actionY - hh * .55f, heartX, actionY - hh * .30f, heartX, actionY - hh * .30f)
            cubicTo(heartX, actionY - hh * .30f, heartX + hw * .10f, actionY - hh * .55f, heartX + hw * .30f, actionY - hh * .68f)
            cubicTo(heartX + hw * .80f, actionY - hh, heartX + hw * 1.05f, actionY + hh * .25f, heartX, actionY + hh)
            close()
        }
        val heartPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (card.likeCount > 0) Color.rgb(219, 104, 113) else iconColor
            style = if (card.likeCount > 0) Paint.Style.FILL else Paint.Style.STROKE
            strokeWidth = spec.px(1.8f)
        }
        canvas.drawPath(heartPath, heartPaint)
        if (card.likeCount > 0) {
            canvas.drawText(card.likeCount.toString(), heartX + spec.px(17f), actionY + spec.px(5f), countPaint)
        }

        // 26dp chat bubble optical box.
        val halfW = spec.px(11f)
        val halfH = spec.px(9f)
        val bubble = RectF(commentX - halfW, actionY - halfH, commentX + halfW, actionY + halfH * .75f)
        canvas.drawRoundRect(bubble, spec.px(3.5f), spec.px(3.5f), stroke)
        val tail = Path().apply {
            moveTo(commentX - spec.px(3f), bubble.bottom)
            lineTo(commentX - spec.px(spec.COVER_RADIUS_DP), bubble.bottom + spec.px(spec.COVER_RADIUS_DP))
            lineTo(commentX + spec.px(1.5f), bubble.bottom + spec.px(.5f))
        }
        canvas.drawPath(tail, stroke)
        if (card.commentCount > 0) {
            canvas.drawText(card.commentCount.toString(), commentX + spec.px(spec.VERTICAL_PADDING_DP), actionY + spec.px(5f), countPaint)
        }
    }

    private fun humanReadableShareName(card: TopilmaCardRow): String {
        val p = card.presentation()
        val raw = buildString {
            append("Topilma - ").append(p.title)
            if (p.author.isNotBlank()) append(" - ").append(p.author)
        }
        val safe = raw.replace(Regex("[\\/:*?\"<>|]"), "-").replace(Regex("\\s+"), " ").trim().take(110)
        return "$safe.png"
    }

    private fun decodeThumbnail(file: File, target: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (bounds.outWidth / sample > target * 2 || bounds.outHeight / sample > target * 2) sample *= 2
        return BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
    }
}
