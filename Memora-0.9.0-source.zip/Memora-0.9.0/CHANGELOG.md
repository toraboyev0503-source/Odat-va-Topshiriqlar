# Changelog

## 0.9.0 — Play Release Candidate

- Added Google Play Billing Library 9.1.0 integration for the single
  `memora_premium` subscription and four base plans.
- Added Play-controlled offer selection for a one-month free trial; reinstalling
  the app does not reset Play account eligibility.
- Added backend purchase-token verification, encrypted seven-day offline
  entitlement caching, pending-purchase handling and post-verification acknowledgement.
- Added read-only behavior after expiry while preserving viewing, search,
  statistics, playback and every export format.
- Added automatic device-language selection with English fallback while retaining
  the existing manual choice and all 13 UI languages.
- Kept all journal content local and added no advertising, analytics or crash SDK.
- Separated release signing from debug signing and removed the bundled test key.
- Replaced the custom build bootstrap with the official checksum-pinned Gradle wrapper.
- Added bounded backup/media import and canonical private-storage path validation.
- Added a GitHub Actions test → lint → signed AAB pipeline.
- Retained the 0.5.7 editor/reader paragraph gap at exactly 60% of line-height.

## 0.5.7 baseline

- Structural paragraph blocks, 60% paragraph spacing, short/long notes, media,
  reminders, titles, statistics, search, app lock, 13 languages, HTML/Word export
  and `.memora` backup/import form the preserved functional baseline.
