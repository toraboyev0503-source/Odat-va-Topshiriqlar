# Memora 0.9.0 production audit

Audit date: 2026-09-03. Baseline archive SHA-256:
`5A6E36390583EE9099C0613D8B7E38EE1F34AAB17330979709A7A3D114DBE36D`
(matched the checksum supplied with Memora 0.5.7).

## Release gate results

| Area | Result |
|---|---|
| SDK | `compileSdk=36`, `targetSdk=36`; compliant with the 2026 Play target requirement |
| Minimum Android | `minSdk=26` retained as the best compatibility/security balance for this codebase |
| Version | `0.9.0` / code `20` |
| App identity | In-app/launcher `Memora`; Play listing title documented as `Memora – Private Journal` |
| Monetization | One Play subscription, four base-plan IDs, Play offer-token selection |
| Expiry | Repository-level write guard plus UI gates; reading/search/media/statistics/export remain open |
| Offline | AES-GCM cache using a non-exportable Android Keystore key; max 7 days and never beyond Play expiry |
| Content privacy | No journal content enters billing verification; Android backup disabled; cleartext disabled |
| Tracking | No advertising, analytics or crash-reporting SDK configured |
| Signing | Debug and release separated; release credentials are environment-only; bundled test key removed |
| CI | Backend tests, Android unit tests, release lint, signed release AAB and signature verification |
| Paragraph layout | Centralized 60% gap retained and unit tested |

Final local verification: 21/21 Android unit tests passed, 3/3 backend contract
tests passed, `lintRelease` completed with 0 errors (41 non-blocking dependency,
icon and style advisories plus 1 hint), and the minified signed AAB build completed.
The signing key used for this local build was temporary and is not a deliverable.

## Why minSdk 26 remains optimal

The application already relies on Android 8-era platform behavior and `java.time`,
private scoped app storage, notification channels and modern security primitives.
Lowering the minimum would require desugaring plus additional legacy behavior and
test surface without helping the Play target requirement. Raising it would remove
working Android 8/9 devices without a current technical need. API 26 is therefore
retained for this RC.

## Security hardening performed

- Purchase entitlement is granted only after a `PURCHASED` result is verified by
  Android Publisher API; `PENDING` never grants write access.
- The app sends only package name, product ID and purchase token to the verifier.
- Backup manifests, legacy JSON and media entries have explicit limits.
- Backup paths are normalized, whitelisted to `media/images` or `media/audio`, and
  canonicalized beneath private app storage; missing media is dropped on import.
- Gallery images are bounds-read and sampled before decode to reduce memory-exhaustion risk.
- Automatic notification permission prompting on first launch was removed; reminder
  creation remains the contextual permission point.
- Release builds require HTTPS verification, signing variables, minification and
  resource shrinking.
- The official Gradle wrapper uses the published Gradle 8.13 SHA-256 checksum.

## Residual release-owner actions

These cannot be embedded in source: create the Play developer/app record, configure
the product/base plans/offers and prices, deploy the verifier, grant its service
account Play access, create and protect the upload key, supply GitHub secrets, host
the privacy policy, complete Data safety/content-rating forms, and execute Play
license/internal/closed testing. See `PLAY_CONSOLE_SETUP.md`.

The minimal verifier intentionally has no journal database and no RTDN subscriber.
The app rechecks Play at foreground and uses the bounded offline cache. For a later
multi-device/account backend, add RTDN and durable token state without expanding the
journal-content boundary.
