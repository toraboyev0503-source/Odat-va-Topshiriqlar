package com.memora.app.media

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.core.content.FileProvider
import com.memora.app.data.model.NoteBlock
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.UUID

class MediaStorage(private val context: Context) {
    data class CameraCapture(val uri: Uri, val file: File)
    data class ImportedFile(val relativePath: String, val byteCount: Long)

    private val root: File get() = context.filesDir.canonicalFile

    fun importImage(uri: Uri): NoteBlock.Image {
        val bounds = BitmapFactory.Options().also { options ->
            options.inJustDecodeBounds = true
            context.contentResolver.openInputStream(uri)?.use { input ->
                BitmapFactory.decodeStream(input, null, options)
            } ?: error("Unable to read image")
        }
        require(bounds.outWidth > 0 && bounds.outHeight > 0) { "Unsupported image" }
        var sample = 1
        while (
            maxOf(bounds.outWidth / sample, bounds.outHeight / sample) > MAX_IMAGE_DIMENSION ||
            (bounds.outWidth.toLong() / sample) * (bounds.outHeight.toLong() / sample) > MAX_IMAGE_PIXELS
        ) {
            sample *= 2
        }
        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        val bitmap = context.contentResolver.openInputStream(uri)?.use { input ->
            BitmapFactory.decodeStream(input, null, options)
        }
            ?: error("Unable to read image")
        val relative = "media/images/${UUID.randomUUID()}.jpg"
        val target = resolve(relative)
        target.parentFile?.mkdirs()
        FileOutputStream(target).use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)
        }
        bitmap.recycle()
        return NoteBlock.Image(relativePath = relative, mimeType = "image/jpeg")
    }

    fun createCameraCapture(): CameraCapture {
        val dir = File(context.cacheDir, "camera").apply { mkdirs() }
        val file = File(dir, "${UUID.randomUUID()}.jpg")
        if (!file.exists()) file.createNewFile()
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        return CameraCapture(uri, file)
    }

    fun importCameraImage(capture: CameraCapture): NoteBlock.Image =
        try {
            importImage(capture.uri)
        } finally {
            runCatching { capture.file.delete() }
        }

    fun discardCameraCapture(capture: CameraCapture) {
        runCatching { capture.file.delete() }
    }

    fun newAudioFile(): Pair<String, File> {
        val relative = "media/audio/${UUID.randomUUID()}.m4a"
        val target = resolve(relative)
        target.parentFile?.mkdirs()
        return relative to target
    }

    fun normalizedMediaPath(relativePath: String): String? {
        val normalized = relativePath.replace('\\', '/').trim()
        if (normalized.length !in 1..MAX_RELATIVE_PATH_LENGTH) return null
        if (normalized.startsWith('/') || normalized.split('/').any { it.isBlank() || it == "." || it == ".." }) {
            return null
        }
        if (!SAFE_MEDIA_PATH.matches(normalized)) return null
        return normalized
    }

    fun resolve(relativePath: String): File {
        val normalized = requireNotNull(normalizedMediaPath(relativePath)) { "Invalid media path" }
        val resolved = File(root, normalized).canonicalFile
        require(resolved.path.startsWith(root.path + File.separator)) { "Media path escapes app storage" }
        return resolved
    }

    fun delete(relativePath: String) {
        runCatching { resolve(relativePath).delete() }
    }

    fun storeImported(
        relativeFolder: String,
        extension: String,
        input: InputStream,
        maxBytes: Long
    ): ImportedFile {
        require(relativeFolder == "images" || relativeFolder == "audio") { "Invalid media folder" }
        val cleanExt = extension.trimStart('.').lowercase().takeIf { SAFE_EXTENSION.matches(it) } ?: "bin"
        val relative = "media/$relativeFolder/${UUID.randomUUID()}.$cleanExt"
        val target = resolve(relative)
        target.parentFile?.mkdirs()
        var written = 0L
        try {
            FileOutputStream(target).buffered().use { output ->
                val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                while (true) {
                    val read = input.read(buffer)
                    if (read < 0) break
                    written += read
                    require(written <= maxBytes) { "Backup media entry is too large" }
                    output.write(buffer, 0, read)
                }
            }
        } catch (error: Throwable) {
            runCatching { target.delete() }
            throw error
        }
        return ImportedFile(relative, written)
    }

    companion object {
        private const val MAX_IMAGE_DIMENSION = 4096
        private const val MAX_IMAGE_PIXELS = 16_777_216L
        private const val MAX_RELATIVE_PATH_LENGTH = 240
        private val SAFE_MEDIA_PATH = Regex("^media/(images|audio)/[A-Za-z0-9._-]+$")
        private val SAFE_EXTENSION = Regex("^[a-z0-9]{1,8}$")
    }
}
