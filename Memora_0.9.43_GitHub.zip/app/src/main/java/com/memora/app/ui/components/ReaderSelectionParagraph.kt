package com.memora.app.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.Hyphens
import androidx.compose.ui.text.style.LineBreak
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.memora.app.data.model.NoteBlock
import com.memora.app.ui.theme.highlightComposeColor
import com.memora.app.prefs.FontChoice
import com.memora.app.ui.theme.fontFamily
import com.memora.app.prefs.AppLanguage

/** Read-only selectable paragraph: selection range stays per block. Highlight operations never
 * modify paragraph text; existing bold/italic spans are preserved by NoteHighlightPolicy.
 */
@Composable
fun ReaderSelectionParagraph(
    block: NoteBlock.Text,
    fontChoice: FontChoice,
    language: AppLanguage,
    query: String,
    focusedMatchOffset: Int?,
    canHighlight: Boolean,
    onHighlight: (blockId: String, start: Int, end: Int, color: String?) -> Unit,
    onShare: (selected: String, asImage: Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val ink = MaterialTheme.colorScheme.onSurface
    val annotated = remember(block, query) {
        buildAnnotatedString {
            append(block.text)
            block.styles.forEach { span ->
                if (span.start in 0..block.text.length && span.end in 0..block.text.length && span.end > span.start) {
                    addStyle(
                        SpanStyle(
                            fontWeight = if (span.bold) FontWeight.Bold else null,
                            fontStyle = if (span.italic) FontStyle.Italic else null,
                            background = highlightComposeColor(span.highlight) ?: Color.Unspecified
                        ), span.start, span.end
                    )
                }
            }
            if (query.isNotBlank()) {
                var start = block.text.indexOf(query, ignoreCase = true)
                while (start >= 0) {
                    addStyle(SpanStyle(background = Color(0xFFD5DCE0)), start, start + query.length)
                    start = block.text.indexOf(query, start + query.length, ignoreCase = true)
                }
            }
        }
    }
    var value by remember(block.id) { mutableStateOf(TextFieldValue(annotatedString = annotated)) }
    LaunchedEffect(annotated) {
        value = value.copy(annotatedString = annotated,
            selection = TextRange(value.selection.start.coerceIn(0, block.text.length),
                value.selection.end.coerceIn(0, block.text.length)), composition = null)
    }
    val selectedStart = minOf(value.selection.start, value.selection.end).coerceIn(0, block.text.length)
    val selectedEnd = maxOf(value.selection.start, value.selection.end).coerceIn(0, block.text.length)
    val hasSelection = selectedEnd > selectedStart
    val selected = if (hasSelection) block.text.substring(selectedStart, selectedEnd) else ""
    val clipboard = LocalClipboardManager.current
    val searchRequester = remember { BringIntoViewRequester() }
    var textLayout by remember(block.id) { mutableStateOf<TextLayoutResult?>(null) }
    LaunchedEffect(focusedMatchOffset, textLayout) {
        val offset = focusedMatchOffset ?: return@LaunchedEffect
        val layout = textLayout ?: return@LaunchedEffect
        if (block.text.isNotEmpty()) {
            val rect = runCatching { layout.getBoundingBox(offset.coerceIn(0, block.text.lastIndex)) }.getOrNull()
            if (rect != null) searchRequester.bringIntoView(rect)
        }
    }
    val labels = ReaderActionsLabels.forLanguage(language)

    Column(modifier) {
        BasicTextField(
            value = value,
            onValueChange = { incoming ->
                if (incoming.text == block.text) value = incoming.copy(annotatedString = annotated, composition = null)
            },
            modifier = Modifier.fillMaxWidth().wrapContentHeight().bringIntoViewRequester(searchRequester),
            onTextLayout = { textLayout = it },
            textStyle = TextStyle(
                color = ink, fontFamily = fontFamily(fontChoice), fontSize = 18.sp, lineHeight = 28.sp,
                hyphens = Hyphens.Auto, lineBreak = LineBreak.Paragraph
            ),
            cursorBrush = SolidColor(Color.Transparent),
            readOnly = true,
        )
        if (hasSelection) {
            Column(Modifier.padding(top = 5.dp, bottom = 5.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(3.dp), modifier = Modifier.fillMaxWidth()) {
                    TextButton(onClick = {
                        clipboard.setText(AnnotatedString(selected))
                        value = value.copy(selection = TextRange(selectedEnd))
                    }) { Text(labels.copy, fontSize = 11.sp) }
                    TextButton(onClick = { onShare(selected, false) }) { Text(labels.share, fontSize = 11.sp) }
                    TextButton(onClick = { onShare(selected, true) }) { Text(labels.image, fontSize = 11.sp) }
                }
                if (canHighlight) {
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp),
                        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()) {
                        Text(labels.marker, style = MaterialTheme.typography.labelSmall)
                        listOf("YELLOW", "GREEN", "ROSE").forEach { shade ->
                            androidx.compose.material3.Surface(
                                onClick = { onHighlight(block.id, selectedStart, selectedEnd, shade) },
                                shape = androidx.compose.foundation.shape.CircleShape,
                                color = highlightComposeColor(shade) ?: Color.Yellow,
                                modifier = Modifier.padding(2.dp).size(32.dp)
                            ) {
                                androidx.compose.foundation.layout.Box(Modifier.size(32.dp))
                            }
                        }
                        TextButton(onClick = { onHighlight(block.id, selectedStart, selectedEnd, null) }) {
                            Text(labels.clear, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

/** New reader actions are translated for all 13 supported interface locales. */
data class ReaderActionsLabels(
    val copy: String, val share: String, val image: String, val marker: String,
    val clear: String, val search: String, val pdf: String, val preview: String
) {
    companion object {
        fun forLanguage(l: AppLanguage): ReaderActionsLabels = when (l) {
            AppLanguage.UZ -> ReaderActionsLabels("Nusxalash", "Ulashish", "Rasm", "Marker", "Olib tashlash", "Qidirish", "PDF", "Ko‘rinish")
            AppLanguage.RU -> ReaderActionsLabels("Копировать", "Поделиться", "Фото", "Маркер", "Убрать", "Поиск", "PDF", "Просмотр")
            AppLanguage.EN -> ReaderActionsLabels("Copy", "Share", "Image", "Mark", "Clear", "Search", "PDF", "Preview")
            AppLanguage.AR -> ReaderActionsLabels("نسخ", "مشاركة", "صورة", "تحديد", "إزالة", "بحث", "PDF", "معاينة")
            AppLanguage.TR -> ReaderActionsLabels("Kopyala", "Paylaş", "Resim", "İşaretle", "Kaldır", "Ara", "PDF", "Önizleme")
            AppLanguage.FR -> ReaderActionsLabels("Copier", "Partager", "Image", "Marquer", "Effacer", "Chercher", "PDF", "Aperçu")
            AppLanguage.DE -> ReaderActionsLabels("Kopieren", "Teilen", "Bild", "Markieren", "Entfernen", "Suchen", "PDF", "Vorschau")
            AppLanguage.ES -> ReaderActionsLabels("Copiar", "Compartir", "Imagen", "Marcar", "Quitar", "Buscar", "PDF", "Vista previa")
            AppLanguage.PT_BR -> ReaderActionsLabels("Copiar", "Compartilhar", "Imagem", "Marcar", "Remover", "Buscar", "PDF", "Prévia")
            AppLanguage.HI -> ReaderActionsLabels("कॉपी", "साझा", "चित्र", "चिह्नित", "हटाएँ", "खोजें", "PDF", "झलक")
            AppLanguage.ID -> ReaderActionsLabels("Salin", "Bagikan", "Gambar", "Tandai", "Hapus", "Cari", "PDF", "Pratinjau")
            AppLanguage.JA -> ReaderActionsLabels("コピー", "共有", "画像", "マーク", "解除", "検索", "PDF", "プレビュー")
            AppLanguage.KO -> ReaderActionsLabels("복사", "공유", "이미지", "강조", "해제", "검색", "PDF", "미리보기")
        }
    }
}
