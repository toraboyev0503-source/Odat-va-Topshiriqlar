package com.memora.app.data.model

/** Annotations are stored as style spans inside the note's blocksJson. They survive backup,
 * splitting/merging paragraphs and editor's offset adjustments without extra database tables.
 * An existing bold or italic span is never modified by the highlighter.
 */
object NoteHighlightPolicy {
    val colors = setOf("YELLOW", "GREEN", "ROSE")

    fun setColor(block: NoteBlock.Text, start: Int, end: Int, color: String?): NoteBlock.Text {
        require(color == null || color in colors)
        val a = minOf(start, end).coerceIn(0, block.text.length)
        val b = maxOf(start, end).coerceIn(0, block.text.length)
        if (a >= b) return block
        val result = mutableListOf<TextInlineStyle>()
        for (style in block.styles) {
            if (style.highlight == null || style.end <= a || style.start >= b) {
                result += style
                continue
            }
            // Keep the annotated parts outside the changed range; preserve bold/italic.
            if (style.start < a) result += style.copy(end = a)
            if (style.end > b) result += style.copy(start = b)
            if (style.bold || style.italic) {
                result += style.copy(start = maxOf(a, style.start), end = minOf(b, style.end), highlight = null)
            }
        }
        if (color != null) result += TextInlineStyle(start = a, end = b, highlight = color)
        return block.copy(styles = result.filter { it.end > it.start }.sortedWith(compareBy({ it.start }, { it.end })))
    }
}
