# Memora 0.9.43 — acceptance checklist

Before release, build through GitHub Actions using the included workflow and check the following on a real Android phone.

1. **Titles:** read a long and a short note; verify 39sp heading in both reader and editor, wrapped titles, and ordinary paragraph font unchanged.
2. **Reader controls:** only Back, Edit and Search float at the top; there is no redundant top Delete. Bottom Delete remains and requires confirmation.
3. **Copy/mark:** long press within a paragraph, drag selection handles, copy text, apply yellow/green/rose, change color, clear selection; verify existing bold/italic remains.
4. **Editing compatibility:** open that note in Editor, add/delete text before and inside a marked span, split and merge paragraphs; verify colored markers remain correctly aligned. Selection range is paragraph-scoped; the bottom Copy copies the entire note.
5. **Search:** search with several occurrences spanning multiple paragraphs; next/previous arrows should bring the target line into view; blank and no-match queries should not crash.
6. **Paper share:** preview title and excerpt, export plain text, a long multipage PNG, PDF and HTML. Ensure first/last pages, title, text and creation/edit dates are correctly placed. Images should keep their natural aspect ratio. Audio is represented by an attachment label in exports, not embedded playable audio.
7. **Themes/locales:** all five palettes, light/dark and 13 languages. Some export metadata labels may fall back to English for languages other than Uzbek/Russian.
8. **Backup:** create a `.memora` backup with highlighted text; restore to a clean install, confirm highlight colors and text/media. Imported notes retain their relative style metadata.
9. **Compatibility:** update an existing 0.9.42 debug install without uninstalling, confirm all existing notes, memories, settings, album photos and audio remain available.
10. **Keyboard/accessibility:** back and editing interactions must not open keyboard while read-only selection is active, and TalkBack/large font layouts should be checked.

Static checks are not a substitute for an Android Gradle compile and on-device testing. Android SDK/Gradle distribution were unavailable in the authoring container, so these must be completed in GitHub Actions after approval to upload.
