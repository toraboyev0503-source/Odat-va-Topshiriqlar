#!/usr/bin/env python3
"""Version-independent structural guards for the 0.9.39 stability release.

These smoke checks complement, but do not replace, Android compilation and tests.
"""
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
errors = []
checks = 0

def read(rel):
    p = ROOT / rel
    if not p.is_file():
        errors.append(f"missing: {rel}")
        return ""
    return p.read_text(encoding="utf-8")

def check(label, condition):
    global checks
    checks += 1
    if not condition: errors.append(label)

def balanced(text):
    stack=[]; pairs={')':'(',']':'[','}':'{'}
    i=0; block=0
    while i<len(text):
        if block:
            if text.startswith('/*',i): block+=1; i+=2; continue
            if text.startswith('*/',i): block-=1; i+=2; continue
            i+=1; continue
        if text.startswith('//',i):
            j=text.find('\n',i+2)
            i=len(text) if j<0 else j
            continue
        if text.startswith('/*',i): block=1; i+=2; continue
        if text.startswith('"""',i):
            j=text.find('"""',i+3)
            if j<0: return False
            i=j+3; continue
        if text[i] in ('"',"'"):
            q=text[i]; i+=1
            while i<len(text):
                if text[i]=='\\': i+=2; continue
                if text[i]==q: i+=1; break
                i+=1
            continue
        c=text[i]
        if c in '([{': stack.append(c)
        elif c in ')]}':
            if not stack or stack.pop()!=pairs[c]: return False
        i+=1
    return not stack and block==0

p='app/src/main/java/com/memora/app/'
gradle=read('app/build.gradle.kts')
editor=read(p+'ui/screens/EditorScreen.kt')
repository=read(p+'data/repository/MemoraRepository.kt')
backup=read(p+'export/ExportManager.kt')
review=read(p+'data/repository/TopilmaReviewSelector.kt')
ocr=read(p+'share/OcrCacheStorage.kt')
prefs=read(p+'prefs/TopilmaIntegrationPreferences.kt')
process=read(p+'integration/TopilmaProcessTextActivity.kt')
integration=read(p+'ui/screens/TopilmaIntegrationScreen.kt')
db=read(p+'data/local/AppDatabase.kt')
server=read('backend/server.mjs')
workflow=read('.github/workflows/android-build.yml')
check('version 0.9.39', 'versionName = "0.9.39"' in gradle and 'versionCode = 60' in gradle)
check('test debug signature preserved', 'keystore/memora-test-debug.jks' in gradle and 'applicationIdSuffix = ".debug"' in gradle)
check('database version unchanged', 'version = 8' in db and 'ALL_MIGRATIONS' in db)
check('save title validation', 'NoteTitlePolicy.canPersist(title)' in repository and 'NoteSaveResult.TitleRequired' in editor)
check('recovery for uncommitted draft', 'recoveryStore.write(' in editor and 'snapshot.title.isNotBlank()' in editor)
check('editor remains on save failure', 'showSaveFailure()\n                        return@launch' in editor)
check('media not removed on confirmation', 'storage.delete(media.relativePath)' not in editor)
check('media is referenced before cleanup', 'repository.isMediaReferenced(path)' in editor)
check('Obsidian not called synchronously when exiting editor', 'repository.syncNoteToObsidianNow(it)' not in editor)
check('review quota fallback', 'for (candidate in scored)' in review and 'selected.size >= target' in review)
check('backup transaction', 'repository.withImportTransaction' in backup and 'restoreDatabaseExtras' in backup)
check('backup rollback cleanups', all(s in backup for s in ['noteMediaCreated.forEach(storage::delete)', 'topilmalarMediaCreated.forEach(topilmalarStorage::delete)','timeTraceCreated.forEach(timeTraceStorage::delete)']))
check('media staged and validated', 'Backup is missing note media files' in backup and 'restoreBackupEntry' in backup)
check('OCR copy byte limit', 'MAX_BYTES = 24L' in ocr and 'target.delete()' in ocr)
check('integration selector actually checked', 'prefs::isEnabled' in process and 'if (isPreferredOrigin)' in process)
check('integration theme matches Memora', 'MemoraTheme(settings)' in process)
check('integration localized UX', 'AppLanguage.RU' in process and 'AppLanguage.RU' in integration)
check('Billing local limits', 'createRateLimiter' in server and 'limiter.enter(' in server and 'limiter.leave()' in server)
check('CI builds and checks', all(x in workflow for x in ['testDebugUnitTest','lintDebug','assembleDebug','assembleDebugAndroidTest','regression_0939.py']))
check('No old workflow to interfere', not (ROOT/'.github/workflows/main.yml').exists())
check('Android migration test included', (ROOT/'app/src/androidTest/java/com/memora/app/data/local/AppDatabaseMigrationTest.kt').exists())
navigation = read(p+'ui/MemoraApp.kt')
notes = read(p+'ui/screens/NotesHubScreen.kt')
theme = read(p+'ui/theme/MemoraTheme.kt')
lang_screen = read(p+'ui/screens/LanguageScreen.kt')
theme_screen = read(p+'ui/screens/ThemeScreen.kt')
security = read(p+'ui/screens/SecurityScreen.kt')
overlays = read(p+'ui/components/MemoraOverlays.kt')
archive_policy = read(p+'ui/screens/NotesArchivePolicy.kt')
check('U-01 no double fade on root tabs', 'EnterTransition.None' in navigation and 'ExitTransition.None' in navigation and 'slideInHorizontally' in navigation)
check('U-02 only completed years archived', 'NotesArchivePolicy.archived(year, currentYear)' in notes and 'year < currentYear' in archive_policy)
check('U-02 no month folders', 'expandedMonths' not in notes and 'ArchiveHeaderLevel.MONTH' not in notes)
check('U-02 discovery search remains open', 'if (discoveryMode)' in notes and 'groupedByDay.forEach' in notes)
check('U-03 keyboard hides bottom navigation', 'WindowInsets.ime.getBottom' in navigation and 'if (showBottomNavigation)' in navigation)
check('U-03 complete themed Material colors', all(x in theme for x in ['surfaceContainerHigh', 'secondaryContainer', 'tertiaryContainer','outlineVariant','shapes = shapes']))
check('U-03 themed sheets and dialogs', 'fun MemoraSheet(' in overlays and 'fun MemoraDialog(' in overlays)
check('U-03 search filter compact and has apply', 'filterResultsLabel(language)' in notes and 'MemoraSheet(' in notes)
check('U-04 language cards preserve every entry', 'items(AppLanguage.entries' in lang_screen and 'MemoraSelectionCard' in lang_screen)
check('U-05 theme previews and palette', 'fun PalettePreview(' in theme_screen and 'fun ModePreview(' in theme_screen and 'FontPreviews(' in theme_screen)
check('U-06 security selection cards', 'MemoraSelectionCard(' in security and 'Switch(' in security)
check('No Room schema changes', 'version = 8' in db)
# Quiet Navigation 0.9.39: user video revealed overlaid titles and old-page ghosting.
quiet = read(p+'ui/QuietNavigationPolicy.kt')
quiet_test = read('app/src/test/java/com/memora/app/ui/QuietNavigationPolicyTest.kt')
check('Q-01 detail transition is exactly 170 ms', 'DETAIL_DURATION_MS = 170' in quiet and 'QuietNavigationPolicy.DETAIL_DURATION_MS' in navigation)
check('Q-01 subtle travel is exactly 12 dp', 'DETAIL_TRAVEL_DP = 12' in quiet and 'QuietNavigationPolicy.DETAIL_TRAVEL_DP.dp.roundToPx()' in navigation)
check('Q-02 no whole-screen fades', 'fadeIn(' not in navigation and 'fadeOut(' not in navigation and 'import androidx.compose.animation.fade' not in navigation)
check('Q-03 root tabs switch without animation', 'EnterTransition.None' in navigation and 'ExitTransition.None' in navigation and 'isMemoraPrimaryDestination()' in navigation)
check('Q-04 stable NavHost bounds', 'modifier = Modifier.fillMaxSize(),' in navigation and 'modifier = Modifier.fillMaxSize().then(if (showBottomNavigation)' not in navigation)
check('Q-05 every destination wrapped with opaque canvas', navigation.count('MemoraNavigationPage(') == 20 and navigation.count('composable(') == 19)
check('Q-06 themed opaque destination color', 'color = MaterialTheme.colorScheme.background' in navigation and 'modifier = Modifier.fillMaxSize().then(' in navigation)
check('Q-07 bottom bar waits for exiting details', 'visibleEntries.collectAsStateWithLifecycle()' in navigation and 'detailStillVisible' in navigation and 'QuietNavigationPolicy.showBottomBar(' in navigation)
check('Q-08 Topilma create treated as detail', 'topilmalarMode != "CREATE"' in quiet and 'isRootTab = entry.arguments?.getString("tab") != "CREATE"' in navigation)
check('Q-09 RTL reverses slide', 'val direction = if (settings.language.rtl) -1 else 1' in navigation)
check('Q-10 previous page remains stationary', 'exitTransition = { ExitTransition.None }' in navigation and 'popEnterTransition = { EnterTransition.None }' in navigation)
check('Q-11 coverage of navigation policy scenarios', all(n in quiet_test for n in ['primaryTabsSwitchWithoutMotion','detailsAndTopilmaCreationAlwaysUseMotion','chromeRemainsHiddenUntilDetailFullyLeaves']))
for file in (ROOT/'app/src').rglob('*.kt'):
    check(f'Kotlin delimiters: {file.name}',balanced(file.read_text(encoding='utf-8')))
for file in (ROOT/'app/src/main').rglob('*.xml'):
    try: ET.parse(file)
    except ET.ParseError as e: errors.append(f'XML: {file}: {e}')
    checks += 1
if errors:
    print(f'Memora 0.9.39 regression FAILED ({len(errors)}/{checks})')
    for error in errors: print(' -', error)
    sys.exit(1)
print(f'Memora 0.9.39 structural regression PASS ({checks} checks).')
