#!/usr/bin/env python3
"""Memora 0.9.40 offline source-contract regression (not an Android runtime test)."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
J = ROOT / 'app/src/main/java/com/memora/app'
checks = []

def read(path):
    p = ROOT / path
    assert p.exists(), f'Missing: {path}'
    return p.read_text(encoding='utf-8')

def assert_case(title, condition):
    checks.append((title,bool(condition)))

build = read('app/build.gradle.kts')
assert_case('Version 0.9.40', 'versionName = "0.9.40"' in build)
assert_case('VersionCode 61', 'versionCode = 61' in build)
assert_case('Application ID preserved', 'applicationId = "com.memora.app"' in build)
assert_case('Debug signing preserved', 'memora-test-debug.jks' in build)

entities = read('app/src/main/java/com/memora/app/data/local/Entities.kt')
database = read('app/src/main/java/com/memora/app/data/local/AppDatabase.kt')
daos = read('app/src/main/java/com/memora/app/data/local/Daos.kt')
for title, value in [
    ('New album entity', 'data class MemoryAlbumPhotoEntity'),
    ('New memory entity', 'data class MemoryRecallEventEntity'),
]:
    assert_case(title, value in entities and entities.count(value)==1)
assert_case('Room schema 9', 'version = 9' in database)
assert_case('8 to 9 migration', 'Migration(8, 9)' in database)
assert_case('Historical migrations intact', all(f'MIGRATION_{i}_{i+1}' in database for i in range(1,9)))
for table in ['memory_album_photos','memory_recall_events']:
    assert_case('New table '+table, f'CREATE TABLE IF NOT EXISTS `{table}`' in database)
    assert_case('DAO accesses '+table, table in daos)
assert_case('Old photos retained', 'TimeTracePhotoEntity::class' in database)
assert_case('Old Topilmalar retained for migration', 'TopilmaSourceEntity::class' in database)

app = read('app/src/main/java/com/memora/app/ui/MemoraApp.kt')
bar = read('app/src/main/java/com/memora/app/ui/components/MemoraBottomBar.kt')
assert_case('Calendar root tab', 'RootTab.CALENDAR' in app and 'Routes.CALENDAR_ROOT' in app)
assert_case('Calendar in bottom bar', 'onCalendar' in bar and 'CalendarMonth' in bar)
assert_case('New album screen used', 'MemoryAlbumScreen(' in app)
assert_case('Memory settings screen used', 'MemorySettingsScreen(' in app)
assert_case('Legacy Topilmalar route not mounted', 'composable(Routes.TOPILMALAR)' not in app)
assert_case('New data in home', 'onMemoryDismiss' in app and 'onMemoryLater' in app)
assert_case('Notification deep-link note', 'pendingMemoryNote' in app)
assert_case('Notification deep-link camera', 'pendingOpenAlbumCamera' in app)

album = read('app/src/main/java/com/memora/app/ui/screens/MemoryAlbumScreen.kt')
for word in ['ORIGINAL','WARM','VINTAGE','INSTANT','MONO']:
    assert_case('Album filter '+word, word in album)
assert_case('Uses CameraX', 'ProcessCameraProvider' in album and 'ImageCapture' in album)
assert_case('20 word caption', 'words(input) <= 20' in album)
assert_case('Cursive saved caption', 'FontFamily.Cursive' in album)
assert_case('Book pager', 'HorizontalPager' in album and 'rotationY' in album)
assert_case('Photo numbering', 'padStart(3' in album)
assert_case('Original photo kept reversible', 'albumFilter(effect)' in album)

rules=read('app/src/main/java/com/memora/app/memories/MemoryRecallPlanner.kt')
assert_case('Minimum seven days', 'minimumAgeDays: Long = 7' in rules)
assert_case('Old-first weighted selection', 'listOf(0,0,0,0,0,1,1,1,2,2)' in rules)
assert_case('Memoized daily selection seed', 'day.toEpochDay()' in rules)
assert_case('Original hour', 'local.hour, local.minute' in rules)
assert_case('Album min 135/180 gaps', 'count == 5) 135' in rules and 'count == 3) 180' in rules)

scheduler=read('app/src/main/java/com/memora/app/memories/MemoryScheduler.kt')
notification=read('app/src/main/java/com/memora/app/memories/MemoryNotificationReceiver.kt')
assert_case('Daily scheduling', 'NEXT_DAY' in scheduler)
assert_case('Best effort exact alarm', 'canScheduleExactAlarms()' in scheduler)
assert_case('30 day recall history', 'minusDays(30)' in scheduler)
assert_case('Two independent channels', 'NotificationChannels.MEMORIES' in notification and 'NotificationChannels.ALBUM' in notification)
for action in ['DISMISS_MEMORY','SNOOZE_MEMORY','DISMISS_ALBUM','SNOOZE_ALBUM']:
    assert_case('Notification action '+action, action in notification)
assert_case('Notes open directly', 'EXTRA_OPEN_NOTE' in notification)
assert_case('Camera opens directly', 'EXTRA_OPEN_ALBUM_CAMERA' in notification)
assert_case('Photo notification stops after saved photo', 'allMemoryAlbum()' in notification)
assert_case('All language localized action labels', 'MemoryText.get(language' in notification)

backups=read('app/src/main/java/com/memora/app/export/ExportManager.kt')
assert_case('New backup schema 7', 'put("schemaVersion", 7)' in backups)
assert_case('Album backed up', 'put("memoryAlbumPhotos"' in backups)
assert_case('Album zip content', 'memoryAlbumStorage.resolve(photo.relativePath)' in backups)
assert_case('Album restored', 'importPhoto(tmp)' in backups)
assert_case('Room backup in transaction', 'repository.withImportTransaction' in backups)
assert_case('Old Topilma backup preserved', 'TopilmalarBackupCodec.toJson' in backups)

editor=read('app/src/main/java/com/memora/app/ui/screens/EditorScreen.kt')
assert_case('Editor floating back', 'CircleShape' in editor and 'shadowElevation' in editor)
assert_case('Editor viewport preserves content', 'Spacer(Modifier.height(52.dp))' in editor)

prefs=read('app/src/main/java/com/memora/app/prefs/UserPreferences.kt')
for k in ['memoryEnabled', 'memoryDailyCount', 'albumReminderEnabled','albumReminderDailyCount','albumReminderRandom','albumReminderHour','albumReminderMinute']:
    assert_case('User preference '+k, k in prefs)

translations=read('app/src/main/java/com/memora/app/memories/MemoryText.kt')
for language in ['UZ','EN','RU','TR','FR','DE','ES','PT_BR','ID','HI','AR','JA','KO']:
    assert_case('Notification locale '+language, f'AppLanguage.{language} to listOf(' in translations)

passed=sum(good for _,good in checks)
for title,good in checks:
    if not good: print('FAIL',title)
print(f'Memora 0.9.40 source regression: {passed}/{len(checks)} passed')
if passed != len(checks):sys.exit(1)
