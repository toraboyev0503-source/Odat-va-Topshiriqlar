# Memora 0.9.39 — Quiet Navigation

## Purpose

Resolve the ghosted/overlapping page titles and flickering when entering and exiting screens shown in the supplied video, without changing the app's features or data.

## Changes

1. Root tabs (Home / Notes / Topilmalar / Settings) have **no enter or exit animation**.
2. On navigation into detail pages: new page slides only **12 dp** (RTL: opposite direction), over **170 ms**, at full opacity. Previous page is stationary.
3. Back from detail: outgoing page slides **12 dp** over **170 ms**; previous page stays still behind it.
4. All **19 navigation destinations** have their own **opaque MaterialTheme.background Surface**. During overlap the previous page cannot bleed through text.
5. NavHost now has stable full-size bounds. Root destinations reserve the 82 dp tab-bar area inside their page, instead of resizing the entire navigation viewport when switching root/detail.
6. The five-button bottom navigation is hidden while any detail destination remains visible (including its exit transition), and while the keyboard is shown.
7. Topilmalar CREATE is a detail destination despite sharing the Topilmalar route pattern.
8. Native Android reduced-animation preferences are respected by Compose animation scale.

## Compatibility

- `versionName=0.9.39`, `versionCode=60`.
- Existing `com.memora.app.debug` package identifier and bundled test keystore are unchanged.
- Room DB schema remains version 8; no migration required.
- No note/editor, Topilmalar, export, or subscription data model modifications.

## Manual acceptance tests on device (required)

- Home -> Notes -> Reader -> Back -> Notes -> Home: no headers appear on top of one another; no color flash; the bar does not float above a visible reader.
- Notes -> Reader -> Editor -> Back -> Reader -> Back -> Notes: same visual stability with quick repeated taps.
- Bottom tabs: instantaneous switch with no overlay of outgoing/incoming text.
- Keyboard in search: five-button bottom bar hidden; no blank 82 dp reserved area; returns when keyboard closes.
- Topilmalar -> CREATE and Back; Settings -> Language/Theme/Security and Back; dialogs and overlays unchanged.
- Repeat on all 5 palettes, light/dark, RTL, smallest/largest settings scale, and with reduced animation settings.

## Automated validation

- `python3 tools/regression_0939.py`: structural guards covering all screens and transitions.
- JUnit `QuietNavigationPolicyTest`: root/detail routes, Topilmalar CREATE, bottom-bar visibility and constants.
- Previous Topilmalar visual checks and backend Billing tests.
- GitHub Actions includes compile + unit tests + lint + APK build. Their result is **not established locally**.

**Note:** Static checks cannot prove frame-perfect transitions on a real phone; only a successful APK build followed by a device video check can verify this fully.
