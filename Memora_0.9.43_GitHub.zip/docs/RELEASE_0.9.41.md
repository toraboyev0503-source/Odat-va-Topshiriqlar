# Memora 0.9.41 — Full Canvas / F-01…F-08

## Functional behavior

The whole Reader and Editor **document** paints to the physical top of the Android screen. The opening header space is **inside** the document's scrollable Column; it disappears with the text on scroll. Controls float in an overlay that uses `statusBarsPadding()`, so they remain below the status icons without holding the scrolling text down.

- Reader uses one continuous canvas for title, created/edited dates, mixed text/media blocks, hashtags and footer actions; the old large body Surface was removed.
- Editor uses the same document logic for both short and long notes; the short-note Surface is removed. The keyboard and bottom tools remain usable.
- Floating Back is circular in both modes. Reader has Pencil and More. Editor has Done, which calls the **existing safe leave/save** action, not an independent bypass.
- When content moves **up** by at least 16dp, floating controls fade out over 140ms; on reverse movement by 16dp they fade in over 170ms. A single tap reveals them **without consuming pointer input**. Text editing selection/cursor taps continue to work.
- Reader→Editor passes a **one-time normalized scroll fraction**. Exact pixel-for-pixel position may differ because writing font metrics differ.
- Only these two routes bypass the top system-bar inset; all other navigation destinations retain safeDrawing insets. The NavHost itself stays full-screen and stable. Quiet Navigation remains 170ms/12dp.

## Validation

1. Reader: scroll until the title/body disappear at the physical top edge; the text should not stop below the status bar. Verify no rounded card or opaque white strip.
2. Editor (SHORT and LONG): repeat with IME hidden, then with the IME open. Tapping text must still position cursor; pressing Back/Done must not lose unsaved text.
3. Swipe content upward/downward past the gesture threshold and tap once to reveal controls. Check short flicks, rapid reverse, nested media blocks and long documents.
4. Reader→Editor should approximately preserve location. Reader, Editor, media playback, hashtags, share and deletion must still work.
5. Verify all existing palette variants, dark/light, RTL direction, different screen sizes, gesture navigation, Android system bars, and 80–150% interface scale.
6. On 0.9.40→0.9.41 updating, check existing notes, audio, images and Room 9 data preserved.

**Source-only preparation:** `tools/regression_0941.py` and pure Kotlin scroll tests can be run locally, but real Android compilation/visual verification must occur in the GitHub build and on a device.
