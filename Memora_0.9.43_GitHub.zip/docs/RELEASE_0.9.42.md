# Memora 0.9.42 — F-09–F-15 delivery notes

## Revisions relative to 0.9.41

- Separate `NotePaper` and `NoteDatesFooter` shared by the reading and writing screens; one scrolling document containing title, text, media, tags and footer timestamps.
- `NoteStatusBarEffect` + pure `NoteStatusBarPolicy` for status bar visibility. `hideAt=68dp`, `restoreAt=12dp` measured from the full-canvas document scroll offset. Original status bar inset uses the **ignoring-visibility** form so screen content and floating controls never reflow simply because the system bar hides.
- Reader/Editor titles use 34sp with 41sp line height. Editor's title-size animation removed.
- Passive saving-status text removed. Autosave, crash recovery, save-failed feedback, voice/media and notifications unchanged.

## Visual acceptance / device QA checklist

1. Open a short note and a long note; initially see system icons and floating control buttons; the paper starts below the controls.
2. Scroll document upward into the Android status region: bar and controls hide without a frame jump or text overlay. Scroll back toward the start: bar reappears once the heading is near the beginning.
3. Tap once while scrolled: floating controls appear without forcing the system bar back. In Editor the tap must still position the cursor correctly.
4. Check every palette and dark mode; both screens use the exact same paper surface and date footer.
5. Scroll to the very end of a long/media-rich note: dates appear after tags and media, inside the paper; when there has been no edit, no edited date is displayed.
6. With an open keyboard and software gestures, edit near the bottom of a very long note. Kursor remains visible; IME does not cover the editing tools. Verify Reader→Editor→Back returns to a sensible scroll position.
7. Test `Back`, Android system Back and navigation between reader/editor. The status bar is restored on other screens.
8. Simulate failed save: error notification remains visible; ordinary save status text does not show.

## Tests and limits

Source regression: `python3 tools/regression_0942.py`; pure Kotlin policy can be compiled using `kotlinc`. Backend tests: `(cd backend && npm test)`. Android unit tests and lint must run on GitHub or a machine with Android SDK. This release does **not** claim APK compilation or physical-device verification in the source preparation phase.

No database migration, note content conversion, package ID change, signing key replacement or backup schema change.
