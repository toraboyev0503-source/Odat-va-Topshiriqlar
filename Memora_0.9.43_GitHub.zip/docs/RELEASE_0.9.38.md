# Memora 0.9.38 — U-01…U-06 qarorlar bo'yicha release tekshiruvi

## Qamrov

| Qaror | O'zgarish | Kod joyi |
|---|---|---|
| U-01 | Tabda bir vaqtning o'zida ikki ekran xiralashmaydi; ichki sahifalarda nozik yo'nalishli o'tish | `ui/MemoraApp.kt` |
| U-02 | Joriy yil sanalar bo'yicha ochiq; avvalgi yil — bitta yopiq guruh, oy papkalari yo'q | `ui/screens/NotesHubScreen.kt`, `ui/screens/NotesArchivePolicy.kt` |
| U-03 | Material 3 to'liq tonal palitra, umumiy modal/dialog, kichik yangi qayd oynasi, ixcham qidiruv filtri, M3 sana oynasi, klaviaturada pastki menyuni berkitish | `ui/theme/MemoraTheme.kt`, `ui/components/MemoraOverlays.kt`, `ui/components/NewNoteSheet.kt`, `ui/screens/NotesHubScreen.kt`, `ui/MemoraApp.kt` |
| U-04 | Barcha 13 ta mavjud til uchun tanlanadigan kartalar | `ui/screens/LanguageScreen.kt`, `ui/components/MemoraSelectionCard.kt` |
| U-05 | Mavzu / palitra / shrift namunasi va masshtab | `ui/screens/ThemeScreen.kt` |
| U-06 | Ilova qulfi va qayta qulf muddati bir uslubdagi kartalarda | `ui/screens/SecurityScreen.kt` |

## Saqlangan moslik

- Android `applicationId`, debug keystore va `.debug` suffix o'zgarmadi; `versionName=0.9.38`, `versionCode=59`.
- Room bazasi version 8, ma'lumotlar modeli va DataStore kalitlari o'zgarmadi.
- Joriy yil arxivi faqat UI guruhlanishi; fayllar bazada yangi papkalarga ko'chirilmaydi.
- Saqlash/Topilmalar/billing/backendning 0.9.37 barqarorlik tuzatishlari qoldirildi.

## Lokal tekshiruv natijasi

- `tools/regression_0938.py`: 185 ta statik tekshiruv PASS.
- `tools/verify_topilma_card_0931.py` va `tools/verify_topilma_icons_0931.py`: PASS.
- `cd backend && npm test`: 5 / 5 PASS.
- `NotesArchivePolicy.kt` mustaqil Kotlin test: 3 / 3 holat PASS.
- YAML sintaksisi va arxiv yaxlitligi tekshirildi.

## GitHub/Qurilmada qoladigan tekshiruvlar

- Android SDK/Gradle bilan `testDebugUnitTest`, `lintDebug`, `assembleDebug`, `assembleDebugAndroidTest`.
- Real 0.9.37 debug APK ustidan yangilab o'rnatish, eski qaydlar, Topilmalar, media, tillar, palitralar va biometriya saqlanishi.
- Klaviatura (IME) ochilib/yopilishi, turli ekran hajmi, RTL, tizimning animatsiya sozlamasi, native sana/vaqt pickerlarida haqiqiy ranglar.
- Ixtiyoriy Android emulatorida tarixiy Room migratsiya testi.

**Statik kod tekshiruvi qurilmadagi vizual va funksional sifat kafolati emas.**
