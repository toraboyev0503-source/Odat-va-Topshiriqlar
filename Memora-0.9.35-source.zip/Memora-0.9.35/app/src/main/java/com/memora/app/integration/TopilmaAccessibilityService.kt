package com.memora.app.integration

import android.accessibilityservice.AccessibilityService
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.memora.app.prefs.TopilmaIntegrationPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class TopilmaAccessibilityService : AccessibilityService(), ClipboardManager.OnPrimaryClipChangedListener {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var clipboard: ClipboardManager
    private lateinit var prefs: TopilmaIntegrationPreferences
    private var activePackage: String? = null
    private var overlay: LinearLayout? = null
    private var lastText: String? = null
    private var lastSelection: String? = null
    private var lastAt: Long = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        prefs = TopilmaIntegrationPreferences(this)
        clipboard.addPrimaryClipChangedListener(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        val pkg = e.packageName?.toString()?.takeIf { it.isNotBlank() } ?: return
        if (pkg != packageName) activePackage = pkg
        if (e.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_SELECTION_CHANGED) {
            val full = e.text.firstOrNull()?.toString().orEmpty()
            val from = e.fromIndex.coerceAtLeast(0)
            val to = e.toIndex.coerceAtMost(full.length)
            if (from < to && to <= full.length) lastSelection = full.substring(from, to).trim().takeIf { it.isNotBlank() }
        }
    }

    override fun onInterrupt() = Unit

    override fun onPrimaryClipChanged() {
        if (!prefs.quickMonitorEnabled()) return
        val pkg = activePackage ?: return
        if (!prefs.isEnabled(pkg)) return
        val clip = clipboard.primaryClip
        val text = clip?.getItemAt(0)?.coerceToText(this)?.toString()?.trim().orEmpty().ifBlank { lastSelection.orEmpty() }
        if (text.isBlank()) return
        val now = System.currentTimeMillis()
        if (text == lastText && now - lastAt < 2500L) return
        lastText = text
        lastAt = now
        showSaveOverlay(text, pkg)
    }

    private fun showSaveOverlay(text: String, pkg: String) {
        removeOverlay()
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val density = resources.displayMetrics.density
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((18 * density).toInt(), (12 * density).toInt(), (18 * density).toInt(), (10 * density).toInt())
            setBackgroundColor(0xFFF7F8F8.toInt())
            elevation = 12 * density
        }
        val title = TextView(this).apply {
            setTextColor(0xFF1C2425.toInt())
            textSize = 16f
            setTypeface(typeface, Typeface.BOLD)
            this.text = "Topilmaga saqlansinmi?"
        }
        val preview = TextView(this).apply {
            setTextColor(0xFF5E686A.toInt())
            textSize = 13f
            maxLines = 2
            this.text = text
            setPadding(0, (4 * density).toInt(), 0, (8 * density).toInt())
        }
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
        val no = Button(this).apply { this.text = "Yo‘q"; setOnClickListener { removeOverlay() } }
        val yes = Button(this).apply {
            this.text = "Ha"
            setOnClickListener {
                isEnabled = false
                val root = rootInActiveWindow
                scope.launch {
                    val result = runCatching { TopilmaExternalCapture.save(applicationContext, text, pkg, root) }
                    withContext(Dispatchers.Main) {
                        removeOverlay()
                        if (result.isFailure) showTransientMessage("Topilmaga saqlanmadi")
                    }
                }
            }
        }
        actions.addView(no)
        actions.addView(yes)
        panel.addView(title)
        panel.addView(preview)
        panel.addView(actions)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM
        }
        runCatching { wm.addView(panel, params); overlay = panel }
    }

    private fun showTransientMessage(message: String) {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val density = resources.displayMetrics.density
        val view = TextView(this).apply {
            text = message
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xDD253638.toInt())
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding((18 * density).toInt(), (10 * density).toInt(), (18 * density).toInt(), (10 * density).toInt())
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = (80 * density).toInt() }
        runCatching {
            wm.addView(view, params)
            view.postDelayed({ runCatching { wm.removeView(view) } }, 1500L)
        }
    }

    private fun removeOverlay() {
        val current = overlay ?: return
        overlay = null
        runCatching { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(current) }
    }

    override fun onDestroy() {
        removeOverlay()
        if (::clipboard.isInitialized) clipboard.removePrimaryClipChangedListener(this)
        scope.cancel()
        super.onDestroy()
    }
}
