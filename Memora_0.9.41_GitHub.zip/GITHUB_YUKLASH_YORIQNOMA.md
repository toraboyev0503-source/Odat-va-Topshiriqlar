# Memora 0.9.41 — GitHub yuklash yo‘riqnomasi

**Hozircha hech narsa GitHub'ga yuklanmaydi.** Foydalanuvchi alohida buyruq berganidan keyingina ZIP va YAML GitHub'ga joylanadi.

1. `Memora_0.9.41_GitHub.zip` faylini repozitoriy ildiziga (root) arxiv sifatida joylang; uni GitHub ichida ochish shart emas.
2. Repozitoriydagi `.github/workflows/main.yml` ni hamroh `android-build_0.9.41.yml` mazmuni bilan almashtiring. Xuddi shu workflow ZIP ichida `.github/workflows/android-build.yml` nomi bilan mavjud; **ikkita bir xil workflow'ni bir vaqtda faol qilmang**.
3. `Actions` bo‘limida `Memora 0.9.41 Android Build` jarayonini oching. `Source regression`, `Billing backend`, `testDebugUnitTest`, `lintDebug`, `assembleDebug` bosqichlarini tekshiring.
4. Build muvaffaqiyatli tugasa `Memora-0.9.41-debug-apk` artefaktidan APK olinadi. So‘ng uni shu chatga taqdim etish mumkin.

Versiya: **0.9.41**, `versionCode 62`. Debug package va keystore avvalgi versiyalar bilan mos; Room v9 o‘zgarmaydi.
