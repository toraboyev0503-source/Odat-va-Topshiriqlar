# Home reflection content pack

Runtime files live in `app/src/main/assets/reflections/`.

The audited source workbook is `650_savol_13_til_audit.xlsx`. It contains 650 aligned items in 13 languages. Each runtime JSON file uses the same ids (`1..650`) and stores the two paragraphs as `p1` and `p2`.

Supported runtime asset tags:

- `uz` — O‘zbekcha
- `en` — English
- `ar` — العربية
- `fr` — Français
- `de` — Deutsch
- `hi` — हिन्दी
- `id` — Bahasa Indonesia
- `ja` — 日本語
- `ko` — 한국어
- `pt-BR` — Português (Brasil)
- `ru` — Русский
- `es` — Español
- `tr` — Türkçe

Run `python3 tools/validate_reflections.py` to verify that all 13 packs are present, non-empty and id-aligned before building.
