#!/usr/bin/env python3
from pathlib import Path
import json, re, sys, zipfile

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / 'app/src/main'
SRC = APP / 'java/com/memora/app'
failures=[]
checks=[]

def text(rel):
    p=ROOT/rel
    if not p.exists():
        failures.append(f'missing file: {rel}')
        return ''
    return p.read_text(encoding='utf-8', errors='replace')

def require(name, cond, detail=''):
    checks.append((name, bool(cond), detail))
    if not cond: failures.append(name + (f': {detail}' if detail else ''))

app=text('app/build.gradle.kts')
motion=text('app/src/main/java/com/memora/app/ui/theme/MemoraMotion.kt')
nav=text('app/src/main/java/com/memora/app/ui/MemoraApp.kt')
share=text('app/src/main/java/com/memora/app/share/ReaderShareManager.kt')
reader=text('app/src/main/java/com/memora/app/ui/screens/ReaderScreen.kt')
editor=text('app/src/main/java/com/memora/app/ui/screens/EditorScreen.kt')
export=text('app/src/main/java/com/memora/app/export/ExportManager.kt')
main=text('app/src/main/java/com/memora/app/MainActivity.kt')
time_export=text('app/src/main/java/com/memora/app/timetrace/TimeTraceVideoExporter.kt')
time_ui=text('app/src/main/java/com/memora/app/ui/screens/TimeTraceScreen.kt')
theme=text('app/src/main/java/com/memora/app/ui/theme/MemoraTheme.kt')
cal=text('app/src/main/java/com/memora/app/ui/screens/CalendarHubScreen.kt')
notes=text('app/src/main/java/com/memora/app/ui/screens/NotesScreen.kt')
search=text('app/src/main/java/com/memora/app/ui/screens/SearchScreen.kt')
stats=text('app/src/main/java/com/memora/app/ui/screens/StatisticsScreen.kt')
reflection=text('app/src/main/java/com/memora/app/reflections/HomeReflectionManager.kt')
media=text('app/src/main/java/com/memora/app/ui/components/MediaBlocks.kt')
export_dialog=text('app/src/main/java/com/memora/app/ui/components/ExportDialog.kt')
mood_model=text('app/src/main/java/com/memora/app/data/model/NoteMood.kt')
db=text('app/src/main/java/com/memora/app/data/local/AppDatabase.kt')

# release identity
require('versionName 0.9.20', 'versionName = "0.9.20"' in app)
require('versionCode >= 40', bool(re.search(r'versionCode\s*=\s*(4\d|[5-9]\d|\d{3,})', app)))

# 1 transition symmetry/no negative pop re-entry
require('back transition uses same positive enter direction', 'popEnterTransition' in nav and 'initialOffsetX = { width -> (width / 24).coerceAtLeast(1) }' in nav)
require('no negative pop enter offset', not re.search(r'popEnterTransition[\s\S]{0,300}initialOffsetX\s*=\s*\{[^}]*-\s*width', nav))

# 2 interactive motion ~30% faster, ambient unchanged
for token,val in [('Press',70),('Fast',100),('FastExit',90),('Standard',150),('StandardExit',120),('Dialog',110),('Snackbar',120),('Ambient',520)]:
    require(f'motion {token}={val}', bool(re.search(rf'const val {token}\s*=\s*{val}\b', motion)))

# 3-6 reader sharing
require('reader share Text/Image/HTML manager exists', all(x in share for x in ['shareText(', 'shareImages(', 'shareHtml(']))
require('reader opens share sheet', 'ModalBottomSheet' in reader and 'ReaderShareManager' in reader)
require('text share bold title', 'StyleSpan(Typeface.BOLD)' in share)
require('share image exact 1080x1350', 'val width = 1080' in share and 'val height = 1350' in share)
require('share image pagination', 'paginate(' in share and 'SEND_MULTIPLE' in share)
require('heavy share generation runs off main thread', 'suspend fun shareImages' in share and 'withContext(Dispatchers.IO)' in share)
require('share branding exact slogan', share.count('Har bir kuningizdan bir iz qoldiring.') >= 2)
require('share branding exact Memora icon', 'memora_brand_symbol_exact' in share)
require('HTML self-contained icon', 'data:image/png;base64' in share)

# 7 mood uses only app stickers/5 enum entries path
require('mood picker uses MoodSticker', 'MoodSticker' in editor and 'NoteMood.entries' in editor)
require('no raw emoji picker in editor', not any(e in editor for e in ['😄','🙂','😐','🙁','😞']))
require('exactly five Memora mood states', all(x in mood_model for x in ['GREAT(', 'GOOD(', 'NEUTRAL(', 'BAD(', 'VERY_BAD(']) and mood_model.count('NoteMood') >= 1)

# 8 image source bottom sheet
require('image Camera/Gallery bottom sheet', 'ModalBottomSheet' in editor and 'imageSourceDialog' in editor and 'TakePicture' in editor)

# 9 unified destructive confirmation
require('shared Memora confirmation component', (ROOT/'app/src/main/java/com/memora/app/ui/components/MemoraDialogs.kt').exists())
for rel in ['ui/screens/ReaderScreen.kt','ui/screens/NotesScreen.kt','ui/screens/NotesHubScreen.kt','ui/screens/EditorScreen.kt','ui/screens/TitlesScreen.kt','ui/screens/RemindersScreen.kt','ui/screens/TimeTraceScreen.kt']:
    s=text('app/src/main/java/com/memora/app/'+rel)
    require(f'confirmation used: {rel}', 'MemoraConfirmationDialog' in s)

# 10 export formats
require('HTML/Word/Backup export paths preserved', all(x in export for x in ['ExportFormat.WORD','ExportFormat.MULTIMEDIA','ExportFormat.BACKUP']))
require('export UI labels HTML', 'label = { Text("HTML") }' in export_dialog)
require('export UI exposes Word and Memora backup', 'ExportFormat.WORD' in export_dialog and 'ExportFormat.BACKUP' in export_dialog and 'S.APP_BACKUP' in export_dialog)

# 11 import preview before restore
require('backup preview API', 'suspend fun previewBackup' in export and 'data class ImportPreview' in export)
require('restore preview dialog', 'ImportPreviewDialog' in main and 'pendingImportPreview' in main)

# 12 permissions explanatory + settings
require('camera/mic permission explanations', 'MemoraPermissionDialog' in editor and 'Manifest.permission.CAMERA' in editor and 'Manifest.permission.RECORD_AUDIO' in editor)
require('editor settings recovery', 'Settings.ACTION_APPLICATION_DETAILS_SETTINGS' in editor)
require('Time Trace settings recovery', 'Settings.ACTION_APPLICATION_DETAILS_SETTINGS' in time_ui)

# 13 empty states
require('shared empty-state component', (ROOT/'app/src/main/java/com/memora/app/ui/components/MemoraEmptyState.kt').exists())
for label,s in [('Notes',notes),('Search',search),('Calendar',cal),('Statistics',stats),('Vaqt izi',time_ui)]:
    require(f'empty state: {label}', 'MemoraEmptyState' in s)

# 14 unified feedback
require('feedback component exists', (ROOT/'app/src/main/java/com/memora/app/ui/components/MemoraFeedback.kt').exists())
require('feedback kinds include loading/success/error/info', all(x in text('app/src/main/java/com/memora/app/ui/components/MemoraFeedback.kt') for x in ['LOADING','SUCCESS','ERROR','INFO']))
require('global feedback host', 'MemoraFeedbackHost' in main)

# 15 MP4 progress/cancel
require('video exporter reports progress', 'onProgress: (Int) -> Unit' in time_export and 'onProgress(100)' in time_export)
require('video exporter cancellation callback', 'isCancelled: () -> Boolean' in time_export)
require('Time Trace UI shows % and cancel', 'exportProgress' in time_ui and 'LinearProgressIndicator' in time_ui and 'exportCancelled' in time_ui)

# 16 dark slate/paper
require('dark slate palette', 'PaletteChoice.SLATE' in theme and 'isSystemInDarkTheme' in theme and '0xFF121719' in theme)
require('paper/slate theme choices present', 'PaletteChoice.PAPER' in theme and 'PaletteChoice.SLATE' in theme)

# 17 no purple selected color
require('Calendar/Notes no purple constants', not re.search(r'E9DDF8|9C27B0|7E57C2|6750A4|Purple', cal+notes, re.I))
require('selected chips use theme/slate/sage colors', 'calendarChipColors' in cal and 'MaterialTheme.colorScheme.primary' in cal)

# 18 no exception detail surfaced in app Kotlin
all_kt='\n'.join(p.read_text(encoding='utf-8',errors='replace') for p in SRC.rglob('*.kt'))
require('no exception.message exposed', not re.search(r'(exception|error|throwable|\bt\b)\.message', all_kt, re.I))

# 19 reflection pack integration
langs=['uz','en','ar','fr','de','hi','id','ja','ko','pt-BR','ru','es','tr']
valid_pack=True
for lang in langs:
    p=APP/'assets/reflections'/f'{lang}.json'
    if not p.exists(): valid_pack=False; failures.append(f'missing reflection language {lang}'); continue
    try: data=json.loads(p.read_text(encoding='utf-8'))
    except Exception as e: valid_pack=False; failures.append(f'invalid reflection json {lang}: {e}'); continue
    ids=[int(x.get('id',-1)) for x in data]
    if len(data)!=650 or ids!=list(range(1,651)) or any(not str(x.get('p1','')).strip() or not str(x.get('p2','')).strip() for x in data):
        valid_pack=False; failures.append(f'bad reflection pack {lang}')
require('reflection pack 13 x 650', valid_pack)
require('Home reflection daily max 6', 'maximumPerDay = 6' in reflection)
require('Home advances after seen', 'reflectionManager.markSeen(item.id)' in nav and 'reflectionManager.nextEligible(settings.language)' in nav)

# preserved high-risk features
require('autosave/recovery preserved', 'EditorRecoveryStore' in editor and (SRC/'recovery/EditorRecoveryStore.kt').exists())
require('audio Pause/Resume/Stop preserved', all(x in media for x in ['onPauseRecording','onResumeRecording','onStopRecording']))
require('image zoom preserved', any(k in media for k in ['transformable','detectTransformGestures','zoom']))
require('CameraX Time Trace preserved', 'androidx.camera.' in time_ui)
require('note date fields preserved', 'createdAt' in reader and 'createdAt' in export)
require('App Lock biometric preserved', 'BiometricPrompt' in main and 'BiometricManager' in main)
require('notifications preserved', (SRC/'notifications').exists())
require('search/calendar/statistics screens preserved', all((SRC/'ui/screens'/f).exists() for f in ['SearchScreen.kt','CalendarHubScreen.kt','StatisticsScreen.kt']))
require('Room migrations preserved', 'RoomDatabase' in db and 'Migration(' in db and 'addMigrations' in db)
require('billing/backend preserved', (SRC/'billing/SubscriptionManager.kt').exists() and (ROOT/'backend').exists())
require('stable debug signing/update path preserved', 'keystore/memora-test-debug.jks' in app and 'storeFile' in app)

# assets/docs that must ship
xlsx=ROOT/'docs/content/650_savol_13_til_audit.xlsx'
require('reflection audit xlsx ships', xlsx.exists())
if xlsx.exists():
    try:
        with zipfile.ZipFile(xlsx) as z: bad=z.testzip()
        require('reflection xlsx CRC valid', bad is None, str(bad))
    except Exception as e: require('reflection xlsx opens', False, str(e))

passed=sum(1 for _,ok,_ in checks if ok)
for name,ok,detail in checks:
    print(('OK  ' if ok else 'FAIL') + name + (f' — {detail}' if detail else ''))
print(f'\nRegression checks: {passed}/{len(checks)} passed')
if failures:
    print('\nFailures:')
    for f in failures: print(' -',f)
    sys.exit(1)
print('Memora 0.9.20 static regression audit PASSED')
