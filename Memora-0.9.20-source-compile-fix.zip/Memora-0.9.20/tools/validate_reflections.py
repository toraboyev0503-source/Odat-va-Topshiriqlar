#!/usr/bin/env python3
"""Validate Memora's 13-language Home reflection content pack."""
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PACK = ROOT / "app" / "src" / "main" / "assets" / "reflections"
TAGS = ["uz", "en", "ar", "fr", "de", "hi", "id", "ja", "ko", "pt-BR", "ru", "es", "tr"]
EXPECTED_COUNT = 650
EXPECTED_IDS = list(range(1, EXPECTED_COUNT + 1))


def load(tag: str) -> list[dict]:
    path = PACK / f"{tag}.json"
    if not path.is_file():
        raise SystemExit(f"Missing reflection pack: {path}")
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise SystemExit(f"Invalid JSON in {path}: {exc}") from exc
    if not isinstance(data, list):
        raise SystemExit(f"{path} must contain a JSON array")
    return data


def main() -> None:
    for tag in TAGS:
        data = load(tag)
        if len(data) != EXPECTED_COUNT:
            raise SystemExit(f"{tag}: expected {EXPECTED_COUNT} items, found {len(data)}")
        ids = []
        for index, item in enumerate(data, start=1):
            if not isinstance(item, dict):
                raise SystemExit(f"{tag} item {index}: object expected")
            item_id = item.get("id")
            p1 = item.get("p1")
            p2 = item.get("p2")
            if not isinstance(item_id, int):
                raise SystemExit(f"{tag} item {index}: integer id expected")
            if not isinstance(p1, str) or not p1.strip():
                raise SystemExit(f"{tag} item {item_id}: p1 is empty")
            if not isinstance(p2, str) or not p2.strip():
                raise SystemExit(f"{tag} item {item_id}: p2 is empty")
            ids.append(item_id)
        if ids != EXPECTED_IDS:
            raise SystemExit(f"{tag}: ids must be exactly 1..{EXPECTED_COUNT} in order")
        print(f"OK {tag}: {len(data)} items")

    print(f"Reflection pack valid: {len(TAGS)} languages x {EXPECTED_COUNT} items")


if __name__ == "__main__":
    main()
